﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
	public class OrdinalComparable : IComparable<OrdinalComparable>
	{
		private readonly Func<IComparable>[] m_ValueFunctions;
		private readonly bool[] m_IsValueCalculated;
		private readonly IComparable[] m_Value;

		private IComparable GetValueAt(int i)
		{
			if (!m_IsValueCalculated[i])
			{
				m_Value[i] = m_ValueFunctions[i]();
				m_IsValueCalculated[i] = true;
			}

			return m_Value[i];
		}

		public OrdinalComparable(params Func<IComparable>[] valueFunctions)
		{
			this.m_ValueFunctions = valueFunctions;
			this.m_IsValueCalculated = new bool[valueFunctions.Length];
			this.m_Value = new IComparable[valueFunctions.Length];
		}

		public int CompareTo(OrdinalComparable other)
		{
			for (int i = 0; i < m_ValueFunctions.Length; i++)
			{
				var value = GetValueAt(i);
				var otherValue = other.GetValueAt(i);
				var comparison = value.CompareTo(otherValue);
				if (comparison < 0)
					return -1;
				if (comparison > 0)
					return 1;
			}

			return 0;
		}
	}
}
