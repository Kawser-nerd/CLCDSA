﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam_TrainTimetable
{
    class csSolver
    {
        public static void Solve(csTestCase Case)
        {
            List<int> DepA = new List<int>();
            List<int> DepB = new List<int>();
            List<int> ArrA = new List<int>();
            List<int> ArrB = new List<int>();

            foreach (csTrip trip in Case.A)
            {
                DepA.Add(trip.Departure);
                ArrB.Add(trip.Arrival);
            }
            foreach (csTrip trip in Case.B)
            {
                DepB.Add(trip.Departure);
                ArrA.Add(trip.Arrival);
            }

            DepA.Sort();
            DepB.Sort();
            ArrA.Sort();
            ArrB.Sort();

            List<int> TrainsA = new List<int>();
            List<int> TrainsB = new List<int>();
            int SolA = 0, SolB = 0;

            //solve for A
            while (DepA.Count > 0)
            {
                //Train will arrive
                if (ArrA.Count > 0 && DepA[0] >= ArrA[0])
                {
                    TrainsA.Add(ArrA[0] + Case.TurnaroundTime);
                    ArrA.RemoveAt(0);
                }
                //train will leave
                else
                {
                    if (TrainsA.Count > 0 && TrainsA[0] <= DepA[0]) TrainsA.RemoveAt(0);
                    else SolA++;
                    DepA.RemoveAt(0);
                }
            }

            //solve for B
            while (DepB.Count > 0)
            {
                //Train will arrive
                if (ArrB.Count>0 && DepB[0] >= ArrB[0])
                {
                    TrainsB.Add(ArrB[0] + Case.TurnaroundTime);
                    ArrB.RemoveAt(0);
                }
                //train will leave
                else
                {
                    if (TrainsB.Count > 0 && TrainsB[0] <= DepB[0]) TrainsB.RemoveAt(0);
                    else SolB++;
                    DepB.RemoveAt(0);
                }
            }

            Case.SolA = SolA;
            Case.SolB = SolB;
        }
    }
}
