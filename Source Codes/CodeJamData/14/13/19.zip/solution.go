package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"math"
)

const (
	// SIMULTANEOUS_LIMIT describes the number of goroutines
	// that will work on the execution concurrently.
	// If >1, multicore processing will be enabled
	SIMULTANEOUS_LIMIT = 1

	//FILENAME, if unset or "" defaults to using console input;
	//if multi-line, FILENAME itself is used as input
	FILENAME = `C-small-attempt0.in`

	N = 1000
)

type TestCase struct {
	Number int //One-based index
	//int1   int
	//float1 float64
	//grid1  [][]int
	values [N]int
}

func (old TestCase) parseFrom(in Reader) (t TestCase) {
	t = old

	//in.GetInt(&t.choice1)
	//in.GetFloat(&t.floatVar)
	//in.GetIntGrid(&t.grid1, 4, 4)
	var n int
	in.GetInt(&n)
	for i := 0; i < N; i++ {
		in.GetInt(&t.values[i])
	}
	return t
}

func init() {
	d, err := ioutil.ReadFile("play/memo2.json")
	if err != nil {
		panic(err)
	}
	json.Unmarshal(d, &counts)
}

var counts [N][N]int
var avgCount int = 2000

func (c TestCase) solve() string {
	answer := ""
	totalProb := 0.0
	for k, v := range c.values {
		totalProb += math.Log(float64(counts[k][v]) / float64(avgCount))
	}

	if totalProb > 0 {
		answer = "BAD"
	} else {
		answer = "GOOD"
	}
	return fmt.Sprintf("Case #%d: %s", c.Number, answer)
}
