﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Gcj.Util;
using System.Linq;

namespace Gcj.Y2013.R2.B
{
    internal class BSolver : GcjSolver
    {
        protected override IEnumerable<object> EnobjSolveCase()
        {
            yield break;
        }

    }
}
