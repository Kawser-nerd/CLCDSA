﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class LessMoney : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            ProblemSet<LessMoney>.Solve(args);
        }
        #endregion

        public override void Parse(ProblemReader file)
        {
            file.Read(out C, out D, out V).Read(out denoms);
        }

        // ReSharper disable InconsistentNaming
        private int C, D;
        private long V;
        private long[] denoms;
        // ReSharper restore InconsistentNaming

        public override object Solve()
        {
            var added = 0;
            var tally = 0L;
            for (var i = 0; i < denoms.Length; i++)
            {
                while (tally+1 < denoms[i])
                {
                    added ++;
                    tally += C*(tally + 1);
                }
                tally += C*denoms[i];
            }
            while (tally < V)
            {
                added++;
                tally = C * (tally + 1) + tally;
            }
            return added;
        }

        public override IEnumerable<Action> StaticInitialize()
        {
            yield return () =>
            {

            };
        }
    }
}
