﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Utils.Infrastructure;

namespace ProblemA {
    public class Problem : IProblem {
        IProblemReader reader;
        IProblemWriter writer;
        public Problem() {
        }
        public void Initialize(IProblemReader reader, IProblemWriter writer) {
            this.reader = reader;
            this.writer = writer;
        }
        public IProblemSolver GetNextProblemSolver() {
            ProblemSolver solver = new ProblemSolver();
            solver.N = reader.ReadInt();
            solver.Points = reader.ReadArray<int>(solver.N, () => reader.ReadInt());
            return solver;
        }

        public int GetProblemsCount() {
            return reader.ReadInt();
        }
    }
}
