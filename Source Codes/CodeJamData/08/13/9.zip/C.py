from math import *
import sys


if __name__ == "__main__":
    ifi = file(sys.argv[1])

    line = ifi.readline()
    N = int(line)
    for tests in xrange(1, N+1):
        print "Case #%d:" % tests,

        Q = int(ifi.readline())

        q = log(3.0 + sqrt(5.0)) * Q
        e = int(floor(exp(q))) % 1000


        print "%d%d%d" % ( 
                e / 100,
                (e / 10) % 10,
                e % 10) 



