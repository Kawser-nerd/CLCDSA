package lib;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;

public class PermutationWithRepetition {

    public static <T> Stream<List<T>> of(Collection<T> items, Comparator<T> comparator) {
        List<T> initial = new ArrayList<>(items);
        initial.sort(comparator);
        return createStreamByStepper(initial, current -> {
            List<T> copy = new ArrayList<>(current);
            boolean success = NextPermutation.step(copy, comparator);
            return success ? Optional.of(copy) : Optional.empty();
        });
    }

    private static <T> Stream<T> createStreamByStepper(T initial, Function<T, Optional<T>> stepper) {
        return StreamFromIterable.get(() -> new Iterator<T>() {
            @SuppressWarnings("OptionalUsedAsFieldOrParameterType")
            Optional<T> next = Optional.of(initial);

            @Override
            public boolean hasNext() {
                return next.isPresent();
            }

            @Override
            public T next() {
                T current = next.orElseThrow(Assertion.FAIL);
                next = stepper.apply(current);
                return current;
            }
        });
    }

}
