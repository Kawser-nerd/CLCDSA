import java.io.PrintStream;
import java.math.BigInteger;
import java.util.Scanner;
import java.util.function.Supplier;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import java.util.stream.Stream;

public class RevengeOfThePancakes {
    static void run() {
        String s = rdLine();
        int res = solve(s);
        wrVal(res);
    }

    private static int solve(String s) {
        int step = 0;
        for (;;) {
            int k = tailPluses(s);
            if (k == 0) return step;

            int r = k;
            while (r > 0 && s.charAt(r - 1) == '-') --r;

            int q = 0;
            while (q < s.length() && s.charAt(q) == '-') ++q;

            int f = q > 0 ? q : r;
            s = flip(s, f);

            ++step;
        }
    }

    private static int tailPluses(String p) {
        int k = p.length();
        while (k > 0 && p.charAt(k - 1) == '+') --k;
        return k;
    }

    private static String flip(String t, int k) {
        char[] cs = t.toCharArray();
        for (int j = 0; j < k; ++j) {
            char c = t.charAt(k - 1 - j);
            cs[j] = c == '+' ? '-' : '+';
        }
        String r = new String(cs);
        return r;
    }

    public static void main(String[] args) {
        int n = rdInt();
        for (int i = 0; i < n; ++i) {
            output.print("Case #" + (i + 1) + ":");
            outputSep = " ";
            run();
            output.print("\n");
        }
        output.flush();
    }

    static Scanner input = new Scanner(System.in);
    static int rdInt() { return rdT(() -> input.nextInt()); }
    static long rdLong() { return rdT(() -> input.nextLong()); }
    static double rdDbl() { return rdT(() -> input.nextDouble()); }
    static BigInteger rdBigInt() { return rdT(() -> input.nextBigInteger()); }
    static String rdStr() { return rdT(() -> input.next()); }
    static String rdLine() { return input.nextLine(); }
    static String[] rdStrs(int n) { return Stream.generate(() -> rdStr()).limit(n).toArray(x -> new String[x]); }
    static int[] rdInts(int n) { return IntStream.generate(() -> rdInt()).limit(n).toArray(); }
    static long[] rdLongs(int n) { return LongStream.generate(() -> rdLong()).limit(n).toArray(); }
    static double[] rdDbls(int n) { return DoubleStream.generate(() -> rdDbl()).limit(n).toArray(); }
    private static <T> T rdT(Supplier<T> supplier) { T t = supplier.get(); input.skip(" |\n|\r\n"); return t; }

    static PrintStream output = new PrintStream(System.out, true);
    static String outputSep = " ";
    static void wrVal(String v) { wrT(v); }
    static void wrVal(int v) { wrT(v); }
    static void wrVal(long v) { wrT(v); }
    static void wrVal(BigInteger v) { wrT(v); }
    static void wrVal(double v) { wrVal(v, 10); }
    static void wrVal(double v, int fracdigs) { wrT(String.format("%." + fracdigs + "f", v)); }
    static void wrVals(int[] vs) { for (int v : vs) wrVal(v); }
    static void wrVals(long[] vs) { for (long v : vs) wrVal(v); }
    static void wrVals(double[] vs) { for (double v : vs) wrVal(v); }
    static void wrVals(double[] vs, int fracdigs) { for (double v : vs) wrVal(v, fracdigs); }
    static void wrVals(String[] vs) { for (String v : vs) wrVal(v); }
    static void wrLn() { output.print("\n"); outputSep = ""; }
    private static void wrT(Object v) { output.print(outputSep); output.print(v); outputSep = " "; }
}
