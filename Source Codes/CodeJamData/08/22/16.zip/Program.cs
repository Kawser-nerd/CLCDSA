using System;
using System.Collections.Generic;
using System.Text;

namespace tc1
{
    class Program
    {
        static void Main(string[] args)
        {
            (new Problem()).Solve(Runner.TestLines, Console.Out);
            Runner.Run();
        }
    }
}
