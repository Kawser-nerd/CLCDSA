﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskA
{
	public class Permuter
	{
		public long GetBest (int[] v1, int[] v2)
		{
			v1= v1.OrderBy (v => v).ToArray ();
			v2 = v2.OrderByDescending (v => v).ToArray ();

			long res= 0;
			for (int i = 0; i < v1.Length; ++i)
				res += v1[i] * v2[i];

			return res;
		}
	}
}
