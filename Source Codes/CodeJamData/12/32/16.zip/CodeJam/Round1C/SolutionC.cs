﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CodeJam.Round1C
{
    internal class SolutionC : ISolution
    {
        private string _problemData;
        private int _problemIndex;

        public int GetProblem(int problemIndex, int startIndex, string[] data)
        {
            _problemIndex = problemIndex;
            _problemData = data[startIndex];
            return startIndex + 1;
        }

        public Result ProcessProblem()
        {
            string result = "";
            return new Result()
                       {
                           Output = result,
                           ProblemIndex = _problemIndex
                       };
        }
    }
}
