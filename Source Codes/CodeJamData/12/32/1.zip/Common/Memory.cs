﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Generic.Common
{
    public class Memory<T> where T : class
    {
        readonly Func<T> func;
        T cache;

        public Memory(Func<T> func)
        {
            this.func = func;
        }

        public T Value
        {
            get { return cache ?? (cache = func()); }
        }

        public Func<U> Select<U>(Func<T,U> uFunc)
        {
            return cache == null ? () => uFunc(func()) : (Func<U>)(() => uFunc(cache));
        }
    }
}
