﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace codejam
{
    class MainClass
    {

        public static void Main(string[] args)
        {
            ml.tell(DateTime.Now.ToLongTimeString());
            long tick = DateTime.Now.Ticks;
            MyApp mp = new MyApp((args.Length > 0) ? args[0] : "");

            mp.Run();

            ml.tell(DateTime.Now.ToLongTimeString());
            long t = ((DateTime.Now.Ticks - tick) / 10000000L);

            ml.tell((t / 60).ToString() + " minuts and " + (t % 60).ToString() + " seconds");

#if DEBUG
            Console.ReadLine();
#endif
        }
    }

    public partial class MyApp
    {
        string iFile;

        public MyApp(string f)
        {
            if (f == "")
            {
                DirectoryInfo di = new DirectoryInfo("./");
                FileInfo[] fi = di.GetFiles("*.in");

                DateTime last = DateTime.MinValue;
                foreach (FileInfo a in fi)
                {
                    if (a.CreationTime > last)
                    {
                        last = a.CreationTime;
                        f = a.Name;
                    }
                }
            }
            else
                if (!f.EndsWith(".in"))
                    f += ".in";

            ml.tell("Opening input file " + f);

            iFile = f;
        }

        public void Run()
        {
            RunOnce();

            StreamReader sr = new StreamReader(iFile);
            myStreamWriter sw = new myStreamWriter(iFile.Replace(".in", ".out"), true);
            int N = ml.toi(sr.ReadLine());
            N = N + 0;

            for (int i = 1; !sr.EndOfStream; i++)
            {
                sw = sw + "Case #" + i + ": " + Resolver(sr) + sw.nl;
            }

            sw.Close();
            sr.Close();
        }

        
    }
}
