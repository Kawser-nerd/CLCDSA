import random

def badPermute(n):
	s = range(n)
	for x in range(n):
		r=random.randint(0,n-1)
		s[x],s[r] = s[r],s[x]
	return s

def many(num, n):
	return [badPermute(n) for _ in range(num)]

def understand(l):
	N = len (l[0])
	sums = [[0,]*N for _ in range(N)] #for each place, for each num, count
	for l1 in l:
		for x in range(N):
			sums[x][l1[x]] += 1
	return sums
