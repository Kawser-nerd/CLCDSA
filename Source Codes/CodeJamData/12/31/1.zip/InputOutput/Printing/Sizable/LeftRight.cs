﻿using Generic.InputOutput.Printing.Sized;

namespace Generic.InputOutput.Printing.Sizable
{
    internal class LeftRight : Document
    {
        private readonly Document left;
        private readonly Document right;

        public LeftRight(Document left, Document right)
        {
            this.left = left; this.right = right;
        }

        internal override int GetMinimumWidth()
        {
            return left.GetMinimumWidth() + right.GetMinimumWidth();
        }

        internal override SizedDocument GetSizedDocument(int? preferredWidth)
        {
            var rightMinimum = right.MinimumWidth;
            var leftPrinting = left.GetSizedDocument(preferredWidth - rightMinimum);
            var rightPrinting = right.GetSizedDocument(preferredWidth - leftPrinting.Size.X);
            return leftPrinting + rightPrinting;
        }
    }
}