using System.IO;
using CodeJamLibrary.Interfaces;

namespace CodeJamLibrary.Providers
{
  public class ChangeExtensiontodotOut_FilePathProviderDecorator : IFilePathProvider
  {
    private readonly IFilePathProvider filePathProvider;

    public ChangeExtensiontodotOut_FilePathProviderDecorator(
      IFilePathProvider filePathProvider)
    {
      this.filePathProvider = filePathProvider;
    }

    public string GetFilePath()
    {
      string path = filePathProvider.GetFilePath();
      return Path.ChangeExtension(path, ".out");
    }
  }
}