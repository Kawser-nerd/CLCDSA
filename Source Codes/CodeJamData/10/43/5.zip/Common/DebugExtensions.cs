﻿/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeJam
{
    static class DebugExtensions
    {
        static TextWriter debugWriter = Console.Error;

        public static void Debug(string format, params object[] args)
        {
            Debug(String.Format(format, args));
        }

        public static string Debug(string s)
        {
            debugWriter.WriteLine(s);
            debugWriter.Flush();
            return s;
        }

        public static IEnumerable<T> Debug<T>(this IEnumerable<T> collection)
        {
            var lines = collection.Select(o => o.ToString());
            int totalSize = lines.Sum(l => l.Length);
            if (totalSize > 100)
            {
                Debug("Collection {0}x{1}:", collection.Count(), typeof(T).Name);
                foreach (object o in lines)
                    Debug("    " + o.ToString());
            }
            else
                Debug("[" + String.Join(", ", lines) + "]");
            return collection;
        }

    }
}
