﻿using System;
using System.Collections;
using System.Collections.Generic;
using CodeJamLibrary;
using CodeJamLibrary.Interfaces;

namespace Problems
{
  public class ProblemD : ProblemTemplate
  {
    public class Circle
    {
      public int X { get; set; }
      public int Y { get; set; }
      public int R { get; set; }

      public Circle(int x, int y, int r)
      {
        X = x;
        Y = y;
        R = r;
      }

      public double Dist(Circle other)
      {
        double dist = 0;
        dist = Math.Sqrt(
          Math.Pow(this.X - other.X, 2) +
          Math.Pow(this.Y - other.Y, 2));
        dist += this.R + other.R;

        var tr = Math.Max(this.R, other.R);
        if (dist < tr * 2)
          return tr*2;

        return dist;
      }
    }

    protected override string Solve(IProblemInput problemInput)
    {
      int C = problemInput.ParseInt()[0];

      var circles = new ArrayList();

      for (int i = 0; i < C; i++)
      {
        var b = problemInput.ParseInt();
        circles.Add(new Circle(b[0], b[1], b[2]));
      }

      List<Circle> group1 = new List<Circle>();
      List<Circle> group2 = new List<Circle>();

            double dist1 = 0;
            double dist2 = 0;

      double dist = 0;
      while (true)
      {
        if (circles.Count == 0)
        {
          dist = Math.Max(dist1, dist2);
          break;
        }


        if(circles.Count == 1)
        {
          var circleA = (Circle)circles[0];

          if (group1.Count == 0)
          {
            dist = circleA.R*2;
            break;
          }

          double d1 = 0;
          double d2 = 0;
          foreach (var list in group1)
          {
            var ti = (circleA).Dist(list);
            if (ti > d1)
              d1 = ti;

          }

          foreach (var list in group2)
          {
            var ti = (circleA).Dist(list);
            if (ti > d2)
              d2 = ti;
          }

          if(d1 < d2)
          {
            dist1 = Math.Max(dist1, d1);
          }
          else
          {
            dist2 = Math.Max(dist2, d2);
          }

          dist = Math.Max(dist1, dist2);
          break;
        }



        int ai = 0;
        int aj = 0;
        dist = 0;

        for (int i = 0; i < circles.Count; i++)
        {
          for (int j = 0; j < circles.Count; j++)
          {
            if (i == j)
              continue;

            var tdist = ((Circle) circles[i]).Dist((Circle) circles[j]);

            if (tdist > dist)
            {
              dist = tdist;
              ai = i;
              aj = j;
            }
          }
        }

        double d1i = 0;
        double d2i = 0;
        double d1j = 0;
        double d2j = 0;

        var circleAi = (Circle) circles[ai];
        var circleAj = (Circle)circles[aj];

        foreach (var list in group1)
        {
          var ti = (circleAi).Dist(list);
          if (ti > d1i)
            d1i = ti;

          var tj = (circleAj).Dist(list);
          if (tj > d1j)
            d1j = tj;
        }

        foreach (var list in group2)
        {
          var ti = (circleAi).Dist(list);
          if (ti > d2i)
            d2i = ti;

          var tj = (circleAj).Dist(list);
          if (tj > d2j)
            d2j = tj;
        }

        var op1i2j = Math.Max(d1i, d2j);
        var op2i1j = Math.Max(d2i, d1j);

//        var check = Math.Min(op1i2j, op2iij);
//        if (check > dist)
//        {
//          dist = check;
//          break;
//        }

        if (op1i2j < op2i1j)
        {
          group1.Add(circleAi);
          group2.Add(circleAj);

          dist1 = Math.Max(dist1, d1i);
          dist2 = Math.Max(dist2, d2j);

        }
        else
        {
          group1.Add(circleAj);
          group2.Add(circleAi);

          dist1 = Math.Max(dist1, d1j);
          dist2 = Math.Max(dist2, d2i);
        }

        if(group1.Count == 1)
        {
          dist1 = 2*group1[0].R;
        }
        if (group2.Count == 1)
        {
          dist2 = 2*group2[0].R;
        }

        if( (dist1 > dist) || (dist2 > dist))
        {
          dist = Math.Max(dist1, dist2);
          break;
        }


        circles.Remove(circleAi);
        circles.Remove(circleAj);

      }


      return (dist/2).ToString("0.000000");
    }
  }
}