namespace CodeJamLibrary.Interfaces
{
  public interface IProblemExecution
  {
    void Execute();
  }
}