﻿/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace CodeJam
{
    class A : ParallelSolution
    {
        override public Func<String> StartSolving()
        {
            int N = ReadInt();
            var lines = ReadLines(N * 2 - 1);
            
            return () =>
                {
                    int[,] diamond = new int[N, N];
                    for(int i=0;i<N;i++)
                        for(int j=0;j<N;j++)
                            diamond[i,j] = lines[i+j][j-i+N-1]-'0';

                    for (int newSize = N; newSize < N * 4; newSize++)
                    {
                        for (int x0 = 0; x0 <= newSize - N; x0++)
                            for (int y0 = 0; y0 <= newSize - N; y0++)
                            {
                                bool bad = false;
                                for (int x = 0; x < N; x++)
                                    for (int y = 0; y < N; y++)
                                    {
                                        int newX = x0 + x;
                                        int newY = y0 + y;

                                        Func<int, int, bool> check = (xx, yy) =>
                                        {
                                            var origX = xx - x0;
                                            var origY = yy - y0;
                                            if (origX < 0 || origY < 0 || origX >= N || origY >= N)
                                                return true;
                                            return diamond[x, y] == diamond[origX, origY];
                                        };

                                        if (!(check(newY, newX) && check(newSize - newX - 1, newSize - newY - 1) && check(newSize - newY - 1, newSize - newX - 1)))
                                            bad = true;
                                    }
                                if (!bad)
                                    return (newSize * newSize - N * N).ToString();
                            }
                    }
                    throw new Exception("wtf?");
                };
        }
    }
}
