﻿namespace Generic.InputOutput.Printing.Sizable
{
    public interface IPrintable
    {
        Document Print();
    }
}