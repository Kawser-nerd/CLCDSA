/**
 * 
 */
package gepa.gcj.main.result;

import gepa.gcj.main.ParseException;
import gepa.gcj.main.Result;

/**
 * @author gepa
 *
 */
public class SResult extends SingleLineResult {

    private String value;

    public SResult(String value) {
        this.value = value;
    }

    @Override
    public String getAsString() {
        return value;
    }

    @Override
    public void parseSingle(String data) throws ParseException {
        value = data;
    }

    @Override
    public boolean isSameAs(Result expected) {
        if (!(expected instanceof SResult)) {
            return false;
        }
        SResult o = (SResult)expected;
        return value.equals(o.value);
    }
}
