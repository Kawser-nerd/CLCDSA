﻿using System.Collections.Generic;
using System.Linq;

namespace CodeJam2011.Problems
{
    public class ProblemA : ProblemBase
    {
        protected override string SolveOneCase(InputHelper input)
        {
            int X = input.GetInt();
            int S = input.GetInt();
            int R = input.GetInt();
            int t = input.GetInt();
            int N = input.GetInt();

            int walkways = 0;

            // speed, dist
            var dict = new SortedDictionary<int, int>();

            for (int i = 0; i < N; i++)
            {
                int B = input.GetInt();
                int E = input.GetInt();
                int w = input.GetInt();

                int speed = S + w;

                if( !dict.ContainsKey(speed))
                {
                    dict.Add(speed, 0);
                }

                dict[speed] += E - B;
                walkways += E - B;
            }

            int normal = X - walkways;

            dict.Add(S, normal);

            double time = 0;
            double runRemain = t;

            while( dict.Count > 0)
            {
                var speed = dict.Keys.First();
                var dist = dict[speed];



                if( runRemain * (speed + R-S) > dist )
                {
                    var ttime = ((double) dist)/(speed + R-S);
                    runRemain -= ttime;
                    time += ttime;
                    dict.Remove(speed);
                    
                }


                else
                {
                    var cdist = runRemain*(speed + R-S);
                    var dleft = dist - cdist;

                    time += runRemain + ((double) dleft)/speed;

                    dict.Remove(speed);

                    break;
                }


            }


            foreach (var key in dict.Keys)
            {
                time += ((double)dict[key]) / (key);
            }



            return time.ToString();
        }
    }
}