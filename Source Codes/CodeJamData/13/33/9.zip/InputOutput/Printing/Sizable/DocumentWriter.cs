﻿using System;
using System.Collections.Generic;
using Generic.Containers.Collections.List;

namespace Generic.InputOutput.Printing.Sizable
{
    public class DocumentWriter
    {
        readonly Stack<int> indentations = new Stack<int>();
        readonly Stack<Document> documents = new Stack<Document>(ListUtil.New(Document.Empty));
        Document currentLine = Document.Empty;

        public DocumentWriter Write(char text)
        {
            return Write(text.ToString());
        }

        Document Done { get { return documents.Peek(); } set { documents.Pop(); documents.Push(value); } }
        public DocumentWriter Write(String text)
        {
            return Write(text.Print());
        }

        public DocumentWriter Write(Document text)
        {
            currentLine += text;
            return this;
        }

        public DocumentWriter WriteLine(String text)
        {
            return WriteLine(text.Print());
        }

        public DocumentWriter WriteLine(Document text)
        {
            Write(text);
            WriteLine();
            return this;
        }

        public Document ToDocument()
        {
            return Done ^ currentLine;
        }

        public DocumentWriter WriteLine()
        {
            Done ^= currentLine;
            currentLine = Document.Empty;
            return this;
        }

        public void StartBlock(int indent)
        {
            WriteLine();
            documents.Push(Document.Empty);
            indentations.Push(indent);
        }

        public void EndBlock()
        {
            WriteLine();
            var block = documents.Pop().Indent(indentations.Pop());
            Done ^= block;
        }

        public override string ToString()
        {
            return ToDocument().ToString();
        }
    }
}
