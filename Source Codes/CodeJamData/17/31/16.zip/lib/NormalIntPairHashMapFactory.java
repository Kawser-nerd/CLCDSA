package lib;

public class NormalIntPairHashMapFactory {
    public static final MapFactory<IntPair> INSTANCE = CustomHashMapFactory.create(NormalIntPairHashMapMaterial.INSTANCE);

}
