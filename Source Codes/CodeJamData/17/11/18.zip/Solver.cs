﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Text.RegularExpressions;

namespace Q1
{
	public class Solver : SolverBase
	{
		public const string INPUT_NAME = "big";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = true;
		public const bool PRINT_EVERY_RESULT = true;

		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		public override object SolveTestCase(int testCase)
		{
			var size = GetIntList();
			var rows = size[0];
			var columns = size[1];
			var board = new char[rows][];
			var letters = new HashSet<char>();

			var letMinC = new Dictionary<char, int>();
			var letMaxC = new Dictionary<char, int>();
			var letMinR = new Dictionary<char, int>();
			var letMaxR = new Dictionary<char, int>();

			for (int r = 0; r < rows; r++)
			{
				var line = GetLine();
				board[r] = new char[columns];
				for (int c = 0; c < columns; c++)
				{
					var l = line[c];
					board[r][c] = l;
					if (l != '?')
						letters.Add(l);
					letMinC[l] = Math.Min(c, letMinC.GetOrDefault(l, int.MaxValue));
					letMaxC[l] = Math.Max(c, letMaxC.GetOrDefault(l, int.MinValue));
					letMinR[l] = Math.Min(r, letMinR.GetOrDefault(l, int.MaxValue));
					letMaxR[l] = Math.Max(r, letMaxR.GetOrDefault(l, int.MinValue));
				}
			}

			for (int r = 0; r < rows; r++)
			{
				if (board[r].All(c => c == '?'))
					continue;
				var firstNonQ = board[r].Select((x, i) => new Tuple<char, int>(x, i)).First(t => t.Item1 != '?').Item2;
				var lastSeen = board[r][firstNonQ];
				for (int c = 0; c < columns; c++)
				{
					if (board[r][c] == '?')
						board[r][c] = lastSeen;
					else
						lastSeen = board[r][c];
				}
			}

			for (int r = 0; r < rows; r++)
			{
				if (board[r].All(c => c == '?'))
				{
					int switchR = -1;
					for (int rr = r + 1; rr < rows; rr++)
					{
						if (board[rr].First() != '?')
						{
							switchR = rr;
							break;
						}
					}
					if (switchR == -1)
					{
						for (int rr = r - 1; rr >= 0; rr--)
						{
							if (board[rr].First() != '?')
							{
								switchR = rr;
								break;
							}
						}
					}

					CopyRow(board, switchR, r);
				}
			}

			return Stringify(board);
		}

		private string Stringify(char[][] board)
		{
			return string.Join("\n", board.Select(x => string.Join("", x)));
		}

		private void CopyRow(char[][] board, int from, int to)
		{
			for (int c = 0; c < board[from].Length; c++)
			{
				board[to][c] = board[from][c];
			}
		}
	}
}
