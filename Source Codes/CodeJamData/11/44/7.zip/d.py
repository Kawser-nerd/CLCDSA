import time, math, operator, itertools
from helper import *

t1 = starttimer()

filename = "D%s.%s"
# 0 for test, 1 for small, 2 for large
is_large = 1

mode_str = '' if is_large == 0 else '-small-attempt1' if is_large == 1 else '-large'
infile = filename % (mode_str, 'in')
outfile = filename % (mode_str, 'out')

# parse input
inf = open(infile, 'r')
outf = open(outfile, 'w')

cache = {}
def solve(P, edges):
    big = 1e10
    # (node name, distance from node 0, visited, paths to)
    nodes = [[i, big, False, None] for i in range(P)]

    nodes[0][1] = 0
    nodes[0][3] = [[]]
    node = nodes[0]

    while True:
        node[2] = True
        
        for i in edges.get(node[0], ()):
            if nodes[i][2] == True: continue

            tmp = node[1] + 1
            if tmp < nodes[i][1]:
                paths = []
                for ix in range(len(node[3])):
                    x = node[3][ix][:]
                    x.append(node[0])
                    paths.append(x)
                nodes[i][3] = paths
                
                nodes[i][1] = tmp
            elif tmp == nodes[i][1]:
                paths = []
                for ix in range(len(node[3])):
                    x = node[3][ix][:]
                    x.append(node[0])
                    paths.append(x)
                nodes[i][3].extend(paths)
                pass
            
        # find next node
        c = big
        for i in range(P):
            if nodes[i][2] == False and nodes[i][1] < c:
                node = nodes[i]
                c = node[1]

        if c == big:
            break

    return nodes[1]

try:
    T = readI(inf)
    
    for case in range(1, T+1):
        P, W = readIA(inf)
        w = map(lambda x: tuple(map(int, x.split(','))), readSA(inf))

        edges = {}
        for tm0, tm1 in w:
            if tm0 not in edges:
                edges[tm0] = [tm1]
            else:
                edges[tm0].append(tm1)
                
            if tm1 not in edges:
                edges[tm1] = [tm0]
            else:
                edges[tm1].append(tm0)
                
        tmp = solve(P, edges)
        out1 = len(tmp[3][0]) - 1
        out2 = 0
        for i in range(len(tmp[3])):
            threatened = reduce(lambda x, y: x|set(y), [edges.get(x, []) for x in tmp[3][i]], set())
            threatened -= set(tmp[3][i])
            
            out2 = max(out2, len(threatened))

        print out1, out2
        outf.write("Case #%d: %d %d\n" % (case, out1, out2))
    
finally:
    inf.close()
    outf.close()

endtimer(t1)
