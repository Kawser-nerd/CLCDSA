/**
 * 
 */
package gepa.gcj.main;


/**
 * @author gepa
 *
 */
public abstract class Result implements Cloneable {

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
    public abstract boolean isSingleLine();
    public abstract String[] getAsStringArray();
    public abstract void parse(String[] data) throws ParseException;
    public abstract boolean isSameAs(Result expected);

}
