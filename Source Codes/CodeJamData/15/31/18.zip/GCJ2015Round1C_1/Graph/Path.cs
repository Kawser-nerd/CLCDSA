﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCJ2015Round1C_1
{
	public class Path<T>
		where T : IComparable<T>
	{
		#region Fields

		private List<Node<T>> m_Nodes = new List<Node<T>>();
		private List<Edge<T>> m_Edges = new List<Edge<T>>();

		#endregion

		#region Public Properties

		public IEnumerable<Node<T>> Nodes
		{
			get
			{
				return m_Nodes;
			}
		}

		public IEnumerable<Edge<T>> Edges
		{
			get
			{
				return m_Edges;
			}
		}

		#endregion

		#region C'tor

		public Path()
		{
		}

		#endregion

		#region Public Methods

		public void ConcatToPath(Node<T> node)
		{
			if (!m_Nodes.Any())
			{
				m_Nodes.Add(node);
				return;
			}

			Node<T> last = m_Nodes.Last();
			Edge<T> edge = last.GetEdge(node);
			if (edge == null)
			{
				throw new ArgumentException("Node cannot be concated to path because it is not connected to the last node in the path!", "node");
			}

			m_Nodes.Add(node);
			m_Edges.Add(edge);
		}

		public void ConcatToPath(Edge<T> edge)
		{
			if (!m_Nodes.Any())
			{
				m_Nodes.Add(edge.Source);
				m_Nodes.Add(edge.Target);
				m_Edges.Add(edge);
				return;
			}

			Node<T> last = m_Nodes.Last();
			if (edge.Target != last && edge.Source != last)
			{
				throw new ArgumentException("Node cannot be concated to path because it is not connected to the last node in the path!", "node");
			}
			Node<T> other = edge.Target == last ? edge.Source : edge.Target;

			m_Nodes.Add(other);
			m_Edges.Add(edge);
		}

		public void ConcatToPath(Path<T> path)
		{
			if (!path.m_Nodes.Any())
			{
				return;
			}

			if (!m_Nodes.Any())
			{
				m_Nodes.AddRange(path.m_Nodes);
				m_Edges.AddRange(path.m_Edges);
				return;
			}

			Node<T> last = m_Nodes.Last();
			Node<T> first = path.m_Nodes.First();
			Edge<T> edge = last.GetEdge(first);
			if (edge == null)
			{
				throw new ArgumentException("Path cannot be concated to path because it is not connected to the last node in the path!", "node");
			}

			m_Edges.Add(edge);
			m_Edges.AddRange(path.m_Edges);
			m_Nodes.AddRange(path.m_Nodes);
		}

		public Path<T> Clone()
		{
			Path<T> clone = new Path<T>();
			clone.ConcatToPath(this);
			return clone;
		}

		#endregion
	}
}
