﻿﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace b
{
    class Program
    {
        static void Main(string[] args)
        {

            StreamReader sr = new StreamReader(args[0]);
            StreamWriter sw = new StreamWriter(args[1]);

            int N = int.Parse(sr.ReadLine());
            for (int ii = 1; ii <= N; ii++)
            {
                string[] ln = sr.ReadLine().Split(new Char[] { ' ' });
                int A = int.Parse(ln[0]);
                int B = int.Parse(ln[1]);
                int P = int.Parse(ln[2]);

                bool[] isp = new bool[1001];
                isp[0] = isp[1] = false;
                for (int i = 2; i < 1001; i++)
                {
                    isp[i] = true;
                    for (int j = 2; j * j <= i; j++)
                    {
                        if ((i / j) * j == i)
                        {
                            isp[i] = false;
                            break;
                        }
                    }
                }

                int[] set = new int[1001];
                for (int i = 0; i < 1001; i++) set[i] = i;

                bool again = true;
                while (again)
                {
                    again = false;
                    for(int i=A; i<=B; i++)
                        for (int j = i + 1; j <= B; j++)
                        {
                            if(set[i] != set[j])
                            for(int k=P; k<=i; k++)
                                if (isp[k] && (i / k) * k == i && (j / k) * k == j)
                                {
                                    int g = set[j];
                                    for (int q = A; q <= B; q++)
                                        if (set[q] == g) set[q] = set[i];
                                    again = true;
                                }
                        }
                }

                int[] nn = new int[1001];
                for (int i = A; i <= B; i++) nn[set[i]]++;

                int rv = 0;
                for (int i = 0; i < 1001; i++) if (nn[i] > 0) rv++;

                sw.WriteLine("Case #" + ii + ": " + rv);
            }

            sr.Close();
            sw.Close();
        }
    }
}
