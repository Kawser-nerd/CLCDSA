﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using Generic.Common;
using Generic.Containers.Collections.List;
using Generic.Containers.Collections.Set;
using Generic.InputOutput.Printing.Sizable;
using Generic.InputOutput.Printing.Sized;

namespace Generic.InputOutput.Printing
{
    public static class DocumentUtil
    {
        public static readonly Document LeftParens = "(";
        public static readonly Document RightParens = ")";
        public static readonly Document LeftBrace = "{";
        public static readonly Document RightBrace = "}";
        public static readonly Document Semi = ";";
        public static readonly Document LeftBracket = "[";
        public static readonly Document RightBracket = "]";
        public static readonly Document Colon = ":";

        public static Document Print(this string text)
        {
            return new WrappedDocument(new Text(text));
        }
         
        public static Document Print(IEnumerable list)
        {
            return list.Cast<object>().Select<object, Document>(Print).Seperated(", ").InParens();
        }

        public static Document Print(this double dbl)
        {
            return dbl.ToString("F3",CultureInfo.InvariantCulture);
        }

        public static Document Print(this object obj)
        {
            return GenericPrint(obj, new HashSet<object>(new PointerEqualityComparer()));
        }

        public static Document InParens(this Document document)
        {
            return LeftParens + document + RightParens;
        }

        public static Document InBraces(this Document document)
        {
            return LeftBrace + document + RightBrace;
        }


        public static Document InBrackets(this Document document)
        {
            return LeftBracket + document + RightBracket;
        }

        public static Document Seperated<T, U>(this IEnumerable<T> docs, U seperator)
        {
            return docs.Aggregate(Document.Empty, 
                (current, doc) => current.Concat(Print(seperator), Print(doc)));
        }

        public static Document HorizontalConcat(this IEnumerable<object> docs)
        {
            return docs.Aggregate(Document.Empty, (current, doc) => current + doc.Print());
        }

        public static Document VerticalConcat(this IEnumerable<object> docs)
        {
            return docs.Aggregate(Document.Empty, (current, doc) => current ^ doc.Print());
        }

        public static Document Parameters<T>(this IEnumerable<T> arguments)
        {
            return Seperated(arguments, ",").InParens();
        }

        public static Document Wrap<T>(this IList<T> objects)
        {
            return new WrappedList(objects.SelectList(obj => Print(obj)));
        }

        static DocumentUtil()
        {
            AddTypePrinter<object>((closed,obj) =>
            {
                if (!closed.Add(obj))
                    return "closed";

                var type = obj.GetType();
                Document document = type.Name;
                foreach (var field in type.GetProperties(BindingFlags.Instance | BindingFlags.Public)
                    .Where(prop => prop.GetIndexParameters().Length == 0))
                {
                    document = document ^ (field.Name + Colon - GenericPrint(field.GetValue(obj, null), closed));
                }
                closed.Remove(obj);
                return document;
            });
            AddTypePrinter<double>((_, p) => p.Print());
            AddTypePrinter<string>((_, p) => p);
            AddTypePrinter<int>((_, p) => p.ToString(CultureInfo.InvariantCulture));
            AddTypePrinter<char>((_, p) => p.ToString(CultureInfo.InvariantCulture));
            AddTypePrinter<bool>((_, p) => p.ToString(CultureInfo.InvariantCulture));
            AddTypePrinter<IPrintable>((_, p) => p.Print());
            AddTypePrinter<IEnumerable<bool>>((closed, enumerable) => Print(enumerable.Select(elem => elem.Print())));
            AddTypePrinter<IEnumerable<object>>((closed, enumerable) => Print(enumerable.Select(elem => GenericPrint(elem, closed)).ToList()));
            AddTypePrinter<IEnumerable<int>>((closed, enumerable) => Print(enumerable.Select(elem => Print(elem)).ToList()));
            AddTypePrinter<IList<Document>>((_,list) =>
            {
                Document commaSep = ", ";
                var documents = list.Count == 0 ? Document.Empty : Wrap(list.TakeList(list.Count - 1).SelectList(elem => (Print(elem) + commaSep))
                    .ConcatList(Print(list[list.Count - 1]).Singleton()));
                return documents.InParens();
            });
        }

        static void AddTypePrinter<T>(Func<ISet<object>,T,Document> printer)
        {
            typePrinters.Add(typeof(T), (c,p) => printer(c,(T)p));
        }

        static readonly IDictionary<Type, Func<ISet<object>, object, Document>> typePrinters = new Dictionary<Type, Func<ISet<object>, object, Document>>();

        static Document GenericPrint(object obj, ISet<object> closed)
        {
            if (obj == null)
                return "null";

            var type = obj.GetType();

            if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Tuple<,>))
            {
                var item1 = type.GetProperty("Item1");
                var item2 = type.GetProperty("Item2");
                return (GenericPrint(item1.GetValue(obj,null), closed) + Document.Comma - GenericPrint(item2.GetValue(obj,null), closed)).InParens();
            }

            if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Tuple<,,>))
            {
                var item1 = type.GetProperty("Item1");
                var item2 = type.GetProperty("Item2");
                var item3 = type.GetProperty("Item3");
                return (GenericPrint(item1.GetValue(obj, null), closed) + 
                    Document.Comma - GenericPrint(item2.GetValue(obj, null), closed) +
                    Document.Comma - GenericPrint(item3.GetValue(obj, null),closed)).InParens();
            }

            var validPrinters = typePrinters.Keys.Where(k => k.IsAssignableFrom(type)).ToHashSet();
            var rootPrinters = validPrinters.Where(t => !validPrinters.Any(u => t != u && t.IsAssignableFrom(u))).ToList();
            if (rootPrinters.Count > 1)
                throw new InvalidOperationException(("Ambiguous type printer of type" - type.Print()
                    ^ "type options were" ^ rootPrinters.VerticalConcat()).ToString());
            return typePrinters[rootPrinters.First()](closed,obj);
        }
    }
}
