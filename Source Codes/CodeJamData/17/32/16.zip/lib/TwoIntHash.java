package lib;

public class TwoIntHash {
    public static int hash(int h1, int h2) {
        return Int64Hash.hash((((long) h1) << 32) | h2);
    }
}
