package lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.concurrent.atomic.AtomicInteger;

public class CodeJamLauncher {

    public static void run(String inputFileName, CodeJamCaseSolver caseSolver) {
        AtomicInteger next = new AtomicInteger(1);
        Input input = new Input(NormalTokenizerFactory.INSTANCE.apply(openInputFile(inputFileName)));
        int caseNumber = input.nextInt();
        System.setOut(MergedPrintStream.of(System.out, openOutputFile()));
        Repeat.run(caseNumber, () -> caseSolver.solve(title(next.getAndIncrement()), input));
    }

    private static InputStream openInputFile(String inputFileName) {
        try {
            return new FileInputStream(new File(getDesktopDir(), inputFileName));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private static PrintStream openOutputFile() {
        try {
            return new PrintStream(new File(getDesktopDir(), "output.txt"));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private static String getDesktopDir() {
        return System.getProperty("user.home") + "/Desktop";
    }

    private static String title(int index) {
        return String.format("Case #%d: ", index);
    }

}
