﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoogleCodeJam.Common
{
	public class InputFile
	{
		private StreamReader m_Reader;

		public InputFile(String path)
		{
			m_Reader = new StreamReader(path);
		}

		public int[] ReadIntArray()
		{
			string line = m_Reader.ReadLine();
			string[] values = line.Split(new string[] {" "}, StringSplitOptions.RemoveEmptyEntries);
			return values.Select(s => Int32.Parse(s)).ToArray();
		}

		public decimal[] ReadDecimalArray()
		{
			string line = m_Reader.ReadLine();
			string[] values = line.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
			return values.Select(s => Decimal.Parse(s)).ToArray();
		}

		public double[] ReadDoubleArray()
		{
			string line = m_Reader.ReadLine();
			string[] values = line.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
			return values.Select(s => Double.Parse(s)).ToArray();
		}

		public IEnumerable<string> ReadLines(int count)
		{
			for (int i = 0; i < count; i++)
				yield return m_Reader.ReadLine();
		}

		public string ReadLine()
		{
			return m_Reader.ReadLine();
		}
	}
}
