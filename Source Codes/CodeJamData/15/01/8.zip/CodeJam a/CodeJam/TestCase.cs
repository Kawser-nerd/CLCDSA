/* www.codertom.com  -  copyright Tom Harrison 2015 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace CoderTom.CodeJam
{
    public class TestCase
    {
        public TestCase()
        {
        }

        public TestCase(StreamReader stream)
        {
            var lx = stream.ReadStringArray();
            ShynessLevelsCounts = lx[1];
        }

        public string ShynessLevelsCounts { get; set; }

        public string Solve()
        {
            var extraFriends = 0;
            var audienceSoFar = 0;
            var shynessLevel = 0;

            foreach (var item in ShynessLevelsCounts)
            {
                if (audienceSoFar < shynessLevel)
                {
                    var extraFriendsNeeded = shynessLevel - audienceSoFar;
                    extraFriends += extraFriendsNeeded;
                    audienceSoFar = shynessLevel;
                }

                var countAtThisLevel = int.Parse(item.ToString());
                audienceSoFar += countAtThisLevel;
                shynessLevel++;
            }

            return extraFriends.ToString();
        }

    }
}
