using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;

namespace Cmn.Util
{
    public static partial class U
    {
        public static T Binsearch<T>(Func<T,bool> fCheck, T tStart, T tStepFirst, T tPrecision, Func<T,T,T> add, Func<T,double,T> mul, Func<T,T,T,bool> fOk)
        {
            var tLow = tStart;
            var fLow = fCheck(tLow);
            var tStep = tStepFirst;

            T tHigh;
            for(;;)
            {
                var t = add(tLow, tStep);

                if(fLow == fCheck(t))
                {
                    tLow = t;
                    tStep = mul(tStep, 2);
                }
                else
                {
                    tHigh = t;
                    break;
                }
            }

            Debug.Assert(add(tLow,tStep).Equals(tHigh));

            for(;;)
            {
                tStep = mul(tStep, 0.5);
                var t = add(tLow, tStep);

                if(fOk(tLow,tHigh,tPrecision))
                    return t;

                if(fLow == fCheck(t))
                    tLow = t;
                else
                    tHigh = t;
            }
        }

        public static decimal BinsearchDecimal(Func<decimal,bool> fCheck, decimal tStart, decimal tStepFirst, decimal tPrecision)
        {
            return Binsearch(fCheck, tStart, tStepFirst, tPrecision, (arg1, arg2) => arg1 + arg2, (arg1, d) => arg1 * (decimal) d, (arg1, arg2, arg3) => Math.Abs(arg1 - arg2) < arg3);
        }

        public static double BinsearchDouble(Func<double,bool> fCheck, double tStart, double tStepFirst, double tPrecision)
        {
            return Binsearch(fCheck, tStart, tStepFirst, tPrecision, (arg1, arg2) => arg1 + arg2, (arg1, d) => arg1 * d, (arg1, arg2, arg3) => Math.Abs(arg1 - arg2) < arg3);
        }

        public static T Max<T>(T v1, T v2) where T : IComparable<T>
        {
            return v1.CompareTo(v2) < 0 ? v2 : v1;
        }

        public static T Min<T>(T v1, T v2) where T : IComparable<T>
        {
            return v1.CompareTo(v2) < 0 ? v1 : v2;
        }

        public static Tuple<T, T> TupleIntersect<T>(Tuple<T, T> rng1, Tuple<T, T> rng2) where T : IComparable<T>
        {
            return new Tuple<T, T>(Max(rng1.Item1, rng2.Item1) , Min(rng1.Item2, rng2.Item2));
        }

        public static void Swap<T>(ref T v1, ref T v2)
        {
            var v = v1;
            v1 = v2;
            v2 = v;
        }

        public static string StFormat(this string stFormat, params object[] args)
        {
            return String.Format(stFormat, args);
        }

        public static string StJoin<T>(this IEnumerable<T> enumerable, string separator, Func<T, string> valueSelector)
        {
            return String.Join(separator, enumerable.Select(valueSelector).ToArray());
        }

        public static string StJoin(this IEnumerable<string> enst, char chSep)
        {
            return String.Join(chSep.ToString(CultureInfo.InvariantCulture), enst.ToArray());
        }

        public static string StJoin(this IEnumerable<string> enst, string stSep)
        {
            return String.Join(stSep, enst.ToArray());
        }

        public static bool FIn<T>(this object obj, params T[] rgobj)
        {
            return rgobj.Any(objT => objT.Equals(obj));
        }
        public static TValue EnsureGet<TKey,TValue>(this IDictionary<TKey, TValue> mp, TKey key) where TValue : new ()
        {
            return mp.EnsureGet(key, () => new TValue());
        }

        public static TValue EnsureGet<TKey,TValue>(this IDictionary<TKey, TValue> mp, TKey key, Func<TValue> valueCreator)
        {
            TValue value;
            if (mp.TryGetValue(key, out value))
                return value;

            value = valueCreator();
            mp.Add(key,value);
            
            return value;
        }

        public static TValue GetOrDefault<TKey,TValue>(this IDictionary<TKey, TValue> mp, TKey key, TValue valueDefault)
        {
            TValue value;
            return mp.TryGetValue(key, out value) ? value : valueDefault;
        }
    }
}