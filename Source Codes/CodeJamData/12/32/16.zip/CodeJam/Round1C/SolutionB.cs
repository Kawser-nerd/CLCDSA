﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CodeJam.Round1C
{
    internal class SolutionB : ISolution
    {
        private double[] carPositions;
        private double[] carTimes;

        private double[] gravities;

        private double distance;

        private int _problemIndex;

        public int GetProblem(int problemIndex, int startIndex, string[] data)
        {
            _problemIndex = problemIndex;

            string[] firstLine = data[startIndex++].Split(' ');
            distance = double.Parse(firstLine[0]);
            int carPositionCount = int.Parse(firstLine[1]);
            int gravitiesCount = int.Parse(firstLine[2]);

            carPositions = new double[carPositionCount];
            carTimes = new double[carPositionCount];
            gravities = new double[gravitiesCount];

            for (int i = 0; i < carPositionCount; i++)
            {
                string[] positionLine = data[startIndex++].Split(' ');
                carTimes[i] = double.Parse(positionLine[0]);
                carPositions[i] = double.Parse(positionLine[1]);
            }

            gravities = data[startIndex++].Split(' ').Select(double.Parse).ToArray();
                
            return startIndex;
        }

        public Result ProcessProblem()
        {
            var result = new StringBuilder();
            double minimumTime = 0;

            //Find when the car passes the finish line
            for (int i = 0; i < carPositions.Count(); i++)
            {
                if(carPositions[i] == distance)
                {
                    minimumTime = carTimes[i];
                } else if((i + 1) < carPositions.Count() && carPositions[i] < distance && carPositions[i + 1] > distance)
                {
                    double distanceToTravel = distance - carPositions[i];
                    double totalDistance = carPositions[i + 1] - carPositions[i];
                    double totalTime = carTimes[i + 1] - carTimes[i];
                    double fraction = distanceToTravel/totalDistance;
                    minimumTime = carTimes[i] + (fraction * totalTime);
                }
            }

            for (int i = 0; i < gravities.Count(); i++)
            {
                double timeTaken = Math.Sqrt(distance / (0.5*gravities[i]));
                if(timeTaken < minimumTime)
                {
                    timeTaken = minimumTime;
                }

                result.AppendLine(timeTaken.ToString());
            }

                return new Result()
                               {
                                   Output = result.ToString(),
                                   ProblemIndex = _problemIndex
                               };
        }
    }
}
