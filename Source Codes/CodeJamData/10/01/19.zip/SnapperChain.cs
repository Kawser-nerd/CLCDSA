﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Marius.CodeJam
{
    public class SnapperChain: IParalelSolver
    {
        private ulong N, K;

        public void ReadInput()
        {
            var data = Console.ReadLine().Split().Select(s => ulong.Parse(s)).ToArray();
            N = data[0];
            K = data[1];
        }

        public void WriteAnswer(int caseNumber)
        {
            Console.WriteLine("Case #{0}: {1}", caseNumber, ((K & (SpecialShift(N))) == SpecialShift(N) ? "ON" : "OFF"));
        }

        private ulong SpecialShift(ulong N)
        {
            return (1U << (int)(N)) - 1;
        }

        public void SolveAsync()
        {
        }
    }
}
