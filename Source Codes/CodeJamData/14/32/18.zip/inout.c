/********************************** INCLUDES **********************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>

#include "inout.h"


/******************************* PRIVATE MACROS *******************************/
//#define DBG_ENABLE

#ifdef DBG_ENABLE
#define DBG_PRINTF(...)      printf(__VA_ARGS__)
#else
#define DBG_PRINTF(...)      do{}while(0);
#endif


/******************************** PRIVATE TYPES *******************************/


/*********************** PRIVATE FUNCTIONS DECLARATIONS ***********************/


/*********************** PRIVATE (GLBL) DATA DEFINITIONS **********************/


/*************************** PUBLIC DATA DEFINITIONS **************************/


/************************ PRIVATE FUNCTIONS DEFINITIONS ***********************/


/************************* PUBLIC FUNCTION DEFINITIONS ************************/
/*========
 * Read a number from input file to an integer
 *
 * Range of valid integer: from -2147483648 to 2147483647
 */
int readNumStrFromFileToInt(FILE* inFile, int* num)
{
    int read;
    int isReadingInt = 0;
    int isNegNum = 0;
    int tmpNum = 0;
    
    while (!feof(inFile))
    {
        read = fgetc(inFile);

        if (isdigit(read))
        {
            isReadingInt = 1;
//            DBG_PRINTF("read = %d tmpNum = %d\n",read, tmpNum);
            tmpNum = tmpNum*10 + (read - '0');
        }
        else if (read == '-')
        {
            isReadingInt = 1;
            isNegNum = 1;
        }
        else
        {
            if (isReadingInt)
            {
                break;
            }
        }
    }
    
//    DBG_PRINTF("tmpNum = %d\n",tmpNum);
    if (isReadingInt == 0)
        return 0;
    else
    {
        *num = (isNegNum)? tmpNum*(-1) : tmpNum;
//        DBG_PRINTF("%d\n",*num);
        return 1;
    }
}

/*========
 * Read a number from input file to an unsigned integer
 *
 * Range of valid unsigned integer: from 0 to 4294967295
 */
int readNumStrFromFileToUInt(FILE* inFile, unsigned int* num)
{
    int read;
    int isReadingInt = 0;
    unsigned int tmpNum = 0;
    
    while (!feof(inFile))
    {
        read = fgetc(inFile);

        if (isdigit(read))
        {
            isReadingInt = 1;
//            DBG_PRINTF("read = %d tmpNum = %u\n",read, tmpNum);
            tmpNum = tmpNum*10 + (read - '0');
        }
        else
        {
            if (isReadingInt)
            {
                break;
            }
        }
    }
    
//    DBG_PRINTF("tmpNum = %u\n",tmpNum);
    if (isReadingInt == 0)
        return 0;
    else
    {
        *num = tmpNum;
//        DBG_PRINTF("%u\n",*num);
        return 1;
    }
}

/*========
 * Read a number from input file to a long long integer
 *
 * Range of valid integer: from --9223372036854775808 to 9223372036854775807
 */
int readNumStrFromFileToLongLong(FILE* inFile, long long* num)
{
    int read;
    int isReadingInt = 0;
    int isNegNum = 0;
    long long tmpNum = 0;
    
    while (!feof(inFile))
    {
        read = fgetc(inFile);

        if (isdigit(read))
        {
            isReadingInt = 1;
//            DBG_PRINTF("read = %d tmpNum = %lld\n",read, tmpNum);
            tmpNum = tmpNum*10 + (read - '0');
        }
        else if (read == '-')
        {
            isReadingInt = 1;
            isNegNum = 1;
        }
        else
        {
            if (isReadingInt)
            {
                break;
            }
        }
    }
    
//    DBG_PRINTF("tmpNum = %lld\n",tmpNum);
    if (isReadingInt == 0)
        return 0;
    else
    {
        *num = (isNegNum)? tmpNum*(-1) : tmpNum;
//        DBG_PRINTF("%lld\n",*num);
        return 1;
    }
}

/*========
 * Read a number from input file to a unsigned long long integer
 *
 * Range of valid unsigned integer: from 0 to 18446744073709551615
 */
int readNumStrFromFileToULongLong(FILE* inFile, unsigned long long* num)
{
    int read;
    int isReadingInt = 0;
    unsigned long long tmpNum = 0;
    
    while (!feof(inFile))
    {
        read = fgetc(inFile);

        if (isdigit(read))
        {
            isReadingInt = 1;
//            DBG_PRINTF("read = %d tmpNum = %llu\n",read, tmpNum);
            tmpNum = tmpNum*10 + (read - '0');
        }
        else
        {
            if (isReadingInt)
            {
                break;
            }
        }
    }
    
//    DBG_PRINTF("tmpNum = %llu\n",tmpNum);
    if (isReadingInt == 0)
        return 0;
    else
    {
        *num = tmpNum;
//        DBG_PRINTF("%llu\n",*num);
        return 1;
    }
}

/*========
 * Read a number from input file to a double
 *
 * Range of valid double: from (-)2.22507e-308 to (-)1.79769e+308
 *
 * Remark: double number calucalation seems introducing errors and the resultant
 *         number may not with the same value as the one written in file
 */
int readNumStrFromFileToDouble(FILE* inFile, double* num)
{
    int read;
    int isReadingInt = 0;
    int isNegNum = 0;
    int isAfterDecPoint = 0;
    double tmpNum = 0.0;
    
    while (!feof(inFile))
    {
        read = fgetc(inFile);

        if (isdigit(read))
        {
            isReadingInt = 1;
            DBG_PRINTF("read = %d tmpNum = %f\n",read, tmpNum);
            if (isAfterDecPoint)
            {
                tmpNum += (read - '0')/(pow(10.0, isAfterDecPoint++));
            }
            else
                tmpNum = tmpNum*10.0 + (read - '0');
        }
        else if (read == '-')
        {
            isReadingInt = 1;
            isNegNum = 1;
        }
        else if (read == '.')
        {
            isReadingInt = 1;
            isAfterDecPoint = 1;
        }
        else
        {
            if (isReadingInt)
            {
                break;
            }
        }
    }
    
//    DBG_PRINTF("tmpNum = %f\n",tmpNum);
    if (isReadingInt == 0)
        return 0;
    else
    {
        *num = (isNegNum)? tmpNum*(-1) : tmpNum;
//        DBG_PRINTF("%f\n",*num);
        return 1;
    }
}

/*========
 * Read a number from input file to a character array
 *
 * Note: the buffer length must include a space for the last NULL pointer
 */
int readNumStrFromFileToCharArray(FILE* inFile, char* buffer, int len)
{
    int read;
    int isReading = 0;
    int index = 0;
    
    while (!feof(inFile) && index < len)
    {
        read = fgetc(inFile);

        if (isalpha(read))
        {
            isReading = 1;
//            DBG_PRINTF("read = %d\n",read);
            buffer[index++] = read;
        }
        else
        {
            if (isReading)
            {
                break;
            }
        }
    }
    
    if (isReading == 0)
        return 0;
    else
    {
        buffer[index] = 0;
//        DBG_PRINTF("buffer = %s\n",buffer);
        return 1;
    }
}

void outputCaseIntResult(FILE* outFile, int caseNum, int result)
{
    fprintf(outFile, "Case #%d: %d\n", caseNum, result);
    fflush(outFile);
}

void outputCaseUIntResult(FILE* outFile, int caseNum, unsigned int result)
{
    fprintf(outFile, "Case #%d: %u\n", caseNum, result);
    fflush(outFile);
}

void outputCaseLongLongResult(FILE* outFile, int caseNum, long long result)
{
    fprintf(outFile, "Case #%d: %lld\n", caseNum, result);
    fflush(outFile);
}

void outputCaseULongLongResult(FILE* outFile, int caseNum, unsigned long long result)
{
    fprintf(outFile, "Case #%d: %llu\n", caseNum, result);
    fflush(outFile);
}

void outputCaseStrResult(FILE* outFile, int caseNum, char* result)
{
    fprintf(outFile, "Case #%d: %s\n", caseNum, result);
    fflush(outFile);
}

void outputCaseFloatResult(FILE* outFile, int caseNum, float result)
{
    fprintf(outFile, "Case #%d: %f\n", caseNum, result);
    fflush(outFile);
}

void outputCaseDoubleResult(FILE* outFile, int caseNum, double result)
{
    fprintf(outFile, "Case #%d: %.7lf\n", caseNum, result);
    fflush(outFile);
}

