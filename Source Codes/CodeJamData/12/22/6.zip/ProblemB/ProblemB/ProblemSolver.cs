﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Utils.Infrastructure;

namespace ProblemB {
    class ProblemSolver : IProblemSolver {
        //Properties
        double[,] grid;
        bool[,] extracted;
        bool[,] hasValue;

        //Solver        
        public object Solve() {
            grid = new double[N,M];
            extracted = new bool[N, M];
            hasValue = new bool[N, M];
            grid[0, 0] = 0;
            hasValue[0, 0] = true;

            
            while (true) {
                Tuple<int, int, double> min = ExtractMin();
                if (min.Item1 == N - 1 && min.Item2 == M - 1)
                    return min.Item3;
                Process(min, 1, 0);
                Process(min, -1, 0);
                Process(min, 0, 1);
                Process(min, 0, -1);
            }
        }

        private Tuple<int, int, double> ExtractMin() {
            Tuple<int, int, double> result = null;
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < M; j++) {
                    if (extracted[i, j] || !hasValue[i, j])
                        continue;
                    if (result == null || grid[i, j] < result.Item3)
                        result = new Tuple<int, int, double>(i, j, grid[i, j]);
                }
            }
            extracted[result.Item1, result.Item2] = true;
            return result;
        }
        void Process(Tuple<int, int, double> from, int di, int dj) {
            int ti = from.Item1 + di;
            int tj = from.Item2 + dj;
            if (ti < 0 || ti >= N || tj < 0 || tj >= M)
                return;
            if (CanGo(from.Item1, from.Item2, ti, tj)) {
                double t = CalcTime(from.Item1, from.Item2, ti, tj) + grid[from.Item1, from.Item2];
                if (hasValue[ti, tj])
                    grid[ti, tj] = Math.Min(grid[ti, tj], t);
                else
                    grid[ti, tj] = t;
                hasValue[ti, tj] = true;

            }
        }
        double CalcTime(int si, int sj, int ti, int tj) {
            double waterLevel = H - grid[si, sj] * 10;
            int targetCeil = Cij[ti, tj];
            double dt = 0;
            double remainWater = waterLevel;
            if (targetCeil - waterLevel < 50) {
                dt += (waterLevel - (targetCeil - 50)) / 10;
                remainWater = targetCeil - 50;
            }
            else {
                if (grid[si, sj] == 0)
                    return 0;
            }
            remainWater -= Hij[si, sj];
            if (remainWater >= 20.0)
                return dt + 1;
            else
                return dt + 10;
                
        }

        private bool CanGo(int si, int sj, int ti, int tj) {
            int targetCeil = Cij[ti, tj];
            int targetFloor = Hij[ti, tj];
            if (targetCeil - targetFloor < 50)
                return false;
            int sourceCeil = Cij[si, sj];
            int sourceFloor = Hij[si, sj];
            if (sourceCeil - targetFloor < 50)
                return false;
            if (targetCeil - sourceFloor < 50)
                return false;
            return true;
        }

        public int H { get; set; }

        public int N { get; set; }

        public int M { get; set; }

        public int[,] Cij { get; set; }

        public int[,] Hij { get; set; }
    }
}
