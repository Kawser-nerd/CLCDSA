using System;
using System.IO;
using System.Linq;

namespace CodeJam2010FairWarning
{
    public static class TextReaderExtensions
    {
        public static string[] ReadLineWords(this TextReader reader)
        {
            return reader.ReadLine().Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
        }

        public static int[] ReadLineInts(this TextReader reader)
        {
            return reader.ReadLineWords().Select(str => int.Parse(str)).ToArray();
        }

        public static long[] ReadLineLongs(this TextReader reader)
        {
            return reader.ReadLineWords().Select(str => long.Parse(str)).ToArray();
        }

        public static BigInteger[] ReadLineBigIntegers(this TextReader reader)
        {
            return reader.ReadLineWords().Select(str => new BigInteger(str, 10)).ToArray();
        }
    }
}