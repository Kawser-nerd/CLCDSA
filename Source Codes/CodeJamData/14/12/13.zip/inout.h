/*******************************************************************************/
/*******************************************************************************/

#ifndef INOUT_H
#define INOUT_H


/****************************** PUBLIC MACROS **********************************/


/******************************* PUBLIC TYPES **********************************/


/************************* PUBLIC DATA DECLARATIONS ****************************/


/*********************** PUBLIC FUNCTION DECLARATIONS **************************/
int readNumStrFromFileToInt(FILE* inFile, int* num);
int readNumStrFromFileToUInt(FILE* inFile, unsigned int* num);
int readNumStrFromFileToLongLong(FILE* inFile, long long* num);
int readNumStrFromFileToULongLong(FILE* inFile, unsigned long long* num);
int readNumStrFromFileToDouble(FILE* inFile, double* num);
int readNumStrFromFileToCharArray(FILE* inFile, char* buffer, int len);
void outputCaseIntResult(FILE* outFile, int caseNum, int result);
void outputCaseUIntResult(FILE* outFile, int caseNum, unsigned int result);
void outputCaseLongLongResult(FILE* outFile, int caseNum, long long result);
void outputCaseULongLongResult(FILE* outFile, int caseNum, unsigned long long result);
void outputCaseStrResult(FILE* outFile, int caseNum, char* result);
void outputCaseFloatResult(FILE* outFile, int caseNum, float result);
void outputCaseDoubleResult(FILE* outFile, int caseNum, double result);


#endif // INOUT_H