from operator import mul
from itertools import product
from bisect import bisect_left


__all__ = [
    'factorial',
    'primes',
    'is_prime',
    'compressed_factorize',
    'factorize',
    'phi',
    'divisors',
    'gcd',
    'lcm',
    'egcd',
]


def factorial(n):
    assert n >= 0
    result = 1
    for i in xrange(2, n+1):
        result *= i
    return result


def binomial(n, k):
    assert 0 <= k <= n
    return factorial(n)//(factorial(k)*factorial(n-k))


def eratosphenes(n):
    '''yield all primes less than n'''
    yield 2
    x = [True]*((n-3)//2)
    for i in xrange(len(x)):
        if x[i]:
            p = 2*i+3
            yield p
            if p*p < n:
                for j in xrange(i+p, len(x), p):
                    x[j] = False


_found_odd_primes = []

def _eratosphenes_infinite():
    m = 3
    n = 100
    while True:
        assert m%2
        x = [True]*((n-m+1)//2)
        for p in _found_odd_primes:
            if p >= m:
                break
            if p*p >= n:
                break
            start = (m-p-1)//(2*p)*(2*p)+3*p
            assert start >= m
            assert start-2*p < m
            assert start%p == 0
            for j in xrange((start-m)//2, len(x), p):
                x[j] = False
        for i in xrange(len(x)):
            if x[i]:
                p = 2*i+m
                _found_odd_primes.append(p)
                yield p
                if p*p < n:
                    for j in xrange(i+p, len(x), p):
                        x[j] = False
        m = n
        if m%2 == 0:
            m += 1
        n = n*6//5


_pg = _eratosphenes_infinite()
assert iter(_pg) == _pg     


def primes():
    yield 2
    for p in _found_odd_primes:
        yield p
    for p in _pg:
        yield p
        

def is_prime(n):
    assert n >= 0
    if n < 2:
        return False
    if n == 2:
        return True

    if _found_odd_primes and _found_odd_primes[-1] >= n:
        i = bisect_left(_found_odd_primes, n)
        return _found_odd_primes[i] == n
        
    for p in primes():
        if p*p > n:
            return True
        if n%p == 0:
            return False


def naive_factorize(n):
    assert n > 0
    factors = []
    for p in primes():
        if n == 1:
            return factors
        if p*p > n:
            factors.append(n)
            return factors
        while n%p == 0:
            factors.append(p)
            n //= p


def compressed_factorize(n):
    '''
    return list of pairs (prime, power)
    
    you may want to feed it to OrderedDict or defaultdict sometimes
    '''
    assert n > 0
    result = []
    for p in primes():
        if n == 1:
            return result
        if p*p > n:
            result.append((n, 1))
            return result
        k = 0
        while n%p == 0:
            n //= p
            k += 1
        if k > 0:
            result.append((p, k))


def factorize(n):
    '''list of factors'''

    result = [p for p, k in compressed_factorize(n) for _ in range(k)]
    #assert result == naive_factorize(n)
    return result


def phi(n):
    '''Euler's totient function'''
    result = 1
    for p, k in compressed_factorize(n):
        result *= p**(k-1)*(p-1)
    return result


def naive_divisors(n):
    '''Enumerate all divisors of n in ascending order. Runtime is O(sqrt(n))'''
    i = 1
    while i*i <= n:
        if n%i == 0:
            yield i
        i += 1
    while i*i >= n:
        i -=1
    while i > 0:
        if n%i == 0:
            yield n//i
        i -= 1


def divisors(n):
    '''List of all divisors of n in ascending order'''
    cf = compressed_factorize(n)
    result = []
    for p in product(*([p**i for i in range(k+1)] for p, k in cf)):
        result.append(reduce(mul, p, 1))
    result.sort()
    return result



def gcd(m, n):
    while m != 0:
        n, m = m, n%m
    return n


def lcm(m, n):
    return m*n//gcd(m, n)


def egcd(m, n):
    """
    return triple g, x, y

    where
    g = gcd(m, n) = m*x+n*y
    """
    if m == 0:
        return n, 0, 1
    g, x1, y1 = egcd(n%m, m)
    x = y1-x1*(n//m)
    y = x1
    assert m*x+n*y == g
    return g, x, y



if __name__ == '__main__':
    # primes benchmark

    from time import clock
    from itertools import takewhile

    start = clock()
    
    M = 10**7
    x = list(takewhile(lambda p: p < M, primes()))
    #x = list(eratosphenes(M))
    #print x
    print len(x), 'primes less than', M

    print 'it took', clock()-start