﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Numerics;
using System.Diagnostics;

namespace GCJ
{
    public class D : X
    {
        private int X;
        private int R;
        private int C;
        public override void Init()
        {
            X = ReadInt();
            R = ReadInt();
            C = ReadIntLine();
        }
        public override void Solve()
        {
            bool result = false;
            int N = R * C;
            int T = N % X;
            bool G  = (R > 1) && (C > 1);
            bool G2 = (R > 2) && (C > 2);
            bool G3 = (R > 3) && (C > 3);
            if (X == 1)
                result = true;
            if ((X == 2) && (T == 0))
            {
                result = true;
            }
            if ((X == 3) && (T == 0) && G)
            {
                result = true;
            }
            if ((X == 4) && (T == 0) && G2)
            {
                result = true;
            }
            if ((X == 5) && (T == 0) && G2)
            {
                if (N > 15)
                    result = true;
            }
            if ((X == 6) && (T == 0) && G3)
            {
               result = true;
            }
            Result.Append(result ? "GABRIEL" : "RICHARD");
        }
    }
}