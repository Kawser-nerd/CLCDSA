package lib;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

// TODO 언젠간 쓰곘지
public interface BFSPathFinder {

    static PathFinder create(MapFactory<Integer> mf) {
        return (adj, start, end) -> {
            AtomicReference<List<Integer>> found = new AtomicReference<>(null);
            Map<Integer, Integer> pre = mf.create();
            BFS.traverse(start, adj, (cv, nv) -> {
                pre.put(nv, cv);
                if (nv == end) {
                    List<Integer> r = new ArrayList<>();
                    for (Integer v = end; v != null; v = pre.get(v))
                        r.add(v);
                    found.set(ReversedList.of(r));
                }
            }, () -> found.get() != null, mf);
            return found.get();
        };
    }
}
