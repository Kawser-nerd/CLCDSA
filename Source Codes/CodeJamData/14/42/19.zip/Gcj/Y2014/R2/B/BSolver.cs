﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Cmn.Util;
using Gcj.Util;

namespace Gcj.Y2014.R2.B
{
    internal class BSolver : GcjSolver
    {

        protected override IEnumerable<object> EnobjSolveCase()
        {
            var cn = Fetch<int>();
            var rgn = Fetch<int[]>();

            var mpnToI = rgn.Select((v, i) => new {v, i}).ToDictionary(vi => vi.v, vi => new Wrp<int>{V = vi.i});

            Action<int, int> swap = (i1, i2) =>
            {
                Debug.Assert(Math.Abs(i1 - i2) == 1);
                var n1 = rgn[i1];
                var n2 = rgn[i2];
                rgn[i1] = n2;
                rgn[i2] = n1;
                mpnToI[n1].V = i2;
                mpnToI[n2].V = i1;
            };

            var min = 0;
            var max = cn-1;
            var cswap = 0;
            foreach(var n in rgn.OrderBy(n => n))
            {
                var i = mpnToI[n].V;
                if(i==min)
                {
                    min++;
                }
                else if(i==max)
                {
                    max--;
                }
                else
                {
                    var cswapMin = i - min;
                    var cswapMax = max - i;

                    cswap += Math.Min(cswapMin, cswapMax);
                    if(cswapMin<cswapMax)
                    {
                        for(var ii = i;ii>min;ii--)
                        {
                            swap(ii, ii - 1);
                        }
                        min++;
                    }
                    else
                    {
                        for(var ii = i;ii<max;ii++)
                        {
                            swap(ii, ii + 1);
                        }
                        max--;
                    }
                }
            }
            yield return cswap;
        }

    }
}
