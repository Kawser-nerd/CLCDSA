﻿namespace Generic.Maths.Lines
{
    public class BoundedVertical : Vertical, IBoundedLine
    {
        private readonly double yBottom;
        private readonly double yTop;

        public BoundedVertical(double x, double yBottom, double yTop) : base(x)
        {
            this.yTop = yTop;
            this.yBottom = yBottom;
        }

        #region IBoundedLine Members

        public double LeftX
        {
            get { return X; }
        }

        public double RightX
        {
            get { return X; }
        }

        public double TopY
        {
            get { return yTop; }
        }

        public double BottomY
        {
            get { return yBottom; }
        }

        #endregion

        public override string ToString()
        {
            return "Vertical, x = " + X;
        }
    }
}