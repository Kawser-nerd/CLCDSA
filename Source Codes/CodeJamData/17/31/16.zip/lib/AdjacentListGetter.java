package lib;

import java.util.function.IntConsumer;

public interface AdjacentListGetter {
    void forEach(int vertex, IntConsumer visitor);
}
