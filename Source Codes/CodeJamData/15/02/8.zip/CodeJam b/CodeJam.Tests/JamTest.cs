﻿/* www.codertom.com  -  copyright Tom Harrison 2015 */
using System.IO;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace CoderTom.CodeJam.Tests
{
    [TestFixture]
    public class JamTest
    {
        private ProblemFileInfo _input;

        [SetUp]
        public void ReadExampleFile()
        {
            var parser = new FileParser();
            _input = parser.Parse("ExampleInput.txt");
        }

        [Test]
        public void CanParseTestCaseCount()
        {
            Assert.AreEqual(3, _input.TestCaseCount);
        }

        [Test,
        TestCase(new[] { 1, 1, 1 }, 1),
        TestCase(new[] { 4, }, 3),
        ]
        public void CanSolveAdditionalCases(int[] plates, int result)
        {
            var c = new TestCase() { Plates = plates, PlateCount = plates.Count() };
            Assert.AreEqual(result.ToString(), c.Solve());
        }
        
        [Test]
        public void CanSolveAll()
        {
            _input.SolveAll("Output.txt");
            var result = File.ReadAllText("Output.txt");
            var expected = File.ReadAllText("ExampleOutput.txt");
            Assert.AreEqual(expected, result);
        }
    }
}
