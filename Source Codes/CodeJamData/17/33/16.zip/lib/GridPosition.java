package lib;

public class GridPosition {
    public final int i, j;

    public GridPosition(int i, int j) {
        this.i = i;
        this.j = j;
    }
}
