import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Locale;

public abstract class Template {

	public void start() {
		try {
			Locale.setDefault(Locale.US);

			BufferedReader in = new BufferedReader(new FileReader(getStorage()
					+ getTask() + getInSuffix()));
			BufferedWriter out = new BufferedWriter(new FileWriter(getStorage()
					+ getTask() + getOutSuffix()));
			int n = Integer.parseInt(in.readLine());
			for (int i = 0; i < n; i++) {
				String caseN = "Case #" + String.valueOf(i + 1) + ":";
				System.out.println(caseN);
				out.append(caseN);
				runCase(in, out);
			}
			out.flush();
			out.close();
			in.close();
		} catch (IOException e) {
			e.printStackTrace(System.out);
		}
	}

	//@Test
	//public void testNothing() throws Exception {
		//runTest("test data");
	//}

	public void runTest(String input) {
		try {
			Locale.setDefault(Locale.US);
			
			System.out.println();
			System.out
					.println("-------------------------------------------------");
			System.out.println(input);
			System.out
					.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
			BufferedReader in = new BufferedReader(new StringReader(input));
			StringWriter stringWriter = new StringWriter();
			BufferedWriter out = new BufferedWriter(stringWriter);
			runCase(in, out);
			out.flush();
			in.close();
			out.close();
			System.out
					.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
			System.out.println(stringWriter.toString());
			System.out
					.println("-------------------------------------------------");
			System.out.println();
			System.out.println();
		} catch (IOException e) {
			e.printStackTrace(System.out);
		}
	}

	public abstract void runCase(BufferedReader in, BufferedWriter out) throws IOException;

	public String getStorage() {
		return "c:\\";
	}

	public String getTask() {
		return "current";
	}

	public String getInSuffix() {
		return ".in";
	}

	public String getOutSuffix() {
		return ".out";
	}

}
