﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CodeJam.Round1A
{
    internal class SolutionA : ISolution
    {
        private int charsTyped;
        private int totalChars;
        private double[] probabilities;

        private int problemIndex;

        public int GetProblem(int problemIndex, int startIndex, string[] data)
        {
            this.problemIndex = problemIndex;
            string[] counts = data[startIndex++].Split(' ');
            charsTyped = int.Parse(counts[0]);
            totalChars = int.Parse(counts[1]);
            probabilities = data[startIndex++].Split(' ').Select(double.Parse).ToArray();
            return startIndex;
        }

        public Result ProcessProblem()
        {
            // Keep Typing
            double chanceCorrect = probabilities.Aggregate((total, p) => total*p);
            int charsRemaining = totalChars - charsTyped;
            double lowest = (chanceCorrect * (charsRemaining + 1)) + ((1 - chanceCorrect) * (charsRemaining + totalChars + 2));

            for(int i = 1; i < charsTyped; i++)
            {
                double chance = probabilities.Take(i).Aggregate((total, p) => total * p);
                int remaining = totalChars - i;
                double probability = (chance * (remaining + 1 + (charsTyped - i))) + ((1 - chance) * (totalChars - i + totalChars + 2 + (charsTyped - i)));
                if (probability < lowest)
                    lowest = probability;
            }

            // Press Enter
            int enterImmediate = 2 + totalChars;
            if(enterImmediate < lowest)
                lowest = enterImmediate;

            string result = Math.Round(lowest, 6).ToString();
            int indexOf = result.IndexOf('.');
            if (indexOf == -1)
                result += ".000000";
            else
                result = result.PadRight(indexOf + 7, '0');

            return new Result()
                       {
                           Output = result,
                           ProblemIndex = problemIndex
                       };
        }
    }
}
