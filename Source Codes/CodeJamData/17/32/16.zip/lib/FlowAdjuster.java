package lib;

public class FlowAdjuster {
    public static void adjust(AdderOnEdge flowAdder, int from, int to, int addition) {
        flowAdder.add(from, to, addition);
        flowAdder.add(to, from, -addition);
    }
}
