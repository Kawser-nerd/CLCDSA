package lib;

public class HashMapFactoryForDeepArrayContent {
    public static <T> MapFactory<T[]> create() {
        return ArrayBaseHashMapFactory.of(v -> v);
    }
}
