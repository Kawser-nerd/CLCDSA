﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Chaow.Numeric;

namespace Google {
    static class Program {
        const string inputFile = @"C:\Google\C-large.in";
        const string outputFile = @"C:\Google\__result.out";

        static void Main(string[] args) {
            //read input from file
            string input;
            using (var reader = File.OpenText(inputFile)) {
                input = reader.ReadToEnd();
            }

            //write output to file
            using (var writer = File.CreateText(outputFile)) {
                foreach (var result in Solve(input))
                    writer.WriteLine(result);
            }
        }
        static IEnumerable<string> Solve(string input) {
            //split cases
            string[] cases = input.Split(new[] { "\r\n", "\n" },StringSplitOptions.None);
            int caseCount = int.Parse(cases[0]);

            //enumerate cases
            for (int j = 1; j <= caseCount; j++) {
                string result = SolveWelcomeToCodeJam(cases[j]);
                yield return string.Format("Case #{0}: {1}", j, result);
            }
        }
        public static Func<T1, T2, TResult> When<T1, T2, TResult>(this Func<T1, T2, TResult> func, Func<T1, T2, bool> predicate, Func<T1, T2, TResult> alternative) {
            return (arg1, arg2) => predicate(arg1, arg2) ? alternative(arg1, arg2) : func(arg1, arg2);
        }
        public static Func<T, TResult> Memoize<T, TResult>(this Func<T, TResult> func) {
            var dict = new Dictionary<T, TResult>();
            return arg => {
                TResult value;
                if (!dict.TryGetValue(arg, out value)) {
                    value = func(arg);
                    dict.Add(arg, value);
                }
                return value;
            };
        }
        public static Func<T1, T2, TResult> Memoize<T1, T2, TResult>(this Func<T1, T2, TResult> func) {
            var curried = Memoize<T1, Func<T2, TResult>>(arg1 =>
                              Memoize<T2, TResult>(arg2 => func(arg1, arg2)));
            return (arg1, arg2) => curried(arg1)(arg2);
        }
        public static IEnumerable<int> To(this int from, int to) {
            for (; from < to; from++)
                yield return from;
            if (from == to)
                yield return from;
        }
        static string Right(this string str, int num) {
            if (str.Length < num)
                return str;
            return str.Substring(str.Length - num, num);
        }
        static string SolveWelcomeToCodeJam(string str) {
            string word = "welcome to code jam";

            Func<int, int, BigInteger> func = null;
            func = (i, j) => j.To(str.Length - word.Length + i).Where(x => word[i] == str[x]).Aggregate(BigInteger.Zero, (a, x) => a + func(i + 1, x + 1));
            func = func.When((i, j) => i == word.Length, (i, j) => 1L);
            func = func.When((i, j) => i > 0 && j <= 0, (i, j) => 0L);
            func = func.Memoize();

            string result = func(0, 0).ToString().Right(4);
            if (result.Length < 4)
                return new string('0', 4 -result.Length) + result;
            else
                return result;
        }
    }
}
