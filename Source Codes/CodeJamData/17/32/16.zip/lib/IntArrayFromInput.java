package lib;

import java.util.stream.IntStream;

public class IntArrayFromInput {
    public static int[] next(Input in, int length) {
        return IntStream.generate(in::nextInt).limit(length).toArray();
    }
}
