﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;

namespace km.gcj.qual
{
    class ProgramBS
    {

        static void Main(string[] args)
        {
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            Logic(args);

            sw.Stop();
            Console.WriteLine(sw.Elapsed);
            Console.ReadLine();
        }

        static void Logic(string[] args)
        {
            Problem p = Problem.createProblem(args);
            if (p == null || p.inputLinesCount == 0)
            {
                return;
            }

            long repeat = p.getNextLineAsInt64Array()[0];
            for (int i = 0; i < repeat; i++)
			{
                long[] line = p.getNextLineAsInt64Array();
                long num = line[0];
                long spr = line[1];
                long pnt = line[2];
                int cntPerfect = 0;
                int cntSurprisable = 0;
                for (int j = 3; j < num + 3; j++)
                {
                    Check(pnt, line[j], ref cntPerfect, ref cntSurprisable);
                }
                long answer = cntPerfect + Math.Min(cntSurprisable, spr);
                p.WriteAnswerFullLine(answer.ToString());
			}
        }

        static void Check(long pnt,long t,ref int cntPerfect,ref int cntSurprisable)
        {
            if (pnt == 0)
            {
                cntPerfect++;
            }
            else if (pnt == 1)
            {
                if (t>=1)
                {
                    cntPerfect++;
                }
            }
            else
            {
                if (t >= pnt * 3 - 2)
                {
                    cntPerfect++;
                }
                else if (t >= pnt * 3 - 4)
                {
                    cntSurprisable++;
                }
            }
        }


    }
}
