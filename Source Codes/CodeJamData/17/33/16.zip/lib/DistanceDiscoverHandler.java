package lib;

public interface DistanceDiscoverHandler<T> {
    void onDiscover(T source, T dest, double distance);
}
