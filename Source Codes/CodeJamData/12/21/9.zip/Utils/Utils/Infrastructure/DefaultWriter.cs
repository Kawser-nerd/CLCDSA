﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Utils.Infrastructure {
    public class DefaultWriter : IProblemWriter {
        TextWriter textWriter;
        public DefaultWriter(string fileName) {
            textWriter = new StreamWriter(fileName);
        }

        public void BeginCase(int caseNumber) {
            textWriter.Write(String.Format("Case #{0}: ", caseNumber));
        }

        public void WriteResult(string result) {
            textWriter.Write(result);
        }

        public void EndCase() {
            textWriter.WriteLine();
        }

        public void Close() {
            textWriter.Close();
        }
    }
}
