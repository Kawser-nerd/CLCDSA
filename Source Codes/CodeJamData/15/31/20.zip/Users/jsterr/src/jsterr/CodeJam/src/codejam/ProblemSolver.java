package codejam;

import java.io.BufferedReader;
import java.io.IOException;

public interface ProblemSolver {

    public String solve(BufferedReader in, int testNum) throws IOException;
}
