﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Q1
{
	public class Solver : SolverBase
	{
		public const string INPUT_NAME = "small1-2";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = false;
		public const bool PRINT_EVERY_RESULT = true;

		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		public override object SolveTestCase(int testCase)
		{
			var spl = GetIntList();
			var N = spl[0];
			var P = spl[1];
			IEnumerable<int> groups = GetIntList();

			var happyGroupCount = groups.Count(g => g % P == 0);
			var groupSet = groups.Where(g => g % P != 0).ToList();
			if (!groupSet.Any())
				return happyGroupCount;

			if (P == 2)
				return happyGroupCount + ((int)Math.Ceiling(groupSet.Count() / 2.0));

			if (P == 3)
			{
				var mod1 = groupSet.Count(g => g % P == 1);
				var mod2 = groupSet.Count(g => g % P == 2);
				var overlap = Math.Min(mod1, mod2);
				happyGroupCount += overlap;
				mod1 -= overlap;
				mod2 -= overlap;

				if(mod1 == 0 && mod2 == 0)
					return happyGroupCount;

				var left = Math.Max(mod1, mod2);
				happyGroupCount += ((int)Math.Ceiling(left / 3.0));
				return happyGroupCount;
			}

			throw new Exception();
			foreach (var g in groupSet)
			{
				
			}

			return happyGroupCount;
		}
	}
}
