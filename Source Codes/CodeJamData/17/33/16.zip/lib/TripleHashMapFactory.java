package lib;

public class TripleHashMapFactory {
    public static <T1, T2, T3> MapFactory<Triple<T1, T2, T3>> of(HashMapMaterial<T1> m1, HashMapMaterial<T2> m2, HashMapMaterial<T3> m3) {
        return CustomHashMapFactory.create(TripleHashMapMaterial.of(m1, m2, m3));
    }
}
