package lib;

import java.util.function.Supplier;
import java.util.stream.Stream;

public class LimitedStream {
    public static <T> Stream<T> generate(int n, Supplier<T> s) {
        return Stream.generate(s).limit(n);
    }
}
