package lib;

import java.util.stream.IntStream;

public class MaxAmong {
    public static int max(int... a) {
        return IntStream.of(a).max().getAsInt();
    }
}
