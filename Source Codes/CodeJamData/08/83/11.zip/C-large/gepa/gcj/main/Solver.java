/**
 * 
 */
package gepa.gcj.main;

import java.util.ArrayList;
import java.util.List;


/**
 * @author gepa
 *
 */
public abstract class Solver {

    private List<String> warnings = new ArrayList<String>();

    public abstract void init();
    public abstract Result solve(InputData data);

    public void assertTrue(boolean value, String msg) {
        if (!value) {
            addWarning(msg);
        }
    }
    public void addWarning(String w) {
        warnings.add(w);
    }
    public void clearWarnings() {
        warnings.clear();
    }
    public String[] getWarnings() {
        return warnings.toArray(new String[0]);
    }

}
