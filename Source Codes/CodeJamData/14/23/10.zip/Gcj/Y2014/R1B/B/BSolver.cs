﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using Cmn.Util;
using Gcj.Util;

namespace Gcj.Y2014.R1B.B
{
    internal class BSolver : GcjSolver
    {
        protected override IEnumerable<object> EnobjSolveCase()
        {
            BigInteger a = 0;
            BigInteger b = 0;
            BigInteger k = 0;
            Fetch(out a, out b, out k);

            BigInteger c = 0;
            for(BigInteger a1 = 0;a1<a;a1++)
                for(BigInteger b1 = 0;b1<b;b1++)
                    if((a1 & b1) < k)
                        c++;
            yield return c;
            yield break;
            

            BigInteger sumcn = 0;
            for(BigInteger n = 0; n < k; n++)
            {
                BigInteger cn = 1;

                BigInteger di = 1;
                for (; ; )
                {

                    if(n / di % 2 == 1)
                    {
                        if(di >= a || di >= b)
                        {
                            cn = 0;
                            break;
                        }
                    }
                    else
                    {
                        if(di >= a)
                        {
                            if(di >= b)
                            {
                                if (di > n)
                                    break;

                            }
                            else
                            {
                                cn *= 2;
                            }
                        }
                        else
                        {
                            if(di>=b)
                            {
                                cn *= 2;
                            }
                            else
                            {
                                cn *= 3;
                            }
                        }
                    }
                    di *= 2;
                }

                sumcn += cn;
            }
            yield return sumcn;
        }

    }
}
