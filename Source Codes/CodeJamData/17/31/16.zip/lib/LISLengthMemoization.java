package lib;

import java.util.stream.IntStream;

public class LISLengthMemoization {

    public static Solver<Integer, Integer> of(int[] seq) {
        return MemoizationSolver.of(HashMapFactory.create(), (start, subSolver) -> {
            // seq[start~] 의 LIS 의 길이
            IntStream biggers = Range.of(start + 1, seq.length).filter(index -> seq[start] < seq[index]);
            IntStream nextLisLengths = biggers.map(subSolver::solve);
            return 1 + nextLisLengths.max().orElse(0);
        });
    }
}
