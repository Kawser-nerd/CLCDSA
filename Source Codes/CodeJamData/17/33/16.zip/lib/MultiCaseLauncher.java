package lib;

import java.io.InputStream;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class MultiCaseLauncher {

    public static void run(Function<InputStream, Supplier<String>> tokenizerFactory, Consumer<Input> solver) {
        Launcher.run(tokenizerFactory, input -> {
            int caseNumber = input.nextInt();
            Repeat.run(caseNumber, () -> solver.accept(input));
        });
    }

}
