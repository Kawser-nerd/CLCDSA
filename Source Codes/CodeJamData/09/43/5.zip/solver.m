function solver
f=fopen('sample.in','rt');
f2=fopen('sample.out','wt');
NumCases=fscanf(f,'%d',1);
tic
for caseCounter=1:NumCases
    f3=fopen('temp.out','wt');
    [caseCounter NumCases]
    n=fscanf(f,'%d',1);
    k=fscanf(f,'%d',1);
    history=fscanf(f,'%d',[k n]);
    edges=[];
    for i=1:n-1
        for j=i+1:n
            bigger=history(:,i)>history(:,j);
            if any(bigger) & ~all(bigger) | any(history(:,i)==history(:,j))
                edges=[edges; i j];
            end
        end
    end
    fprintf(f3,'%d %d\n',n,size(edges,1));
    fprintf(f3,'%d %d\n',edges');
    fclose(f3);
    [stat res]=system('Stocks temp.out');
    sol=sscanf(res(strfind(res,'Solution')+10:end),'%d',1);
    fprintf(f2,'Case #%d: %d\n',caseCounter,sol);
    toc
end
fclose all;
