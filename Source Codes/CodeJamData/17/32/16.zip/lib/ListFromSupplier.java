package lib;

import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class ListFromSupplier {
    public static <T> List<T> collect(int n, Supplier<T> s) {
        return LimitedStream.generate(n, s).collect(Collectors.toList());
    }
}
