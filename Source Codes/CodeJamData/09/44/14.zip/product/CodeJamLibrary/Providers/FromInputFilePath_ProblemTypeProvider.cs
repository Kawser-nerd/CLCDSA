using System.IO;
using CodeJamLibrary.Interfaces;

namespace CodeJamLibrary.Providers
{
  public class FromInputFilePath_ProblemTypeProvider : IProblemTypeProvider
  {
    private readonly IFilePathProvider provider;

    public FromInputFilePath_ProblemTypeProvider(IFilePathProvider provider)
    {
      this.provider = provider;
    }

    public ProblemType GetProblemType()
    {
      string fileName = Path.GetFileName(provider.GetFilePath());
      string firstLetter = fileName.Substring(0, 1);

      switch (firstLetter)
      {
        case "A":
          return ProblemType.ProblemA;
        case "B":
          return ProblemType.ProblemB;
        case "C":
          return ProblemType.ProblemC;
        case "D":
          return ProblemType.ProblemD;
        default:
          return ProblemType.Unknown;
      }
    }
  }
}