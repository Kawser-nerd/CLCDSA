﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Numerics;
using System.Diagnostics;

namespace GCJ
{
    public class A : X
    {
        private int N;
        private string S;
        public override void Init()
        {
            N = ReadInt();
            S = ReadStringLine();
        }
        public override void Solve()
        {
            int c = 0;
            int s = 0;
            for (int i = 0; i < N+1; i++)
            {
                if (s < i)
                {
                    c += (i - s);
                    s = i;
                }
                s += int.Parse(S[i].ToString());
            }
            Result.Append(c);
        }
    } 
}