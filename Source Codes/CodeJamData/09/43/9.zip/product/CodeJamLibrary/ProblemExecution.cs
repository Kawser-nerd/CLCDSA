using CodeJamLibrary.Interfaces;

namespace CodeJamLibrary
{
  public class ProblemExecution : IProblemExecution
  {
    private readonly IProblemInput problemInput;
    private readonly IProblemOutput problemOutput;
    private readonly IProblemFactory problemFactory;
    private readonly IProblemTypeProvider problemTypeProvider;

    public ProblemExecution(
      IProblemInput problemInput,
      IProblemOutput problemOutput, 
      IProblemFactory problemFactory,
      IProblemTypeProvider problemTypeProvider)
    {
      this.problemInput = problemInput;
      this.problemOutput = problemOutput;
      this.problemFactory = problemFactory;
      this.problemTypeProvider = problemTypeProvider;
    }

    public void Execute()
    {
      var problem = problemFactory.GetProblem(problemTypeProvider.GetProblemType());
      problem.Solve(problemInput, problemOutput);
    }
  }
}