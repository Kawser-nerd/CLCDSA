#ifndef	__GCJ__TRAINTIMETABLE_H__
#define	__GCJ__TRAINTIMETABLE_H__

#include <vector>
#include <list>
#include <map>

#include "Task.h"

class TrainTimetable : private Task
{
	public:
	TrainTimetable(std::istream&, std::string&, boost::condition&, char &);
	TrainTimetable(TrainTimetable&);
	~TrainTimetable();
	void operator()();

	private:
	unsigned long		na;
	unsigned long		nb;
	unsigned long		t;
	unsigned long		a_departure[100];
	unsigned long		a_arrival[100];
	unsigned long		b_departure[100];
	unsigned long		b_arrival[100];
};

#endif /*__GCJ__TRAINTIMETABLE_H__*/
