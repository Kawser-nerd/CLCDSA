﻿/*
 * This file is made by Feng JIAO(Email: joephone1983@gmail.com) for solving Code Jam contest problems.
 * This file is licensed under The GNU General Public License (GPLv3). For more information, google "GPLv3"
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Library
{

    [Serializable]
    public class Pair<X, Y>
    {
        X _x;
        Y _y;

        public Pair(X first, Y second)
        {
            _x = first;
            _y = second;
        }

        public X first { get { return _x; } }

        public Y second { get { return _y; } }

        public override bool Equals(object obj)
        {
            return Equals(obj as Pair<X, Y>);
        }

        public bool Equals(Pair<X, Y> p)
        {
            if ((object)p == null)
            {
                return false;
            }

            if (System.Object.ReferenceEquals(this, p))
            {
                return true;
            }

            return (((first == null) && (p.first == null))
                    || ((first != null) && first.Equals(p.first)))
                  &&
                (((second == null) && (p.second == null))
                    || ((second != null) && second.Equals(p.second)));

        }

        public override int GetHashCode()
        {
            int hashcode = 0;
            if (first != null)
                hashcode = first.GetHashCode();
            if (second != null)
                hashcode = hashcode * second.GetHashCode() + hashcode + second.GetHashCode();
            return hashcode;
        }

        public static bool operator ==(Pair<X, Y> one, Pair<X, Y> two)
        {
            if (System.Object.ReferenceEquals(one, two))
            {
                return true;
            }

            if (((object)one == null) || ((object)two == null))
            {
                return false;
            }

            return one.Equals(two);

        }

        public static bool operator !=(Pair<X, Y> one, Pair<X, Y> two)
        {
            return !(one == two);

        }

        //Unit test commented out here:
        // Pair<int, int> p1 = new Pair<int,int>(4,5);
        //Pair<int, int> p2 = new Pair<int, int>(4, 6);
        //Pair<int, int> p3 = new Pair<int, int>(5, 5);
        //Pair<int, int> p4 = new Pair<int, int>(4, 5);
        //Pair<int, int> p5 = new Pair<int, int>(6, 6);
        //Pair<int, int> p6 = null;
        //Pair<int, int> p7 = p1;
        //object p8 = p1 as object;
        //object p9 = new int[9];

        //bool works = true;

        //works &= (p1!=p2);
        //works &= (p1 != p3);
        //works &= (p1 == p4);
        //works &= (p1 != p5);
        //works &= (p1 != p6);
        //works &= (p1 == p1);
        //works &= (p1 == p7);
        //works &= (p1 == p8);
        //works &= (p1 != p9);

        //works &= !(p1 == p2);
        //works &= !(p1 == p3);
        //works &= !(p1 != p4);
        //works &= !(p1 == p5);
        //works &= !(p1 == p6);
        //works &= !(p1 != p1);
        //works &= !(p1 != p7);
        //works &= !(p1 != p8);
        //works &= !(p1 == p9);

        //works &= !p1.Equals(p2);
        //works &= !p1.Equals(p3);
        //works &= p1.Equals(p4);
        //works &= !p1.Equals(p5);
        //works &= !p1.Equals(p6);
        //works &= p1.Equals(p1);
        //works &= p1.Equals(p7);
        //works &= p1.Equals(p8);
        //works &= !p1.Equals(p9);



        //Console.WriteLine("result is {0}", works);

    }







    public class SynchronizedCache<TKey, TValue> where TValue : IEquatable<TValue>
    {
        private ReaderWriterLockSlim cacheLock = new ReaderWriterLockSlim();
        private Dictionary<TKey, TValue> innerCache = new Dictionary<TKey, TValue>();

        public TValue this[TKey key]
        {
            get
            {
                cacheLock.EnterReadLock();
                try
                {
                    return innerCache[key];
                }
                finally
                {
                    cacheLock.ExitReadLock();
                }
            }
        }

        public Boolean TryGetValue(TKey key, out TValue value)
        {
            cacheLock.EnterReadLock();
            try
            {
                return innerCache.TryGetValue(key, out value);
            }
            finally
            {
                cacheLock.ExitReadLock();
            }
        }

        public void Add(TKey key, TValue value)
        {
            cacheLock.EnterWriteLock();
            try
            {
                innerCache.Add(key, value);
            }
            finally
            {
                cacheLock.ExitWriteLock();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <param name="timeout">milliseconds</param>
        /// <returns></returns>
        public bool AddWithTimeout(TKey key, TValue value, int timeout)
        {
            if (cacheLock.TryEnterWriteLock(timeout))
            {
                try
                {
                    innerCache.Add(key, value);
                }
                finally
                {
                    cacheLock.ExitWriteLock();
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        public AddOrUpdateStatus AddOrUpdate(TKey key, TValue value)
        {
            cacheLock.EnterUpgradeableReadLock();
            try
            {
                TValue result;
                if (innerCache.TryGetValue(key, out result))
                {
                    if (result.Equals(value))
                    {
                        return AddOrUpdateStatus.Unchanged;
                    }
                    else
                    {
                        cacheLock.EnterWriteLock();
                        try
                        {
                            innerCache[key] = value;
                        }
                        finally
                        {
                            cacheLock.ExitWriteLock();
                        }
                        return AddOrUpdateStatus.Updated;
                    }
                }
                else
                {
                    cacheLock.EnterWriteLock();
                    try
                    {
                        innerCache.Add(key, value);
                    }
                    finally
                    {
                        cacheLock.ExitWriteLock();
                    }
                    return AddOrUpdateStatus.Added;
                }
            }
            finally
            {
                cacheLock.ExitUpgradeableReadLock();
            }
        }

        public void Delete(TKey key)
        {
            cacheLock.EnterWriteLock();
            try
            {
                innerCache.Remove(key);
            }
            finally
            {
                cacheLock.ExitWriteLock();
            }
        }

        public List<TValue> ToSortedValueList(Boolean accending)
        {
            cacheLock.EnterWriteLock();
            try
            {
                if (accending)
                {
                    return innerCache.OrderBy(item => item.Key).Select(item => item.Value).ToList();
                }
                else
                {
                    return innerCache.OrderByDescending(item => item.Key).Select(item => item.Value).ToList();
                }
            }
            finally
            {
                cacheLock.ExitWriteLock();
            }
        }

        public List<KeyValuePair<TKey, TValue>> ToSortedList(Boolean accending)
        {
            cacheLock.EnterWriteLock();
            try
            {
                if (accending)
                {
                    return innerCache.OrderBy(item => item.Key).ToList();
                }
                else
                {
                    return innerCache.OrderByDescending(item => item.Key).ToList();
                }
            }
            finally
            {
                cacheLock.ExitWriteLock();
            }
        }

        public enum AddOrUpdateStatus
        {
            Added,
            Updated,
            Unchanged
        };
    }


    [Serializable]
    public class CloneableObject
    {
        public object Clone()
        {
            BinaryFormatter formatter = new BinaryFormatter();
            object clone = null;

            using (MemoryStream stream = new MemoryStream())
            {
                formatter.Serialize(stream, this);
                stream.Seek(0, SeekOrigin.Begin);
                clone = formatter.Deserialize(stream);
            }

            return clone;
        }
    }
}
