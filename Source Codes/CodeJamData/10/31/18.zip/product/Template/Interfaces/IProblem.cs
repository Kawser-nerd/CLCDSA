namespace Template.Interfaces
{
  public interface IProblem
  {
    void Solve(IInput input, IOutput output);
  }
}