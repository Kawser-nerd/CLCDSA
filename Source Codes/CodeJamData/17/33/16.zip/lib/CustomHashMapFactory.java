package lib;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiPredicate;

public class CustomHashMapFactory {

    private static class Wrapper<T> {
        final T value;
        final int hash;
        final BiPredicate<Wrapper<T>, Wrapper<T>> equalTester;

        private Wrapper(T value, int hash, BiPredicate<Wrapper<T>, Wrapper<T>> equalTester) {
            this.value = value;
            this.hash = hash;
            this.equalTester = equalTester;
        }

        @Override
        public int hashCode() {
            return hash;
        }

        @SuppressWarnings("EqualsWhichDoesntCheckParameterClass")
        @Override
        public boolean equals(Object o) {
            return StrictEqualityTester.areEqual(this, o, equalTester);
        }
    }

    public static <K> MapFactory<K> create(final HashMapMaterial<K> m) {
        BiPredicate<Wrapper<K>, Wrapper<K>> wrapperEqualsFunction = (w1, w2) -> m.equalTester.test(w1.value, w2.value);
        return new MapFactory<K>() {
            @Override
            public <V> Map<K, V> create() {
                HashMap<Wrapper<K>, V> map = new HashMap<>();
                return MapUsingGetterPutter.of(k -> map.get(wrap(k)), (k, v) -> map.put(wrap(k), v));
            }

            private Wrapper<K> wrap(K k) {
                return new Wrapper<>(k, m.hashFunction.applyAsInt(k), wrapperEqualsFunction);
            }
        };
    }

}
