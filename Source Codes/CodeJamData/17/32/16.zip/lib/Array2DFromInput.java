package lib;

import java.util.function.Function;

public class Array2DFromInput {

    public static <T> T[][] next(Input in, int length1, int length2, Class<T> clazz, Function<String, T> converter) {
        return ArrayConstructor.create(length1, ArrayClass.of(clazz), () -> ArrayFromInput.next(in, length2, clazz, converter));
    }
}
