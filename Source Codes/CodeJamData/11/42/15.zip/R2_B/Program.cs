﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using JamHelpers;
using System.Diagnostics;

namespace R2_B
{
	class Program : ProgramBase
	{
		static void Main(string[] args)
		{
			new Program().Run();
		}

		public override void RunCase()
		{
			var header = ReadLine().Split().ToInt();
			int h = header[0];
			int w = header[1];
			int d = header[2];
			int[,] m = new int[w + 1, h + 1];
			for (int y = 0; y < h; y++)
			{
				string line = ReadLine();
				Debug.Assert(line.Length == w);
				for (int x = 0; x < w; x++)
				{
					int mi = line[x] - '0';
					m[x + 1, y + 1] = mi;
				}
			}
			int[,] a0 = new int[w + 1, h + 1];
			int[,] ax = new int[w + 1, h + 1];
			int[,] ay = new int[w + 1, h + 1];

			int[,] b0 = new int[w + 1, h + 1];
			int[,] bx = new int[w + 1, h + 1];
			int[,] by = new int[w + 1, h + 1];

			for (int y = 1; y <= h; y++)
			{
				for (int x = 1; x <= w; x++)
				{
					a0[x, y] = a0[x - 1, y] + m[x, y];
					ax[x, y] = ax[x - 1, y] + m[x, y] * x;
					ay[x, y] = ay[x - 1, y] + m[x, y] * y;

					b0[x, y] = b0[x, y - 1] + a0[x, y];
					bx[x, y] = bx[x, y - 1] + ax[x, y];
					by[x, y] = by[x, y - 1] + ay[x, y];

					//DebugWrite(ay[x, y] + " ");
				}
				//DebugWriteLine("");
			}
			/*DebugWriteLine("");
			for (int y = 1; y <= h; y++)
			{
				for (int x = 1; x <= w; x++)
				{
					DebugWrite(by[x, y] + " ");
				}
				DebugWriteLine("");
			}*/

			/*{
				int s = 5;
				int x = 2;
				int y = 2;

				int d0 = 0;
				int dx = 0;
				int dy = 0;
				int d_ = 0;

				for (int y2 = y; y2 < y + s; y2++)
					for (int x2 = x; x2 < x + s; x2++)
					{
						int r = x + s - 1;
						int b = y + s - 1;
						if ((x2 == x || x2 == r) && (y2 == y || y2 == b))
							continue;
						d0 += m[x2, y2];
						dx += x2 * m[x2, y2];
						dy += y2 * m[x2, y2];
						d_++;
					}
			}*/

			for (int s = Math.Min(w, h); s >= 3; s--)
			{


				for (int y = 1; y + s <= h + 1; y++)
					for (int x = 1; x + s <= w + 1; x++)
					{

						int c0 = 0;
						int cx = 0;
						int cy = 0;

						//0
						c0 += b0[x + s - 1, y + s - 1];
						c0 -= b0[x + s - 1, y - 1];
						c0 -= b0[x - 1, y + s - 1];
						c0 += b0[x - 1, y - 1];

						c0 -= m[x, y];
						c0 -= m[x + s - 1, y];
						c0 -= m[x, y + s - 1];
						c0 -= m[x + s - 1, y + s - 1];

						if (c0 == 0)
						{
							WriteLine(CaseStr + " " + s);
							return;
						}

						//x
						cx += bx[x + s - 1, y + s - 1];
						cx -= bx[x + s - 1, y - 1];
						cx -= bx[x - 1, y + s - 1];
						cx += bx[x - 1, y - 1];

						cx -= x * m[x, y];
						cx -= (x+s-1) * m[x + s - 1, y];
						cx -= x * m[x, y + s - 1];
						cx -= (x+s-1) * m[x + s - 1, y + s - 1];

						double centerX = (double)cx / (double)c0;
						if (centerX != x + 0.5 * (s-1))
							continue;

						//y
						cy += by[x + s - 1, y + s - 1];
						cy -= by[x + s - 1, y - 1];
						cy -= by[x - 1, y + s - 1];
						cy += by[x - 1, y - 1];

						cy -= y * m[x, y];
						cy -= y * m[x + s - 1, y];
						cy -= (y+s-1) * m[x, y + s - 1];
						cy -= (y+s-1) * m[x + s - 1, y + s - 1];

						double centerY = (double)cy / (double)c0;
						if (centerY != y + 0.5 * (s - 1))
							continue;

						WriteLine(CaseStr + " " + s);
						return;
					}
			}
			WriteLine(CaseStr + " " + "IMPOSSIBLE");
		}
	}
}
