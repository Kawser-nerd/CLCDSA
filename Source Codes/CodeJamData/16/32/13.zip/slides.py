#! /usr/bin/env python
from __future__ import print_function, division
try:
    range = xrange
except NameError:
    pass

# import collections
# import functools
import itertools as it
import numpy as np # See http://www.numpy.org
# import sympy as sp # See http://sympy.org/en/index.html
# import gmpy2 # See https://code.google.com/p/gmpy/
# import networkx as nx # See http://networkx.github.io/

import os
import sys
# MY MODULES - available at https://github.com/lackofcheese/CodeJamLib/
sys.path.append(os.path.join(
    os.environ['GOOGLE_DRIVE'], 'Coding', 'GCJ', 'CodeJamLib'))
import codejam_io

def toks_line(f_in, fun=int):
    return [fun(k) for k in f_in.readline().split()]

def process_first(f_in):
    num_cases = int(f_in.readline())
    other_data = None
    return num_cases, other_data

def process_case(f_in, f_out, case_no, other_data=None):
    B, M = toks_line(f_in, int)
    ans = solve(B, M)
    ans_string = "IMPOSSIBLE" if ans is None else "POSSIBLE"
    print("Case #{}: {}".format(case_no, ans_string), file=f_out)
    if ans is not None:
        for line in ans:
            for is_here in line:
                f_out.write(str(is_here))
            f_out.write("\n")

def solve(B, M):
    slide_matrix = np.zeros((B, B), dtype=int)
    if M < 2 ** (B-2):
        bits = "{:0{}b}".format(M, B-2)
        bits = '0' + bits[::-1]
    elif M == 2 ** (B-2):
        bits = '1' * (B-1)
    else:
        return None
    # print("bits:", bits)

    for bldg in range(B-1):
        for nxt in range(bldg+1, B-1):
            slide_matrix[bldg,nxt] = 1

    for i, b in enumerate(bits):
        if b == '1':
            slide_matrix[i, B-1] = 1

    # print(slide_matrix)
    ways = np.zeros(B, dtype=object)
    ways[0] = 1
    for bldg in range(B-1):
        for nxt in range(bldg+1, B):
            if slide_matrix[bldg,nxt]:
                ways[nxt] += ways[bldg]
    # print(ways)

    if ways[B-1] != M:
        print("ERROR", file=sys.stderr)
        sys.exit(-1)
    return slide_matrix

if __name__ == '__main__':
    codejam_io.process_input(process_case, process_first, __file__)
