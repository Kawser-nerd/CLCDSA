package lib;

public class PolarAngle {
    public final double angle;

    public PolarAngle(double angle) {
        Assertion.check(0 <= angle && angle < 2 * Math.PI);
        this.angle = angle;
    }

    @Override
    public String toString() {
        return angle + "";
    }
}
