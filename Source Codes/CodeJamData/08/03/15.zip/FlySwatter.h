#ifndef	__GCJ__FLYSWATTER_H__
#define	__GCJ__FLYSWATTER_H__

#include <vector>
#include <list>
#include <map>

#include "Task.h"

class FlySwatter : private Task
{
	public:
	FlySwatter(std::istream&, std::string&, boost::condition&, char &);
	FlySwatter(FlySwatter&);
	~FlySwatter();
	void operator()();
	double RectCircleCrossing(double, double, double, double);
	double CircleTruncatedSector(double, double, double);

	private:
	double				F;
	double				R;
	double				t;
	double				r;
	double				g;
};

#endif /*__GCJ__FLYSWATTER_H__*/
