﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public class Solver
{
    const string Folder = @"D:\GCJ\GCJ2011\";
    string FileName;
    string GetFile { get { return Folder + FileName; } }
    List<string> Lines;
    public Solver(List<string> lines) 
    {
        Lines = lines;
        FileName = DateTime.Now.ToShortTimeString().Replace(":", "") + DateTime.Now.Second + ".txt";
    }
    void MakeAnswer(int caseNumber, string answer)
    {
        using (StreamWriter sw = File.AppendText(GetFile))
        {
            sw.WriteLine(string.Format("Case #{0}: {1}", caseNumber, answer));
        }
    }
    string Read()
    {
        string value = Lines[0];
        Lines.RemoveAt(0);
        return value;
    }
    public void Execute()
    {
        int cases = Convert.ToInt32(Read());
        for (int caseIndex = 0; caseIndex < cases; caseIndex++)
        {
            Solve(caseIndex + 1);
        }
    }

    const string NO = "NO";
    void Solve(int caseNumber)
    {
        string answer = "";

        Read();
        string[] parts = Read().Split(' ');

        int length = parts.Length;
        int[] values = new int[length];
        for (int index = 0; index < length; index++) { values[index] = Convert.ToInt32(parts[index]); }

        int checkValue = 0;
        for (int i = 0; i < length; i++) { checkValue ^= values[i]; }

        if (checkValue != 0) { answer = NO; }
        else
        {
            int sum = 0;
            int minValue = int.MaxValue;
            for (int index = 0; index < length; index++)
            {
                int value = values[index];
                sum += value;
                if (value < minValue) { minValue = value; }
            }
            answer = (sum - minValue).ToString();
        }

        MakeAnswer(caseNumber, answer);
    }

    int PatrickSum(int a, int b) { return a ^ b; }
}

