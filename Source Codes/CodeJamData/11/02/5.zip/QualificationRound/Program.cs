using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;

public class c
{
    static void Main()
    {
        string file = @"D:\GCJ\GCJ2011\a.txt";

        DateTime now = DateTime.Now;

        List<string> lines = new List<string>();
        using (StreamReader sr = File.OpenText(file))
        {
            string line = sr.ReadLine();
            while (line != null)
            {
                lines.Add(line);
                line = sr.ReadLine();
            }
        }

        Solver solver = new Solver(lines);
        solver.Execute();

        Debug.WriteLine(DateTime.Now - now);
    }
}

