﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prisoner
{
    class Program
    {
        static List<int> cells = new List<int>();
        static IDictionary<int, int> map = new Dictionary<int, int>();

        static long[,] optimum;

        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine().Trim());
            for (int i = 0; i < n; i++)
            {
                string[] pq = Console.ReadLine().Trim().Split(' ');
                int p = int.Parse(pq[0]);
                int q = int.Parse(pq[1]);

                string[] cellString = Console.ReadLine().Trim().Split(' ');
                map.Clear();
                map.Add(0, 1);
                for (int j = 0; j < cellString.Length; j++)
                {
                    map.Add(j + 1, int.Parse(cellString[j]) + 1);
                }
                map.Add(cellString.Length + 1, p + 2);
                
                q += 2;

                optimum = new long[q, q];
                for (int j = 0; j < q; j++)
                {
                    for (int k = 0; k < q; k++)
                    {
                        optimum[j, k] = -1;
                    }
                }
                Console.WriteLine("Case #" + (i + 1).ToString() + ": " + Get(0, q - 1).ToString());
            }
        }

        static long Get(int a, int b)
        {
            if (optimum[a, b] < 0)
            {
                if (b - a < 2)
                {
                    optimum[a, b] = 0;
                }
                else
                {
                    long min = Get(a + 1, b);
                    for(int i = a + 2; i < b; i++)
                    {
                        min = Math.Min(min, Get(a, i) + Get(i, b));
                    }
                    min += (map[b] - map[a] - 2);
                    optimum[a, b] = min;
                }
            }
            return optimum[a, b];
        }
    }
}
