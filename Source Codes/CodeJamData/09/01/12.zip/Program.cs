﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;

namespace Google {
    static class Program {
        const string inputFile = @"C:\Google\A-large.in";
        const string outputFile = @"C:\Google\__result.out";

        static void Main(string[] args) {
            //read input from file
            string input;
            using (var reader = File.OpenText(inputFile)) {
                input = reader.ReadToEnd();
            }

            //write output to file
            using (var writer = File.CreateText(outputFile)) {
                foreach (var result in Solve(input))
                    writer.WriteLine(result);
            }
        }
        static IEnumerable<string> Solve(string input) {
            //split cases
            string[] cases = input.Split(new[] { "\r\n", "\n" },StringSplitOptions.None);
            //int caseCount = int.Parse(cases[0]);

            string[] rules = cases[0].Split(' ');
            int length = int.Parse(rules[0]);
            int wordCount = int.Parse(rules[1]);
            int caseCount = int.Parse(rules[2]);

            List<string> words = new List<string>(wordCount);
            for (int i = 1; i <= wordCount; i++)
                words.Add(cases[i]);

            //enumerate cases
            for (int i = wordCount + 1, j = 1; j <= caseCount; i++, j++) {
                //string[] param = cases[i].Split(' ');
                string token = cases[i];

                string result = SolveAlienLanguage(words, token.ToLetterGroup());
                yield return string.Format("Case #{0}: {1}", j, result);
            }
        }
        static Regex myRegEx = new Regex(@"(?(\()(\((?'letter'[^\)]+)\))|(?'letter'.))", RegexOptions.Compiled);
        static string[] ToLetterGroup(this string str){
            return myRegEx.Matches(str).Cast<Match>().Select(m => m.Groups["letter"].Value).ToArray();
        }
        public static Func<T1, T2, TResult> When<T1, T2, TResult>(this Func<T1, T2, TResult> func, Func<T1, T2, bool> predicate, Func<T1, T2, TResult> alternative) {
            return (arg1, arg2) => predicate(arg1, arg2) ? alternative(arg1, arg2) : func(arg1, arg2);
        }
        static string SolveAlienLanguage(IEnumerable<string> words, string[] letterGroup) {
            Func<IEnumerable<string>, int, int> func = null;
            func = (w, i) => func(w.Where(s => letterGroup[i].Contains(s[i])), i + 1);
            func = func.When((w, i) => i == letterGroup.Length, (w, i) => w.Count());
            return func(words, 0).ToString();
        }
    }
}
