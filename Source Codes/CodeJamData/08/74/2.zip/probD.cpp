// Prewritten header. See lib.el

#include <algorithm>
#include <cmath>
#include <fstream>
#include <iostream>
#include <map>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef pair<int, ii> iii;
typedef pair<ii, ii> iiii;
typedef vector<ii> vii;
typedef vector<vii> vvii;
typedef unsigned long long ull;
#define sz(a) int((a).size())
#define pb push_back
#define mp make_pair
#define all(c) (c).begin(),(c).end()
#define tr(c,i) for(typeof((c).begin()) i = (c).begin(); i != (c).end(); ++i)
#define present(c,x) ((c).find(x) != (c).end())
#define cpresent(c,x) (find(all(c),x) != (c).end())

class Solver {
public:
  Solver(ifstream& i);
  string solve();
private:
  int R;
  int C;
  int initsq;
  vector<vector<int> > memo;
  vector<bool> burned;
  vector<set<int> > moves;
  bool lose(int availablemask, int currentsquare);
};

void solve(string type){
  string infile="c:/codejam/semis/ProblemD/D-" + type + ".in";
  string outfile="c:/codejam/semis/ProblemD/D-" + type + ".out";
  cout << infile << " to " << outfile << endl;
  ifstream input(infile.c_str());
  ofstream output(outfile.c_str());
  int N;
  input >> N;
  cout << N << " cases" << endl;
  for (int i = 1; i <= N; ++i){
    cout << "Case #" << i << endl;
    Solver ps(input);
    string soln=ps.solve();
    output << "Case #" << i << ": " << soln << endl;
    cout << soln << endl;
  }
  input.close();
  output.close();
}

int main(int argc, char* argv[])
{string type = "test";
  if (argc > 1){
    int loc = 0;
    char param = argv[1][loc];
    while (param == '-'){
      ++loc;
      param = argv[1][loc];
    }
    switch (param){
    case '2':
    case 'l':
    case 'L':
      type = "large"; break;
    case '1':
    case 's':
    case 'S':
      type = "small"; break;
    default:
      type = "test"; break;}
  }
  solve(type);
}

Solver::Solver(ifstream& i){
  // Read in data to local variables.
  // Remember to define local variables in class description at top
  i >> R >> C;
  int r = R; int c = C; // Do not rename variables midcode
  char x[C+1];
  burned.assign(r*c,false);
  for (int z = 0; z < r; ++z){
    i >> x;
    cout << x << endl;
    for (int y = 0; y < c; ++y){
      burned[z*c+y] = (x[y] == '#');
      if (x[y] == 'K')
	initsq = z*c+y;
    }
  }
}

bool Solver::lose(int availablemask, int currentsquare){
  if (memo[availablemask][currentsquare] == 0){
    return false;
  }
  else if (memo[availablemask][currentsquare] == 1){
    return true;
  }
  int newmask = availablemask;
  newmask -= (newmask & (1 << currentsquare));
  tr(moves[currentsquare], it){
    if (newmask & (1 << *it)){
      bool winningmove = lose(newmask, *it);
      if (winningmove)
	return false;
    }
  }
  return true;
}


string Solver::solve() {
  // Solve problem, using local variables, and return string.
  // If you need to parse a float with exactly 6 decimal
  // places, do:
  //  char floatBuffer[20];
  //  sprintf(floatBuffer, ".6f", f);
  int r = R; int c = C; // See above on whether you should rename variables
                        // midcode
  moves.assign(r*c, set<int>());
  for (int z = 0; z < r; ++z)
    for (int y = 0; y < c; ++y)
      for (int dz = -1; dz <= 1; ++dz)
	for (int dy = -1; dy <=1; ++dy)
	  if ((z+dz >= 0) && 
	      (z + dz < r) && 
	      (y+dy >= 0) && 
	      (y+dy < c) && 
	      (dy != 0 || dz != 0) && 
	      (!burned[z*c+y]) && 
	      (!burned[(z+dz)*c+y+dy])){
	    moves[z*c+y].insert((z+dz)*c+y+dy);
	  }
  vector<int> losingposition(r*c, -1);
  memo.assign(1<<(r*c), losingposition);
  int startingposition = 0;
  for (int i = 0; i < r*c; ++i)
    if (!burned[i])
      startingposition |= (1 << i);
  if (lose(startingposition, initsq)){
    return "B";
  } else {
    return "A";
  }
}

