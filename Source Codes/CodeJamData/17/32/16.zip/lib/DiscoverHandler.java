package lib;

public interface DiscoverHandler<V> {
    boolean handleAndGetContinuity(V vertex, double distance);
}
