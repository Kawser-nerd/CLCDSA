﻿using System;
using System.Collections.Generic;
using Generic.InputOutput.Printing.Sizable;

namespace Generic.Common
{
    public static class Reflections
    {
        public static T DeepCopy<T>(T t)
        {
            return DeepCopyHelper(t, new Dictionary<object, object>());
        }

        private static T DeepCopyHelper<T>(T t, IDictionary<Object, Object> map)
        {
            var result = (T) Activator.CreateInstance(t.GetType());
            map.Add(t, result);
            foreach (var fieldInfo in t.GetType().GetFields())
            {
                var value = fieldInfo.GetValue(t);
                if (value.GetType().IsByRef)
                    value = map.ContainsKey(value) ? map[value] : DeepCopyHelper(value, map);
                fieldInfo.SetValue(result, value);
            }
            return result;
        }

        public static Document Print(Object t)
        {
            var writer = new DocumentWriter();
            PrintHelper(t, writer, new HashSet<object>());
            return writer.ToDocument();
        }

        private static void PrintHelper(Object t, DocumentWriter writer, ISet<object> map)
        {
            if (map.Contains(t))
            {
                writer.Write("recurse");
                return;
            }

            map.Add(t);
            writer.Write(t.GetType().Name);
            writer.StartBlock(2);
            foreach (var fieldInfo in t.GetType().GetFields())
            {
                writer.Write(fieldInfo.Name + " = ");
                var value = fieldInfo.GetValue(t);
                if (value.GetType().IsByRef)
                    PrintHelper(value, writer, map);
                else
                    writer.Write(value.ToString());
                writer.WriteLine();
            }
            writer.EndBlock();
        }
    }
}