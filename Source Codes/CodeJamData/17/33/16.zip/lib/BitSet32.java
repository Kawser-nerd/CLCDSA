package lib;

// TODO 어설션?
public class BitSet32 {

    public static int singleton(int e) {
        return 1 << e;
    }

    public static boolean contains(int set, int e) {
        return (set & (1 << e)) != 0;
    }

    public static int inserted(int set, int e) {
        return set + (1 << e);
    }

    public static int size(int set) {
        return Integer.bitCount(set);
    }

}
