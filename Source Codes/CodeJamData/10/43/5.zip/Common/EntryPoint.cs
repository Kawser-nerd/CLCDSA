﻿/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;

namespace CodeJam
{
    class EntryPoint
    {
        [STAThread]
        static void Main(String[] args)
        {
            Run(Config.ProgramToRun);
        }
        
        static void Run(String problemName)
        {
            var solution = (SolutionBase)Activator.CreateInstance(Type.GetType(typeof(EntryPoint).Namespace + "." + problemName));

            var inFileName = Directory.GetFiles(Config.inputPath, problemName + "*" + ".in").Where(file => File.GetLastWriteTime(file) >= DateTime.Now.AddMinutes(-2)).SingleOrDefault();
            if (inFileName == null)
            {
                string sampleDataPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, problemName + "-sample.txt");
                if (!File.Exists(sampleDataPath) || File.ReadAllText(sampleDataPath).Trim().Length == 0)
                    solution.Solve();
                else
                    verifySample(solution, File.ReadAllLines(sampleDataPath));
            }
            else
            {
                String outputDir = Path.Combine(Config.outputPath, DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss"));
                Directory.CreateDirectory(outputDir);
                String outputFilePath = Path.Combine(outputDir, problemName + ".out");

                TextWriter originalConsoleOut = Console.Out;

                using (var outputFile = new StreamWriter(File.OpenWrite(outputFilePath), Encoding.ASCII))
                using (var outputWriter = new TeeWriter(outputFile, Console.Out))
                using (var inFile = File.OpenText(inFileName))
                {
                    Console.SetIn(inFile);
                    Console.SetOut(outputWriter);
                    try
                    {
                        solution.Solve();
                    }
                    finally
                    {
                        Console.Out.Flush();
                        Console.SetOut(originalConsoleOut);
                    }
                }
                if (inFileName.Contains("small"))
                    File.Move(inFileName, Path.Combine(outputDir, problemName + ".in"));
                var args = String.Format(Config.archiverArgs, Path.Combine(outputDir, "source.zip"), Config.sourcePath);
                Process.Start(Config.archiverPath, args);

                Clipboard.SetText(outputFilePath);
            }
        }

        private static void verifySample(SolutionBase solution, string[] sample)
        {
            var trimmed = sample.Where(s => s.Trim().Length > 0);
            var output = trimmed.SkipWhile(l => !l.StartsWith("Case #1:"));
            var input = trimmed.TakeWhile(l => !l.StartsWith("Case #1:"));

            StringWriter outWriter = new StringWriter();
            foreach (string s in output)
                outWriter.WriteLine(s);
            StringWriter inWriter = new StringWriter();
            foreach (string s in input)
                inWriter.WriteLine(s);

            StringWriter realOutWriter = new StringWriter();
            TextWriter consoleOut = Console.Out;

            Console.SetIn(new StringReader(inWriter.ToString()));
            Console.SetOut(new TeeWriter(realOutWriter, consoleOut));

            solution.Solve();

            Console.SetOut(consoleOut);

            var str1 = realOutWriter.ToString();
            var str2 = outWriter.ToString();
            if (str1 == str2)
            {
                Console.WriteLine("");
                Console.WriteLine("    *** Correct ***");
                Console.WriteLine("");
            }
            else
            {
                Console.WriteLine("");
                Console.WriteLine("!!!!! INCORRECT !!!!!");
                Console.WriteLine("");
            }
        }
    }
}
