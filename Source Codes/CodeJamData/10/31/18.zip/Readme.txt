Requires: Visual Studio 2008 & .Net 3.5

Also, a reference may need to be added for the assembly: Oyster.IntX.dll
This is a publicly availlable assembly for handling large integers.
The source code for it can be found at: http://intx.codeplex.com/



INSTRUCTIONS:

0) The algorithm for the problem will be found in the file ProblemX.cs, where X is A,B,C, or D. The other code is a support framework to make solving the problems more effcient.

1) Compile in Visual Studio 2008

2) The executable is CodeJam.exe and will be found in the directory product/CodeJam/bin/..../ 

3) Place the input file in the directory "Input/" found in the executable directory.  The input file must begin with the letter "A", "B", "C" or "D".  The program framework will only load the problem algorithm (ProblemA, ProblemB, ProblemC or ProblemD) corresponding to the name of the input file.  Further, only one input file should be in the "Input/" directory while executing.

4) Run CodeJam.exe

5) Output will be writen to the directory "Output/", and also to the console.
