#include<iostream>
#include<limits>
#include<queue>
#include<cassert>

using namespace std;

typedef unsigned long UL;
typedef signed long SL;

const SL max_V=100;

struct graph
{
	SL V;
	struct
	{
		SL sz;
		SL v[max_V]; //vertex
		SL f[max_V]; //capacity
		SL c[max_V]; //flow
		SL opp_index[max_V]; //adjl[adjl[x].v[y]].v[adjl[x].opp_index[y]] == x
	}adjl[max_V];
};

const SL inv = numeric_limits<SL>::max();

SL augment(graph &g, const SL s, const SL t)
{
	struct
	{
		SL v, index;
	}prev[max_V];
	for(SL i=0; i<g.V; ++i)
	{
		prev[i].v=inv;
		prev[i].index=inv;
	}
	bool visited[max_V]={0}; //all false
	queue<SL> q;
	visited[s]=true;
	q.push(s);
	while(!q.empty())
	{
		SL cur=q.front();q.pop();
		for(SL i=0; i<g.adjl[cur].sz; ++i)
		{
			const SL x=g.adjl[cur].v[i];
			if(!visited[x] && g.adjl[cur].c[i])
			{
				visited[x]=true;
				prev[x].v=cur;
				prev[x].index=i;
				if(x==t) //early termination
					goto ZZZZ; //multilevel break
				q.push(x);
			}
		}
	}
	ZZZZ: //target for multilevel break
	if(!visited[t]) //no augmenting path, max flow has been reached
		return inv;
	SL add_flow = inv;
	SL cur_v=t;
	while(cur_v != s)
	{
		const SL prev_v = prev[cur_v].v;
		const SL cap = g.adjl[prev_v].c[prev[cur_v].index];
		if(cap<add_flow)
			add_flow=cap;
		cur_v = prev_v;
	}
	assert(add_flow>0);
	//Additional flow determined. Now update flows and capacities
	
	cur_v=t;
	while(cur_v !=s)
	{
		const SL prev_v = prev[cur_v].v;
		const SL prev_ind = prev[cur_v].index; //index of cur_v in the adjl of prev_v
		assert(g.adjl[prev_v].v[prev_ind] == cur_v);
		
		const SL cur_ind = g.adjl[prev_v].opp_index[prev_ind]; //index of prev_v in the adjl of cur_v
		assert(g.adjl[cur_v].v[cur_ind] == prev_v);
		
		g.adjl[prev_v].f[prev_ind] += add_flow;
		g.adjl[prev_v].c[prev_ind] -= add_flow;
		
		g.adjl[cur_v].f[cur_ind] -= add_flow;
		g.adjl[cur_v].c[cur_ind] += add_flow;
		
		assert(g.adjl[cur_v].c[cur_ind]>=0);
		assert(g.adjl[prev_v].c[prev_ind] >=0);
		
		cur_v=prev_v;
	}
	return add_flow;
}


int main()
{
	graph g;
	SL E;
	cin>>g.V>>E;
	for(SL i=0; i<g.V; ++i)
		g.adjl[i].sz=0;
	const SL s=0, t=g.V-1;
	SL pos[max_V][max_V]; //pos[i][j] : position of j i the adjl of i, if it exists; inv otherwise
	for(SL i=0; i<g.V; ++i)
		for(SL j=0; j<g.V; ++j)
			pos[i][j] = inv;
	for(SL i=0; i<E; ++i)
	{
		SL x,y,c;
		cin>>x>>y>>c;
		if(pos[x][y] == inv) //xy and yx haven't occured yet
		{
			SL &x_sz = g.adjl[x].sz;
			SL &y_sz = g.adjl[y].sz;
			g.adjl[x].v[x_sz] = y;
			g.adjl[x].f[x_sz] = 0;
			g.adjl[x].c[x_sz] = c;
			g.adjl[x].opp_index[x_sz]=y_sz;
			pos[x][y] = x_sz;
			
			g.adjl[y].v[y_sz] = x;
			g.adjl[y].f[y_sz] = 0;
			g.adjl[y].c[y_sz] = 0;
			g.adjl[y].opp_index[y_sz]=x_sz;
			pos[y][x] = y_sz;
			++x_sz;
			++y_sz;
		}
		else //yx has occured
			g.adjl[x].c[pos[x][y]] = c;
	}
	
	SL tot_flow=0;
	while(true)
	{
		const SL cur_flow = augment(g,s,t);
		if(cur_flow == inv)
			break;
		tot_flow+=cur_flow;
	}
	cout<<tot_flow<<endl;
}
