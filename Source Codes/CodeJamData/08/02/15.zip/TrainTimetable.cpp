#include <vector>
#include <list>
#include <sstream>
#include <algorithm>

#include "TrainTimetable.h"
#include "Utils.h"


TrainTimetable::TrainTimetable(std::istream &in, std::string &out, boost::condition &c, char &f)
	: Task(out, c, f)
{
	std::istringstream	input_t;
	std::istringstream	input_nab;
	std::string			str;
	unsigned long		ch1;
	unsigned long		h,m;

	GetString(in, str);

	input_t.str(str);
	input_t >> t;
	GetString(in, str);
	input_nab.str(str);
	
	input_nab >> na >> nb;

	for(ch1 = 0; ch1 < na; ch1++)
	{
		std::istringstream	input_time;
		GetString(in, str);
		input_time.str(str);
		input_time >> h;
		input_time.ignore();
		input_time >> m;
		a_departure[ch1] = h * 60 + m;
		input_time >> h;
		input_time.ignore();
		input_time >> m;
		a_arrival[ch1] = h * 60 + m;
	}

	for(ch1 = 0; ch1 < nb; ch1++)
	{
		std::istringstream	input_time;
		GetString(in, str);
		input_time.str(str);
		input_time >> h;
		input_time.ignore();
		input_time >> m;
		b_departure[ch1] = h * 60 + m;
		input_time >> h;
		input_time.ignore();
		input_time >> m;
		b_arrival[ch1] = h * 60 + m;
	}
}

TrainTimetable::TrainTimetable(TrainTimetable &n) : Task(n)
{
	t = n.t;
	na = n.na;
	nb = n.nb;
	memcpy(a_departure, n.a_departure, na * sizeof(unsigned long));
	memcpy(a_arrival, n.a_arrival, na * sizeof(unsigned long));
	memcpy(b_departure, n.b_departure, nb * sizeof(unsigned long));
	memcpy(b_arrival, n.b_arrival, nb * sizeof(unsigned long));
}


TrainTimetable::~TrainTimetable()
{
}

void TrainTimetable::operator()()
{
	std::ostringstream	output;
	unsigned long		a_ch;
	unsigned long		b_ch;
	unsigned long		a_start;
	unsigned long		b_start;

	a_start = 0;
	b_start = 0;
	std::sort(a_departure, a_departure + na);
	std::sort(a_arrival, a_arrival + na);
	std::sort(b_departure, b_departure + nb);
	std::sort(b_arrival, b_arrival + nb);

	/*A->B*/
	for(a_ch = 0, b_ch = 0; a_ch < na; a_ch++)
	{
		if(b_ch >= nb || a_departure[a_ch] < (b_arrival[b_ch] + t))
			a_start++;
		else
			b_ch++;
	}

	/*B->A*/
	for(a_ch = 0, b_ch = 0; b_ch < nb; b_ch++)
	{
		if(a_ch >= na || b_departure[b_ch] < (a_arrival[a_ch] + t))
			b_start++;
		else
			a_ch++;
	}

	output << a_start << " " << b_start;
	result = output.str();

	flag = 1;
	finish.notify_all();
}
