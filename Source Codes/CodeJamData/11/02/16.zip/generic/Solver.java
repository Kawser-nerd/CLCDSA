package generic;

public interface Solver{

	public String solveCase();
}