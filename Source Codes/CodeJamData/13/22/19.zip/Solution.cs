﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;

namespace codejam
{
    public partial class MyApp
    {
        public void RunOnce()
        {
            
        }

        int sx = 20;
        int bx, by;
        int total, caido;
        public string Resolver(StreamReader sr)
        {
            int n;
            string[] temp = ml.split(sr);
            ml.put(temp, out n, out bx, out by);

            if (Math.Abs(bx) > sx-1 || Math.Abs(by) > sx-1)
                return "0.0";

            bx += sx;

            bool[,] f = new bool[sx*2, sx];

            total = 0;
            caido = 0;

            fall(f, n);

            float res = (float)caido / (float)total;

            return res.ToString("0.00000000000").Replace(",",".");
        }

        void fall(bool[,] f, int n)
        {
            if (n == 0)
            {
                //Cayeron todos!!!
                total++;
                
                if (f[bx, by])
                    caido++;
                return;
            }

            if (!f[sx, 0])
            {
                f[sx, 0] = true;
                fall(f, n - 1);
                return;
            }

            int y;
            for (y = sx-1; !f[sx, y]; y--) ;
            y+=2;

            bool ml = canmoveLeft(f, sx, y), mr = canmoveRight(f, sx, y);

            if (canmoveLeft(f, sx, y))
            {
                bool[,] ff = (bool[,])f.Clone();
                int yy = y;
                int xx = sx;

                while (canmoveLeft(ff, xx, yy))
                {
                    xx--;
                    yy--;
                }

                ff[xx, yy] = true;
                fall(ff, n - 1);
            }

            if (canmoveRight(f, sx, y))
            {
                bool[,] ff = (bool[,])f.Clone();
                int yy = y;
                int xx = sx;

                while (canmoveRight(ff, xx, yy))
                {
                    xx++;
                    yy--;
                }

                ff[xx, yy] = true;
                fall(ff, n - 1);
            }

            if (!ml && !mr)
            {
                f[sx, y] = true;
                fall(f, n - 1);
            }
            
        }

        bool canmoveLeft(bool[,] f, int x, int y)
        {
            if (y == 0)
                return false;
            return !f[x - 1, y - 1];
        }

        bool canmoveRight(bool[,] f, int x, int y)
        {
            if (y == 0)
                return false;
            return !f[x + 1, y - 1];
        }
    }
}
