﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Marius.CodeJam
{
    public class PasswordProblem: IParalelSolver
    {
        private int A, B;
        private decimal[] p;
        private decimal _answer;

        public void ReadInput()
        {
            var input = Console.ReadLine().Split().Select(s => int.Parse(s)).ToArray();
            A = input[0];
            B = input[1];

            p = Console.ReadLine().Split().Select(s => decimal.Parse(s)).ToArray();
        }

        public void WriteAnswer(int caseNumber)
        {
            Console.WriteLine("Case #{0}: {1:F6}", caseNumber, _answer);
        }

        public void SolveAsync()
        {
            var count = 0;
            var prob = 1m;
            var exp = 0m;

            _answer = decimal.MaxValue;

            for (int i = 1; i <= A; i++)
            {
                count = A - i + B - i + 1;
                prob = prob * p[i - 1];

                exp = prob * count + (1 - prob) * (count + B + 1);
                if (exp < _answer)
                    _answer = exp;
            }

            // enter case:
            if ((1 + B + 1) < _answer)
                _answer = (1 + B + 1);
        }
    }
}
