﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Security.Policy;
using Cmn.Util;
using Gcj.Util;

namespace Gcj.Y2014.R1B.B
{
    public class BSolver : IConcurrentSolver
    {
        public int CCaseGet(Pparser pparser)
        {
            return pparser.Fetch<int>();
        }

        public ConcurrentGcjSolver.DgSolveCase DgSolveCase(Pparser pparser)
        {
            int A, B, K;
            pparser.Fetch(out A, out B, out K);
            return () => Solve(A, B, K);
        }

        private IEnumerable<object> Solve(int A, int B, int K)
        {
            int cOk = 0;
            for (int i = 0; i < A; i++)
            {
                for (int j = 0; j < B; j++)
                {

                    var z = i & j;

                    if (z < K)
                        cOk++;

                }
            }


            yield return cOk;
        }

        int[] ToBin(int i)
        {
            if (i == 0)
            {
                return new int[]{0};
            }

            var rgb = new List<int>();
                
            while (i > 0)
            {
                rgb.Insert(0, i % 2 == 0 ? 0 : 1);
                i /= 2;
            }

            return rgb.ToArray();
        }
    }
}
