package jam;

import java.util.Scanner;

/**
 * @author Bergmann Gábor
 *
 */
public class C {
	public static void main(String[] args) {
		new C().run();
	}


	int cells;
	int[] prisoners;
	int[][] subsolution;
	
	
	private void run() {
		Scanner sc = new Scanner(System.in); 
		int cases = sc.nextInt();
	    for (int thisCase = 0; thisCase < cases; thisCase++ ) {
	    	cells = sc.nextInt();
	    	int q = sc.nextInt();
	    	prisoners = new int[q+2];
	    	prisoners[0] = 0; prisoners[q+1] = cells+1;
	    	for (int i=0; i<q; i++) prisoners[i+1] = sc.nextInt();
//	    	System.out.println("*");
//	    	for (int i=0; i<prisoners.length; i++) System.out.print(prisoners[i]+" ");
//	    	System.out.println("*");
	    	
	    	subsolution=new int[q+2][q+2];
	    	for (int left=0; left<subsolution.length-1; left++) subsolution[left][left+1] = 0;
	    	for (int diff=2; diff<subsolution.length; diff++)
	    		for (int left=0; left<subsolution.length-diff; left++)
	    		{
	    			int best = Integer.MAX_VALUE;
	    			for (int div = 1; div<diff; div++) {
	    				int candidate = subsolution[left][left+div] + subsolution[left+div][left+diff];
	    				if (candidate<best) best = candidate;
	    			}
	    			subsolution[left][left+diff] = best + prisoners[left+diff] - prisoners[left] - 2;
	    		}
//	    	System.out.println("*");
//	    	for (int diff=1; diff<subsolution.length; diff++)
//	    		for (int left=0; left<subsolution.length-diff; left++)
//	    			System.out.println(left+"-"+(left+diff)+":"+subsolution[left][left+diff]);
//	    	System.out.println("*");

    		System.out.println("Case #"+(thisCase+1)+": " + subsolution[0][subsolution.length-1]);
	    }

	}

}
