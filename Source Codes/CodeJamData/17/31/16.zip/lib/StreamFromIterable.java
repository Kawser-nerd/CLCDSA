package lib;

import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public class StreamFromIterable {

    public static <T> Stream<T> get(Iterable<T> iterable) {
        return StreamSupport.stream(iterable.spliterator(), false);
    }

}
