﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright>
//    Copyright © 2013 Daisuke Takahashi
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace CodeJam2013.C
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.IO;

    /// <summary>
    /// Manages a case of the problem
    /// </summary>
    internal class Case
    {
        private static readonly Random R = new Random();

        private int r, n, m, k;
        private ulong[][] prodsSet;
        private object answer;

        // @TODO: (1) Put fields to hold the problem data here

        /// <summary>
        /// Prevents a default instance of the <see cref="Case" /> class from being created.
        /// </summary>
        /// <param name="r">The r.</param>
        /// <param name="n">The n.</param>
        /// <param name="m">The m.</param>
        /// <param name="k">The k.</param>
        /// <param name="prodsSet">The prods.</param>
        private Case(int r, int n, int m, int k, ulong[][] prodsSet)
        {
            this.r = r;
            this.n = n;
            this.m = m;
            this.k = k;
            this.prodsSet = prodsSet;
            this.answer = null;
        }

        /// <summary>
        /// Gets a value indicating whether this case <see cref="Case" /> has been solved.
        /// </summary>
        public bool IsSolved
        {
            get { return this.answer != null; }
        }

        /// <summary>
        /// Gets the answer.
        /// </summary>
        /// <exception cref="System.InvalidOperationException">The problem has not been solved yet.</exception>
        public object Answer
        {
            get
            {
                if (!this.IsSolved)
                {
                    throw new InvalidOperationException("The problem has not been solved yet.");
                }

                return this.answer;
            }
        }

        /// <summary>
        /// Loads a new test case from the stream.
        /// </summary>
        /// <param name="sr">The stream reader object which the case is to be loaded from.</param>
        /// <returns>A new instance of <see cref="Case"/> class.</returns>
        // ReSharper disable PossibleNullReferenceException
        public static Case Load(StreamReader sr)
        {
            var line1 = new Tokeniser(sr.ReadLine());
            var r = line1.ReadInt32();
            var n = line1.ReadInt32();
            var m = line1.ReadInt32();
            var k = line1.ReadInt32();
            var prodsSet = new ulong[r][];
            for (var i = 0; i < r; ++i)
            {
                prodsSet[i] = new ulong[k];
                var line = new Tokeniser(sr.ReadLine());
                for (var j = 0; j < k; ++j)
                {
                    prodsSet[i][j] = line.ReadUInt64();
                }
            }

            return new Case(r, n, m, k, prodsSet);
        }
        // ReSharper restore PossibleNullReferenceException

        /// <summary>
        /// Solves this case.
        /// </summary>
        [SuppressMessage("StyleCop.CSharp.LayoutRules", "SA1501:StatementMustNotBeOnSingleLine", Justification = "Reviewed. Suppression is OK here.")]
        public void Solve()
        {
            if (this.IsSolved)
            {
                return;
            }

            var answerStrings = new string[this.r];
            for (var i = 0; i < this.r; ++i)
            {
                var answerChars = new char[this.n];

                var prods = this.prodsSet[i];
                var isEverything1 = true;
                var isExact2There = false;
                var isExact4There = false;
                var isExact8There = false;
                var isExact16There = false;
                int countOf2 = 0, countOf3 = 0, countOf5 = 0, countOf7 = 0;
                int totalOf2 = 0, totalOf3 = 0, totalOf5 = 0, totalOf7 = 0;

                foreach (var prod in prods)
                {
                    if (prod == 1) { continue; }

                    isEverything1 = false;
                    if (prod == 2) { isExact2There = true; }
                    var countOf2X = Factorization.HowManyTimeWeCanDevideBy2(prod);
                    var countOf3X = Factorization.HowManyTimeWeCanDevideBy3(prod);
                    var countOf5X = Factorization.HowManyTimeWeCanDevideBy5(prod);
                    var countOf7X = Factorization.HowManyTimeWeCanDevideBy7(prod);
                    if (countOf2 < countOf2X) { countOf2 = countOf2X; }
                    if (countOf3 < countOf3X) { countOf3 = countOf3X; }
                    if (countOf5 < countOf5X) { countOf5 = countOf5X; }
                    if (countOf7 < countOf7X) { countOf7 = countOf7X; }

                    totalOf7 += countOf7X;
                }

                // if everything is 1, generate the answer randomly.
                if (isEverything1)
                {
                    for (var j = 0; j < this.n; ++j)
                    {
                        answerChars[j] = (char)('0' + R.Next(2, this.m + 1));
                    }

                    answerStrings[i] = new string(answerChars);
                    continue;
                }

                var determined = 0;
                if (isExact2There) { answerChars[determined++] = '2'; }
                while (--countOf3 >= 0) { answerChars[determined++] = '3'; }
                while (--countOf5 >= 0) { answerChars[determined++] = '5'; }
                while (--countOf7 >= 0) { answerChars[determined++] = '7'; }

                var remaining = this.n - determined;
                switch (remaining)
                {
                    case 0:
                        break;
                    case 1:
                        this.Remaining1(answerChars, ref determined, countOf2);
                        break;
                    case 2:
                        this.Remaining2(answerChars, ref determined, countOf2);
                        break;
                    default:
                        this.Remaining3(answerChars, ref determined, countOf2);
                        break;
                }

                remaining = this.n - determined;
                if (remaining == 0)
                {
                    answerStrings[i] = new string(answerChars);
                    continue;
                }

                for (var j = determined; j < this.n; ++j)
                {
                    answerChars[j] = (char)('0' + R.Next(2, this.m + 1));
                }

                answerStrings[i] = new string(answerChars);
            }

            this.answer = "\n" + string.Join("\n", answerStrings);
        }

        private void Remaining1(char[] answerChars, ref int determined, int countOf2)
        {
            switch (countOf2)
            {
                case 1:
                    answerChars[determined++] = '2';
                    break;
                case 2:
                    answerChars[determined++] = '4';
                    break;
            }
        }

        private void Remaining2(char[] answerChars, ref int determined, int countOf2)
        {
            switch (countOf2)
            {
                case 2:
                    answerChars[determined++] = '2';
                    answerChars[determined++] = '2';
                    break;
                case 3:
                    answerChars[determined++] = '2';
                    answerChars[determined++] = '4';
                    break;
                case 4:
                    answerChars[determined++] = '4';
                    answerChars[determined++] = '4';
                    break;
            }
        }

        private void Remaining3(char[] answerChars, ref int determined, int countOf2)
        {
            switch (countOf2)
            {
                case 3:
                    answerChars[determined++] = '2';
                    answerChars[determined++] = '2';
                    answerChars[determined++] = '2';
                    break;
                case 4:
                    answerChars[determined++] = '2';
                    answerChars[determined++] = '2';
                    answerChars[determined++] = '4';
                    break;
                case 5:
                    answerChars[determined++] = '2';
                    answerChars[determined++] = '4';
                    answerChars[determined++] = '4';
                    break;
                case 6:
                    answerChars[determined++] = '4';
                    answerChars[determined++] = '4';
                    answerChars[determined++] = '4';
                    break;
            }
        }
    }

    internal static class Factorization
    {
        public static int HowManyTimeWeCanDevideBy2(ulong number)
        {
            return HowManyTimeWeCanDevideByX(number, 2);
        }

        public static int HowManyTimeWeCanDevideBy3(ulong number)
        {
            return HowManyTimeWeCanDevideByX(number, 3);
        }

        public static int HowManyTimeWeCanDevideBy5(ulong number)
        {
            return HowManyTimeWeCanDevideByX(number, 5);
        }

        public static int HowManyTimeWeCanDevideBy7(ulong number)
        {
            return HowManyTimeWeCanDevideByX(number, 7);
        }

        private static int HowManyTimeWeCanDevideByX(ulong number, ulong X)
        {
            var result = 0;
            while (number % X == 0)
            {
                number /= X;
                ++result;
            }

            return result;
        }
    }
}
