#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cassert>
#include <algorithm>
#include <string>
#include <vector>
#include <deque>
#include <map>
#include <set>

using namespace std;

#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#define pb push_back
#define mp make_pair
#define sz(x) ((int)(x).size())
#define forn(i, n) for (int i = 0; i < (n); i++)

typedef long long ll;

typedef vector<ll> vll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;
typedef pair<int, int> pii;

void read() {
  scanf("%*s");
}

bool endsWith(string a, string b) {
  return a.length() >= b.length() && string(a, a.length() - b.length()) == b;
}

int main(int argc, char *argv[]) {
  string fn = "";
  {
    if (argc >= 2) fn = argv[1];
    if (endsWith(fn, ".in")) fn = string(fn, 0, fn.length() - 3);
    assert(freopen((fn + ".in").c_str(), "rb", stdin));
  }

  int TC;
  assert(scanf("%d", &TC) >= 1);
  for (int TN = 1; TN <= TC; TN++) {
    int startPos = ftell(stdin);
    read();
    int endPos = ftell(stdin);
    int toRead = endPos - startPos;
    assert(toRead >= 1);

    fseek(stdin, startPos, SEEK_SET);
    
    static char name[128];
    snprintf(name, sizeof name, "%s-%03d.in", fn.c_str(), TN);
    freopen(name, "wb", stdout);
    printf("-%d\n", TN);

    char* buf = (char*)malloc(toRead + 1);
    fread(buf, 1, toRead, stdin);
    buf[toRead] = 0;
    fwrite(buf, 1, toRead, stdout);
    free(buf);

    fseek(stdin, endPos, SEEK_SET);
    fclose(stdout);
  }
  return 0;
}
