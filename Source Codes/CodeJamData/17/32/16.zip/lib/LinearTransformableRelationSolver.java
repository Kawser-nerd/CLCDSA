package lib;

import java.util.function.BinaryOperator;

// 이름이 어색하다
public class LinearTransformableRelationSolver {

    public static <T> Row<T> calc(int stage, int n, Row<T> initRow, WeightFunction<T> weight, BinaryOperator<Matrix<T>> multiplier) {
        Matrix<T> init = ColumnMatrix.of(new Vector<T>(n, initRow::get));
        Matrix<T> transformation = FlattenMatrix.create(new Matrix<T>(n, n, weight::get));
        Matrix<T> power = Power.calc(transformation, stage, multiplier);
        Matrix<T> result = multiplier.apply(power, init);
        return index -> result.element.at(index, 0);
    }

}
