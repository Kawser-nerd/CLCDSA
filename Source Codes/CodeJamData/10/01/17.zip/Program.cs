﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;

namespace CodeJam2010SnapperChain
{
    public class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                Console.WriteLine("Usage: " + Process.GetCurrentProcess().MainModule.FileName + " <input filename>");
                return;
            }

            Run(args[0]);
        }

        private static void Run(string filename)
        {
            using (TextReader reader = new StreamReader(filename))
            {
                using (TextWriter fileWriter = new StreamWriter(filename + ".output.txt", false, Encoding.ASCII))
                {
                    using (TextWriter consoleWriter = Console.Out)
                    {
                        MultipleTextWriters writers = new MultipleTextWriters(fileWriter, consoleWriter);
                        Run(reader, writers);
                    }
                }
            }
        }

        private static void Run(TextReader reader, MultipleTextWriters writers)
        {
            int numTests = reader.ReadLineInts()[0];
            Console.WriteLine(numTests + " tests");
            for (int i = 0; i != numTests; ++i)
            {
                writers.Write("Case #" + (i + 1) + ": ");
                RunTest(writers, reader);
                writers.Write(Environment.NewLine);
            }
        }

        private static void RunTest(MultipleTextWriters writer, TextReader reader)
        {
            var test = reader.ReadLineLongs();
            long n = test[0];
            long k = test[1];

            long bigN = 1 << (int)n;
            long modulo = k % bigN;
            bool on = (modulo == bigN - 1);
            writer.Write(on ? "ON" : "OFF");
        }
    }
}