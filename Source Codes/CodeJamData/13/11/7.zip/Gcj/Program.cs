﻿using Gcj.Util;
using Gcj.Y2012.R1A.C;
using Gcj.Y2013.R1A.A;

namespace Gcj
{
    class Program
    {
        static void Main(string[] args)
        {
            ConcurrentGcjSolver.Solve<BullsEyeSolver>(false);
        }
    }
}
