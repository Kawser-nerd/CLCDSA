﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;

namespace GCJ2015Round1C_3
{
	class CCTrimmer : IPermutatorArrayTrimmer<int>
	{
		private List<int> coins;

		public CCTrimmer(List<int> coins)
		{
			this.coins = coins;
		}

		public bool TrimNeeded(int[] currentBoard, int lastAddedI, Dictionary<int, int> appearanceCounter)
		{
			foreach (var coin in this.coins)
			{
				if (appearanceCounter[coin] > 1)
					return true;
			}
			return false;
		}
	}

	public class Solver : SolverBase
	{
		public class Coin
		{
			public Coin(long m, long d)
			{
				this.m = m;
				this.d = d;
			}

			public long m;
			public long d;
			public double speed
			{
				get
				{
					return 360.0 / this.m;
				}
			}
		}
		public const string INPUT_NAME = "smallpractice";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = false;

		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		public override string SolveTestCase(int testCase)
		{
			var info = GetIntList();
			var C = info[0];
			var D = info[1];
			var V = info[2];
			var coins = GetIntList();

			if (C != 1)
			{
				return ":(";
			}

			if (CanBuyAll(D, V, coins))
			{
				return "0";
			}

			var noncoins = new List<int>();
			for (int i = 1; i < V; i++)
			{
				if (!coins.Contains(i))
					noncoins.Add(i);
			}

			for (int i = 1; i <= V; i++)
			{
				Permutator<int> permutator = new Permutator<int>(noncoins, -1);
				foreach (var perm in permutator.GetArrayPermutations(i, new CCTrimmer(noncoins)))
				{
					var newCoins = new List<int>(coins);
					newCoins.AddRange(perm);
					if (CanBuyAll(D, V, newCoins))
					{
						Print(perm);
						return i.ToString();
					}
				}
			}

			return ":/";
		}

		private static bool CanBuyAll(int D, int V, List<int> coins)
		{
			bool[] canBuy = new bool[V + 1];
			CanBuyAllIn(V, coins, 0, canBuy);

			bool result = true;
			for (int i = 0; i <= V; i++)
			{
				result = result && canBuy[i];
			}

			return result;

		}

		private static void CanBuyAllIn(int V, List<int> coins, int shift, bool[] canBuy)
		{
			if (shift > V)
				return;
			canBuy[shift] = true;
			if(coins.Count == 0)
				return;
			var newCoins = new List<int>(coins);
			foreach (var coin in coins)
			{
				newCoins.Remove(coin);
				CanBuyAllIn(V, newCoins, shift + coin, canBuy);
			}
		}

		private static bool CanBuyAll2(int D, int V, List<int> coins)
		{
			bool[] canBuy = new bool[V + 1];
			canBuy[0] = true;

			Permutator<int> permutator = new Permutator<int>(coins.Union(new[] { 0 }), -1);
			foreach (var permutation in permutator.GetArrayPermutations(D, new CCTrimmer(coins)))
			{
				var sum = permutation.Sum();
				if (sum <= V)
				{
					canBuy[sum] = true;
				}
			}

			bool result = true;
			for (int i = 0; i <= V; i++)
			{
				result = result && canBuy[i];
			}

			return result;
		}
	}
}
