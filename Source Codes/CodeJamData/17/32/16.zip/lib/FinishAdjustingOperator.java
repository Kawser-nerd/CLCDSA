package lib;

import java.util.function.BinaryOperator;
import java.util.function.UnaryOperator;

public class FinishAdjustingOperator {
    public static <T> BinaryOperator<T> of(BinaryOperator<T> originalOperator, UnaryOperator<T> finishOperator) {
        return (v1, v2) -> {
            T original = originalOperator.apply(v1, v2);
            return finishOperator.apply(original);
        };
    }

}
