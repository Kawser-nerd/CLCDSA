﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace RopeIntranet
{
    /// <summary>
    /// .net 3.5
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            var inFile = String.Empty;
            var outFile = String.Empty;

            for (var i = 0; i < args.Length; i++)
            {
                switch (args[i])
                {
                    case "-i":
                        inFile = args[++i];
                        break;
                    case "-o":
                        outFile = args[++i];
                        break;
                }
            }

            if (!String.IsNullOrEmpty(inFile) && !String.IsNullOrEmpty(outFile))
            {
                using (var reader = new StreamReader(inFile))
                using (var writer = new StreamWriter(outFile))
                {
                    var p = new Program();
                    p.Run(reader, writer);
                }
            }
        }

        private void Run(StreamReader reader, StreamWriter writer)
        {
            var stopwatch = Stopwatch.StartNew();

            var caseCount = int.Parse(reader.ReadLine());
            for (var i = 0; i < caseCount; i++)
            {
                var buffer = reader.ReadLine();
                var n = int.Parse(buffer);
                var wires = new List<Wire>(n);
                for (var w = 0; w < n; w++)
                {
                    buffer = reader.ReadLine();
                    var values = buffer.Split(' ').Select(s => int.Parse(s)).ToArray();
                    wires.Add(new Wire { A = values[0], B = values[1] });
                }
                var result = Solve(wires);
                writer.WriteLine("Case #{0}: {1}", i + 1, result);
            }

            Console.WriteLine("Time:{0}", stopwatch.Elapsed);
        }

        private int Solve(IEnumerable<Wire> wires)
        {
            var orderByA = wires.OrderBy(w => w.A).ToArray();

            var count = 0;

            for (var i = 0; i < orderByA.Length; i++)
            {
                for (var j = i + 1; j < orderByA.Length; j++)
                {
                    if (orderByA[j].B < orderByA[i].B) count++;
                }
            }

            return count;
        }
    }

    class Wire
    {
        public int A { get; set; }
        public int B { get; set; }
    }
}
