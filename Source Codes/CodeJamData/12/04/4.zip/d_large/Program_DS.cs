﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;

namespace km.gcj.qual
{
    class ProgramDS
    {

        static void Main(string[] args)
        {
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            Logic(args);

            sw.Stop();
            Console.WriteLine(sw.Elapsed);
            Console.ReadLine();
        }

        static void Logic(string[] args)
        {
            Problem p = Problem.createProblem(args);
            if (p == null || p.inputLinesCount == 0)
            {
                return;
            }

            long repeat = p.getNextLineAsInt64Array()[0];
            for (int i = 0; i < repeat; i++)
            {
                long[] hwd = p.getNextLineAsInt64Array();
                ProgramDS.height = (int)hwd[0]; //  (ﾟдﾟ )
                ProgramDS.width = (int)hwd[1]; //  (ﾟдﾟ )
                ProgramDS.depth = (int)hwd[2]; //  (ﾟдﾟ )
                ProgramDS.depth_sq = ProgramDS.depth * ProgramDS.depth;
                var r = p.getNextLines(ProgramDS.height);
                ProgramDS.room = r.Select(x => x.ToCharArray().ToList()).ToList(); //  (ﾟдﾟ )
                for (int y = 0; y < ProgramDS.height; y++)
                {
                    for (int x = 0; x < ProgramDS.width; x++)
                    {
                        if (ProgramDS.room[y][x] == 'X')
                        {
                            startPosition = new { X = x, Y = y };
                            ProgramDS.room[y][x] = '.';
                        }
                    }
                }

                p.WriteAnswerFullLine(LookAround().ToString());
//                Console.WriteLine();
            }
        }

        private static List<List<char>> room;
        private static int height;
        private static int width;
        private static int depth;
        private static int depth_sq;
        private static dynamic startPosition;

        static long LookAround()
        {
            // （」・ω・）」はじまるよー！
            long ret = 0;
            if (LookLinear(new { X =  1, Y =  0 })) ret++;
            if (LookLinear(new { X = 0, Y = 1 })) ret++;
            if (LookLinear(new { X = -1, Y = 0 })) ret++;
            if (LookLinear(new { X = 0, Y = -1 })) ret++;
            for (int dx = 1 - ProgramDS.depth; dx < ProgramDS.depth; dx++)
            {
                if (dx == 0) continue; // （´・ω・｀）もうカウントしてるよ…
                int dx_sq = dx * dx;
                for (int dy = 1 - ProgramDS.depth; dy < ProgramDS.depth; dy++)
                {
                    if (dy == 0) { continue;} // （´・ω・｀）もうカウントしてるよ…

                    int dist_sq = dx_sq + dy * dy;
                    if (ProgramDS.depth_sq < dist_sq) { continue; } // （´・ω・｀）ちょっとその角度は無理じゃないかな……

                    if (Gcd(dx, dy) > 1) { continue; } // （´・ω・｀）すまない、互いに素じゃないんだ……
                    if (LookLinear(new { X = dx, Y = dy })) { ret++; } // (｀・ω・´) さあ、判定しようか！
                }
            }

            // （／・ω・）／答えを返すよ！
            return ret;
        }

        /// <summary>
        /// 辿ります。
        /// </summary>
        /// <param name="layDirection"></param>
        /// <returns></returns>
        static bool LookLinear(dynamic layDirection)
        {
            int denominator = layDirection.X * layDirection.Y * 2; // 分母値
            if (denominator < 0) denominator = -denominator; // 分母は正に
            if (denominator == 0) denominator = 2; // 分母は少なくとも2
            var avatarPos = new { X = ProgramDS.startPosition.X * denominator, Y = ProgramDS.startPosition.Y * denominator }; // 化身
            var layPos = new { X = ProgramDS.startPosition.X * denominator, Y = ProgramDS.startPosition.Y * denominator }; // 光線
            int distanseUnit = 0; // 進行距離(ユニット単位)

            return LookLinear(layDirection.X, layDirection.Y, avatarPos.X, avatarPos.Y, layPos.X, layPos.Y, denominator, distanseUnit);
        }

        /// <summary>
        /// 再帰で辿ります。
        /// </summary>
        /// <param name="layDirection"></param>
        /// <param name="avatarPos"></param>
        /// <param name="layPos"></param>
        /// <param name="denominator"></param>
        /// <param name="distanseUnit"></param>
        /// <returns></returns>
        static bool LookLinear(int layDX, int layDY, int avatarPX, int avatarPY, int layPX, int layPY, int denominator, int distanseUnit)
        {
            while (true)
            {
                // 光線が直進
                var newLayX = layPX + layDX;
                var newLayY = layPY + layDY;
                distanseUnit++;
                // 距離は光線係数＊進行距離
                double distanse = (double)distanseUnit * Math.Sqrt(
                    (double)(layDX * layDX + layDY * layDY)
                    );
                if (ProgramDS.depth * denominator < distanse) { 
                    return false; 
                } // 光線は減衰してしまった……

                // 見えた！
                if (newLayX == ProgramDS.startPosition.X * denominator && newLayY == ProgramDS.startPosition.Y * denominator) return true;

                // 直進？反射？消滅？
                if ((newLayX + denominator / 2) % denominator == 0 && (newLayY + denominator / 2) % denominator == 0)
                {
                    int cellX;
                    int cellY;
                    cellX = (newLayX + Math.Sign(layDX) * (denominator / 2)) / denominator;
                    cellY = (newLayY + Math.Sign(layDY) * (denominator / 2)) / denominator;
                    bool diag = ProgramDS.room[cellY][cellX] == '#';
                    cellX = (newLayX + Math.Sign(layDX) * (denominator / 2)) / denominator;
                    cellY = (newLayY - Math.Sign(layDY) * (denominator / 2)) / denominator;
                    bool hori = ProgramDS.room[cellY][cellX] == '#';
                    cellX = (newLayX - Math.Sign(layDX) * (denominator / 2)) / denominator;
                    cellY = (newLayY + Math.Sign(layDY) * (denominator / 2)) / denominator;
                    bool vert = ProgramDS.room[cellY][cellX] == '#';
                    if (diag)
                    {
                        if (hori && vert)
                        {
                            // 後退反射
                            if (depth * denominator < distanse * 2) {
                                return false; 
                            } // 今引き返しても、戻れないんだ……
                            else {
                                return true; 
                            } // 見えた！
                        }
                        else if (hori && !vert)
                        {
                            // 反射！
                            layDX = -layDX;
                            // 分身！
                            avatarPX = newLayX * 2 - avatarPX;
                        }
                        else if (!hori && vert)
                        {
                            // 反射！
                            layDY = -layDY;
                            // 分身！
                            avatarPY = newLayY * 2 - avatarPY;
                        }
                        else
                        {
                            // 消滅
                            return false;
                        }
                    }
                }
                else if ((newLayX + denominator / 2) % denominator == 0)
                {
                    int cellX;
                    int cellY;
                    cellX = (newLayX + Math.Sign(layDX) * (denominator / 2)) / denominator;
                    cellY = (newLayY + denominator / 2) / denominator;
                    bool hori = ProgramDS.room[cellY][cellX] == '#';
                    if (hori)
                    {
                        // 反射！
                        layDX = -layDX;
                        // 分身！
                        avatarPX = newLayX * 2 - avatarPX;
                    }
                }
                else if ((newLayY + denominator / 2) % denominator == 0)
                {
                    int cellX;
                    int cellY;
                    cellX = (newLayX + denominator / 2) / denominator;
                    cellY = (newLayY + Math.Sign(layDY) * (denominator / 2)) / denominator;
                    bool vert = ProgramDS.room[cellY][cellX] == '#';
                    if (vert)
                    {
                        // 反射！
                        layDY = -layDY;
                        // 分身！
                        avatarPY = newLayY * 2 - avatarPY;
                    }
                }
                else
                {
                }
                // まだっ、まだ見えないっ！
                layPX = newLayX;
                layPY = newLayY;
            }
        }

        static int Gcd(int a, int b)
        {
            if (a < 0) a = -a;
            if (b < 0) b = -b;
            if (a < b) return innerGcd(b, a);
            else return innerGcd(a, b);
        }

        static int innerGcd(int a, int b)
        {
            if (a < b) return innerGcd(b, a);
            if (b == 0) return a;
            return innerGcd(b,a%b);
        }

        // （」・ω・）」ソースここまで。
    }
}
