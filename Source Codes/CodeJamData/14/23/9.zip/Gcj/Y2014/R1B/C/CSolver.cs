﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Security.Permissions;
using System.Security.Policy;
using Cmn.Util;
using Gcj.Util;

namespace Gcj.Y2014.R1B.C
{
    public class CSolver : IConcurrentSolver
    {
        public int CCaseGet(Pparser pparser)
        {
            return pparser.Fetch<int>();
        }

        public ConcurrentGcjSolver.DgSolveCase DgSolveCase(Pparser pparser)
        {
            int ccity, cpath;
            pparser.Fetch(out ccity, out cpath);

            var rgzip = pparser.FetchN<string>(ccity);
            

            var mp = new Dictionary<int, HashSet<int>>();

            for(int i=0;i<cpath;i++)
            {
                int icityA, icityB;
                pparser.Fetch(out icityA, out icityB);
                if (!mp.ContainsKey(icityA))
                    mp[icityA] = new HashSet<int>();

                if (!mp.ContainsKey(icityB))
                    mp[icityB] = new HashSet<int>();

                mp[icityA].Add(icityB);
                mp[icityB].Add(icityA);
            }

            return () => Solve(rgzip.ToArray(), mp);
        }

        private IEnumerable<object> Solve(string[] rgzip, Dictionary<int, HashSet<int>> rgpath)
        {
            string zipMin = null;
            foreach (var rgcity in Rgpermute(Enumerable.Range(1, rgzip.Length).ToArray()))
            {
                if(!FHasPath(rgcity, rgpath))
                    continue;
                
                var zip = Zip(rgcity, rgzip);
                if (zipMin == null || BigInteger.Parse(zip) < BigInteger.Parse(zipMin))
                    zipMin = zip;

            }
            Console.Write(".");
            yield return zipMin;
        }

        private bool FHasPath(int[] rgcity, Dictionary<int, HashSet<int>> rgpath)
        {
            var icityAt = rgcity[0];
            var vrm = new Stack<int>();
            vrm.Push(icityAt);

            for (int i = 1; i < rgcity.Length; i++)
            {
                var icityTo = rgcity[i];
                icityAt = vrm.Peek();
                var fCanFly = rgpath[icityAt].Contains(icityTo);
                while(!fCanFly)
                {
                    vrm.Pop();

                    if (!vrm.Any())
                        return false;
                    icityAt = vrm.Peek();
                    fCanFly = rgpath[icityAt].Contains(icityTo);

                }

                vrm.Push(icityTo);
            }
            return true;

        }

        private string Zip(int[] rgcity, string[] rgzip)
        {
            string st = "";
            foreach (var icity in rgcity)
                st += rgzip[icity-1];
            return st;
        }


        private IEnumerable<int[]> Rgpermute(int[] rgst)
        {
            return Rgpermute(rgst, new List<int>(), new bool[rgst.Length]);

        }

        private IEnumerable<int[]> Rgpermute(int[] rgst, List<int> rgstout, bool[] fseen)
        {
            if (rgstout.Count == rgst.Length)
            {
                yield return rgstout.ToArray();
                yield break;
            }

            for (int i = 0; i < rgst.Length; i++)
            {
                if (!fseen[i])
                {
                    fseen[i] = true;
                    rgstout.Add(rgst[i]);
                    foreach (var x in Rgpermute(rgst, rgstout, fseen)) yield return x;
                    rgstout.RemoveAt(rgstout.Count - 1);
                    fseen[i] = false;
                }
            }
        }
    }
}
