﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class TrieSharding : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            ProblemSet<TrieSharding>.Solve(args);
        }
        #endregion

        public override void Parse(ProblemReader file)
        {
            file.Read(out M, out N).Read(M, out S);
        }

        // ReSharper disable InconsistentNaming
        private int M, N;
        private string[] S;
        // ReSharper restore InconsistentNaming

        public override object Solve()
        {
            var max = 0;
            var ct = 0;
            for (var i = 0; i < (int) Math.Pow(N, M); i++)
            {
                var mine = 0;
                for (var j = 0; j < N; j++) mine += Go(i, j);
                if (mine > max)
                {
                    max = mine;
                    ct = 1;
                }
                else if (mine == max) ct++;
            }

            return max + " " + ct;
        }

        private int Go(int num, int me)
        {
            var set = new HashSet<string>();
            for (var i = 0; i < M; i++, num /= N)
            {
                if (num % N == me) for (var j = 0; j <= S[i].Length; j++) set.Add(S[i].Substring(0, j));
            }
            return set.Count;
        }

        public override IEnumerable<Action> StaticInitialize()
        {
            yield return () =>
            {

            };
        }
    }
}
