﻿/*
 * This file is made by Feng JIAO(Email: joephone1983@gmail.com) for solving Code Jam contest problems.
 * This file is licensed under The GNU General Public License (GPLv3). For more information, google "GPLv3"
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public static class MathHelper
    {
        public static int FromBase(int[] numberArray, int baseNum)
        {
            int output = 0;
            for (int i = 0; i < numberArray.Length; i++)
            {
                if (numberArray[i] >= baseNum)
                {
                    throw new OverflowException(String.Format("The {0}th number: {1} is out of range. Suggest check the base number.",
                                                    i.ToString(), numberArray[i].ToString()));
                }
                output = output * baseNum + numberArray[i];
            }
            return output;
        }

        public static int[] ToBase(int input, int baseNum)
        {
            List<int> output = new List<int>(32);
            int rem = 0;
            do
            {
                input = Math.DivRem(input, baseNum, out rem);
                output.Add(rem);
            }
            while (input > 0);
            output.Reverse();
            return output.ToArray();
        }

        public static int[] ToIntArray(this int number)
        {
            if (number < 0)
            {
                throw new NotSupportedException("input number must not be negative.");
            }

            var charArray = number.ToString().ToCharArray();
            var returnArray = new int[charArray.Length];
            for (int i = 0; i < charArray.Length; i++)
            {
                returnArray[i] = Int32.Parse(charArray[i].ToString());
            }
            return returnArray;
        }

        public static IEnumerable<TSource> GetMax<TSource, TResult>(this IEnumerable<TSource> source, Func<TSource, TResult> selector)
        {
            if (source.Count() == 0)
            {
                return source;
            }
            TResult m = source.Max(selector);
            return source.Where(s => selector(s).Equals(m)) as IEnumerable<TSource>;
        }

        public static IEnumerable<TSource> GetMin<TSource, TResult>(this IEnumerable<TSource> source, Func<TSource, TResult> selector)
        {
            if (source.Count() == 0)
            {
                return source;
            }
            TResult m = source.Min(selector);
            return source.Where(s => selector(s).Equals(m)) as IEnumerable<TSource>;
        }

        public static int GCD(int a, int b)
        {
            int Remainder;

            while (b != 0)
            {
                Remainder = a % b;
                a = b;
                b = Remainder;
            }
            return a;
        }

        public static int GCD(int[] a)
        {
            if (a.Length == 0)
            {
                throw new InvalidOperationException("intput is empty");
            }
            if (a.Length == 1)
            {
                return a[0];
            }

            int gcd = GCD(a[0], a[1]);
            for (int i = 2; i < a.Length; i++)
            {
                gcd = GCD(gcd, a[i]);
                if (gcd == 1)
                    break;
            }
            return gcd;
        }

    }
}
