package jam;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Bergmann Gábor
 *
 */
public class A {

	public static void main(String[] args) {
		new A().run();
	}

	Map<Character, Integer> assignment;

	private void run() {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		
	    int cases;

		try {
			cases = Integer.parseInt(input.readLine());
		    for (int thisCase = 0; thisCase < cases; thisCase++ ) {
		    	String line = input.readLine();

		    	assignment = new HashMap<Character, Integer>();
		    	for (int i=0; i<line.length(); i++) {
		    		char c = line.charAt(i);
		    		Integer val = assignment.get(c);
					if (val == null) {
						int previously = assignment.size();
						if (previously == 0) val=1;
						else if (previously == 1) val=0;
						else val=previously;
						assignment.put(c, val);
					}
		    	}
		    	int distinct = assignment.size();
		    	int base = (distinct>1)? distinct: 2;
		    	
		    	long seconds = 0;
		    	for (int i=0; i<line.length(); i++) {
		    		char c = line.charAt(i);
		    		Integer val = assignment.get(c);
		    		seconds = base*seconds + val;
		    	}

		    	System.out.println("Case #"+(thisCase+1)+": "+seconds);	
		    }	
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

}
