#!/usr/bin/python3
# -*- coding: utf-8 -*-

import sys
import os
import subprocess

def linebelow(r1, r2):
	return(all([x<y for (x,y) in zip(r1,r2)]))

rdln = sys.stdin.readline

T = int(rdln())

for t in range(T):
	[N, K] = [int(x) for x in rdln().split()]
	stocks = [ [int(x) for x in rdln().split()] for w in range(N)]
	edges=[]
	f = subprocess.Popen("./nf1", shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
	for i in range(N):
		edges.append((0, i+1))
		edges.append((i+1+N,1+2*N))
	for i in range(N):
		for j in range(N):
			if(linebelow(stocks[i], stocks[j])):
				edges.append((i+1, j+1+N))
	#print(2*N+2, len(edges),file=f.stdin)
	f.stdin.write((str(2*N+2)+" "+str(len(edges))+"\n").encode())
	for (x,y) in edges:
		#print(x,y,1, file=f.stdin)
		f.stdin.write((str(x)+" "+str(y)+" 1\n").encode())
	f.stdin.flush()
	print("Case #", t+1, ": ", N - int(f.stdout.readline()), sep="")
	f.stdin.close()
	f.stdout.close()