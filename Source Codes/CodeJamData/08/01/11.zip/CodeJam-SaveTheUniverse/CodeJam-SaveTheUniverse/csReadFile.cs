﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeJam_SaveTheUniverse
{
    class csReadFile
    {
        private int NumTestCases = 0;
        private List<csTestCase> Cases  = new List<csTestCase>(); //List of cases

        public List<csTestCase> TestCases
        {
            get
            {
                return Cases;
            }
        }


        public csReadFile(string FileName)
        {
            StreamReader R = new StreamReader(FileName);
            string str;

            //read first line
            str = R.ReadLine();
            NumTestCases = int.Parse(str);

            //loop test cases
            for (int i = 0; i < NumTestCases; i++)
            {
                csTestCase Case = new csTestCase();
                
                //read number of search engines
                str = R.ReadLine();
                int n1 = int.Parse(str);

                //read engine names
                for (int j = 0; j < n1; j++)
                {
                    str = R.ReadLine();
                    Case.EngineNames.Add(str);
                }

                //read number of keywords
                str = R.ReadLine();
                n1 = int.Parse(str);

                //read keywords
                for (int j = 0; j < n1; j++)
                {
                    str = R.ReadLine();
                    Case.Keywords.Add(str);
                }

                Cases.Add(Case);
            }
        }

        public void WriteFile(string FileName)
        {
            StreamWriter W = new StreamWriter(FileName);

            int i = 1;
            foreach (csTestCase Case in Cases)
            {
                W.WriteLine("Case #" + i + ": " + Case.Solution.ToString());
                i++;
            }

            W.Close();
        }
    }
}
