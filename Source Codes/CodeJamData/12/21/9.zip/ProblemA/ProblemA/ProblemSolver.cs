﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Utils.Infrastructure;
using System.Globalization;

namespace ProblemA {
    class ProblemSolver : IProblemSolver {
        //Properties

        //Solver        
        public object Solve() {
            int x = 0;            
            for (int i = 0; i < N; i++) {
                x += Points[i];                
            }
            int s = x;
            int k = 0;
            for (int i = 0; i < N; i++) {
                if (N * Points[i] >= 2 * x) {
                    s -= Points[i];
                    k++;
                }
                
            }
            double[] r = new double[N];                        
            for (int i = 0; i < N; i++) {
                if (N * Points[i] >= 2 * x)
                    continue;
                r[i] = (1.0 - (((N - k) * Points[i] - s) * 1.0 / x)) / (N - k);
                //double y = (2.0/N - (double)(Points[i]) / x);
                //r.Add(Math.Max(y, 0));            
                //sum += r[i];
            }
            List<string> result = new List<string>();
            for (int i = 0; i < N; i++) {
                result.Add(String.Format(CultureInfo.InvariantCulture, "{0}", r[i] * 100.0));
            }

            return String.Join(" ", result.ToArray());
        }
        
        public int N { get; set; }

        public int[] Points { get; set; }
    }
}
