#!/bin/sh
for i in $* ; do
	i=$(echo "$i" | sed 's/^in\///' | sed 's/^out\///' | sed 's/\.in$//'  | sed 's/\.out$//')
	prog=$(echo "$i" | sed 's/\..*$//')
	make "g/$prog" | grep -v 'up to date'
	echo "Generating out/$i.out from in/$i"
	cat "in/$i" | "g/$prog" > "out/$i.out"
done
