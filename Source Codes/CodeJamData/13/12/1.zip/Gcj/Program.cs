﻿using Gcj.Util;
using Gcj.Y2013.R1A.A;
using Gcj.Y2013.R1A.B;

namespace Gcj
{
    class Program
    {
        static void Main(string[] args)
        {
            GcjSolver.Solve<BSolver>();
            //ConcurrentGcjSolver.Solve<OutOfGasConcurrentSolver2>(true);
        }
    }
}
