#!/bin/sh
make clean
rm -rf ccan
rm -rf *.bz2
rm -rf out/*
