﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Chaow.Collections;

namespace Google {
    static class Program {
        const string inputFile = @"C:\Google\B-large.in";
        const string outputFile = @"C:\Google\__result.out";

        static void Main(string[] args) {
            //read input from file
            string input;
            using (var reader = File.OpenText(inputFile)) {
                input = reader.ReadToEnd();
            }

            //write output to file
            using (var writer = File.CreateText(outputFile)) {
                foreach (var result in Solve(input))
                    writer.WriteLine(result);
            }
        }
        static IEnumerable<string> Solve(string input) {
            //split cases
            string[] cases = input.Split(new[] { "\r\n", "\n" },StringSplitOptions.None);
            int caseCount = int.Parse(cases[0]);

            //enumerate cases
            for (int i = 1, j = 1; j <= caseCount; j++) {

                //read size
                string[] size = cases[i].Split(' ');
                int height = int.Parse(size[0]);
                int width = int.Parse(size[1]);
                i++;

                List<int[]> geo = new List<int[]>();
                for (int k = 0; k < height; k++, i++)
                    geo.Add(cases[i].Split(new[] { ' ' }, width).Select(s => int.Parse(s)).ToArray());

                string result = SolveWatersheds(geo.ToArray());
                yield return string.Format("Case #{0}:{1}", j, result);
            }
        }
        static int GetValue(this int[][] geo, Point point) {
            return geo[point.Y][point.X];
        }
        static Point FindNextPoint(this int[][] geo, Point currentPoint) {
            Point targetPoint = currentPoint;
            int currentValue = geo.GetValue(currentPoint);
            int targetValue = int.MaxValue;

            //Go North
            if (currentPoint.Y > 0) {
                Point point = currentPoint.Go(Direction.North);
                int value = geo.GetValue(point);
                if (currentValue > value && targetValue > value) {
                    targetPoint = point;
                    targetValue = value;
                }
            }
            if (currentPoint.X > 0) {
                Point point = currentPoint.Go(Direction.West);
                int value = geo.GetValue(point);
                if (currentValue > value && targetValue > value) {
                    targetPoint = point;
                    targetValue = value;
                }
            }
            if (currentPoint.X + 1 < geo[0].Length) {
                Point point = currentPoint.Go(Direction.East);
                int value = geo.GetValue(point);
                if (currentValue > value && targetValue > value) {
                    targetPoint = point;
                    targetValue = value;
                }
            }
            if (currentPoint.Y + 1 < geo.Length) {
                Point point = currentPoint.Go(Direction.South);
                int value = geo.GetValue(point);
                if (currentValue > value && targetValue > value) {
                    targetPoint = point;
                    targetValue = value;
                }
            }
            return targetPoint;
        }
        static string SolveWatersheds(int[][] geo) {
            var set = new DisjointSet<Point>();

            for (int y = 0; y < geo.Length; y++) {
                for (int x = 0; x < geo[y].Length; x++) {
                    Point currentPoint = new Point(x, y);
                    Point targetPoint = geo.FindNextPoint(currentPoint);
                    set.Union(currentPoint, targetPoint);
                }
            }

            const string letters = "abcdefghijklmnopqrstuvwxyz";
            StringBuilder sb = new StringBuilder();
            var dict = new Dictionary<Point, char>();
            for (int y = 0; y < geo.Length; y++) {
                sb.AppendLine();
                for (int x = 0; x < geo[y].Length; x++) {
                    Point point = new Point(x, y);
                    char c;

                    Point parent = set.FindParent(point);
                    if (!dict.TryGetValue(parent, out c)) {
                        c = letters[dict.Count];
                        dict.Add(parent, c);
                    }

                    sb.Append(c);
                    if (x + 1 < geo[y].Length)
                        sb.Append(' ');
                }
            }
            return sb.ToString();
        }
    }
    enum Direction {
        North,
        West,
        East,
        South,
    }
    struct Point : IEquatable<Point> {
        readonly int _x;
        public int X {
            get { return _x; }
        }

        readonly int _y;
        public int Y {
            get { return _y; }
        }

        public Point(int x, int y) {
            _x = x;
            _y = y;
        }

        public bool Equals(Point other) {
            return _x == other._x && _y == other._y;
        }
        public override bool Equals(object obj) {
            if (!(obj is Point))
                return false;
            return Equals((Point)obj);
        }
        public override int GetHashCode() {
            return (_y << 4) ^ _x;
        }
        public Point Go(Direction direction) {
            switch (direction) {
            case Direction.North:
                return new Point(_x, _y - 1);
            case Direction.West:
                return new Point(_x - 1, _y);
            case Direction.East:
                return new Point(_x + 1, _y);
            case Direction.South:
                return new Point(_x, _y + 1);
            }
            throw new Exception();
        }
    }
}
