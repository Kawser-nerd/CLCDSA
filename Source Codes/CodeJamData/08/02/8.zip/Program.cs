﻿/*
 * C# Version 3.5
 * */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

public class Train
{
    public int start;
    public int end;
    public int place;

    int Value(char c)
    {
        return c - '0';
    }

    int get(string s)
    {
        int hour = Value(s[0]) * 10 + Value(s[1]);
        int mint = Value(s[3]) * 10 + Value(s[4]);
        return hour * 60 + mint;
    }

    public Train(string s,int p)
    {
        var tokens = s.Split(" \t".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
        start = get(tokens[0]);
        end = get(tokens[1]);
        place = p;

    }
}

class Program
{
    static void Main(string[] args)
    {
        using (StreamReader sr = new StreamReader(args[0]))
        {
            int tst = Int32.Parse(sr.ReadLine());
            for (int cas = 1; cas <= tst; ++cas)
            {
                int t = Int32.Parse(sr.ReadLine());
                var nanb = sr.ReadLine().Split(" \t".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                int na = Int32.Parse(nanb[0]);
                int nb = Int32.Parse(nanb[1]);
                List<Train> list = new List<Train>();
                for (int i = 0; i < na; ++i)
                {
                    list.Add(new Train(sr.ReadLine(),0));
                }
                for (int i = 0; i < nb; ++i)
                {
                    list.Add(new Train(sr.ReadLine(),1));
                }
                var ot = list.OrderBy(tr => tr.start).ToArray();
                bool[] visited = new bool[na + nb];
                int[] res = new int[2];
                for (int i = 0; i < na + nb; ++i)
                {
                    if (visited[i])
                    {
                        continue;
                    }
                    res[ot[i].place]++;
                    int cur = i;
                    while (true)
                    {
                        cur = Enumerable.Range(cur + 1, na + nb - cur - 1).FirstOrDefault(j => (!visited[j] && ot[j].place != ot[cur].place && ot[j].start >= (ot[cur].end + t)));
                        if (cur==0)
                        {
                            break;
                        }
                        visited[cur] = true;

                    }
                }
                Console.WriteLine("Case #" + cas + ": " + res[0] + " " + res[1]);
            }
        }
    }
}
