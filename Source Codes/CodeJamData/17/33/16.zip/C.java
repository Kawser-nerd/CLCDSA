import lib.CodeJamLauncher;
import lib.DoubleArrayFromInput;

import java.util.Arrays;
import java.util.stream.IntStream;

public class C {

    private static double u;

    public static void main(String[] ignored) throws Exception {
        CodeJamLauncher.run("C-small-1-attempt1.in", (caseTitle, in) -> {
            int n = in.nextInt();
            int k = in.nextInt();
            u = in.nextDouble();
            double[] p = DoubleArrayFromInput.next(in, n);

            while (u > 0) {
                Arrays.sort(p);
                double min = p[0];
                int minCount = (int) Arrays.stream(p).filter(v -> v == min).count();
                if (minCount == n) {
                    double add = u / minCount;
                    IntStream.range(0, n)
                            .filter(i -> p[i] == min)
                            .forEach(i -> p[i] += add);
                    u = 0;
                } else {
                    double next = p[minCount];
                    double add = Math.min(next - min, u / minCount);
                    IntStream.range(0, n)
                            .filter(i -> p[i] == min)
                            .forEach(i -> p[i] += add);
                    u -= add * minCount;
                }
            }

            double m = 1;
            for (int i = 0; i < n; i++)
                m *= Math.min(1.0, p[i]);

            System.out.println(caseTitle + String.format("%.10f", m));
        });
    }

}
