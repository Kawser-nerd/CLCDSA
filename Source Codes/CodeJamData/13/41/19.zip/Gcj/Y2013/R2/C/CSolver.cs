﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Gcj.Util;
using System.Linq;

namespace Gcj.Y2013.R2.C
{
    internal class CSolver : GcjSolver
    {
        protected override IEnumerable<object> EnobjSolveCase()
        {
            yield break;
        }
    }
}
