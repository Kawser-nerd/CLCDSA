﻿using Template;
using Template.Interfaces;

namespace Problems
{
  public class ProblemD : ProblemTemplate
  {
    public ProblemD(ICaseFormatter caseFormatter) : base(caseFormatter)
    {
    }

    protected override string SolveOneCase(IInput input)
    {
      return "";
    }
  }
}