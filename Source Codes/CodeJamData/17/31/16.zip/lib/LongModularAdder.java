package lib;

import java.util.function.BinaryOperator;

public class LongModularAdder {
    public static BinaryOperator<Long> of(long mod) {
        return FinishAdjustingOperator.of(LongAdder.INSTANCE, LongModularAdjuster.of(mod));
    }
}
