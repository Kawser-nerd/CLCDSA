using System;
using CodeJam2011.Problems;

namespace CodeJam2011
{
    public class Program
    {
        static void Main(string[] args)
        {
            var problem = new ProblemC();

            problem.Solve(new InputHelper(Console.In), Console.Out);
        }
    }
}