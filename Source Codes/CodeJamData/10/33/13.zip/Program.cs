﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace Chess
{
    /// <summary>
    /// .net 3.5
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            var inFile = String.Empty;
            var outFile = String.Empty;

            for (var i = 0; i < args.Length; i++)
            {
                switch (args[i])
                {
                    case "-i":
                        inFile = args[++i];
                        break;
                    case "-o":
                        outFile = args[++i];
                        break;
                }
            }

            if (!String.IsNullOrEmpty(inFile) && !String.IsNullOrEmpty(outFile))
            {
                using (var reader = new StreamReader(inFile))
                using (var writer = new StreamWriter(outFile))
                {
                    var p = new Program();
                    p.Run(reader, writer);
                }
            }
        }

        private void Run(StreamReader reader, StreamWriter writer)
        {
            var stopwatch = Stopwatch.StartNew();

            var caseCount = int.Parse(reader.ReadLine());
            for (var i = 0; i < caseCount; i++)
            {
                var buffer = reader.ReadLine();
                var values = buffer.Split(' ').Select(s => int.Parse(s)).ToArray();
                var height = values[0];
                var width = values[1];
                var board = new bool[height, width];
                for (var h = 0; h < height; h++)
                {
                    buffer = reader.ReadLine();
                    for (var w = 0; w < width / 4; w++)
                    {
                        var num = int.Parse(buffer[w].ToString(), System.Globalization.NumberStyles.HexNumber);
                        board[h, w * 4 + 0] = (num & 8) > 0;
                        board[h, w * 4 + 1] = (num & 4) > 0;
                        board[h, w * 4 + 2] = (num & 2) > 0;
                        board[h, w * 4 + 3] = (num & 1) > 0;
                    }
                }

                Solve(board, height, width, writer, i + 1);
            }

            Console.WriteLine("Time:{0}", stopwatch.Elapsed);
        }

        private void Solve(bool[,] board, int height, int width, StreamWriter writer, int caseId)
        {
            var analysis = new int[height, width];
            var maxValue = 1;

            for (var h1 = 0; h1 < height; h1++)
            {
                for (var w1 = 0; w1 < width; w1++)
                {
                    var h0 = h1 - 1;
                    var w0 = w1 - 1;

                    var value = 1;

                    if (h0 >= 0 &&
                        w0 >= 0 &&
                        board[h1, w1] != board[h0, w1] &&
                        board[h1, w1] != board[h1, w0] &&
                        board[h1, w1] == board[h0, w0])
                        value = Math.Min(Math.Min(analysis[h0, w1], analysis[h1, w0]), analysis[h0, w0]) + 1;

                    analysis[h1, w1] = value;
                    maxValue = Math.Max(maxValue, value);
                }
            }

            var total = 0;
            var list = new List<Result>();
            for (var size = maxValue; size >= 2; size--)
            {
                var count = 0;
                for (var h = 0; h < height; h++)
                {
                    for (var w = 0; w < width; w++)
                    {
                        if (analysis[h, w] >= size)
                        {
                            var good = true;
                            for (var i = 1; i <= size - 1; i++)
                            {
                                if (analysis[h - i, w - i] < size - i)
                                {
                                    good = false;
                                    break;
                                }
                                for (var j = 1; j <= i; j++)
                                {
                                    if (analysis[h - i, w - i + j] < size - i ||
                                        analysis[h - i + j, w - i] < size - i)
                                    {
                                        good = false;
                                        break;
                                    }
                                }
                            }
                            if (good)
                            {
                                for (var hh = h - size + 1; hh <= h; hh++)
                                    for (var ww = w - size + 1; ww <= w; ww++)
                                        analysis[hh, ww] = 0;
                                count++;
                            }
                        }
                    }
                }
                if (count > 0)
                {
                    list.Add(new Result { Size = size, Count = count });
                    total += count * size * size;
                }
            }
            if (total < width * height)
            {
                list.Add(new Result { Size = 1, Count = width * height - total });
            }
            writer.WriteLine("Case #{0}: {1}", caseId, list.Count);
            foreach (var r in list)
            {
                writer.WriteLine("{0} {1}", r.Size, r.Count);
            }
        }
    }

    class Result
    {
        public int Size { get; set; }
        public int Count { get; set; }
    }
}
