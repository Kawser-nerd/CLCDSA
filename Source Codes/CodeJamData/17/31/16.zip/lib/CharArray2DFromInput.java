package lib;

public class CharArray2DFromInput {
    public static char[][] next(Input in, int n) {
        return ArrayFromInput.next(in, n, char[].class, String::toCharArray);
    }
}
