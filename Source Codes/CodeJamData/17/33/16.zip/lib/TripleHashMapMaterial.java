package lib;

public class TripleHashMapMaterial {

    public static <T1, T2, T3> HashMapMaterial<Triple<T1, T2, T3>> of(HashMapMaterial<T1> m1, HashMapMaterial<T2> m2, HashMapMaterial<T3> m3) {
        return new HashMapMaterial<>(triple -> {
            int hash1 = m1.hashFunction.applyAsInt(triple.v1);
            int hash2 = m2.hashFunction.applyAsInt(triple.v2);
            int hash3 = m3.hashFunction.applyAsInt(triple.v3);
            return TwoIntHash.hash(TwoIntHash.hash(hash1, hash2), hash3);
        }, (p1, p2) -> {
            boolean test1 = m1.equalTester.test(p1.v1, p2.v1);
            if (!test1)
                return false;
            boolean test2 = m2.equalTester.test(p1.v2, p2.v2);
            if (!test2)
                return false;
            return m3.equalTester.test(p1.v3, p2.v3);
        });
    }
}
