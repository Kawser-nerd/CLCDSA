﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoogleCodeJam.Common
{
	public class OutputFile
	{
		private readonly StreamWriter m_Writer;

		public OutputFile(string path)
		{
			m_Writer = new StreamWriter(path);
		}

		public void WriteCase(int caseNumber, string value)
		{
			if (value == "")
				m_Writer.WriteLine(String.Format("Case #{0}:", caseNumber));
			else
				m_Writer.WriteLine(String.Format("Case #{0}: {1}", caseNumber, value));
		}

		public void Write(string str)
		{
			m_Writer.Write(str);
		}

		public void Close()
		{
			m_Writer.Close();
		}
	}
}
