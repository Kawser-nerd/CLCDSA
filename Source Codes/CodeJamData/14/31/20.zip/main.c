/********************************** INCLUDES **********************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "inout.h"


/******************************* PRIVATE MACROS *******************************/
//#define DBG_ENABLE

#ifdef DBG_ENABLE
#define DBG_PRINTF(...)      printf(__VA_ARGS__)
#else
#define DBG_PRINTF(...)      do{}while(0);
#endif

#define NUM_OF_ARGUMENT         3
#define IN_FILE_NAME_INDEX      1
#define OUT_FILE_NAME_INDEX     2

#define max(a,b)                        \
    (                                   \
        {                               \
            __typeof__ (a) _a = (a);    \
            __typeof__ (b) _b = (b);    \
            _a > _b ? _a : _b;          \
        }                               \
    )

#define min(a,b)                        \
    (                                   \
        {                               \
            __typeof__ (a) _a = (a);    \
            __typeof__ (b) _b = (b);    \
            _a < _b ? _a : _b;          \
        }                               \
    )

/******************************** PRIVATE TYPES *******************************/


/*********************** PRIVATE FUNCTIONS DECLARATIONS ***********************/


/*********************** PRIVATE (GLBL) DATA DEFINITIONS **********************/


/*************************** PUBLIC DATA DEFINITIONS **************************/


/************************ PRIVATE FUNCTIONS DEFINITIONS ***********************/


/************************* PUBLIC FUNCTION DEFINITIONS ************************/
void processAllTestCase(FILE* inFile, FILE* outFile)
{
    int numOfTestCase;
    int i,j;
//    int result = 0;
    long long p;
    long long tmpP;
    long long q;
    bool impossible;
    int numTwo;

    readNumStrFromFileToInt(inFile, &numOfTestCase);
    
    //Process all test cases
    for (i=0; i<numOfTestCase; i++)
    {
        //Process a test case
        readNumStrFromFileToLongLong(inFile, &p);
        readNumStrFromFileToLongLong(inFile, &q);
        
        DBG_PRINTF("p=%lld q=%lld\n", p, q);
        
        impossible = false;
        
        tmpP = p;
        for (j=0; j<40; j++)
        {
            tmpP = tmpP*2;
            
            if (tmpP >= q)
            {
                tmpP -= q;
                
                if (tmpP > 0)
                {
                    //check for impossible cases
                    numTwo = 0;
                    
                    while (p%2 == 0)
                    {
                        p /= 2;
                        
                        if (q % 2)
                        {
                            impossible = true;
                            break;
                        }
                        else
                            q /= 2;
                    }
                    
                    if (!impossible)
                    {
                        while (true)
                        {
                            if (q % 2)
                            {
                                DBG_PRINTF("q % 2 > 0, p=%lld q=%lld\n", p, q);
                                if (p % q)
                                {
                                    impossible = true;
                                }
                                                                
                                break;
                            }
                        
                            q /= 2;
                        
                            if (q == 1)
                            {
                                DBG_PRINTF("q==1\n");
                                break;
                            }
                        }
                    }
                }
                break;
            }
        }
        
        //Output Result, case num start from 1
        if (impossible)
        {
            outputCaseStrResult(outFile, i+1, "impossible");
        }
        else
            outputCaseIntResult(outFile, i+1, j+1);
    }
}

/* program in_file_name out_file_name */
int main( int argc, const char* argv[] )
{
    int i;
    FILE* inFile;
    FILE* outFile;

    DBG_PRINTF( "argc=%d\n", argc );
    if (argc != NUM_OF_ARGUMENT) {
        printf("Not enough Argument!!\ne.g. argv[0] <in_file_name> <out_file_name>\n");
        return 1;
    }
    
    for (i=0; i<argc; i++) {
        DBG_PRINTF("%s\n", argv[i]);
    }
    
    inFile = fopen(argv[IN_FILE_NAME_INDEX], "r");
    if ( inFile == NULL) {
        printf("Can't open input file %s\n", argv[IN_FILE_NAME_INDEX]);
        return 1;
    }
    
    outFile = fopen(argv[OUT_FILE_NAME_INDEX], "w");
    if ( outFile == NULL) {
        printf("Can't open output file %s\n", argv[OUT_FILE_NAME_INDEX]);
        return 1;
    }

    processAllTestCase(inFile, outFile);
   
    fclose(inFile);
    fclose(outFile);
    
    return 0;
}
