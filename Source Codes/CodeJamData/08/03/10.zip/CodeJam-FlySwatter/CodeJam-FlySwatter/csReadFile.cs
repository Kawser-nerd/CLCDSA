﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeJam_FlySwatter
{
    class csReadFile
    {
        private int NumTestCases = 0;
        private List<csTestCase> Cases  = new List<csTestCase>(); //List of cases

        public List<csTestCase> TestCases
        {
            get
            {
                return Cases;
            }
        }


        public csReadFile(string FileName)
        {
            StreamReader R = new StreamReader(FileName);
            string str;

            //read first line
            str = R.ReadLine();
            NumTestCases = int.Parse(str);

            //loop test cases
            for (int i = 0; i < NumTestCases; i++)
            {
                csTestCase Case = new csTestCase();
                
                //read data
                str = R.ReadLine();

                Case.f = double.Parse(str.Split(" ".ToCharArray())[0]);
                Case.R = double.Parse(str.Split(" ".ToCharArray())[1]);
                Case.t = double.Parse(str.Split(" ".ToCharArray())[2]);
                Case.r = double.Parse(str.Split(" ".ToCharArray())[3]);
                Case.g = double.Parse(str.Split(" ".ToCharArray())[4]);

                Case.fix();

                Cases.Add(Case);
            }
        }

        public void WriteFile(string FileName)
        {
            StreamWriter W = new StreamWriter(FileName);

            int i = 1;
            foreach (csTestCase Case in Cases)
            {
                string str = Case.Solution.ToString("#.######");
                if (str.Length < 8)
                {
                    if (str.Equals("")) str = "0.000000";
                    if (str[0] == '.') str = "0" + str;
                    if (!str.Contains(".")) str = str + ".000000";
                    while (str.Length < 8) str = str + "0";
                }
                W.WriteLine("Case #" + i + ": " + str);
                i++;
            }

            W.Close();
        }
    }
}
