﻿/* www.codertom.com  -  copyright Tom Harrison 2015 */
using System.IO;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace CoderTom.CodeJam.Tests
{
    [TestFixture]
    public class JamTest
    {
        private ProblemFileInfo _input;

        [SetUp]
        public void ReadExampleFile()
        {
            var parser = new FileParser();
            _input = parser.Parse("ExampleInput.txt");
        }
        
        [Test]
        public void CanSolveAll()
        {
            _input.SolveAll("Output.txt");
            var result = File.ReadAllText("Output.txt");
            var expected = File.ReadAllText("ExampleOutput.txt");
            Assert.AreEqual(expected, result);
        }
    }
}
