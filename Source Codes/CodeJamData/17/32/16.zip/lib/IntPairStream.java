package lib;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class IntPairStream {
    public static Stream<IntPair> range(int n, int m) {
        return IntStream.range(0, n).boxed()
                .flatMap(i -> IntStream.range(0, m).mapToObj(j -> new IntPair(i, j)));
    }
}
