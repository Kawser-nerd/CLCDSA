﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam_Practice
{
    class Program
    {
        static void Main(string[] args)
        {
            // Read number of input
            int inputs = int.Parse(Console.ReadLine());
            List<Case> cases = new List<Case>();

            for (int i = 0; i < inputs; i++)
            {
                Case newCase = new Case();
                newCase.Cash = int.Parse(Console.ReadLine()); // Get the cash
                int max = int.Parse(Console.ReadLine()); // Ignore the counter
                newCase.Items = Console.ReadLine().Split(' ').Select(item => new Item() { Value = int.Parse(item), Id = Guid.NewGuid() }).Take(max).ToList(); // Get the item values
                cases.Add(newCase);
            }

            cases.ForEach(c =>
            {
                int indexItem1 = 1;
                c.Items.ForEach(item =>
                {
                    Item result = c.Items.FirstOrDefault(subItem => subItem.Value + item.Value == c.Cash && item.Id != subItem.Id);
                    if (result != null)
                    {
                        c.item1 = indexItem1;
                        c.item2 = c.Items.IndexOf(result) + 1;

                        if (c.item1 > c.item2)
                        {
                            c.item1 = c.item2;
                            c.item2 = indexItem1;
                        }
                    }
                    indexItem1++;
                });
                Console.WriteLine(string.Format("Case #{0}: {1} {2}", cases.IndexOf(c) + 1, c.item1, c.item2));
            });
        }
    }
}
