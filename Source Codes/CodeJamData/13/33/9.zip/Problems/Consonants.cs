﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Generic.Containers.Collections.Set;

namespace Google_Code_Jam.Problems
{
    class ConsonantProblem
    {
        string name;
        int n;

        public ConsonantProblem(string name, int n)
        {
            this.name = name;
            this.n = n;
        }

        public string Name
        {
            get { return name; }
        }

        public int N
        {
            get { return n; }
        }
    }

    class Consonants : Algorithm<ConsonantProblem,long>
    {
        public override ConsonantProblem Parse(StreamReader reader)
        {
            var words = JamUtil.ReadWords(reader);
            var name = words[0];
            var n = int.Parse(words[1]);
            return new ConsonantProblem(name, n);
        }

        public override long Solve(ConsonantProblem problem)
        {
            var consonantGroups = FindValidConsequtiveSonsonantSubstrings(problem).ToList();
            var minimum = 0;
            long subStringsCount = 0;
            foreach(var consonantGroup in consonantGroups)
            {
                subStringsCount += SubstringsForConsonantGroup(minimum, consonantGroup, problem);
                minimum = consonantGroup.Item1 + 1;
            }
            return subStringsCount;
        }

        static long SubstringsForConsonantGroup(int minimum, SubString consonantGroup, ConsonantProblem problem)
        {
            var startsCount = consonantGroup.Item1 + 1 - minimum;
            var endsCount = problem.Name.Length - consonantGroup.Item2;
            return startsCount * endsCount;
        }

        const string VOWELS = "aeiou";

        class SubString : Tuple<int,int> //Only inclusive shit.
        {
            public SubString(int item1, int item2)
                : base(item1, item2)
            {
            }
        }

        static IEnumerable<SubString> FindValidConsequtiveSonsonantSubstrings(ConsonantProblem problem)
        {
            var currentCount = 0;
            var startOfCount = 0;
            for(int i =0;i<problem.Name.Length;i++)
            {
                var c = problem.Name[i];
                if (!VOWELS.Contains(c))
                {
                    if (currentCount == 0)
                        startOfCount = i;
                    currentCount++;
                }
                else
                    currentCount = 0;
                if (currentCount == problem.N)
                {
                    yield return new SubString(startOfCount,i);
                    startOfCount++;
                    currentCount--;
                }
            }
        }

        public override string Print(long solution)
        {
            return solution.ToString();
        }
    }
}
