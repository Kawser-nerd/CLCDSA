﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Numerics;
using System.Diagnostics;

namespace GCJ
{
    public class C : X
    {
        private long L;
        private long X;
        private string S;
        Dictionary<string, string> Transform = new Dictionary<string, string>();
        public override void Init()
        {
            L = ReadLong();
            X = ReadLongLine();
            S = ReadStringLine();
            Transform.Add("ii", "-");
            Transform.Add("ij", "k");
            Transform.Add("ik", "j-");
            Transform.Add("ji", "k-");
            Transform.Add("jj", "-");
            Transform.Add("jk", "i");
            Transform.Add("ki", "j");
            Transform.Add("kj", "i-");
            Transform.Add("kk", "-");
            Transform.Add("--", "");
            Transform.Add("-i", "i-");
            Transform.Add("-j", "j-");
            Transform.Add("-k", "k-");
        }
        public override void Solve()
        {
            bool result = true;
            int l = (int) (X%4L);
            if (l < 3) l += 4;
            if (L < 10) l += 40;
            if (l > X) l = (int) X;

            var b = new StringBuilder();
            
            for (int i = 0; i < l; i++)
            {
                b.Append(S);
            }
            string s = b.ToString();

            s = Reduce(s, 'i');
            if (s.Length < 1) result = false;
            if (result && s[0] != 'i') result = false;
            if (result)
            {
                s = s.Substring(1);
                s = Reduce(s, 'j');
            }
            if (s.Length < 1) result = false;
            if (result && s[0] != 'j') result = false;
            if (result)
            {
                s = s.Substring(1);
                s = Reduce(s, 'k');
            }
            if (s.Length < 1) result = false;
            if (result && s[0] != 'k') result = false;
            if (result)
            {
                s = s.Substring(1);
                s = Reduce(s, 'x');
            }
            if (s.Length > 0) result = false;

            Result.Append(result ? "YES" : "NO");
        }

        private string Reduce(string s, char d)
        {
            while (s.Length > 1 && s[0] != d)
            {
                var x = s.Left(2);
                var r = s.Substring(2);
                if (x[1] == '-')
                {
                    if (x == "--")
                    {
                        s = r;
                        continue;
                    }
                    if (r.Length > 0)
                    {
                        var r0=r[0];
                        if (r0 == '-')
                        {
                            s = x[0].ToString() + r.Substring(1); ;
                            continue;                           
                        }
                        x = x[0].ToString() + r0.ToString();
                        r = '-' + r.Substring(1);
                    }
                    else
                    {
                        break;
                    }
                }
                var t = Transform[x];
                s = t + r;
            }
            return s;
        }
    }
}