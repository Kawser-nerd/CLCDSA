namespace CodeJam.Providers
{
  public interface IProblemTypeProvider
  {
    ProblemType GetProblemType();
  }
}