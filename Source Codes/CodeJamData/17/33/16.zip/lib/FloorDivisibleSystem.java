package lib;

// 적당한 이름을 못찾겠다. Integer 라는 이름이 제일 좋지만 이미 있어서 쓸수가 없으니. 
public interface FloorDivisibleSystem<T> {
    T one();

    T add(T a, T b);

    T subtract(T a, T b);

    T floorDivide(T a, T b);

    int compare(T a, T b);
}
