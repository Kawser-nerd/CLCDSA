﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class TheRepeater : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            ProblemSet<TheRepeater>.Solve(args);
        }
        #endregion

        public override void Parse(ProblemReader file)
        {
            file.Read(out N).Read(N, out ss);
        }

        // ReSharper disable InconsistentNaming
        private int N;
        private string[] ss;
        // ReSharper restore InconsistentNaming

        public override object Solve()
        {
            var maps = ss.Select(Map).ToArray();
            if (maps.Any(tp => maps.Any(tp2 => tp.Item1 != tp2.Item1))) return "Fegla Won";
            var nums = maps.Select(m => m.Item2).ToArray();
            var ct = 0;
            for (var i = 0; i < nums[0].Length; i++)
            {
                var x = int.MaxValue;
                var mn = nums.Select(p => p[i]).Min();
                var mx = nums.Select(p => p[i]).Max();
                for (var j = mn; j <= mx; j++)
                {
                    var y = nums.Sum(r => Math.Abs(r[i] - j));
                    x = Math.Min(x, y);
                }
                ct += x;
            }
            return ct;
        }

        private Tuple<string, int[]> Map(string s)
        {
            var ll = new List<int>();
            var curr = 0;
            var ans = "" + s[0];
            for (var i = 1; i < s.Length; i++)
            {
                if (s[i] != s[curr])
                {
                    ll.Add(i-curr);
                    ans += s[i];
                    curr = i;
                }
            }
            ll.Add(s.Length - curr);
            return Tuple.Create(ans, ll.ToArray());
        }

        public override IEnumerable<Action> StaticInitialize()
        {
            yield return () =>
            {

            };
        }
    }
}
