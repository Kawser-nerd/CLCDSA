using System;
using System.IO;
using CodeJam.Providers;

namespace CodeJam
{
  public class Timer : ITimer
  {
    private readonly IFilePathProvider filePathProvider;
    private DateTime startTime;
    private DateTime stopTime;

    public Timer(IFilePathProvider filePathProvider)
    {
      this.filePathProvider = filePathProvider;
    }

    public void Start()
    {
      startTime = DateTime.Now;
    }

    public void Stop()
    {
      stopTime = DateTime.Now;
    }

    public void WriteToFile()
    {
      var duration = stopTime - startTime;
      var output = "Algorithm Running Time: " + duration.TotalSeconds.ToString() + " Seconds.";
      File.WriteAllText(filePathProvider.TimerFilePath(), output);
    }
  }
}