﻿/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeJam
{
    abstract class ParallelSolution : SolutionBase
    {
        abstract public Func<String> StartSolving();

        public override void Solve()
        {
            int casesCount = Int32.Parse(Console.ReadLine());

            var cases = Enumerable.Range(0, casesCount).Select(i => StartSolving()).ToArray();
            
            var results = cases.Select((c,i) => String.Format("Case #{0}: {1}", i + 1, c()));

            foreach (var s in results)
                Console.WriteLine(s);
        }
    }
}
