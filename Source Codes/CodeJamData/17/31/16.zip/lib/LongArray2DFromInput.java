package lib;

public class LongArray2DFromInput {
    public static long[][] next(Input in, int size1, int size2) {
        return ArrayConstructor.create(size1, long[].class, () -> LongArrayFromInput.next(in, size2));
    }
}
