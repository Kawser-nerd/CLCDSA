﻿using GoogleCodeJam.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MagicTrick
{
	class CardGame
	{
		private CardGrid m_FirstGrid;
		private int m_FirstRow;
		private CardGrid m_SecondGrid;
		private int m_SecondRow;

		public CardGame(InputFile input)
		{
			m_FirstRow = input.ReadIntArray()[0];
			m_FirstGrid = new CardGrid(input);
			m_SecondRow = input.ReadIntArray()[0];
			m_SecondGrid = new CardGrid(input);
		}

		public string CalculateResult()
		{
			List<int> firstPossibles = m_FirstGrid.GetRow(m_FirstRow);
			List<int> secondPossibles = m_SecondGrid.GetRow(m_SecondRow);

			List<int> possibles = firstPossibles.Intersect(secondPossibles).ToList();
			if (possibles.Count == 1)
				return possibles[0].ToString();
			else if (possibles.Count > 1)
				return "Bad magician!";
			else
				return "Volunteer cheated!";
		}
	}


	class CardGrid
	{
		private int[,] m_Cards;
		private const int ROWS = 4;
		private const int COLUMNS = 4;

		public CardGrid(InputFile input)
		{
			m_Cards = new int[ROWS, COLUMNS];

			for (int row = 0; row < ROWS; row++)
			{
				int[] values = input.ReadIntArray();
				for (int col = 0; col < COLUMNS; col++)
				{
					m_Cards[row, col] = values[col];
				}
			}
		}

		public List<int> GetRow(int rowNumber)
		{
			List<int> rowValues = new List<int>();
			for (int col = 0; col < COLUMNS; col++)
				rowValues.Add(m_Cards[rowNumber - 1, col]);

			return rowValues;
		}
	}
}
