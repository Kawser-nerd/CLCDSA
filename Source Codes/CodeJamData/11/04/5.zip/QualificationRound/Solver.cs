﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public class Solver
{
    const string Folder = @"D:\GCJ\GCJ2011\";
    string FileName;
    string GetFile { get { return Folder + FileName; } }
    List<string> Lines;
    public Solver(List<string> lines) 
    {
        Lines = lines;
        FileName = DateTime.Now.ToShortTimeString().Replace(":", "") + DateTime.Now.Second + ".txt";
    }
    void MakeAnswer(int caseNumber, string answer)
    {
        using (StreamWriter sw = File.AppendText(GetFile))
        {
            sw.WriteLine(string.Format("Case #{0}: {1}", caseNumber, answer));
        }
    }
    string Read()
    {
        string value = Lines[0];
        Lines.RemoveAt(0);
        return value;
    }
    public void Execute()
    {
        Initialze();
        int cases = Convert.ToInt32(Read());
        for (int caseIndex = 0; caseIndex < cases; caseIndex++)
        {
            Solve(caseIndex + 1);
        }
    }

    int Length;
    bool[] Counted;
    int[] Values;
    void Solve(int caseNumber)
    {
        Read();
        string[] parts = Read().Split(' ');

        Length = parts.Length;
        Values = new int[Length];
        for (int index = 0; index < Length; index++) { Values[index] = Convert.ToInt32(parts[index]); }

        Counted = new bool[Length];

        double answer = 0.0;
        for (int index = 0; index < Length; index++)
        {
            int value = Values[index];
            if (value == index + 1) { continue; }

            int elementCount = GetElementCount(index);
            answer += GetExpectation(elementCount);
        }
        MakeAnswer(caseNumber, answer.ToString());
    }

    int GetElementCount(int index)
    {
        if (Counted[index]) { return 0; }
        Counted[index] = true;
        int value = Values[index];
        return GetElementCount(value - 1) + 1;
    }

    double[] dp = new double[1001];
    double GetExpectation(int elementCount)
    {
        if (elementCount == 0) { return 0.0; }
        return dp[elementCount];
    }

    void Initialze()
    {
        dp[2] = 2.0;
        for (int index = 3; index < 1001; index++)
        {
            dp[index] = index;
        }
    }
}

