namespace CodeJamLibrary.Interfaces
{
  public interface IProblemFactory
  {
    IProblem GetProblem(ProblemType problemType);
  }
}