﻿using CodeJam.Factories;

namespace CodeJam
{
  internal class Program
  {
    private static void Main(string[] args)
    {
      ObjectFactory.GetInstance<CodeJamMain>().Execute();
    }
  }
}