import getopt, sys
def CodeJamSolver(infilename, problemclasstype, outfilename):
	print "Parsing " + infilename + " to " + outfilename
	infileobject = open(infilename,'r')
	outfileobject = open(outfilename, 'w')
	N = int(infileobject.readline())
	for i in range(N):

		print 'Case #' + str(i+1)
		problem = problemclasstype(infileobject)
		solution = problem.solution()
		print solution
		outfileobject.write('Case #' + str(i+1) + ': ' + solution + '\n')
	infileobject.close()
	outfileobject.close()

class ProblemA:
    def __init__(self, fileobject):
        ## Read from fileobject into local variables with lines like
        ## self.T = int(fileobject.readline())
        ##  or
        ## self.contents=fileobject.readline().rstrip('\n')
        ##  or
        ## self.words=fileobject.readline().split(' ')
        ##  or
        ## self.nums = [int(x) for x in fileobject.readline().split(' ')]
        self.N = int(fileobject.readline())
        self.name = ["nameholder" for i in range(self.N)]
        self.ingredients = [[] for i in range(self.N)]
        for i in range(self.N):
            words = fileobject.readline().rstrip('\n').split(' ')
            self.name[i] = words[0]
            self.ingredients[i] = [words[k] for k in range(2,len(words)) if words[k] < 'a']
        
    def solution(self):
        ## Use above local variables to return string
        ## for example: return str(x) + ' ' + str(y)
        ## parse floats with eg. "%1.6f" % f
        recipegoogle = {}
        for i in range(self.N):
            recipegoogle[self.name[i]] = i
        ings = [[recipegoogle[b] for b in a] for a in self.ingredients]
        dfs = [0]
        indx = 0
        while indx < len(dfs):
            dfs = dfs + ings[indx]
            indx += 1
        dfs.reverse()
        bowls = [0 for i in range(self.N)]
        for i in dfs:
            if (len(ings[i]) == 0):
                bowls[i] = 1
            else:
                needs = [bowls[k] for k in ings[i]]
                needs.sort()
                needs.reverse()
                needs = [needs[k]+k for k in range(len(needs))]
                needs += [1+len(needs)]
                bowls[i] = max(needs)
        return str(bowls[0])

def usage():
	print "probA.py    runs on test data"
	print "probA.py -t runs on test data"
	print "probA.py -s runs on small data"
	print "probA.py -l runs on large data"
	print "probA.py -h prints this message"

def main():
	try:
		opts, args = getopt.getopt(sys.argv[1:], "hstl", ["help", "small", "test", "large"])
	except getopt.GetoptError, err:
		print str(error)
		usage()
		sys.exit(2);
	type = "test"
	for o, a in opts:
		if o in ("-h", "--help"):
			usage()
			sys.exit()
		elif o in ("-s", "--small"):
			type = "small"
		elif o in ("-l", "--large"):
			type = "large"
	infile = "c:\codejam\semis\problemA\A-" + type + ".in"
	outfile = "c:\codejam\semis\problemA\A-" + type + ".out"
	CodeJamSolver(infile, ProblemA, outfile)

if __name__ == "__main__":
	main()

