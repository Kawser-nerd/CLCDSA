﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    public static class Config
    {
        public static string ProgramToRun = "A";

        public static String inputPath = @"C:\Documents and Settings\User\Downloads\";
        public static String sourcePath = @"C:\Documents and Settings\User\My Documents\Visual Studio 10\Projects\CodeJam2010\CodeJam2010.R2\";
        public static String outputPath = @"C:\Documents and Settings\User\My Documents\Visual Studio 10\Projects\CodeJam2010\Output\";

        public static String archiverPath = @"C:\Program Files\WinRAR\WinRAR.exe";
        public static String archiverArgs = @"a -n*.cs -n*.csproj -r -ep1 ""{0}"" ""{1}""";
    }
}
