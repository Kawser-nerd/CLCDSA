package pl.javahussars.Ominous_Omino;

class TestCase {

	static String RICH = "RICHARD";
	static String GAB = "GABRIEL";

	int X, R, C;

	public TestCase(int x, int r, int c) {
		X = x;
		R = r;
		C = c;
	}

	String resolve() {
		if (X == 1) {
			return GAB;
		}

		int min = Math.min(R, C);
		int max = Math.max(R, C);

		if (X >= 7 || R * C % X > 0 || X > max) {
			return RICH;
		}

		if (X >= 2 * min + 1) {
			return RICH;
		}

		if (X == 2 || X == 3) {
			return GAB;
		}

		if (X == 4) {
			if (min == 2) {
				return RICH;
			} else {
				return GAB;
			}
		}

		if (X == 5) {
			if (min == 3 && max == 5) {
				return RICH;
			} else {
				return GAB;
			}
		}

		if (X == 6) {
			if (min == 3) {
				return RICH;
			} else {
				return GAB;
			}
		}

		return GAB;
	}
}
