﻿using GoogleCodeJam.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinesweeperMaster
{
	class Program
	{
		static void Main(string[] args)
		{
			InputFile input = new InputFile("input.txt");
			OutputFile output = new OutputFile("JAM_OUTPUT.txt");

			int[] values = input.ReadIntArray();
			int TEST_COUNT = values[0];

			for (int i = 0; i < TEST_COUNT; i++)
			{
				MineGrid problem = new MineGrid(input);
				output.WriteCase(i + 1, null);
				output.Write(problem.CalculateAnswer());
			}

			output.Close();
		}
	}
}
