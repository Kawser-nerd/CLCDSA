﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CodeJam_SaveTheUniverse
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.openFileDialog1.ShowDialog() != DialogResult.OK) return;
            csReadFile R = new csReadFile(this.openFileDialog1.FileName);
            foreach (csTestCase Case in R.TestCases)
            {
                Case.Solution = csSolver.SolveCase(Case);
            }
            if (this.saveFileDialog1.ShowDialog() != DialogResult.OK) return;
            R.WriteFile(this.saveFileDialog1.FileName);
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }
    }
}
