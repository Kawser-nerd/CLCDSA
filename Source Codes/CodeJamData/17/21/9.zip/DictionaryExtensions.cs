﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
	public static class DictionaryExtensions
	{
		public static TValue GetOrDefault<TKey, TValue>(this Dictionary<TKey, TValue> d, TKey key,
			TValue def = default(TValue))
		{
			TValue result;
			return d.TryGetValue(key, out result) ? result : def;
		}
	}
}
