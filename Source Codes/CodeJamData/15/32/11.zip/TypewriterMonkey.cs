﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class TypewriterMonkey : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            ProblemSet<TypewriterMonkey>.Solve(args);
        }
        #endregion

        public override void Parse(ProblemReader file)
        {
            file.Read(out K, out L, out S).Read(out keyboard).Read(out target);
        }

        // ReSharper disable InconsistentNaming
        private int K, L, S;
        private string keyboard;
        private string target;
        // ReSharper restore InconsistentNaming

        public override object Solve()
        {
            if (K > 7 || L > 7 || S > 7) return -1.0;

            double ct = 0;
            double total = 0;
            double max = 0;

            foreach (var word in All())
            {
                ct++;
                var saw = 0;
                for (var x = word.IndexOf(target); x != -1; x = word.IndexOf(target, x + 1))
                {
                    saw++;
                }
                max = Math.Max(max, saw);
                total += saw;
            }

            return (ct*max - total)/ct;
        }

        IEnumerable<string> All()
        {
            for (var i = 0;; i++)
            {
                var myi = i;
                var word = "";
                for (var j = 0; j < S; j++)
                {
                    word += keyboard[myi%K];
                    myi /= K;
                }
                if (myi > 0) yield break;
                yield return word;
            }
        } 

        public override IEnumerable<Action> StaticInitialize()
        {
            yield return () =>
            {

            };
        }
    }
}
