import time, math, operator, re
from helper import *

t1 = starttimer()

filename = "D%s.%s"
# 0 for test, 1 for small, 2 for large
is_large = 2

mode_str = '' if is_large == 0 else '-small-attempt0' if is_large == 1 else '-large'
infile = filename % (mode_str, 'in')
outfile = filename % (mode_str, 'out')

# parse input
inf = open(infile, 'r')
outf = open(outfile, 'w')

def solve_war(n, k):
    N = len(n)
    points = 0
    used = [False for _ in range(N)]
    for i in range(N):
        a = n[i]
        for j in range(N):
            if not used[j] and k[j] > n[i]:
                used[j] = True
                break
        else:
            points += 1
            for j in range(N):
                if not used[j]: used[j] = True
    return points

def solve_deceitful(n, k):
    N = len(n)
    ka = 0
    kb = N-1

    points = 0
    for i in range(N):
        if n[i] > k[ka]:
            # either make Ken play his lowest by telling higher than his largest
            points += 1
            ka += 1
        else:
            # or make Ken play his highest by telling just lower than his largest
            kb -= 1
    return points

try:
    T = readI(inf)
    
    for case in range(1, T+1):
        # Ken always plays the smallest block just larger than Naomi's block
        N = readI(inf)
        n = map(float, readL(inf).split())
        k = map(float, readL(inf).split())
        n.sort()
        k.sort()
        y = solve_deceitful(n, k)
        z = solve_war(n, k)
        
        outf.write("Case #%d: %d %d\n" % (case, y, z))
        print "Case #%d: %d %d" % (case, y, z)  

finally:
    inf.close()
    outf.close()

endtimer(t1)
