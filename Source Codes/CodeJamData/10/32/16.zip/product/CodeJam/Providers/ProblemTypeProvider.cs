using System.IO;

namespace CodeJam.Providers
{
  public class ProblemTypeProvider : IProblemTypeProvider
  {
    private readonly IFilePathProvider filePathProvider;

    public ProblemTypeProvider(IFilePathProvider filePathProvider)
    {
      this.filePathProvider = filePathProvider;
    }


    public ProblemType GetProblemType()
    {
      string inputFileName = Path.GetFileName(filePathProvider.InputFilePath());

      string firstLetter = inputFileName.Substring(0, 1).ToUpperInvariant();

      switch (firstLetter)
      {
        case "A":
          return ProblemType.ProblemA;
        case "B":
          return ProblemType.ProblemB;
        case "C":
          return ProblemType.ProblemC;
        case "D":
          return ProblemType.ProblemD;
        default:
          return ProblemType.Default;
      }
    }
  }
}