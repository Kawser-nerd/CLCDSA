#!/usr/bin/perl -lp
s/(\d\d):(\d\d)/$1*60+$2/ge


