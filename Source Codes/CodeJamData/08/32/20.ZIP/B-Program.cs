﻿using System;
using System.Globalization;
using System.IO;
using System.Threading;

namespace B
{
    class Program
    {
        struct InputItem
        {
            public string s;
        }

        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

            if (args.Length != 1)
            {
                Console.WriteLine("Input file name isn't existing.");
                return;
            }

            string input_file_path = args[0];

            InputItem[] input;
            { // Read input data
                using (StreamReader input_file = File.OpenText(input_file_path))
                {
                    int n = int.Parse(input_file.ReadLine()); // Number of cases
                    input = new InputItem[n];
                    for (int ii = 0; ii < n; ++ii)
                    {
                        string line = input_file.ReadLine();

                        input[ii].s = line;
                    }
                }
            }

            using (StreamWriter output_file = File.CreateText(input_file_path + ".out"))
            {
                int i_case = 0;
                foreach (InputItem i in input)
                {
                    ++i_case;

                    // Processing
                    long n = Process(i);

                    output_file.WriteLine("Case #{0}: {1}", i_case, n);
                    output_file.Flush();
                }
            }
        }

        static long Process(InputItem input)
        {
            var a = new long[input.s.Length];
            for (var l = 0; l < a.Length; ++l )
            {
                a[l] = long.Parse(new string(input.s[l], 1));
            }

            var sa = new int[input.s.Length];
            sa[0] = 1;
            long count = Process(a, sa, 0);

            return count;
        }

        static long Process(long[] a, int[] sa, int pos)
        {
            if (pos == a.Length - 1)
            {
                long n = 0;

                int start = 0;
                int sign = 0;
                for (int i = 0; i < a.Length; ++i)
                {
                    if (sa[i] == 0 && i != a.Length - 1)
                        continue;

                    long num = 0;
                    for (int ii = start; ii <= i; ++ii)
                    {
                        num = num*10 + a[ii];
                    }
                    if (sign != 0)
                        num *= sign;
                    n += num;

                    start = i + 1;
                    sign = sa[i];
                }

                if (n % 2 == 0 || n % 3 == 0 || n % 5 == 0 || n % 7 == 0)
                    return 1;
                return 0;
            }

            long count = 0;
            for(int s = -1; s < 2; ++s)
            {
                sa[pos] = s;
                count += Process(a, sa, pos + 1);
            }
            return count;
        }
    }
}
