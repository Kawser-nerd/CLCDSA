﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Text;
using System.Threading;

#if GENERATE_ZIP
using Ionic.Zip;
using System.Globalization;
#endif

namespace Marius.CodeJam
{
    public static class Program
    {
        [STAThread]
        static void Main(params string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            Thread.CurrentThread.CurrentUICulture = CultureInfo.InstalledUICulture;

            if (args.Length == 2)
            {
                Console.SetIn(new StreamReader(args[0]));
                Console.SetOut(new StreamWriter(args[1]));
            }

#if DEBUG
            bool async = false;
#else
            bool async = true;
#endif
            ParalelSolve<Rotate>(async);

            if (args.Length == 2)
            {
                Console.In.Close();
                Console.Out.Close();

                Console.SetIn(new StreamReader(Console.OpenStandardInput()));
                Console.SetOut(new StreamWriter(Console.OpenStandardOutput()));
            }
        }

        public static void ParalelSolve<T>() where T: IParalelSolver, new()
        {
            ParalelSolve<T>(true);
        }

        public static void ParalelSolve<T>(bool async) where T: IParalelSolver, new()
        {
            ParalelSolver<T> solver = new ParalelSolver<T>();
            solver.Solve(async);

#if GENERATE_ZIP
            GenerateSubmisionFile<T>();
#endif
        }

#if GENERATE_ZIP
        // not needed to solve the problem
        private static void GenerateSubmisionFile<T>()
        {
            //Generate submission file
            //USING: dotnetzip library from dotnetzip.codeplex.com (MS-PL)
            using (var zip = new ZipFile())
            {
                zip.AddFile("..\\Program.cs", "");

                var solverFile = typeof(T).Name + ".cs";
                zip.AddFile(Path.Combine("..\\", solverFile), "");

                DependencyAttribute[] deps = (DependencyAttribute[])typeof(T).GetCustomAttributes(typeof(DependencyAttribute), true);
                for (int i = 0; i < deps.Length; i++)
                {
                    var path = Path.Combine("..\\", deps[i].File);
                    zip.AddFile(path, "");
                }

                using (var submitFile = new FileStream("Sources.zip", FileMode.Create))
                {
                    submitFile.SetLength(0);

                    zip.Save(submitFile);
                }
            }
        }
#endif
    }

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Interface | AttributeTargets.Struct, Inherited = true, AllowMultiple = true)]
    public sealed class DependencyAttribute: Attribute
    {
        private readonly string _file;

        public DependencyAttribute(string file)
        {
            this._file = file;
        }

        public string File
        {
            get { return _file; }
        }
    }

    public interface IParalelSolver
    {
        void ReadInput(); // will be called linearly
        void WriteAnswer(int caseNumber); // will be called linearly

        void SolveAsync(); // will be called asyncly
    }

    public sealed class ParalelSolver<T>
        where T: IParalelSolver, new()
    {
        private int _solved;

        public void Solve()
        {
            Solve(true);
        }

        public void Solve(bool async)
        {
            var numCases = int.Parse(Console.ReadLine());
            T[] solvers = new T[numCases];
            for (int i = 0; i < numCases; i++)
            {
                solvers[i] = new T();
                solvers[i].ReadInput();
            }

            _solved = 0;
            for (int i = 0; i < solvers.Length; i++)
            {
                if (async)
                {
                    ThreadPool.QueueUserWorkItem((s) =>
                        {
                            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
                            Thread.CurrentThread.CurrentUICulture = CultureInfo.InstalledUICulture;

                            T solver = (T)s;
                            solver.SolveAsync();

                            Interlocked.Increment(ref _solved);
                        }, solvers[i]);
                }
                else
                {
                    solvers[i].SolveAsync();
                    _solved++;
                }
            }

            Thread.Sleep(10);
            while (_solved < solvers.Length)
            {
                Thread.Sleep(500);
            }

            for (int i = 0; i < solvers.Length; i++)
            {
                solvers[i].WriteAnswer(i + 1);
            }
        }
    }
}
