package lib;

public interface Solver<I, O> {
    O solve(I input);
}
