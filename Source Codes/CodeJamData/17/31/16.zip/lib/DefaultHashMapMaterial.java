package lib;

public class DefaultHashMapMaterial {

    public static <T> HashMapMaterial<T> create() {
        // 해시 펑션은 널도 허용한다.
        return new HashMapMaterial<>(v -> v == null ? 0 : v.hashCode(), Object::equals);
    }
}
