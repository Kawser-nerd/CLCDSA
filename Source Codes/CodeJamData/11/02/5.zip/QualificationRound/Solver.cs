﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public class Solver
{
    const string Folder = @"D:\GCJ\GCJ2011\";
    string FileName;
    string GetFile { get { return Folder + FileName; } }
    List<string> Lines;
    public Solver(List<string> lines) 
    {
        Lines = lines;
        FileName = DateTime.Now.ToShortTimeString().Replace(":", "") + DateTime.Now.Second + ".txt";
    }
    void MakeAnswer(int caseNumber, string answer)
    {
        using (StreamWriter sw = File.AppendText(GetFile))
        {
            sw.WriteLine(string.Format("Case #{0}: {1}", caseNumber, answer));
        }
    }
    string Read()
    {
        string value = Lines[0];
        Lines.RemoveAt(0);
        return value;
    }
    public void Execute()
    {
        int cases = Convert.ToInt32(Read());
        for (int caseIndex = 0; caseIndex < cases; caseIndex++)
        {
            Solve(caseIndex + 1);
        }
    }

    void Solve(int caseNumber)
    {
        string answer = "";

        string[] parts = Read().Split(' ');

        Dictionary<string, string> combines = new Dictionary<string, string>();
        int combineCount = Convert.ToInt32(parts[0]);
        for(int index = 0; index < combineCount; index++)
        {
            string part = parts[1 + index];
            string key1 = part[0].ToString() + part[1].ToString();
            string key2 = part[1].ToString() + part[0].ToString();
            string value = part.Substring(2);
            combines.Add(key1, value);
            combines[key2] = value;
        }

        List<string> opposeds = new List<string>();
        int opposedCount = Convert.ToInt32(parts[combineCount + 1]);
        for (int index = 0; index < opposedCount; index++)
        {
            string part = parts[2 + index + combineCount];
            string key1 = part[0].ToString() + part[1].ToString();
            string key2 = part[1].ToString() + part[0].ToString();
            opposeds.Add(key1);
            opposeds.Add(key2);
        }

        string invoke = parts[combineCount + opposedCount + 3];

        string output = "";
        int length = invoke.Length;
        for (int index = 0; index < length; index++)
        {
            string target = invoke[index].ToString();
            if (output.Length == 0)
            {
                output += target;
                continue;
            }

            // combine
            string key = target + output[output.Length - 1].ToString();
            if (combines.ContainsKey(key))
            {
                output = output.Substring(0, output.Length - 1) + combines[key];
                continue;
            }
            output += target;

            // opposed
            for (int i = 0; i < output.Length; i++)
            {
                string opposedKey = output[i].ToString() + target;
                if (opposeds.Contains(opposedKey))
                {
                    output = "";
                    break;
                }
            }
        }

        List<string> letters = new List<string>();
        foreach (char ch in output)
        {
            letters.Add(ch.ToString());
        }

        answer = "[" + string.Join(", ", letters.ToArray()) + "]";

        MakeAnswer(caseNumber, answer);
    }
}

