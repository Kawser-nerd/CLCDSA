﻿using System.Collections.Generic;
using Gcj.Util;

namespace Gcj.Y2015.R1A.C
{
    class CSolver : GcjSolver
    {
        protected override IEnumerable<object> EnobjSolveCase()
        {
            yield break;
        }

    }
}
