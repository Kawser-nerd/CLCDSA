﻿﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace c
{
    class Program
    {
        static void Main(string[] args)
        {

            StreamReader sr = new StreamReader(args[0]);
            StreamWriter sw = new StreamWriter(args[1]);

            int N = int.Parse(sr.ReadLine());
            for (int ii = 1; ii <= N; ii++)
            {
                int K = int.Parse(sr.ReadLine());
                string[] ln = sr.ReadLine().Split(new Char[] { ' ' });
                int n = int.Parse(ln[0]);
                int[] d = new int[n];
                for (int i = 0; i < n; i++) d[i] = int.Parse(ln[i + 1]);

                int[] deck = new int[K];
                deck[0] = 1;
                int j=1;
                for (int i = 2; i <= K; i++)
                {
                    int ct = 0;
                    for (; ct < i; j++)
                    {
                        if (deck[j % K] == 0) ct++;
                    }
                    deck[(j-1) % K] = i;
                }

                string rv = "";
                for (int i = 0; i < d.Length; i++)
                    rv = rv + (rv.Length > 0 ? " " : "") + deck[d[i] - 1];

                sw.WriteLine("Case #" + ii + ": " + rv);
            }

            sr.Close();
            sw.Close();
        }
    }
}
