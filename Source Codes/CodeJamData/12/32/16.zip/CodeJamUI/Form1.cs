﻿using System;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using CodeJam;

namespace CodeJamUI
{
    public partial class Form1 : Form
    {
        private DateTime _startTime;
        private DateTime _endTime;
        private Engine _codeJamEngine;

        public Form1()
        {
            InitializeComponent();
        }

        private void OpenFileClick(object sender, EventArgs e)
        {
            DialogResult result = openInputFile.ShowDialog();

            if (result == DialogResult.OK)
            {
                RunProcessor();
            }
        }

        private void RunProcessor()
        {
            _startTime = DateTime.Now;
            string[] data = File.ReadAllLines(openInputFile.FileName);
            _codeJamEngine = new Engine();
            _codeJamEngine.ProcessingComplete += CodeJamEngineOnProcessingComplete;
            _codeJamEngine.Start(data);
        }

        private void CodeJamEngineOnProcessingComplete(object sender, EventArgs eventArgs)
        {
            String filenameBase = openInputFile.FileName.Replace(".in", "");
            File.WriteAllLines(filenameBase + ".out", _codeJamEngine.Results);

            _endTime = DateTime.Now;
            txtOutput.Text = _codeJamEngine.Results.Aggregate((output, r) => output + Environment.NewLine + r);
            lblTimeTaken.Text = "Time Taken: " + (_endTime - _startTime).ToString();
        }
    }
}
