package lib;

import java.util.stream.Stream;

public interface Vertexes<T> {
    Stream<T> get();
}
