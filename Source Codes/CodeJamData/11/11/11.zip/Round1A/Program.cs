﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Round1A
{
	class Program
	{
		static void Main(string[] args)
		{
			ProblemA.Solve(Console.In, Console.Out);
		}
	}
}
