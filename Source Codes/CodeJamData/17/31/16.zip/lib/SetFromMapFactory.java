package lib;

import java.util.Set;

public class SetFromMapFactory {

    @Deprecated
    public static <T> Set<T> create(MapFactory<T> mf) {
        return SetFactoryUsingMapFactory.create(mf).create();
    }

}
