﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Cmn.Util;
using Gcj.Util;
using System.Linq;

namespace Gcj.Y2013.R2.D
{
    internal class DSolver : GcjSolver
    {
        protected override IEnumerable<object> EnobjSolveCase()
        {
            yield break;
        }
    }
}
