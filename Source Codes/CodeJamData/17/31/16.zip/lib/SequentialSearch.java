package lib;

import java.util.stream.IntStream;

public class SequentialSearch {
    public static <T> int findOrN1(T[] a, String target) {
        return IntStream.range(0, a.length).filter(j -> target.equals(a[j])).findAny().orElse(-1);
    }
}
