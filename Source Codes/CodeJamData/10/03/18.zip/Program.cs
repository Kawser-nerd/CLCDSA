﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;

namespace CodeJam2010ThemePark
{
    public class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                Console.WriteLine("Usage: " + Process.GetCurrentProcess().MainModule.FileName + " <input filename>");
                return;
            }

            Run(args[0]);
        }

        private static void Run(string filename)
        {
            using (TextReader reader = new StreamReader(filename))
            {
                using (TextWriter fileWriter = new StreamWriter(filename + ".output.txt", false, Encoding.ASCII))
                {
                    using (TextWriter consoleWriter = Console.Out)
                    {
                        MultipleTextWriters writers = new MultipleTextWriters(fileWriter, consoleWriter);
                        Run(reader, writers);
                    }
                }
            }
        }

        private static void Run(TextReader reader, MultipleTextWriters writers)
        {
            int numTests = reader.ReadLineInts()[0];
            for (int i = 0; i != numTests; ++i)
            {
                writers.Write("Case #" + (i + 1) + ": ");
                RunTest(writers, reader);
                writers.Write(Environment.NewLine);
            }
        }

        private static void RunTest(MultipleTextWriters writer, TextReader reader)
        {
            var testTitle = reader.ReadLineLongs();
            long r = testTitle[0];
            long k = testTitle[1];
            long n = testTitle[2];

            var groups = reader.ReadLineLongs();
            if (groups.Length != n)
                throw new InvalidOperationException();

            groups = groups.Where(group => group <= k).ToArray();

            long sum = 0;
            var startGroupIndexToNumGroupsAndSum = new KeyValuePair<long, long>?[n];
            long currentGroupIndex = 0;
            for (int round = 0; round != r; ++round)
            {
                KeyValuePair<long, long>? pairOrNull = startGroupIndexToNumGroupsAndSum[currentGroupIndex];
                if (pairOrNull == null)
                {
                    long currentSum = 0;
                    long numGroups = 0;
                    while (numGroups < n && k >= currentSum + groups[(currentGroupIndex + numGroups) % n])
                        currentSum += groups[(currentGroupIndex + numGroups++) % n];
                    pairOrNull = new KeyValuePair<long, long>(numGroups, currentSum);
                    startGroupIndexToNumGroupsAndSum[currentGroupIndex] = pairOrNull;
                }

                KeyValuePair<long, long> pair = pairOrNull.Value;
                sum += pair.Value;
                currentGroupIndex = (currentGroupIndex + pair.Key) % n;
            }

            writer.Write(sum.ToString());
        }
    }
}
