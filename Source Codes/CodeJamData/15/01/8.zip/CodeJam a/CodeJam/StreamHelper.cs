/* www.codertom.com  -  copyright Tom Harrison 2015 */
using System.IO;
using System.Linq;
using System.Numerics;

namespace CoderTom.CodeJam
{
    public static class StreamHelper
    {
        public static long[] ReadLongArray(this StreamReader stream)
        {
            var line = stream.ReadLine();
            var array = line.Split(' ');
            var items = array.Select(x => long.Parse(x)).ToArray();
            return items;
        }

        public static int[] ReadIntArray(this StreamReader stream)
        {
            var line = stream.ReadLine();
            var array = line.Split(' ');
            var items = array.Select(x => int.Parse(x)).ToArray();
            return items;
        }


        public static BigInteger[] ReadBigNumberArray(this StreamReader stream)
        {
            var line = stream.ReadLine();
            var array = line.Split(' ');
            var items = array.Select(x => BigInteger.Parse(x)).ToArray();
            return items;
        }

        public static string[] ReadStringArray(this StreamReader stream)
        {
            var line = stream.ReadLine();
            var items = line.Split(' ');
            return items;
        }


        public static string ReadString(this StreamReader stream)
        {
            var line = stream.ReadLine();
            return line;
        }

        public static int ReadInt(this StreamReader stream)
        {
            var line = stream.ReadLine();
            var testCaseCount = int.Parse(line);
            return testCaseCount;
        }
    }
}