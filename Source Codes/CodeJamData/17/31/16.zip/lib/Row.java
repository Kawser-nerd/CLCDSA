package lib;

public interface Row<T> {
    T get(int index);
}
