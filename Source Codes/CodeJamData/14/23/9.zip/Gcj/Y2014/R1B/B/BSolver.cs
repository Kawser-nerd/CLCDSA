﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Security.Policy;
using Cmn.Util;
using Gcj.Util;

namespace Gcj.Y2014.R1B.B
{
    public class BSolver : IConcurrentSolver
    {
        public int CCaseGet(Pparser pparser)
        {
            return pparser.Fetch<int>();
        }

        public ConcurrentGcjSolver.DgSolveCase DgSolveCase(Pparser pparser)
        {
            int A, B, K;
            pparser.Fetch(out A, out B, out K);
            return () => Solve(A, B, K);
        }

        private IEnumerable<object> Solve(int A, int B, int K)
        {
            if (A == 0 || B == 0 || K == 0)
                throw new Exception();

            if (A <= K || B <= K)
            {
                yield return (ulong)A*(ulong)B;
                yield break;
                
            }

            //mindegyik K-nál nagyobb
            var bitA = ToBin(A);
            var bitB = ToBin(B);
            var bitK = ToBin(K);

            //akkor üti meg a szar.


            int vonal = bitK.Length;

            ulong cwin = 0;
            //ahol a legnagyobb helyiértékű egyes lesz
            for (int iAFirst = 0; iAFirst < bitA.Length; iAFirst++)
            {
                for (int iBFirst = 0; iBFirst < bitB.Length; iBFirst++)
                {
                    //ugyanott a vonaltól balra -> nagyobb mint k-1, coki
                    if(iAFirst > vonal && iBFirst > vonal && iAFirst == iBFirst)        
                        continue;

                    ulong cwinT = 1;

                    //minegyik a vonaltól balra van
                    if (iAFirst > vonal && iBFirst > vonal)
                    {
                        if (iAFirst > iBFirst)
                        {
                            //a-val el kell menni iBfirst-ig
                            for (int iA = iAFirst + 1; iA > iBFirst; iA --)
                            {
                                if (bitA[iA] == 1)
                                    cwinT *= 2; //0-át vagy 1-et is rakhatunk, mert B-ből nulla jön
                                //else csak 0-át rakhatunk
                            }

                            int iX = iBFirst; //most már együtt lépünk, először tutira 0-át és 1-et kell válas


                        }

                        if (iBFirst > iAFirst)
                        {
                            
                        }
                    }
                }
                
            }


            yield break;

        }

        int[] ToBin(int i)
        {
            if (i == 0)
            {
                return new int[]{0};
            }

            var rgb = new List<int>();
                
            while (i > 0)
            {
                rgb.Insert(0, i % 2 == 0 ? 0 : 1);
                i /= 2;
            }

            return rgb.ToArray();
        }
    }
}
