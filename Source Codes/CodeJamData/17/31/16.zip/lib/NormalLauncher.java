package lib;

import java.util.function.Consumer;

public class NormalLauncher {
    public static void run(Consumer<Input> solver) {
        Launcher.run(NormalTokenizerFactory.INSTANCE, solver);
    }
}
