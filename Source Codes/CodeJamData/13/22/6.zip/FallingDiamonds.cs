﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class FallingDiamonds : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            FileWrapper.Process<FallingDiamonds>(args);
        }
        #endregion

        int N, X, Y;

        public override object Solve()
        {
            N = In<int[]>()[0];
            X = Last<int[]>()[1];
            Y = Last<int[]>()[2];
            if (X < 0)
                X = -X;

            int pyr = 1;
            while (((pyr + 2) * (pyr + 3)) / 2 <= N)
                pyr += 2;

            if (X + Y < pyr)
                return 1.0;

            if (X + Y != pyr + 1)
                return 0.0;

            int falling = N - ((pyr) * (pyr + 1)) / 2;
            long[] row = new long[falling + 1];
            row[0] = 1;
            for (int k = 1; k <= falling; k++)
                row[k] = row[k - 1] * (falling + 1 - k) / k;
            
            long num = 0;
            for (int i = 0; i <= falling; i++)
            {
                int away = falling - i, towards = i;
                if (away > pyr + 1)
                {
                    towards += away - (pyr + 1);
                    away = pyr + 1;
                }
                if (towards > pyr + 1)
                {
                    away += towards - (pyr + 1);
                    towards = pyr + 1;
                }
                if (towards >= Y + 1)
                    num += row[i];
            }

            return num / ((double)row.Sum());
        }
    }
}
