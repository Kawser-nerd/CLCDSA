﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Runtime.ExceptionServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Q2
{
	public class Solver : SolverBase
	{
		public const string INPUT_NAME = "small1";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = false;
		public const bool PRINT_EVERY_RESULT = true;

		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		public override object SolveTestCase(int testCase)
		{
			var spl = GetIntList();
			var N = spl[0];
			var C = spl[1];
			var M = spl[2];
			var tickets = new Dictionary<int, List<Ticket>>();
			for (int i = 0; i < N; i++)
				tickets[i] = new List<Ticket>();
			for (int i = 0; i < M; i++)
			{
				var spl2 = GetIntList();
				var loc = spl2[0] - 1;
				tickets[loc].Add(new Ticket { Location = spl2[0] - 1, Customer = spl2[1] - 1 });
			}

			var totalRides = GetTotalRides(tickets, N);
			int totalPromotions = 0;
			var seats = new Dictionary<int, int>();
			seats[0] = tickets[0].Count;
			for (int l = 1; l < N; l++)
			{
				var c = tickets[l].Count;
				if (c <= totalRides)
				{
					seats[l] = c;
					continue;
				}
				totalPromotions += c - totalRides;
			}
			return string.Format("{0} {1}", totalRides, totalPromotions);
		}

		private static int GetTotalRides(Dictionary<int, List<Ticket>> tickets, int N)
		{
			var seats = new Dictionary<int, int>();
			var totalRides = tickets[0].Count;
			seats[0] = totalRides;
			for (int l = 1; l < N; l++)
			{
				var c = tickets[l].Count;
				if (c <= totalRides)
				{
					seats[l] = c;
					continue;
				}
				var promotionsNeeded = c - totalRides;

				while (promotionsNeeded > 0)
				{
					for (int i = 0; i < l; i++)
					{
						var free = totalRides - seats[i];
						var toUse = Math.Min(free, promotionsNeeded);
						promotionsNeeded -= toUse;
						seats[i] -= toUse;
						if (promotionsNeeded == 0)
							break;
					}
					if (promotionsNeeded > 0)
					{
						totalRides++;
						promotionsNeeded--;
					}
				}

				seats[l] = totalRides;
			}

			var signleCustomerTicketCount = tickets.Values.SelectMany(x => x).GroupBy(t => t.Customer).Select(g => g.Count());
			return Math.Max(totalRides, signleCustomerTicketCount.Max());
		}
	}

	public class Ticket
	{
		public int Location;
		public int Customer;
	}
}
