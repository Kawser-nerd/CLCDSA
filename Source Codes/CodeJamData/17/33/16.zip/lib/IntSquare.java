package lib;

public class IntSquare {
    public static int of(int v) {
        return v * v;
    }
}
