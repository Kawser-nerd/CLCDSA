﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class DataPacking : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            ProblemSet<DataPacking>.Solve(args);
        }
        #endregion

        public override void Parse(ProblemReader file)
        {
            file.Read(out N, out X).Read(out S);
        }

        // ReSharper disable InconsistentNaming
        private int N, X;
        private int[] S;
        // ReSharper restore InconsistentNaming

        public override object Solve()
        {
            Array.Sort(S);
            var ct = 0;
            for (int rt = S.Length - 1, lt = 0; rt >= lt; rt--, ct++)
            {
                if (X >= S[rt] + S[lt]) lt++;
            }

            return ct;
        }

        public override IEnumerable<Action> StaticInitialize()
        {
            yield return () =>
            {

            };
        }
    }
}
