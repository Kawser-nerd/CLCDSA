/**
 * 
 */
package gepa.gcj.main.result;

import gepa.gcj.main.ParseException;
import gepa.gcj.main.Result;

/**
 * @author gepa
 *
 */
public class LResult extends SingleLineResult {

    private long value;

    public LResult(long value) {
        this.value = value;
    }

    @Override
    public String getAsString() {
        return "" + value;
    }

    @Override
    public void parseSingle(String data) throws ParseException {
        try {
            value = Long.parseLong(data);
        } catch (NumberFormatException e) {
            throw new ParseException("Could not parse \"" + data + "\" to long!", e);
        }
    }

    @Override
    public boolean isSameAs(Result expected) {
        if (!(expected instanceof LResult)) {
            return false;
        }
        LResult o = (LResult)expected;
        return value == o.value;
    }
}
