#!/usr/bin/env python
import sys
from mypy.codejam import *

class UniverseTestCase(TestCase):
    def parseTestCase(self, file):
        self.numEngines = int(file.readline())
        self.engines = []
        for engine in xrange(self.numEngines):
            self.engines.append(file.readline())
        self.numQueries = int(file.readline())
        self.queries = []
        for query in xrange(self.numQueries):
            self.queries.append(file.readline())

def findMaxRun(queries, engines):
    """Return length of longest run at start of queries without a one of engines appearing."""
    max = 0
    for engine in engines:
        if engine not in queries:
            return len(queries)
        index = queries.index(engine)
        if index > max:
            max = index
    return max

def solver(testcase):
    assert(testcase is not None)
    queries = testcase.queries
    engines = testcase.engines
    if len(queries) == 0:
        return "0"
    print "%d engines %d queries" % (testcase.numEngines, testcase.numQueries)
    position = 0
    switches = -1 # Don't count initial run
    while position < len(queries):
        position += findMaxRun(queries[position:], engines)
        switches += 1
    return "%d" % switches
    
def main():
    problem = GoogleProblem(testcaseClass=UniverseTestCase)
    problem.solve(solver)

if __name__ == "__main__":
    sys.exit(main())
