package lib;

import java.util.Arrays;

public class IntQuadruple {

    public final int v1, v2, v3, v4;

    public IntQuadruple(int v1, int v2, int v3, int v4) {
        this.v1 = v1;
        this.v2 = v2;
        this.v3 = v3;
        this.v4 = v4;
    }

    @Override
    public String toString() {
        return Arrays.asList(v1, v2, v3, v4).toString();
    }
}
