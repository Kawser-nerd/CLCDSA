﻿using Template.Interfaces;

namespace Template
{
  public abstract class ProblemTemplate : IProblem
  {
    protected int NumberOfCases;
    private readonly ICaseFormatter caseFormatter;

    public ProblemTemplate(ICaseFormatter caseFormatter)
    {
      this.caseFormatter = caseFormatter;
    }

    public void Solve(IInput input, IOutput output)
    {
      SetupAndGetNumberOfCases(input);

      for (int i = 0; i < NumberOfCases; i++)
      {
        output.WriteLine(caseFormatter.FormatOutput(SolveOneCase(input)));
      }
    }

    protected virtual void SetupAndGetNumberOfCases(IInput input)
    {
      NumberOfCases = input.ParseInt()[0];
    }

    protected abstract string SolveOneCase(IInput input);
  }
}