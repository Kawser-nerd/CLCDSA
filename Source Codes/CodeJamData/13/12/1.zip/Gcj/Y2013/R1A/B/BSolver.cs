﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Gcj.Util;
using System.Linq;

namespace Gcj.Y2013.R1A.B
{
    internal class BSolver : GcjSolver
    {
        protected override IEnumerable<object> EnobjSolveCase()
        {
            int eMax;
            int eBack;
            int ctask;
            Fetch(out eMax, out eBack, out ctask);
            var rgvalue = Fetch<int[]>().ToList();

            decimal e = eMax;
            decimal score = 0;
            for(var itask = 0;itask<rgvalue.Count;itask++)
            {
                decimal efree = (e + eBack) - eMax;
                if(efree >= e)
                {
                    efree = e;
                }
                else
                {
                    var c = 1;
                    for(;;)
                    {
                        var itask2 = itask + c;

                        if(itask2 >= rgvalue.Count)
                        {
                            efree = e;
                            break;
                        }

                        if(rgvalue[itask2] >= rgvalue[itask])
                            break;

                        efree = (e + eBack + c * eBack) - eMax;

                        if(efree >= e)
                        {
                            efree = e;
                            break;
                        }

                        c++;
                    }
                }
                if(efree<0)
                    efree = 0;
                score += rgvalue[itask] * efree;
                e = Math.Min(eMax, e-efree+eBack);
            }
            yield return score;

            //var rgeminAfter = new int[rgvalue.Count].ToList();
            //var rgf = new bool[rgvalue.Count].ToList();

            //foreach(var grp in rgvalue.Select((v,i)=>new{v,i}).GroupBy(vivalue => vivalue.v).OrderByDescending(grp => grp.Key))
            //{
            //    foreach(var vivalue in grp.OrderBy(vivalue => vivalue.i))
            //    {
            //        if(rgf[vivalue.i])

            //        rgf[vivalue.i] = true;
            //        var efree = 0;


            //        for(var ctaskFree = 1;;ctaskFree++)
            //        {
            //            if(vivalue.i-ctaskFree<0)
            //                break;

            //            efree += eBack;

            //            if(efree)

            //            if(rgf[vivalue.i-ctaskFree])
            //                break;
            //        }

            //    }
            //}

            //var e = eMax;

            //long score = 0;
            //for(var itask = 0;itask < rgvalue.Count;)
            //{
            //    var eminAfter = rgeminAfter[itask];

            //    var efree = e - (eminAfter - eBack);

            //    Debug.Assert(efree >= 0);

            //    score += efree * rgvalue[itask];

            //    e = eminAfter;

            //    itask++;
            //}

            //yield return score;
        }

    }
}
