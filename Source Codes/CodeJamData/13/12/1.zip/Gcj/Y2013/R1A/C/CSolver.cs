﻿using System.Collections.Generic;
using Gcj.Util;

namespace Gcj.Y2013.R1A.C
{
    internal class CSolver : GcjSolver
    {
        protected override IEnumerable<object> EnobjSolveCase()
        {
            yield break;
        }

    }
}
