import time, math, operator, re
from helper import *

timer1 = starttimer()

filename = "B%s.%s"
# 0 for test, 1 for small, 2 for large
is_large = 2

mode_str = '' if is_large == 0 else '-small-attempt0' if is_large == 1 else '-large'
infile = filename % (mode_str, 'in')
outfile = filename % (mode_str, 'out')

# parse input
inf = open(infile, 'r')
outf = open(outfile, 'w')

try:
    T = readI(inf)
    
    for case in range(1, T+1):
        C, F, X = map(float, readL(inf).split())
        time = 0.0
        cookies = 0.0
        rate = 2.0
        while True:
            t1 = (X - cookies) / rate
            t2 = (C - cookies) / rate
            t3 = t2 + X / (rate + F)
            if fcmp(t1, t3, 1e-9) <= 0:
                time += t1
                cookies += t1*rate
                break
            else:
                time += t2
                cookies = 0.0
                rate += F
                                
        outf.write("Case #%d: %.7f\n" % (case, time))
        print "Case #%d: %.7f" % (case, time)  
       
    
finally:
    inf.close()
    outf.close()

endtimer(timer1)
