""" All Your Base

:Abstract: Solution to Google Code Jam 2009 Round 1C
:Authors:  iki
:Contact:  jan.killian at (g)mail.com

.. contents::

Problem statement
=================

Input
-----

Output
------

Limits
------

Doctest
=======

>>> test(
...   testlabel='sample via parse()',
...   testinput='''3
...   11001001
...   cats
...   zig
... ''')  #doctest: +NORMALIZE_WHITESPACE
Case #1: 201
Case #2: 75
Case #3: 11

"""
__docformat__ = 'restructuredtext en'

from codejam import *

def solve(m):
    if not m: return 0
    base = max(2, len(set(m)))
    bmap = { m[0]: 1 }
    zero = False
    for t in m:
        if not t in bmap:
            if zero:
                bmap[t] = len(bmap)
            else:
                bmap[t] = 0
                zero = True
    n = 0
    b = 1
    for t in reversed(m):
        n += bmap[t] * b
        b *= base

    return n

def parse(fi):
    return [fi.next().strip()]

main(solve, parse)
