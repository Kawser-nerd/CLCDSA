import generic.InUtils;
import generic.Solver;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

// Small correct

public class QB implements Solver {

	@Override
	public String solveCase() {
		String[] tokens = InUtils.oneLineStringArray();
		Map<String, String> combines = new HashMap<String, String>();
		Set<Opp> opps = new HashSet<Opp>();
		int numberOfCombines = Integer.parseInt(tokens[0]);
		for(int i=0; i<numberOfCombines; i++){
			String newCombine = tokens[1+i];
			combines.put(newCombine.substring(0, 2),  newCombine.substring(2, 3));
			combines.put(newCombine.substring(1, 2) + newCombine.substring(0, 1),  newCombine.substring(2, 3));
		}
		int numberOfOpps = Integer.parseInt(tokens[1+numberOfCombines]);
		for(int i=0; i<numberOfOpps; i++){
			Opp newOpp = new Opp();
			newOpp.first = tokens[1+numberOfCombines+1+i].substring(0,1);
			newOpp.second = tokens[1+numberOfCombines+1+i].substring(1,2);
			opps.add(newOpp);
		}
		String formula = tokens[1+numberOfCombines+1+numberOfOpps+1];
		Stack<String> result = new Stack<String>();
		for(int i=0; i<formula.length(); i++){
			String element = formula.substring(i, i+1);
			if(result.isEmpty())
				result.add(element);
			else if(combines.containsKey(result.peek()+element)){
				String popped = result.pop();
				for(Opp opp : opps)
					opp.removeOne(popped);
				result.add(combines.get(popped+element));
			}
			else
				result.add(element);
			boolean clear = false;
			for(Opp opp : opps){
				opp.signalElement(result.peek());
				if(opp.alert()){
					clear = true;
					break;
				}
			}
			if(clear){
				result = new Stack<String>();
				for(Opp opp : opps)
					opp.clear();
			}
		}
		return Arrays.toString(result.toArray());
	}

	private class Opp{
		String first;
		String second;
		int firstGot = 0;
		int secondGot = 0;

		public void signalElement(String element) {
			if(element.equals(first))
				firstGot++;
			if(element.equals(second))
				secondGot++;
		}

		public void removeOne(String popped) {
			if(popped.equals(first))
				firstGot--;
			if(popped.equals(second))
				secondGot--;
		}

		public void clear() {
			firstGot = 0;
			secondGot = 0;
		}

		public boolean alert() {
			return firstGot>0 && secondGot>0;
		}
	}
}
