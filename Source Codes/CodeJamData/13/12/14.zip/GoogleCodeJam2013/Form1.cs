﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace GoogleCodeJam2013
{
    public partial class GCJ_A2010_R0Q_A_1 : Form
    {
        public GCJ_A2010_R0Q_A_1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtFile.Text = openFileDialog1.InitialDirectory;
        }

        private void btnFile_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            txtFile.Text = openFileDialog1.FileName;
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            txtOutput.Clear();
            StreamWriter sw = new StreamWriter(txtFile.Text.Replace(".in", ".out"), false, Encoding.ASCII);
            StreamReader sr = new StreamReader(txtFile.Text);
            string sResultLine = string.Empty;
            string sLine = string.Empty;
            int nTestCases = 0;

            sLine = sr.ReadLine();
            if (!int.TryParse(sLine, out nTestCases))
            {
                txtOutput.AppendText("Invalid number of test cases!");
                return;
            }
            txtOutput.AppendText("There are " + nTestCases.ToString() + " test cases.\n");

            //---------- for each test case - begin ----------
            double PI = 3.142; //Math.PI;

            for (int iTestCase = 0; iTestCase < nTestCases; iTestCase++)
            {
                //-------------------- test case - begin ----------
                //DateTime date1 = DateTime.Now;

                //------------------------------ data preparation - begin ----------
                Regex reg = new Regex(" ");
                string[] splitted;

                sLine = sr.ReadLine();
                splitted = reg.Split(sLine);

                long E = long.Parse(splitted[0]);
                long R = long.Parse(splitted[1]);
                long N = long.Parse(splitted[2]);

                sLine = sr.ReadLine();
                splitted = reg.Split(sLine);

                long[] acts = new long[N];
                for (int i = 0; i < N; i++)
                    acts[i] = long.Parse(splitted[i]);
                //------------------------------ data preparation - end ----------

                //------------------------------ algorithm - begin ----------
                int look_ahead = (int)Math.Floor((decimal)E / (decimal)R);

                long gain = 0;
                if (E <= R)
                {
                    for (int i = 0; i < N; i++)
                        gain += acts[i];
                    gain *= E;
                }
                else
                {
                    long current_energy = E;
                    for (int i = 0; i < N; i++)
                    {
                        //long max_value = acts[i];
                        //long energy_used = current_energy;
                        //for (int j = 0; j < look_ahead && i + j + 1 < N; j++)
                        //{
                        //    if (acts[i + j + 1] > max_value)
                        //    {
                        //        energy_used = (((j + 1) * R) + current_energy) - E;
                        //        if (energy_used < 0) energy_used = 0;
                        //    }
                        //}
                        //gain += energy_used * acts[i];
                        //current_energy -= (energy_used - R);
                        long max_value = acts[i];
                        long energy_used = 0;
                        long min_energy_used = current_energy;
                        for (int j = 0; j < look_ahead && i + j + 1 < N; j++)
                        {
                            if (acts[i + j + 1] > acts[i])
                            {
                                energy_used = (((j + 1) * R) + current_energy) - E;
                                if (energy_used < 0) energy_used = 0;
                                if (energy_used < min_energy_used) min_energy_used = energy_used;
                            }
                        }
                        gain += min_energy_used * acts[i];
                        current_energy -= (min_energy_used - R);
                        if (current_energy > E) current_energy = E;
                    }
                }
                //------------------------------ algorithm - end ----------

                //------------------------------ result - begin ----------
                sResultLine = "Case #" + (iTestCase + 1).ToString() + ": " + gain.ToString() + "\n";
                //txtOutput.AppendText(sResultLine);
                sw.Write(sResultLine);
                //sw.Flush();
                //------------------------------ algorithm - end ----------

                //DateTime date2 = DateTime.Now;
                //txtOutput.AppendText("Solved in " + (date2-date1).Milliseconds.ToString("#,##0") + " ms.\n");
                //-------------------- test case - end ----------
            }
            //---------- for each test case - end ----------

            sr.Close();
            sw.Close();
        }
    }
}
