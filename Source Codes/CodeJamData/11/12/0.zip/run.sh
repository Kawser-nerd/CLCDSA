pypy/bin/pypy killer.py $* < B-large.in > B-large.out.$1
