﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace TaskA
{
	class Program
	{
		static void Main (string[] args)
		{
			if (args.Length < 2)
				return;

			var f1 = File.OpenText (args[0]);
			var f2 = File.CreateText (args[1]);
			int casesNum = Int32.Parse (f1.ReadLine ());


			var p= new Permuter();
			for (int i = 0; i < casesNum; ++i)
			{
				int n = Int32.Parse (f1.ReadLine ());
				int[]v1= new int[n];
				int[] v2 = new int[n];

				string[] ss = f1.ReadLine ().Split (' ');
				for (int k = 0; k < n; ++k)
					v1[k] = Int32.Parse (ss[k]);
				ss = f1.ReadLine ().Split (' ');
				for (int k = 0; k < n; ++k)
					v2[k] = Int32.Parse (ss[k]);

				f2.WriteLine (String.Format ("Case #{0}: {1}", i + 1, p.GetBest (v1, v2)));
			}

			f1.Close ();
			f2.Close ();
		}
	}
}

