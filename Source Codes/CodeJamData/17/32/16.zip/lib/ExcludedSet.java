package lib;

import java.util.Set;

public class ExcludedSet {
    public static <T> Set<T> of(Set<T> original, T value, SetFactory<T> factory) {
        Set<T> r = factory.create();
        r.addAll(original);
        r.remove(value);
        return r;
    }
}
