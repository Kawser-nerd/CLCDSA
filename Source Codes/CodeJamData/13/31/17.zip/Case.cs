﻿namespace CodeJam2013.A
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;

    /// <summary>
    /// Manages a case of the problem
    /// </summary>
    internal class Case
    {
        private readonly string name;
        private readonly int n;

        private object answer;

        /// <summary>
        /// Prevents a default instance of the <see cref="Case" /> class from being created.
        /// </summary>
        private Case(string name, int n)
        {
            this.name = name;
            this.n = n;
            this.answer = null;
        }

        #region Pre-implemented code
        /// <summary>
        /// Gets a value indicating whether this case <see cref="Case" /> has been solved.
        /// </summary>
        public bool IsSolved
        {
            get { return this.answer != null; }
        }

        /// <summary>
        /// Gets the answer.
        /// </summary>
        /// <exception cref="System.InvalidOperationException">The problem has not been solved yet.</exception>
        public object Answer
        {
            get
            {
                if (!this.IsSolved)
                {
                    throw new InvalidOperationException("The problem has not been solved yet.");
                }

                return this.answer;
            }
        }
        #endregion Pre-implemented code

        /// <summary>
        /// Loads a new test case from the stream.
        /// </summary>
        /// <param name="sr">The stream reader object which the case is to be loaded from.</param>
        /// <returns>A new instance of <see cref="Case"/> class.</returns>
        // ReSharper disable PossibleNullReferenceException
        public static Case Load(StreamReader sr)
        {
            var line = new Tokeniser(sr.ReadLine());
            var name = line.ReadString();
            var n = line.ReadInt32();
            return new Case(name, n);
        }
        // ReSharper restore PossibleNullReferenceException

        /// <summary>
        /// Solves this case.
        /// </summary>
        public void Solve()
        {
            if (this.IsSolved)
            {
                return;
            }

            var consonants = this.FindConsanatBlocks();

            var result = 0L;
            foreach (var block in consonants)
            {
                // ブロック内だけで構成されるもの
                {
                    var nn = block.Length - this.n + 1;
                    Debug.Assert(nn >= 1);
                    var countInternal = nn * (nn + 1) / 2;
                    result += countInternal;
                }

                // ブロックを全部選択し、かつ両側を1個以上取り込むもの
                // -1 はブロックを全部選択し、両側から1つもとらない場合（以前にカウント済み）を相殺するため
                {
                    var countBothSide = block.Left * block.Right;
                    result += countBothSide;
                }

                // ブロックの左側を1個以上取り込み、右側からとらないもの
                {
                    var nn = block.Length - this.n + 1;
                    Debug.Assert(nn >= 1);
                    var countLeftOnly = nn * block.Left;
                    result += countLeftOnly;
                }

                // ブロックの左側からとらず、右側を1個以上取り込むもの
                {
                    var nn = block.Length - this.n + 1;
                    var countRightOnly = nn * block.Right;
                    result += countRightOnly;
                }
            }

            this.answer = result;
        }

        private ConsonantBlock[] FindConsanatBlocks()
        {
            var consonantsTemp = new List<ConsonantBlock>();
            var length = 0;
            var prevEnd = 0;
            for (var i = 0; i < this.name.Length; ++i)
            {
                if (IsConsonant(this.name[i]))
                {
                    ++length;
                }
                else
                {
                    if (length >= this.n)
                    {
                        consonantsTemp.Add(new ConsonantBlock(length, i - length - prevEnd, this.name.Length - i));
                        prevEnd = i - this.n + 1;
                    }

                    length = 0;
                }
            }

            if (length >= this.n)
            {
                consonantsTemp.Add(new ConsonantBlock(length, this.name.Length - length - prevEnd, 0));
            }

            return consonantsTemp.ToArray();
        }

        private static bool IsConsonant(char c)
        {
            switch (c)
            {
                case 'a':
                case 'i':
                case 'u':
                case 'e':
                case 'o':
                    return false;
                default:
                    return true;
            }
        }

        private class ConsonantBlock
        {
            public readonly long Left;
            public readonly long Right;
            public readonly long Length;

            public ConsonantBlock(long length, long left, long right)
            {
                this.Length = length;
                this.Left = left;
                this.Right = right;
            }

            public override string ToString()
            {
                return string.Format("Length={0}, Left={1}, Right={2}", this.Length, this.Left, this.Right);
            }
        }
    }
}
