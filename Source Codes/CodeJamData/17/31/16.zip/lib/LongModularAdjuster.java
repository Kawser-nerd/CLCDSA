package lib;

import java.util.function.UnaryOperator;

public class LongModularAdjuster {

    public static UnaryOperator<Long> of(long modulus) {
        return ModularAdjuster.of(LongAdder.INSTANCE, LongModular.INSTANCE, modulus);
    }
}
