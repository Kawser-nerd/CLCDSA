package lib;

public interface WeightFunction<T> {
    T get(int currentIndex, int previousIndex);
}
