﻿using System.Collections.Generic;
using Gcj.Util;

namespace Gcj.Y2015.R1A.D
{
    class DSolver : GcjSolver
    {
        protected override IEnumerable<object> EnobjSolveCase()
        {
            yield break;
        }

    }
}
