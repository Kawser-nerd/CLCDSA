package lib;

import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Map;

public class SetFactoryUsingMapFactory {

    public static <T> SetFactory<T> create(MapFactory<T> mf) {
        return () -> {
            Map<T, Object> map = mf.create();
            return new AbstractSet<T>() {
                @Override
                public Iterator<T> iterator() {
                    throw new UnsupportedOperationException();
                }

                @Override
                public int size() {
                    throw new UnsupportedOperationException();
                }

                @Override
                public boolean add(T v) {
                    return map.put(v, v) == null;
                }

                @Override
                public boolean contains(Object o) {
                    return map.get(o) != null;
                }
            };
        };
    }
}
