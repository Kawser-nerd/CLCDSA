package lib;

public class ResidualGetter {

    public static GetterOnEdge of(GetterOnEdge capacity, GetterOnEdge flow) {
        return (from, to) -> capacity.get(from, to) - flow.get(from, to);
    }
}
