using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Collections;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Runtime.Serialization;

namespace ConsoleApplication1
{
	class Program
	{
		class TestCase
		{
			int n;
			double[] x;
			double[] y;
			double[] z;
			double[] p;
			double P;

			public void Read(TextReader reader)
			{
				n = int.Parse(reader.ReadLine());
				x = new double[n];
				y = new double[n];
				z = new double[n];
				p = new double[n];
				for (int i=0; i<n; i++)
				{
					string[] ss = reader.ReadLine().Split(new char[]{' ' , '\t'}, StringSplitOptions.RemoveEmptyEntries);
					x[i] = double.Parse(ss[0]);
					y[i] = double.Parse(ss[1]);
					z[i] = double.Parse(ss[2]);
					p[i] = double.Parse(ss[3]);
				}
			}
			public void Solve()
			{
				for (int i = 0; i < n; i++)
				{
				}
				for (int i = 0; i < n; i++ )
					for (int j = i + 1; j < n; j++)
					{
						double xij = (x[i] / p[i] + x[j] / p[j]) / (1/p[i] + 1/p[j]);
						double yij = (y[i] / p[i] + y[j]/p[j]) / (1/p[i] + 1/p[j]);
						double zij = (z[i]/p[i] + z[j]/p[j]) / (1/p[i] + 1/p[j]);
						double pij = Math.Abs(x[i] - xij) / p[i] + Math.Abs(y[i] - yij) / p[i] + Math.Abs(z[i] - zij) / p[i];
						if (P < pij)
							P = pij;
					}
			}
			public string Solution
			{
				get { return P.ToString("0.000000"); }
			}
		}

		List<TestCase> testcases = new List<TestCase>();

		#region Common functions
		static void Main(string[] args)
		{
			if (args.Length == 1 && args[0].ToLower() == "-manual")
			{
				Console.WriteLine("Please enter test case data");
				Console.WriteLine("-------------------------------------------------------------------------------");
				new Program().Solve(Console.In, Console.Out, 1);
			}
			else if (args.Length == 2)
			{
				Console.WriteLine("Input: {0}", args[0]);
				new Program().Solve(File.OpenText(args[0]), File.CreateText(args[1]), -1);
				Console.WriteLine("Output: {0}", args[1]);
			}
			else
			{
				ConsoleColor color = Console.ForegroundColor;
				Console.WriteLine("Using:");
				Console.ForegroundColor = ConsoleColor.White;
				Console.WriteLine("Solution.exe -manual");
				Console.ForegroundColor = color;
				Console.WriteLine("\tfor manual entering of test case, or");
				Console.ForegroundColor = ConsoleColor.White;
				Console.WriteLine("Solution.exe input_file output_file");
				Console.ForegroundColor = color;
				Console.WriteLine("\twhere arguments are paths to the files");
				Console.WriteLine();
			}

			Console.WriteLine("-------------------------------------------------------------------------------");
			Console.WriteLine("Finished. Press ENTER to quit.");
			Console.ReadLine();
		}
		void Solve(TextReader reader, TextWriter writer, int n)
		{
			if (n == -1)
				n = int.Parse(reader.ReadLine());

			ReadInput(reader, n);
			Console.WriteLine("-------------------------------------------------------------------------------");
			DateTime start = DateTime.Now;
			for (int i = 0; i < testcases.Count; i++)
			{
				Console.Write("Solving {0}...", i + 1);
				DateTime tstart = DateTime.Now;
				testcases[i].Solve();
				TimeSpan T = DateTime.Now - start;
				TimeSpan t = DateTime.Now - tstart;
				Console.WriteLine("{0:d2}:{1:d2}.{2:d3}/{3:d2}:{4:d2}.{5:d3}", (int) t.TotalMinutes, t.Seconds, t.Milliseconds, (int) T.TotalMinutes, T.Seconds, T.Milliseconds);
			}
			Console.WriteLine("-------------------------------------------------------------------------------");
			WriteOutput(writer);
		}
		void ReadInput(TextReader reader, int n)
		{
			for (int i = 0; i < n; i++)
			{
				TestCase testcase = new TestCase();
				testcase.Read(reader);
				testcases.Add(testcase);
			}
		}
		void WriteOutput(TextWriter writer)
		{
			for (int i = 0; i < testcases.Count; i++)
				writer.WriteLine("Case #{0}: {1}", i + 1, testcases[i].Solution);
			writer.Flush();
		}
		#endregion Common

	}
}
