package lib;

import java.util.List;

public class MatrixFromRowVectors {
    public static <T> Matrix<T> wrap(List<Vector<T>> rowVectors) {
        int n = rowVectors.size();
        int m = rowVectors.get(0).n;
        return new Matrix<>(n, m, (i, j) -> rowVectors.get(i).element.at(j));
    }
}
