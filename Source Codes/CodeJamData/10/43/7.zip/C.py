# Go to a requested generation.  The given generation can be an
# absolute number like 1,000,000 (commas are optional) or a number
# relative to the current generation like +9 or -6.  If the target
# generation is less than the current generation then we go back
# to the starting generation (normally 0) and advance to the target.
# Authors: Andrew Trevorrow and Dave Greene, April 2006.
# Updated Sept-Oct 2006 -- XRLE support and reusable default value.
# Updated April 2010 -- much faster, thanks to PM 2Ring.

from glife import validint
from time import time
import golly as g


import sys

f = open('/home/theli/Desktop/C.in')
casenum = int(f.readline())

for casei in xrange(casenum):
	g.reset()
	g.new('')
	g.setrule('cj')
	R = int(f.readline())
	g.setstep(1)
	for r in xrange(R):
		_ = f.readline().splitlines()[0].split()
		x1,y1,x2,y2 = (int(x) for x in _)
		for x in xrange(x1, x2 + 1):
			for y in xrange(y1, y2 + 1):
				g.setcell(x,y,1)
	time = 0
	while not g.empty():
		g.run(1)
		time+=1
	print 'Case #%d: %s' % (casei+1,time)
	
	
golly.show("Done")
