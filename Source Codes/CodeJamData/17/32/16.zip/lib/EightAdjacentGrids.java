package lib;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class EightAdjacentGrids {

    private static final int[] DX = {-1, -1, -1, 0, 1, 1, 1, 0};
    private static final int[] DY = {-1, 0, 1, 1, 1, 0, -1, -1};

    public static Stream<GridPosition> of(GridPosition p, int length1, int length2) {
        return IntStream.range(0, 8)
                .mapToObj(k -> new GridPosition(p.i + DX[k], p.j + DY[k]))
                .filter(adjacent -> inRange(adjacent, length1, length2));
    }

    private static boolean inRange(GridPosition p, int length1, int length2) {
        return InRange.in(p.i, 0, length1) && InRange.in(p.j, 0, length2);
    }
}
