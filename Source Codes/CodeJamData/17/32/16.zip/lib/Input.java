package lib;

import java.util.function.Supplier;

public class Input {

    private final Supplier<String> supplier;

    public Input(Supplier<String> supplier) {
        this.supplier = supplier;
    }

    public int nextInt() {
        return Integer.parseInt(next());
    }

    public long nextLong() {
        return Long.parseLong(next());
    }

    public double nextDouble() {
        return Double.parseDouble(next());
    }

    public String next() {
        return supplier.get();
    }

}
