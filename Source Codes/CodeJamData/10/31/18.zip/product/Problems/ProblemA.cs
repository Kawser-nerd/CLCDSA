﻿using Template;
using Template.Interfaces;

namespace Problems
{
  public class ProblemA : ProblemTemplate
  {
    public ProblemA(ICaseFormatter caseFormatter) : base(caseFormatter)
    {
    }

    protected override string SolveOneCase(IInput input)
    {
      int N = input.ParseInt()[0];

      int[] A = new int[N];
      int[] B = new int[N];

      for (int i = 0; i < N; i++)
      {
        var buff = input.ParseInt();
        A[i] = buff[0];
        B[i] = buff[1];
      }

      int inter = 0;

      for (int i = 0; i < N; i++)
      {
        for (int j = i+1; j < N; j++)
        {
          if ((A[i] < A[j] && B[i] > B[j])
            || (A[i] > A[j] && B[i] < B[j]))
            inter++;

        }
      }


      return inter.ToString();
    }
  }
}