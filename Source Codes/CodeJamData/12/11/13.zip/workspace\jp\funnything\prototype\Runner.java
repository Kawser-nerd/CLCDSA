package jp.funnything.prototype;

import java.io.File;
import java.io.IOException;

import jp.funnything.competition.util.CompetitionIO;
import jp.funnything.competition.util.Packer;

import org.apache.commons.io.FileUtils;

public class Runner {
    public static void main( final String[] args ) throws Exception {
        new Runner().run();
    }

    void pack() {
        try {
            final File dist = new File( "dist" );

            if ( dist.exists() ) {
                FileUtils.deleteQuietly( dist );
            }

            final File workspace = new File( dist , "workspace" );

            FileUtils.copyDirectory( new File( "src/main/java" ) , workspace );
            FileUtils.copyDirectory( new File( "../../../../CompetitionUtil/Lib/src/main/java" ) , workspace );

            Packer.pack( workspace , new File( dist , "sources.zip" ) );
        } catch ( final IOException e ) {
            throw new RuntimeException( e );
        }
    }

    void run() throws Exception {
        final CompetitionIO io = new CompetitionIO();

        final int t = io.readInt();

        for ( int index = 0 ; index < t ; index++ ) {
            final int[] values = io.readInts();
            final int a = values[ 0 ];
            final int b = values[ 1 ];
            final double[] p = new double[ a ];
            final String[] ps = io.readTokens();
            for ( int i = 0 ; i < p.length ; i++ ) {
                p[ i ] = Double.parseDouble( ps[ i ] );
            }

            io.write( index + 1 , solve( a , b , p ) );
        }

        io.close();

        pack();
    }

    double solve( final int a , final int b , final double[] p ) {
        double ans = 1 + b + 1;

        for ( int nbs = 0 ; nbs <= a ; nbs++ ) {
            double pOK = 1;

            for ( int i = 0 ; i < p.length ; i++ ) {
                if ( i < a - nbs ) {
                    pOK *= p[ i ];
                }
            }

            final int nTypeOK = b - a + 1 + nbs * 2;
            final int nTypeNG = nTypeOK + b + 1;

            final double value = nTypeOK * pOK + nTypeNG * ( 1 - pOK );

            ans = Math.min( ans , value );
        }

        return ans;
    }
}
