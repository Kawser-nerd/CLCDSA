import java.util.*
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Created by niyaz on 08.04.17.
 */

fun main(args: Array<String>) {

    class Cell(val c: Char, val x: Int, val y: Int)

    class Input(val test: Int, val n: Int, val a: Array<Cell>)

    class Output(val value: Int, val a: Array<Cell>)

    fun solve(test: Input): Output {
        val n = test.n
        val g = Array(2, { Array(n, { BooleanArray(n) }) })
        val a = test.a
        fun decode(c: Char): Int {
            if (c == 'o') return 3
            if (c == 'x') return 1
            if (c == '+') return 2
            return 0
        }
        fun encode(a: Boolean, b: Boolean): Char {
            val x = (if (b) 1 else 0) * 2 + (if (a) 1 else 0)
            if (x <= 0 || x > 3) throw AssertionError()
            return ".x+o"[x]
        }
        for (e in a) {
            val mask = decode(e.c)
            for (i in 0..1) {
                if (((mask shr i) and 1) == 1) {
                    g[i][e.x][e.y] = true
                }
            }
        }
        val rows = BooleanArray(n)
        val cols = BooleanArray(n)
        val sum = BooleanArray(n + n - 1)
        val dif = BooleanArray(n + n - 1)
        for (i in 0..n - 1) {
            for (j in 0..n - 1) {
                if (g[0][i][j]) {
                    rows[i] = true
                    cols[j] = true
                }
                if (g[1][i][j]) {
                    sum[i + j] = true
                    dif[i - j + n - 1] = true
                }
            }
        }
        val h = g.clone()
        for (i in h.indices) {
            h[i] = h[i].clone()
            for (j in h[i].indices) {
                h[i][j] = h[i][j].clone()
            }
        }
        for (i in 0..n - 1) {
            for (j in 0..n - 1) {
                if (!rows[i] && !cols[j]) {
                    rows[i] = true
                    cols[j] = true
                    h[0][i][j] = true
                }
            }
        }
        val matcher = KuhnMatchingGraph(n + n - 1, n + n - 1)
        for (i in 0..n - 1) {
            for (j in 0..n - 1) {
                if (!sum[i + j] && !dif[i - j + n - 1]) {
                    matcher.addEdge(i + j, i - j + n - 1)
                }
            }
        }
        val maximumMatching = matcher.computeMaximumMatching()
        for (from in 0..n + n - 2) {
            val to = matcher.p1[from]
            if (to >= 0) {
                val v = (from + to - n + 1) / 2
                val u = from - v
                h[1][v][u] = true
            }
        }
        val value = h.sumBy { it.sumBy { it.sumBy { if (it) 1 else 0 } } }
        val d = ArrayList<Cell>()
        for (i in 0..n - 1) {
            for (j in 0..n - 1) {
                if (g[0][i][j] != h[0][i][j] || g[1][i][j] != h[1][i][j]) {
                    d.add(Cell(encode(h[0][i][j], h[1][i][j]), i, j))
                }
            }
        }
        return Output(value, d.toTypedArray())
    }

    fun read(test: Int, input: Scanner): Input {
        val n = input.nextInt()
        val m = input.nextInt()
        val a = Array(m, { Cell(input.next()[0], input.nextInt() - 1, input.nextInt() - 1) })
        return Input(test, n, a)
    }

    fun write(test: Int, result: Output) {
        println("Case #$test: ${result.value} ${result.a.size}")
        for (e in result.a) {
            println("${e.c} ${e.x + 1} ${e.y + 1}")
        }
    }

    val programStart = System.currentTimeMillis()

    val testsProcessed = AtomicInteger(0)
    val totalTime = AtomicLong(0)
    val input = Scanner(System.`in`)
    val t = input.nextInt()
    val threadManager = Executors.newFixedThreadPool(3)
    val futures = Array(t, { i -> read(i + 1, input) }).map { x ->
        threadManager.submit(Callable<Output> {
            val start = System.currentTimeMillis()
            val ret = solve(x)
            val time = System.currentTimeMillis() - start
            System.err.println("Finished testcase #${x.test} in ${time}ms, processed ${testsProcessed.incrementAndGet()} tests")
            totalTime.addAndGet(time)
            ret
        })
    }
    for ((i, f) in futures.withIndex()) {
        write(i + 1, f.get())
    }
    threadManager.shutdownNow()
    System.err.println("Processed $testsProcessed in ${System.currentTimeMillis() - programStart}ms, and ${totalTime}ms of total time")
}
