﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BigNum;

namespace gcj
{
    class B
    {
        public void solve()
        {
            int notc = int.Parse(Console.ReadLine());
            for (int i = 1; i <= notc; i++)
            {
                string[] vars = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                long l = long.Parse(vars[0]);
                long p = long.Parse(vars[1]);
                long c = long.Parse(vars[2]);
                long temp = l;
                long totres = 0;
                while (true)
                {
                    temp = temp * c;
                    if (temp < p)
                        totres++;
                    else
                        break;
                }
                double val = Math.Log((double)totres, (double)2);
                long lval = (long)val;
                lval++;
                if (totres == 0)
                    lval = 0;
                Console.WriteLine("Case #" + i + ": " + lval);
            }
        }
    }
}
