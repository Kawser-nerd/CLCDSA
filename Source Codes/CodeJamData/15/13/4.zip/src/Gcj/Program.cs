﻿using Gcj.Util;
using Gcj.Y2015.R1A.A;
using Gcj.Y2015.R1A.B;
using Gcj.Y2015.R1A.C;


namespace Gcj
{
    class Program
    {
        static void Main(string[] args)
        {
            GcjSolver.Solve<CSolver>();
            //ConcurrentGcjSolver.Solve<OutOfGasConcurrentSolver2>(true);
        }
    }
}
