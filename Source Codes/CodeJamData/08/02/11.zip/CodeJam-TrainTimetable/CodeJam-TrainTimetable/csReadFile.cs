﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeJam_TrainTimetable
{
    class csReadFile
    {
        private int NumTestCases = 0;
        private List<csTestCase> Cases  = new List<csTestCase>(); //List of cases

        public List<csTestCase> TestCases
        {
            get
            {
                return Cases;
            }
        }


        public csReadFile(string FileName)
        {
            StreamReader R = new StreamReader(FileName);
            string str;

            //read first line
            str = R.ReadLine();
            NumTestCases = int.Parse(str);

            //loop test cases
            for (int i = 0; i < NumTestCases; i++)
            {
                csTestCase Case = new csTestCase();
                
                //read turn around time
                str = R.ReadLine();
                Case.TurnaroundTime = int.Parse(str);

                //read NA / NB
                str = R.ReadLine();
                Case.NA = int.Parse(str.Split(" ".ToCharArray())[0]);
                Case.NB = int.Parse(str.Split(" ".ToCharArray())[1]);

                //read A timetable
                for (int j = 0; j < Case.NA; j++)
                {
                    str = R.ReadLine();
                    int DepH = int.Parse(str.Split(": ".ToCharArray())[0]);
                    int DepM = int.Parse(str.Split(": ".ToCharArray())[1]);
                    int ArrH = int.Parse(str.Split(": ".ToCharArray())[2]);
                    int ArrM = int.Parse(str.Split(": ".ToCharArray())[3]);

                    Case.A.Add(new csTrip(DepH, DepM, ArrH, ArrM));
                }

                //read B timetable
                for (int j = 0; j < Case.NB; j++)
                {
                    str = R.ReadLine();
                    int DepH = int.Parse(str.Split(": ".ToCharArray())[0]);
                    int DepM = int.Parse(str.Split(": ".ToCharArray())[1]);
                    int ArrH = int.Parse(str.Split(": ".ToCharArray())[2]);
                    int ArrM = int.Parse(str.Split(": ".ToCharArray())[3]);

                    Case.B.Add(new csTrip(DepH, DepM, ArrH, ArrM));
                }

                Cases.Add(Case);
            }
        }

        public void WriteFile(string FileName)
        {
            StreamWriter W = new StreamWriter(FileName);

            int i = 1;
            foreach (csTestCase Case in Cases)
            {
                W.WriteLine("Case #" + i + ": " + Case.SolA.ToString() + " " + Case.SolB.ToString());
                i++;
            }

            W.Close();
        }
    }
}
