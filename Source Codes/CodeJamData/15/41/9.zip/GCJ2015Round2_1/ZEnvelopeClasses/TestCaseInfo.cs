﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GCJ2015Round2_1
{
	public class TestCaseInfo
	{
		#region Fields

		private Dictionary<int, string> m_TestCaseInputMap = new Dictionary<int, string>();

		#endregion

		#region Methods

		public void AddTestCaseInputInfo(int testCase, string line)
		{
			string currentValue;
			if (!m_TestCaseInputMap.TryGetValue(testCase, out currentValue))
			{
				currentValue = line;
			}
			else
			{
				currentValue += Environment.NewLine + line;
			}

			m_TestCaseInputMap[testCase] = currentValue;
		}

		public string this[int t]
		{
			get
			{
				return m_TestCaseInputMap[t];
			}
		}

		#endregion
	}
}
