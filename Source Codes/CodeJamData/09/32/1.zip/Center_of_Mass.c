#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(void)
{
	int		T, t;
	int		N, n;
	int		i, j, k;
	int		x, y, z, vx, vy, vz;
	double	sx, sy, sz, svx, svy, svz;
	double	tm;
	double	l, r;
	

	scanf("%d\n", &T);

	for(t = 0; t < T; t++)
	{
		sx = sy = sz = svx = svy = svz = 0;
		scanf("%d\n", &N);
		for(n = 0; n < N; n++)
		{
			scanf("%d%d%d%d%d%d\n", &x, &y, &z, &vx, &vy, &vz);
			sx += x;
			sy += y;
			sz += z;
			svx += vx;
			svy += vy;
			svz += vz;
		}
		l = -(sx * svx + sy * svy + sz * svz);
		r = svx * svx + svy * svy + svz * svz;
		if (r == 0.)
			tm = 0.;
		else
			tm = l/r;
		if (tm <= 0.)
			tm = 0.;
		l = sqrt((tm * svx + sx) * (tm * svx + sx) + (tm * svy + sy) * (tm * svy + sy) + (tm * svz + sz) * (tm * svz + sz)) / (double)N;

		printf("Case #%d: %.7f %.7f\n", t + 1, l, tm);
	}
	return 1;
}
