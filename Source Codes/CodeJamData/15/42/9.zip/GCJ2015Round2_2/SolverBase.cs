﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;

namespace GCJ2015Round2_2
{
	public abstract class SolverBase
	{
		private IEnumerator<string> m_InputEnumerator;
		public SolverBase(IEnumerator<string> enumerator)
		{
			m_InputEnumerator = enumerator;
		}

		public static SolverBase Create(IEnumerator<string> enumerator)
		{
			return new Solver(enumerator);
		}

		public abstract string SolveTestCase(int testCase);

		protected string GetLine()
		{
			string line = m_InputEnumerator.Current;

			m_InputEnumerator.MoveNext();

			return line;
		}

		protected int GetInt()
		{
			return int.Parse(GetLine());
		}

		protected List<int> GetIntList()
		{
			List<int> result = new List<int>();
			string[] allStrings = GetLine().Split(' ');
			foreach (string s in allStrings)
			{
				result.Add(int.Parse(s));
			}

			return result;
		}

		protected long GetLong()
		{
			return long.Parse(GetLine());
		}

		protected List<long> GetLongList()
		{
			List<long> result = new List<long>();
			string[] allStrings = GetLine().Split(' ');
			foreach (string s in allStrings)
			{
				result.Add(long.Parse(s));
			}

			return result;
		}

		protected List<BigInteger> GetBigIntList()
		{
			List<BigInteger> result = new List<BigInteger>();
			string[] allStrings = GetLine().Split(' ');
			foreach (string s in allStrings)
			{
				BigInteger value;
				BigInteger.TryParse(s, out value);
				result.Add(value);
			}

			return result;
		}

		protected BigInteger GetBigInt()
		{
			BigInteger value;
			BigInteger.TryParse(GetLine(), out value);
			return value;
		}

		protected double GetDouble()
		{
			return double.Parse(GetLine());
		}

		protected List<double> GetDoubleList()
		{
			var result = new List<double>();
			string[] allStrings = GetLine().Split(' ');
			foreach (string s in allStrings)
			{
				result.Add(double.Parse(s));
			}

			return result;
		}

		protected Neighbours<T> GetNeighbours<T>(T[][] board, int x, int y, T defaultValue = default(T))
		{
			return new Neighbours<T>(board, x, y, defaultValue);
		}

		protected T[][] DeepClone<T>(T[][] source, Func<T, T> cloneFunc = null)
		{
			if (cloneFunc == null)
				cloneFunc = t => t;

			T[][] res = new T[source.Length][];
			for (int i = 0; i < source.Length; i++)
			{
				res[i] = new T[source[i].Length];
				for (int j = 0; j < source[i].Length; j++)
				{
					res[i][j] = cloneFunc(source[i][j]);
				}
			}
			return res;
		}

		protected T[] DeepClone<T>(T[] source, Func<T, T> cloneFunc = null)
		{
			if (cloneFunc == null)
				cloneFunc = t => t;

			T[] res = new T[source.Length];
			for (int i = 0; i < source.Length; i++)
			{
				res[i] = cloneFunc(source[i]);
			}

			return res;
		}

		protected void Print<T>(T[] array)
		{
			string toPrint = string.Join(", ", array);
			Program.PrintOut(toPrint);
		}
		protected void Print<T>(T[][] array)
		{
			string toPrint = string.Join(Environment.NewLine, array.Select(arr => string.Join(", ", arr)));
			Program.PrintOut(toPrint);
		}
	}
}
