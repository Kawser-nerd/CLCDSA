package lib;

import java.util.Arrays;

public class IntArrayHashMapMaterial {
    public static final HashMapMaterial<int[]> INSTANCE = new HashMapMaterial<>(Arrays::hashCode, Arrays::equals);
}
