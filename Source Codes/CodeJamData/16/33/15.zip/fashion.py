#! /usr/bin/env python
from __future__ import print_function, division
try:
    range = xrange
except NameError:
    pass

import collections
# import functools
# import itertools as it
# import numpy as np # See http://www.numpy.org
# import sympy as sp # See http://sympy.org/en/index.html
# import gmpy2 # See https://code.google.com/p/gmpy/
# import networkx as nx # See http://networkx.github.io/

import os
import sys
# MY MODULES - available at https://github.com/lackofcheese/CodeJamLib/
sys.path.append(os.path.join(
    os.environ['GOOGLE_DRIVE'], 'Coding', 'GCJ', 'CodeJamLib'))
import codejam_io

def toks_line(f_in, fun=int):
    return [fun(k) for k in f_in.readline().split()]

def process_first(f_in):
    num_cases = int(f_in.readline())
    other_data = None
    return num_cases, other_data

def process_case(f_in, f_out, case_no, other_data=None):
    J, P, S, K = toks_line(f_in)
    ans = solve(J, P, S, K)
    nc = len(ans)
    print("Case #{}: {}".format(case_no, nc), file=f_out)
    for combo in ans:
        print(' '.join(str(c+1) for c in combo), file=f_out)

def solve(J, P, S, K):
    # print(J, P, S, K)
    n_per_JP = min(S, K)
    n_ways = J * P * n_per_JP
    JS = collections.Counter()
    PS = collections.Counter()
    combos = []
    counts = [0] * S
    for j in range(J):
        for p in range(P):
            for n in range(n_per_JP):
                s = (j+p+n)%S
                if JS[j,s] >= K:
                    print("ERROR", file=sys.stderr)
                    return None
                if PS[p,s] >= K:
                    print("ERROR", file=sys.stderr)
                    return None
                combos.append((j, p, s))
                JS[j,s] += 1
                PS[p,s] += 1
    return combos

if __name__ == '__main__':
    codejam_io.process_input(process_case, process_first, __file__)
