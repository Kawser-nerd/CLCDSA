﻿using System;
using CodeJamLibrary.Interfaces;

namespace CodeJamLibrary
{
  public abstract class ProblemTemplate : IProblem
  {
    private const string header =
      @"
*********************************************************
*
*   Running {0}
*
*********************************************************";
    protected int Cycles;

    public void Solve(IProblemInput problemInput, IProblemOutput problemOutput)
    {
      Console.Error.WriteLine(header, this.GetType().ToString());

      SetupAndGetCycles(problemInput);

      for (int i = 0; i < Cycles; i++)
      {
        problemOutput.WriteCase(Solve(problemInput));
      }
    }

    protected virtual void SetupAndGetCycles(IProblemInput problemInput)
    {
      Cycles = int.Parse(problemInput.SplitLine()[0]);
    }

    protected abstract string Solve(IProblemInput problemInput);
  }
}
