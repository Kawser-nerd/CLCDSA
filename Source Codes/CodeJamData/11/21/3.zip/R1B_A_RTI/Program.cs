﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using JamHelpers;
using System.Diagnostics;

namespace R1B_A_RTI
{
	class Program : ProgramBase
	{
		static void Main(string[] args)
		{
			new Program().Run();
		}

		public override void RunCase()
		{
			string[] lines = ReadMultiLine();
			var wins = new List<int>[lines.Length];
			var losses = new List<int>[lines.Length];
			for (int me = 0; me < lines.Length; me++)
			{
				wins[me] = new List<int>();
				losses[me] = new List<int>();
				for (int opp = 0; opp < lines[me].Length; opp++)
				{

					char c = lines[me][opp];
					if (c == '1')
						wins[me].Add(opp);
					else if (c == '0')
						losses[me].Add(opp);
					else if (c != '.')
						Debug.Assert(false);
				}
			}
			double[] wp = new double[lines.Length];
			double[] owp = new double[lines.Length];
			double[] oowp = new double[lines.Length];

			for (int me = 0; me < lines.Length; me++)
			{
				var games = wins[me].Concat(losses[me]);
				Debug.Assert(games.Count() == games.Distinct().Count());
				Debug.Assert(games.All(j => j != me));
				double myWp = (double)wins[me].Count / (wins[me].Count + losses[me].Count);
				wp[me] = myWp;
				double myOwp = 0;
				foreach (int opp in games)
				{
					var oppWins = wins[opp].Where(i => i != me).Count();
					var oppLosses = losses[opp].Where(i => i != me).Count();
					var oppGames = oppWins + oppLosses;
					double owp0 = (double)oppWins / oppGames;
					myOwp += owp0;
				}
				myOwp = myOwp / games.Count();
				owp[me] = myOwp;
			}

			for (int me = 0; me < lines.Length; me++)
			{
				var games = wins[me].Concat(losses[me]);
				double myOowp = games.Select(opp => owp[opp]).Average();
				oowp[me] = myOowp;
			}
			WriteLine(CaseStr);
			for (int me = 0; me < lines.Length; me++)
			{
				double score = 0.25 * wp[me] + 0.5 * owp[me] + 0.25 * oowp[me];
				WriteLine(score);
			}
		}
	}
}
