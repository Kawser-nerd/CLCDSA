package pl.javahussars.Dijkstra;

class Quat {
	static Quat ONE = new Quat('1');
	static Quat i = new Quat('i');
	static Quat j = new Quat('j');
	static Quat k = new Quat('k');

	static Quat _ONE = new Quat('1', false);
	static Quat _i = new Quat('i', false);
	static Quat _j = new Quat('j', false);
	static Quat _k = new Quat('k', false);

	char c;
	boolean positive = true;

	private Quat(char c) {
		this.c = c;
	}

	static Quat get(char c) {
		switch (c) {
		case '1':
			return ONE;
		case 'i':
			return i;
		case 'j':
			return j;
		case 'k':
			return k;
		default:
			return null;
		}
	}

	Quat(char c, boolean positive) {
		this.c = c;
		this.positive = positive;
	}

	Quat mult(Quat other) {
		Quat _this = positive ? this : this.negate();
		Quat _other = other.positive ? other : other.negate();

		Quat res = _this.multPositives(_other);
		if (positive && other.positive || !positive && !other.positive) {
			return res;
		} else {
			return res.negate();
		}
	}

	private Quat multPositives(Quat other) {

		if (c == '1') {
			return other;
		}

		if (other.c == '1') {
			return this;
		}

		if (c == other.c) {
			return _ONE;
		}

		if (c == 'i') {
			if (other.c == 'j') {
				return k;
			} else {
				return _j;
			}
		} else if (c == 'j') {
			if (other.c == 'i') {
				return _k;
			} else {
				return i;
			}
		} else { // c == 'k'
			if (other.c == 'i') {
				return j;
			} else {
				return _i;
			}
		}
	}

	Quat negate() {
		switch (c) {
		case '1':
			return positive ? _ONE : ONE;
		case 'i':
			return positive ? _i : i;
		case 'j':
			return positive ? _j : j;
		case 'k':
			return positive ? _k : k;
		default:
			return null;
		}
	}

	@Override
	public String toString() {
		return (positive ? "" : "-") + c;
	}
}
