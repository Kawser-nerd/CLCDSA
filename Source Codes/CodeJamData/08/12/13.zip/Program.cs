﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace TaskB
{
	class Program
	{
		static void Main (string[] args)
		{
			//args = new string[] { "B-small-attempt0.in", "a.out" };

			if (args.Length < 2)
				return;

			var f1 = File.OpenText (args[0]);
			var f2 = File.CreateText (args[1]);
			int casesNum = Int32.Parse (f1.ReadLine ());


			var shaker = new Shaker ();
			for (int i = 0; i < casesNum; ++i)
			{
				int flavoursNum = Int32.Parse (f1.ReadLine ());
				int clientsNum = Int32.Parse (f1.ReadLine ());

				int[][] clientLoves= new int[clientsNum][];

				for (int k = 0; k < clientsNum; ++k)
				{
					string[] ss = f1.ReadLine ().Split (' ');
					int n = Int32.Parse (ss[0]);
					clientLoves[k]= new int[n*2];
					for (int j = 0; j < n * 2; j += 2)
					{
						clientLoves[k][j] = Int32.Parse (ss[j + 1]);
						clientLoves[k][j+1] = Int32.Parse (ss[j + 2]);
					}
				}


				int[] res = shaker.GetBest (flavoursNum, clientLoves);

				if (res == null)
					f2.WriteLine (String.Format ("Case #{0}: IMPOSSIBLE", i + 1));
				else
				{
					string s = "";
					for (int jj = 0; jj < res.Length; ++jj)
						s += res[jj] + " ";
					s = s.Trim ();
					f2.WriteLine (String.Format ("Case #{0}: {1}", i + 1, s));
				}


			}

			f1.Close ();
			f2.Close ();
		}
	}
}
