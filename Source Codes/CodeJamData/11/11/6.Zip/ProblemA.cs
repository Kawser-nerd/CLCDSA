﻿namespace CodeJam2011.Problems
{
    public class ProblemA : ProblemBase
    {
        private const string Possible = "Possible";
        private const string Broken = "Broken";

        protected override string SolveOneCase(InputHelper input)
        {
            long N = input.GetLong();
            int PD = input.GetInt();
            int PG = input.GetInt();

            if ((PG == 100 && PD != 100) || (PG == 0 && PD != 0))
                return Broken;

            int denom = Denom(PD);

            if (denom <= N)
                return Possible;

            return Broken;
        }

        private int Denom(int PD)
        {
            int denom = 100;

            for (int i = 0; i < 2; i++)
            if( PD % 2 == 0)
            {
                denom /= 2;
                PD /= 2;
            }

            for (int i = 0; i < 2; i++)
                if (PD % 5 == 0)
                {
                    denom /= 5;
                    PD /= 5;
                }

            return denom;
        }

    }
}