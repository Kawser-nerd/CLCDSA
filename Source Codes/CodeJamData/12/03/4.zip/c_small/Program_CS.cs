﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;

namespace km.gcj.qual
{
    class ProgramCS
    {

        static void Main(string[] args)
        {
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            Logic(args);

            sw.Stop();
            Console.WriteLine(sw.Elapsed);
            Console.ReadLine();
        }

        static void Logic(string[] args)
        {
            Problem p = Problem.createProblem(args);
            if (p == null || p.inputLinesCount == 0)
            {
                return;
            }

            long repeat = p.getNextLineAsInt64Array()[0];
            for (int i = 0; i < repeat; i++)
            {
                int answer = Counting(p.getNextLineAsStringArray());

                p.WriteAnswerFullLine(answer.ToString());
//                Console.WriteLine();
            }
        }

        static int Counting(string[] prmLine)
        {
            // （」・ω・）」桁数ー！
            int numDigits = prmLine[0].Length;
            int a = Int32.Parse(prmLine[0]);
            int b = Int32.Parse(prmLine[1]);
            int ret = 0;

            int start = 1;
            for (int i = 1; i < numDigits; i++)
            {
                start *= 10;
            }
            for (int num = start+1; num < b; num++)
            {
                ret += CountDetail(num, a, b, numDigits, start);
            }

            // （／・ω・）／答えを返すよ！
            return ret;
        }

        static int CountDetail(int num, int a, int b, int digit, int start)
        {
            int set = 0;
            int num_t = num;

            if (a <= num_t && num_t <= b)
            {
                set++;
            }
            for (int i = 1; i < digit; i++)
            {
                int f = num_t / start;
                num_t = (num_t % start) * 10 + (num_t / start);
                if (num_t < start)
                {
                    // (ﾟдﾟ )キニシナイ！
                    continue;
                }
                else if (num_t<num)
                {
                    // （´・ω・｀）もうカウントしてるよ…
                    return 0;
                }
                else if (num_t == num)
                {
                    // （繰り返す。この数字は何度でも繰り返す）
                    break;
                }
                else
                {
                    if (a <= num_t && num_t <= b)
                    {
                        set++;
                    }
                }
            }
//            if (set * (set - 1) / 2 > 0)
//            {
//                Console.WriteLine("{0}:{1}", num, set * (set - 1) / 2);
//            }
            // （／・ω・）／答えを返すよ！
            return set * (set - 1) / 2;
        }


    }
}
