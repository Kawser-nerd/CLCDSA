package lib;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

// TODO 미완.
public class PushRelabel {

    private static int[] height = new int[10000];
    private static int[] excess = new int[10000];
    private static int n;
    private static AdjacentListGetter adj;
    private static GetterOnEdge residualGetter;
    private static AdderOnEdge flowAdder;

    public static int fillAndGetAddition(int n, AdjacentListGetter adj, AdderOnEdge flowAdder, GetterOnEdge flow, GetterOnEdge capacity, int source, int sink) {
        PushRelabel.n = n;
        PushRelabel.adj = adj;
        PushRelabel.flowAdder = flowAdder;
        residualGetter = ResidualGetter.of(capacity, flow);
        Arrays.fill(height, 0, n, 0);
        Arrays.fill(excess, 0, n, 0);
        height[source] = n;
        adj.forEach(source, next -> {
            int c = capacity.get(source, next);
            FlowAdjuster.adjust(flowAdder, source, next, c);
            excess[next] += c;
            excess[source] -= c;
        });

        while (true) {
            int u = findOverflow(source, sink);
            if (u == -1)
                break;
//            System.out.println(Arrays.toString(Arrays.copyOf(height, n)));
//            System.out.println(Arrays.toString(Arrays.copyOf(excess, n)));
            boolean pushed = tryPush(u);
            if (!pushed)
                relabel(u);

//            if (u == 6) {
//
//                System.out.println("u pushed " + u + " " + pushed);
//                System.out.println(Arrays.toString(Arrays.copyOf(height, n)));
//                System.out.println(Arrays.toString(Arrays.copyOf(excess, n)));
//            }

//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
        }

        AtomicInteger total = new AtomicInteger(0);
        adj.forEach(source, v -> {
            total.addAndGet(flow.get(source, v));
        });
        return total.get();
    }

    private static int findOverflow(int start, int end) {
        for (int v = 0; v < n; v++)
            if (excess[v] > 0 && v != start && v != end)
                return v;
        return -1;
    }

    private static boolean tryPush(int u) {
        AtomicBoolean pushed = new AtomicBoolean(false);
        adj.forEach(u, v -> {
            if (!pushed.get()) {
                int residual = residualGetter.get(u, v);
                if (residual > 0 && height[u] == height[v] + 1) { // push할수 있으면 하는거야.
                    int d = Math.min(excess[u], residual);
                    FlowAdjuster.adjust(flowAdder, u, v, d);
                    excess[u] -= d;
                    excess[v] += d;
                    pushed.set(true);
                }
            }
        });
        return pushed.get();
    }

    private static void relabel(int u) {
        AtomicInteger minh = new AtomicInteger(Integer.MAX_VALUE);
        adj.forEach(u, v -> {
//            if (u == 6 && v == 1)
//                System.out.println("res " + u + " " + v + " " + residualGetter.get(u, v));
            if (residualGetter.get(u, v) > 0) {
//                if (u == 6)
//                    System.out.println("update " + v);
                minh.set(Math.min(minh.get(), height[v]));
            }
        });
//        System.out.println("minh " + minh);
        height[u] = minh.get() + 1;
    }
}
