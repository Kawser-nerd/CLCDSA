﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;





public class Program
{

    static void Main(string[] args)
    {
        using (StreamReader sr = new StreamReader(args[0]))
        {
            int tst = Int32.Parse(sr.ReadLine());
            for (int cas = 1; cas <= tst;cas++ )
            {
                int S = Int32.Parse(sr.ReadLine());
                string[] e = new string[S];
                for (int i = 0; i < S; ++i) e[i] = sr.ReadLine();
                int Q = Int32.Parse(sr.ReadLine());
                string[] q = new string[Q];
                for (int i = 0; i < Q; ++i) q[i] = sr.ReadLine();
                var dic = Enumerable.Range(0, S).ToDictionary(i => e[i], i => i);
                var a = q.Select(s => dic[s]).ToArray();
                int res = 0;
                int cur = -1;
                while (true)
                {
                    var nexts = Enumerable.Range(0, S).Where(i => i != cur);
                    if (nexts.Any(i => !a.Contains(i)))
                    {
                        break;
                    }
                    var firsts = nexts.Select(i => Enumerable.Range(0, a.Length).First(j => a[j] == i));
                    int index = firsts.Max();
                    cur = a[index];
                    ++res;
                    a = a.Skip(index + 1).ToArray();
                }
                Console.WriteLine("Case #"+cas+": "+res);

            }
            
        }
    }
}





