#ifndef	__GCJ__TASK_H__
#define	__GCJ__TASK_H__

#include <string>
#include <iostream>
#include <boost/thread/condition.hpp>

class Task
{
	public:
	Task(std::string &out, boost::condition &c, char &f) : result(out), finish(c), flag(f) {};
	Task(Task &n) : result(n.result), finish(n.finish), flag(n.flag) {};
	~Task() {};

	protected:
	std::string			&result;
	boost::condition	&finish;
	char				&flag;

};

#endif /*__GCJ__TASK_H__*/