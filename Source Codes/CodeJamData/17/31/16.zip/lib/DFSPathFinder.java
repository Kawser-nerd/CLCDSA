package lib;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class DFSPathFinder {

    public static PathFinder create(MapFactory<Integer> vertexKeyMapFactory) {
        return (adj, start, end) -> {
            Deque<Integer> history = new ArrayDeque<>();
            AtomicReference<List<Integer>> found = new AtomicReference<>();
            DFS.traverse(start, adj, v -> {
                history.add(v);
                if (v == end)
                    found.set(new ArrayList<>(history));
            }, history::removeLast, () -> found.get() != null, vertexKeyMapFactory);
            return found.get();
        };
    }

}
