﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Marius.CodeJam
{
    public class Rotate: IParalelSolver
    {
        private int _n, _k;
        private int[,] _board, _res;
        private string _answer;

        public void ReadInput()
        {
            var dim = Console.ReadLine().Split().Select(s => int.Parse(s)).ToArray();
            _n = dim[0];
            _k = dim[1];

            _board = new int[_n, _n];
            for (int i = 0; i < _n; i++)
            {
                var line = Console.ReadLine().Trim();
                for (int j = 0; j < line.Length; j++)
                {
                    _board[i, j] = C(line[j]);
                }
            }
        }

        private int C(char p)
        {
            if (p == '.')
                return 0;
            if (p == 'B')
                return 1;
            if (p == 'R')
                return 2;
            throw new ArgumentException();
        }

        public void WriteAnswer(int caseNumber)
        {
            Console.WriteLine("Case #{0}: {1}", caseNumber, _answer);
            /*
            for (int i = 0; i < _n; i++)
            {
                for (int j = 0; j < _n; j++)
                {
                    switch (_res[i, j])
                    {
                        case 0:
                            Console.Write('.');
                            break;
                        case 1:
                            Console.Write('B');
                            break;
                        case 2:
                            Console.Write('R');
                            break;
                        default:
                            break;
                    }
                }
                Console.WriteLine();
            }*/
        }

        public void SolveAsync()
        {
            int[,] res = new int[_n, _n];

            for (int i = 0; i < _n; i++)
            {
                int c = 0;
                for (int j = _n - 1; j >= 0; j--)
                {
                    if (_board[i, j] != 0)
                    {
                        res[i, c++] = _board[i, j];
                    }
                }
            }


            bool b = FindK(res, 1);
            bool r = FindK(res, 2);

            if (b && r)
                _answer = "Both";
            else if (b)
                _answer = "Blue";
            else if (r)
                _answer = "Red";
            else
                _answer = "Neither";

            _res = res;
        }

        private bool FindK(int[,] res, int p)
        {
            int ch = 0, cv = 0;
            for (int i = 0; i < _n; i++)
            {
                for (int j = 0; j < _n; j++)
                {
                    if (res[i, j] == p)
                        ch++;
                    else
                        ch = 0;

                    if (res[i, j] == p)
                    {
                        // \
                        int x = i, y = j, cd = 0;
                        while (true)
                        {
                            if (res[x, y] == p)
                                cd++;
                            else
                                break;

                            x++;
                            y++;

                            if (x >= _n || y >= _n || cd >= _k)
                                break;
                        }

                        if (cd >= _k)
                            return true;

                        x = i; y = j; cd = 0;
                        while (true)
                        {
                            if (res[x, y] == p)
                                cd++;
                            else
                                break;

                            x++;
                            y--;
                            
                            if (x >= _n || y < 0 || cd >= _k)
                                break;
                        }

                        if (cd >= _k)
                            return true;

                        // /
                    }

                    if (ch >= _k)
                        return true;
                }
                ch = 0;
            }

            for (int j = 0; j < _n; j++)
            {
                for (int i = 0; i < _n; i++)
                {
                    if (res[i, j] == p)
                        cv++;
                    else
                        cv = 0;

                    if (cv >= _k)
                        return true;
                }
                cv = 0;
            }

            return false;
        }
    }
}
