﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    public class ProcessorC
    {
        int cursor = 0;
        string[] stringData;

        private string getNextValue()
        {
            return stringData[cursor++];
        }

        private void appendString(StringBuilder output, string add) {
            if (output.Length > 0)
            {
                if (output[output.Length - 1] == add[0])
                {
                    output.Append(" ");
                }
            }
            output.Append(add);
        }

        public string Execute(string[] data)
        {
            stringData = data;
            StringBuilder output = new StringBuilder();

            // Read number of input
            int inputs = int.Parse(getNextValue());
            
            for (int i = 0; i < inputs; i++)
            {
                StringBuilder presses = new StringBuilder();
                getNextValue().ToList().ForEach(c =>
                {
                    switch (c)
                    {
                        case 'a':
                            appendString(presses, "2");
                            break;
                        case 'b':
                            appendString(presses, "22");
                            break;
                        case 'c':
                            appendString(presses, "222");
                            break;
                        case 'd':
                            appendString(presses, "3");
                            break;
                        case 'e':
                            appendString(presses, "33");
                            break;
                        case 'f':
                            appendString(presses, "333");
                            break;
                        case 'g':
                            appendString(presses, "4");
                            break;
                        case 'h':
                            appendString(presses, "44");
                            break;
                        case 'i':
                            appendString(presses, "444");
                            break;
                        case 'j':
                            appendString(presses, "5");
                            break;
                        case 'k':
                            appendString(presses, "55");
                            break;
                        case 'l':
                            appendString(presses, "555");
                            break;
                        case 'm':
                            appendString(presses, "6");
                            break;
                        case 'n':
                            appendString(presses, "66");
                            break;
                        case 'o':
                            appendString(presses, "666");
                            break;
                        case 'p':
                            appendString(presses, "7");
                            break;
                        case 'q':
                            appendString(presses, "77");
                            break;
                        case 'r':
                            appendString(presses, "777");
                            break;
                        case 's':
                            appendString(presses, "7777");
                            break;
                        case 't':
                            appendString(presses, "8");
                            break;
                        case 'u':
                            appendString(presses, "88");
                            break;
                        case 'v':
                            appendString(presses, "888");
                            break;
                        case 'w':
                            appendString(presses, "9");
                            break;
                        case 'x':
                            appendString(presses, "99");
                            break;
                        case 'y':
                            appendString(presses, "999");
                            break;
                        case 'z':
                            appendString(presses, "9999");
                            break;
                        case ' ':
                            appendString(presses, "0");
                            break;
                    }
                });
                output.AppendLine(string.Format("Case #{0}: {1}", i + 1, presses.ToString()));
            }

            return output.ToString();
        }
    }
}
