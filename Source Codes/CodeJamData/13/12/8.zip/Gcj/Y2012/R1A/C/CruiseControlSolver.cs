﻿using System;
using System.Globalization;
using System.Linq;
using System.Collections.Generic;
using Cmn.Util;
using Gcj.Util;

namespace Gcj.Y2012.R1A.C
{
    public class CruiseControlSolver : IConcurrentSolver
    {
      
        public int CCaseGet(Pparser pparser)
        {
            return pparser.Fetch<int>();
        }

        public ConcurrentGcjSolver.DgSolveCase DgSolveCase(Pparser pparser)
        {
            /* The first line of the input file gives the number of test cases, T. T test cases follow.
             * Each test case begins with the number N. N lines follow, each describing a single car. 
             * Each line contains a character Ci (denoting whether the car is initially in the left or the right lane), 
             * two integers describing the speed Si of the car (in meters per second), and the initial position Pi of the car
             * (in meters), denoting the distance between the rear end of the car and some fixed line across the road.
             * All the cars are moving away from this line, and no car is behind the line.*/
            var ccar = pparser.Fetch<int>();
            var rgcar = pparser.FetchN<Car>(ccar);
            for (int i = 0; i < rgcar.Count; i++)
                rgcar[i].id = i;

                return () => EnobjSolveCase(rgcar);
        }

        private IEnumerable<object> EnobjSolveCase(List<Car> rgcar)
        {
            var mprgovertakeBycar = new Dictionary<Car, List<Overtake>>();
            var mprgovertakeBycarOther = new Dictionary<Car, List<Overtake>>();

            foreach (var car in rgcar)
            {
                mprgovertakeBycar[car] = new List<Overtake>();
                mprgovertakeBycarOther[car] = new List<Overtake>();
            }
            
            foreach (var carA in rgcar)
            foreach (var carB in rgcar)
            {
                if(carA == carB)
                    continue;

                var overtake = carA.OvertakeGet(carB);
                if (overtake != null)
                {
                    mprgovertakeBycar[carA].Add(overtake);
                    mprgovertakeBycarOther[carB].Add(overtake);
                }
            }

            decimal tmin = decimal.MaxValue;
            foreach (var carA in rgcar)
            {
                foreach (var overtakeAB in mprgovertakeBycar[carA])
                {
                    var carB = overtakeAB.CarOther;

                    //meg tudja-e előzni B-t?
                    var tstartAB = overtakeAB.TStart;
                    
                    //egyszerre előznek valakit?
                    var hlmB = HlmcarOvertakenByCarAtT(mprgovertakeBycar, carB, tstartAB, overtakeBX => overtakeBX.CarOther);
                    var hlmA = HlmcarOvertakenByCarAtT(mprgovertakeBycar, carA, tstartAB, overtakeAX => overtakeAX.CarOther);
                    
                    hlmA.Intersect(hlmB);
                    if (hlmA.Count > 0)
                        tmin = Math.Min(tmin, tstartAB);

                    //egyszerre előzik őket?
                    hlmB = HlmcarOvertakenByCarAtT(mprgovertakeBycarOther, carB, tstartAB, overtakeXB => overtakeXB.Car);
                    hlmA = HlmcarOvertakenByCarAtT(mprgovertakeBycarOther, carA, tstartAB, overtakeXA => overtakeXA.Car);
                    hlmA.Intersect(hlmB);
                    if (hlmA.Count > 0)
                        tmin = Math.Min(tmin, tstartAB);

                }
            }
            if (tmin == decimal.MaxValue)
                yield return "Possible";
            else
                yield return tmin.ToString("0.######", CultureInfo.InvariantCulture);
        }

        Hlm<Car>  HlmcarOvertakenByCarAtT(Dictionary<Car, List<Overtake>> mpx, Car carA, decimal t, Func<Overtake,Car> dgCarFromOvertake)
        {
            var hlmCar = new Hlm<Car>();
            foreach (var overtake in mpx[carA])
            {
                if (overtake.TStart <= t && t < overtake.TEnd)
                    hlmCar.Add(dgCarFromOvertake(overtake));
            }
            return hlmCar;
        }
    

        Overtake OvertakeGet(Dictionary<Car, List<Overtake>> mpx, Car carA, Car carB)
        {
            return mpx[carA].FirstOrDefault(overtakeH => overtakeH.CarOther == carB) ??
                   mpx[carB].FirstOrDefault(overtakeH => overtakeH.CarOther == carA);
        }

        public enum Klane
        {
            L,R
        }

        public class Overtake
        {
            public readonly Car Car;
            public readonly Car CarOther;
            public readonly decimal TStart;
            public readonly decimal TEnd;

            public Overtake(Car car, Car carOther, decimal tStart, decimal tEnd)
            {
                Car = car;
                CarOther = carOther;
                TStart = tStart;
                TEnd = tEnd;
            }
        }

        /*space-time parallelogram*/
        public class Car
        {
            public readonly decimal S0;
            public readonly decimal V;
            public int id;

            public Car(Klane klane, decimal v, decimal s0)
            {
                
                V = v;
                S0 = s0;
            }
    
            public Overtake OvertakeGet(Car car)
            {
                if (car.V > V) //gyorsabb
                    return null;
                if (car.S0 + 5 <= S0) //már megelőztük
                    return null;
                if (car.V == V && car.S0 >= S0 + 5) //nem érjük utol
                    return null;

                if (car.V == V) //sose előzzük meg
                    return new Overtake(this, car, 0, decimal.MaxValue);

                var tStart = TutkGet(S0 + 5, V, car.S0, car.V); //elérjük a hátulját
                
                if (tStart < 0)  //már eleve előzzük
                    tStart = 0;
                
                var tEnd = TutkGet(S0, V, car.S0 + 5, car.V); //elhagyjuk az elejét
                return new Overtake(this, car, tStart, tEnd);

            }

            private static decimal TutkGet(decimal sA, decimal vA, decimal sB, decimal vB)
            {
                var epsilon = new decimal(0.0001);

                //if(epsilon >= Math.Abs(sA-sB))
                //    throw new Exception("nagyon közel vannak");

                if(1/epsilon < Math.Abs(vA-vB))
                    throw new Exception("túl nagy sebesség különbség");

                //vA*t+sA = vB*t+sB
                var t = (sA - sB)/(vB - vA);
                return t;
            }

            
        }
    }
}
