#!/usr/bin/env python
import sys
from mypy.codejam import *
#from decimal import *
from math import *

#pi = Decimal("3.141592653589793238462643383")

class FlyTestCase(TestCase):
    def parseTestCase(self, file):
        nums = map(float, file.readline().split())
        assert(len(nums) == 5)
        self.f = nums[0]
        self.R = nums[1]
        self.t = nums[2]
        self.r = nums[3]
        self.g = nums[4]

class point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def distanceTo(self, point):
        return hypot(self.x - point.x, self.y - point.y)

class square:
    def __init__(self, lowerLeftPoint, upperRightPoint):
        self.lowerLeft = lowerLeftPoint
        self.upperRight = upperRightPoint

def arcArea(radius, chordLength):
    theta = 2 * asin(chordLength/(2 * radius))
    area = radius **2 * (theta - sin(theta))/2
    return area

def squareOpenArea(x, y, innerRadius, stringRadius, betweenStrings, flyRadius):
    bottom = y * (betweenStrings + 2 * stringRadius) + stringRadius + flyRadius
    top = bottom + betweenStrings - 2 * flyRadius
    left = x * (betweenStrings + 2 * stringRadius) + stringRadius + flyRadius
    right = left + betweenStrings - 2 * flyRadius
    innerRadiusSq = innerRadius**2
    print "Square: %f,%f %f,%f  InnerRadius: %f (%f)" % (left, bottom, right, top, innerRadius, innerRadiusSq)
    if bottom **2 + left**2 > innerRadiusSq:
        print "No square in ring"
        return 0
    if top**2 + right**2 < innerRadiusSq:
        print "Full square in ring"
        return (top - bottom) * (right - left)
    if top**2 + left**2 > innerRadiusSq:
        # upper left corner is outside of circle
        leftHeight = sqrt(innerRadiusSq - left**2)
        if bottom**2 + right**2 > innerRadiusSq:
            # lower right corner is outside of circle
            print "UL and LR corners outside of ring"
            bottomRight = sqrt(innerRadiusSq - bottom**2)
            area = (bottomRight - left) * (leftHeight - bottom) /2
            chordLength = hypot(leftHeight - bottom,
                                bottomRight - left)
            area += arcArea(innerRadius, chordLength)
            return area
        else:
            # lower right corner is inside of cicle
            print "UL corner outside of ring"
            rightHeight = sqrt(innerRadiusSq - right**2)
            area = (rightHeight - bottom) * (right - left)
            area += (leftHeight - rightHeight) * (right - left) / 2
            chordLength = hypot(leftHeight - rightHeight, right - left)
            area += arcArea(innerRadius, chordLength)
            return area
    else:
        # upper left corner is inside of circle
        topRight = sqrt(innerRadiusSq - top**2)
        if bottom**2 + right**2 > innerRadiusSq:
            # lower right corner is outside of circle
            print "LR corner outside of circle"
            bottomRight = sqrt(innerRadiusSq - bottom **2)
            area = (topRight - left) * (top - bottom)
            area += (bottomRight - topRight) * (top - bottom) / 2
            chordLength = hypot(bottomRight - topRight, top - bottom)
            area += arcArea(innerRadius, chordLength)
            return area
        else:
            # lower right corner is inside of cicle
            print "UR corner outside of circle"
            rightHeight = sqrt(innerRadiusSq - right**2)
            area = (top - bottom) * (right - left)
            area -= (top - rightHeight) * (right - topRight) / 2
            chordLength = hypot(right - topRight, top - rightHeight)
            area += arcArea(innerRadius, chordLength)
            return area

def solver(testcase):
    assert(testcase is not None)
    outerRadius = testcase.R
    betweenStrings = testcase.g
    stringRadius = testcase.r
    ringThickness = testcase.t
    flyRadius = testcase.f
    print "outerRadius = %f betweenStrings = %f stringRadius = %f ringThickness = %f flyRadius = %f" % (outerRadius, betweenStrings, stringRadius, ringThickness, flyRadius)
    # Special cases
    if flyRadius * 2 >= betweenStrings:
        print "Fly bigger than hole"
        return "1.00000000"
    if flyRadius == 0:
        print "Fly zero size"
        return "0.00000000"
    racquetArea = outerRadius**2 * pi
    innerRadius = outerRadius - (ringThickness + flyRadius)
    innerArea = innerRadius**2 * pi
    numStrings = int(floor(innerRadius / (stringRadius * 2 + betweenStrings))) + 1
    print "numStrings: %d" % numStrings
    area = 0
    for x in xrange(numStrings):
        print "x = %d" % x
        for y in xrange(numStrings):
            print "y = %d" % y
            area += squareOpenArea(x,y, innerRadius, stringRadius, betweenStrings, flyRadius)
            print "Area: %f" % area
    area *= 4
    prob = 1 - (area / racquetArea)
    return "%f" % prob

def main():
    problem = GoogleProblem(testcaseClass=FlyTestCase)
    problem.solve(solver)

if __name__ == "__main__":
    sys.exit(main())
