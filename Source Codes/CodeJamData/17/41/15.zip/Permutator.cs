﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
	public interface IPermutatorArrayTrimmer<T>
	{
		bool TrimNeeded(T[] currentBoard, int lastAddedI, Dictionary<T, int> appearanceCounter);
	}

	public interface IPermutatorBoardTrimmer<T>
	{
		bool TrimNeeded(T[][] currentBoard, int lastAddedI, int lastAddedJ, Dictionary<T, int> appearanceCounter);
	}

	public class Permutator<T>
	{
		#region Fields

		private readonly Random _random = new Random();

		private readonly bool _randomizeOrder;
		private readonly bool _noRepetitions;
		private readonly bool _orderMakesNoDifference;

		private readonly T _wildCard;
		private readonly List<T> _values;

		#endregion

		#region C'tor

		public Permutator(IEnumerable<T> values, T wildCard = default(T), bool randomizeOrder = true, bool noRepetitions = false, bool orderMakesNoDifference = false)
		{
			this._wildCard = wildCard;
			_randomizeOrder = randomizeOrder;
			_noRepetitions = noRepetitions;
			_orderMakesNoDifference = orderMakesNoDifference;
			this._values = values.ToList();
		}

		#endregion

		#region Methods

		public IEnumerable<T[]> GetArrayPermutations(int n, IPermutatorArrayTrimmer<T> trimmer = null)
		{
			Func<T[], int, Dictionary<T, int>, bool> trimmerFunc;
			if (trimmer == null)
				trimmerFunc = ((x, y, z) => false);
			else
				trimmerFunc = trimmer.TrimNeeded;
			return GetArrayPermutations(n, trimmerFunc);
		}

		public IEnumerable<T[]> GetArrayPermutations(int n, Func<T[], int, Dictionary<T, int>, bool> trimNeeded)
		{
			T[] result = new T[n];
			if (!Equals(_wildCard, default(T)))
				for (int i = 0; i < n; i++)
					result[i] = _wildCard;

			Dictionary<T, int> appearanceCounter = _values.ToDictionary(value => value, value => 0);

			if (_wildCard != null)
				appearanceCounter.Add(_wildCard, n);

			return GetArrayPermutationsInternal(result, 0, appearanceCounter, trimNeeded);
		}

		public IEnumerable<T[][]> GetBoardPermutations(int n, int m, IPermutatorBoardTrimmer<T> trimmer = null)
		{
			Func<T[][], int, int, Dictionary<T, int>, bool> trimmerFunc;
			if (trimmer == null)
				trimmerFunc = ((x, y, z, w) => false);
			else
				trimmerFunc = trimmer.TrimNeeded;
			return GetBoardPermutations(n, m, trimmerFunc);
		}

		public IEnumerable<T[][]> GetBoardPermutations(int n, int m, Func<T[][], int, int, Dictionary<T, int>, bool> trimNeeded)
		{
			T[][] result = new T[n][];
			for (int i = 0; i < n; i++)
			{
				result[i] = new T[m];
				for (int j = 0; j < m; j++)
				{
					result[i][j] = _wildCard;
				}
			}

			Dictionary<T, int> appearanceCounter = _values.Where(value => value != null).ToDictionary(value => value, value => 0);

			if (_wildCard != null)
				appearanceCounter.Add(_wildCard, n * m);

			return GetBoardPermutationsInternal(result, 0, 0, appearanceCounter, trimNeeded);
		}

		private IEnumerable<T[]> GetArrayPermutationsInternal(T[] result, int i, Dictionary<T, int> appearanceCounter, Func<T[], int, Dictionary<T, int>, bool> trimmer)
		{
			if (i >= result.Length)
			{
				yield return DeepClone(result);
				yield break;
			}

			T previousValue = _wildCard;
			IEnumerable<T> usedValues = _values;
			if (_noRepetitions)
				usedValues = usedValues.Where(t => appearanceCounter[t] == 0);
			if (_orderMakesNoDifference)
			{
				var largestExisting = _values.Select((x, ind) => new Tuple<T, int>(x, ind)).Reverse().FirstOrDefault(t => appearanceCounter[t.Item1] > 0);
				if (largestExisting != null)
				{
					var maxIndex = largestExisting.Item2;
					usedValues = usedValues.Where(t => _values.IndexOf(t) >= maxIndex);
				}
			}
			if (_randomizeOrder)
				usedValues = usedValues.OrderBy(x => _random.Next());
			usedValues = usedValues.ToList();

			foreach (T value in usedValues)
			{
				result[i] = value;

				if (previousValue != null)
					appearanceCounter[previousValue]--;
				if (value != null)
					appearanceCounter[value]++;

				previousValue = value;
				if (trimmer(result, i, appearanceCounter))
					continue;
				foreach (var complete in GetArrayPermutationsInternal(result, i + 1, appearanceCounter, trimmer))
					yield return complete;
			}

			result[i] = _wildCard;

			if (previousValue != null)
				appearanceCounter[previousValue]--;
			if (_wildCard != null)
				appearanceCounter[_wildCard]++;
		}

		private IEnumerable<T[][]> GetBoardPermutationsInternal(T[][] result, int i, int j, Dictionary<T, int> appearanceCounter, Func<T[][], int, int, Dictionary<T, int>, bool> trimmer)
		{
			if (i >= result.Length)
			{
				yield return DeepClone(result);
				yield break;
			}

			T previousValue = _wildCard;

			IEnumerable<T> usedValues = _values;
			if (_noRepetitions)
				usedValues = usedValues.Where(t => appearanceCounter[t] == 0);
			if (_randomizeOrder)
				usedValues = usedValues.OrderBy(x => _random.Next());
			usedValues = usedValues.ToList();

			foreach (T value in usedValues)
			{
				result[i][j] = value;

				if (previousValue != null)
					appearanceCounter[previousValue]--;
				if (value != null)
					appearanceCounter[value]++;

				previousValue = value;
				if (trimmer(result, i, j, appearanceCounter))
					continue;
				int nextI = j == result[i].Length - 1 ? i + 1 : i;
				int nextJ = j == result[i].Length - 1 ? 0 : j + 1;
				foreach (var complete in GetBoardPermutationsInternal(result, nextI, nextJ, appearanceCounter, trimmer))
					yield return complete;
			}

			result[i][j] = _wildCard;
			if (previousValue != null)
				appearanceCounter[previousValue]--;
			if (_wildCard != null)
				appearanceCounter[_wildCard]++;
		}

		private T[][] DeepClone(T[][] source)
		{
			T[][] res = new T[source.Length][];
			for (int i = 0; i < source.Length; i++)
			{
				res[i] = new T[source[i].Length];
				for (int j = 0; j < source[i].Length; j++)
					res[i][j] = CloneIfPossible(source[i][j]);
			}
			return res;
		}

		private T[] DeepClone(T[] source)
		{
			T[] res = new T[source.Length];
			for (int i = 0; i < source.Length; i++)
				res[i] = CloneIfPossible(source[i]);

			return res;
		}

		private T CloneIfPossible(T t)
		{
			if (t is ICloneable)
				return (T)(t as ICloneable).Clone();

			return t;
		}

		#endregion
	}
}
