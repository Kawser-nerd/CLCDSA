﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Marius.CodeJam
{
    public class KingdomRush: IParalelSolver
    {
        private Tuple<int, int, int>[] _input;
        private int _answer;

        public void ReadInput()
        {
            var n = int.Parse(Console.ReadLine());
            _input = new Tuple<int, int, int>[n];
            for (int i = 0; i < _input.Length; i++)
            {
                var input = Console.ReadLine().Split().Select(s => int.Parse(s)).ToArray();
                _input[i] = Tuple.Create(input[0], input[1], i);
            }
        }

        public void WriteAnswer(int caseNumber)
        {
            Console.Write("Case #{0}: ", caseNumber);
            if (_answer < 0)
                Console.WriteLine("Too Bad");
            else
                Console.WriteLine(_answer);
        }

        public void SolveAsync()
        {
            var stars = 0;
            var list = new LinkedList<Tuple<int, int, int>>(_input.OrderByDescending(s => s.Item2).ThenBy(s => s.Item1));

            var games = 0;
            var can = true;
            var current = list.First;
            var set = new BitArray(list.Count);

            while (can)
            {
                can = false;
                var has = true;
                while (has)
                {
                    has = false;
                    current = list.First;
                    while (current != null)
                    {
                        var next = current.Next;
                        if (current.Value.Item2 <= stars)
                        {
                            has = true;
                            games++;
                            if (!set[current.Value.Item3])
                                stars += 2;
                            else
                                stars++;
                            list.Remove(current);
                        }
                        current = next;
                    }
                }

                current = list.First;
                while (current != null)
                {
                    var next = current.Next;
                    if (!set[current.Value.Item3] && current.Value.Item1 <= stars)
                    {
                        can = true;
                        games++;
                        stars++;
                        set[current.Value.Item3] = true;
                        break;
                    }
                    current = next;
                }
            }

            _answer = games;
            if (list.Count > 0)
                _answer = -1;
        }
    }
}
