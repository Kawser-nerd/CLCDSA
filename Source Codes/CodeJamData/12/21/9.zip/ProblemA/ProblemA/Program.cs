﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Utils.Infrastructure;

namespace ProblemA {
    class Program {
        static void Main(string[] args) {
            DefaultReader reader = new DefaultReader(args[0]);
            DefaultWriter writer = new DefaultWriter(args[0] + ".out");
            ProblemRunner runner = new ProblemRunner(new Problem(), reader, writer);
            runner.Run();
        }
    }
}
