﻿using System.Collections;
using System.Collections.Generic;
using CodeJamLibrary;
using CodeJamLibrary.Interfaces;

namespace Problems
{
  public class ProblemC : ProblemTemplate
  {
    protected override string Solve(IProblemInput problemInput)
    {
      return "";
    }
  }
}
