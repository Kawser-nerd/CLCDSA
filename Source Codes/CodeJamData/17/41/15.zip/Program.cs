﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Threading;

namespace Q1
{
	public class Program : IDisposable
	{
		#region Consts

		private const int FILE_HISTORY_SIZE = 5;

		#endregion

		#region Fields

		private StreamWriter m_OutputWriter;
		private static string InputFilePath
		{
			get
			{
				return string.Format(@"../../in/{0}.in", Solver.INPUT_NAME);
			}
		}

		private static string OutputFilePath
		{
			get
			{
				return string.Format(@"../../out/{0}.out", Solver.INPUT_NAME);
			}
		}

		#endregion

		#region Properties

		public LineEnumerator InputReader
		{
			get;
			private set;
		}

		#endregion

		#region C'tor

		static void Main(string[] args)
		{
			var stopwatch = new Stopwatch();
			stopwatch.Start();
			TestCaseInfo info;
			SolverBase solver;
			using (Program program = new Program())
			{
				solver = program.Run();
				info = program.InputReader.TestCaseInfo;
			}

			PrintOut("Solution complete in {0}ms!", stopwatch.ElapsedMilliseconds);
			string olderFilePath = GetPreviousFilePath(OutputFilePath);
			string correctFilePath = GetCorrectFilePath(OutputFilePath);

			if (File.Exists(correctFilePath))
			{
				PrintOut("Comparing with correct solution results...");
				using (FileComparer comparer = new FileComparer(OutputFilePath, correctFilePath, info, solver.ResultEqualityComparer))
					comparer.PrintComparisonResults();
			}
			else if (File.Exists(olderFilePath))
			{
				PrintOut("Comparing with previous solution results...");
				using (FileComparer comparer = new FileComparer(OutputFilePath, olderFilePath, info, solver.ResultEqualityComparer))
					comparer.PrintComparisonResults();
			}

			PrintOut("Saving code into zip...");
			CreateCodeZip();
			OpenExplorerInDirectory();

			stopwatch.Stop();

			PrintOut("All done! Took {0} seconds", stopwatch.Elapsed.TotalSeconds);
			Console.ReadKey();
		}

		private static void OpenExplorerInDirectory()
		{
			var sourceDir = Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)));
			var path = Path.Combine(sourceDir, "out");
			Process.Start(new ProcessStartInfo
			{
				FileName = path,
				UseShellExecute = true,
				Verb = "open"
			});
		}

		private static void CreateCodeZip()
		{
			var tmpDirectoryName = "tmp";

			var sourceDir = Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)));
			var tmpFolder = Path.Combine(sourceDir, tmpDirectoryName);
			if (Directory.Exists(tmpFolder))
				Directory.Delete(tmpFolder, true);
			Directory.CreateDirectory(tmpFolder);
			foreach (var codeFile in Directory.EnumerateFiles(sourceDir, "*.cs", SearchOption.AllDirectories))
			{
				var relative = codeFile.Substring(sourceDir.Length + 1);
				if (relative.StartsWith("obj") || relative.StartsWith(tmpDirectoryName))
					continue;
				var target = Path.Combine(tmpFolder, relative);
				var dir = Path.GetDirectoryName(target);
				if (!Directory.Exists(dir))
					Directory.CreateDirectory(dir);
				File.Copy(codeFile, target);
			}

			var targetZip = Path.Combine(sourceDir, "out", "Code.zip");

			if (File.Exists(targetZip))
				File.Delete(targetZip);
			ZipFile.CreateFromDirectory(tmpFolder, targetZip);

			Directory.Delete(tmpFolder, true);
		}

		public Program()
		{
			InputReader = new LineEnumerator(InputFilePath);

			PushBackOldOutputFilesIfNeeded(OutputFilePath);

			m_OutputWriter = new StreamWriter(OutputFilePath);
		}

		#endregion

		#region Methods

		private SolverBase Run()
		{
			int testCount;
			try
			{
				testCount = int.Parse(InputReader.Current);
			}
			catch (Exception ex)
			{
				throw new Exception(string.Format("File {0}.in is probably empty!", Solver.INPUT_NAME), ex);
			}

			InputReader.MoveNext();

			SolverBase solver = SolverBase.Create(InputReader);
			for (int t = 1; t <= testCount; t++)
			{
#pragma warning disable 0162
				PrintOutNoNl("Solving test case #{0}...", t);
				var watch = new Stopwatch();
				watch.Start();

				this.InputReader.UpdateTestCase(t);

				var resultObj = solver.SolveTestCase(t);
				if (resultObj == null)
					throw new ArgumentNullException(string.Format("Result to test case {0} was null!", t));

				var result = resultObj.ToString();

				OutputResult(t, result);
				watch.Stop();
				PrintOut(" Test case #{0} solved in {1}ms!" + (Solver.PRINT_EVERY_RESULT ? " Result:" : ""), t, watch.ElapsedMilliseconds);
				if (Solver.PRINT_EVERY_RESULT)
					PrintOut(result);
#pragma warning restore 0162
			}
			return solver;
		}

		private void OutputResult(int t, string result)
		{
			m_OutputWriter.Write("Case #{0}:", t);

#pragma warning disable 0162
			if (Solver.SKIP_LINE_AFTER_CASE_OUTPUT)
			{
				m_OutputWriter.WriteLine();
			}
#pragma warning restore 0162
			else
			{
				m_OutputWriter.Write(" ");
			}

			m_OutputWriter.WriteLine(result);
		}

		private void PushBackOldOutputFilesIfNeeded(string filePath, int depth = 1)
		{
			if (!File.Exists(filePath))
				return;

			if (depth >= FILE_HISTORY_SIZE)
			{
				File.Delete(filePath);
				return;
			}

			string newFilePath = GetPreviousFilePath(filePath);

			PushBackOldOutputFilesIfNeeded(newFilePath, depth + 1);
			File.Move(filePath, newFilePath);
		}

		private static string GetPreviousFilePath(string filePath)
		{
			string oldFileName = Path.GetFileName(filePath);
			string oldFileDir = Path.GetDirectoryName(filePath);

			string[] fileComponents = oldFileName.Split('.');
			string filePrefix = fileComponents[0];
			string fileExtension = fileComponents.Last();
			int fileCounter;
			if (fileComponents.Length == 2 || !int.TryParse(fileComponents[1], out fileCounter))
			{
				fileCounter = 1;
			}

			string newFileName = string.Format("{0}.{1}.{2}", filePrefix, fileCounter + 1, fileExtension);

			return Path.Combine(oldFileDir, newFileName);
		}

		private static string GetCorrectFilePath(string filePath)
		{
			string oldFileName = Path.GetFileName(filePath);
			string oldFileDir = Path.GetDirectoryName(filePath);

			string[] fileComponents = oldFileName.Split('.');

			string filePrefix = fileComponents[0];
			string fileExtension = fileComponents.Last();

			string newFileName = string.Format("{0}.correct.{1}", filePrefix, fileExtension);

			return Path.Combine(oldFileDir, newFileName);
		}

		public static void PrintOut(string str, params object[] param)
		{
			string formatted = string.Format(str, param);
			Console.WriteLine(formatted);
			Debug.WriteLine(formatted);
		}

		public static void PrintOutNoNl(string str, params object[] param)
		{
			string formatted = string.Format(str, param);
			Console.Write(formatted);
			Debug.Write(formatted);
		}

		public static void PrintOut(string str, ConsoleColor color, params object[] param)
		{
			var oldColor = Console.ForegroundColor;
			Console.ForegroundColor = color;
			PrintOut(str, param);
			Console.ForegroundColor = oldColor;
		}

		public static void PrintOutNoNl(string str, ConsoleColor color, params object[] param)
		{
			var oldColor = Console.ForegroundColor;
			Console.ForegroundColor = color;
			PrintOutNoNl(str, param);
			Console.ForegroundColor = oldColor;
		}

		public void Dispose()
		{
			InputReader.Dispose();
			m_OutputWriter.Dispose();
		}

		#endregion
	}
}
