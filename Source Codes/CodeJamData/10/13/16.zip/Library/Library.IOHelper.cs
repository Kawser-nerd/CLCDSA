﻿/*
 * This file  is made by Feng JIAO(Email: joephone1983@gmail.com) for solving Code Jam contest problems.
 * This file  is licensed under The GNU General Public License (GPLv3). For more information, google "GPLv3"
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Library
{

    public static class IOHelper
    {

        public static string InputFile()
        {
            switch (Config._FileSize)
            {
                case InputFileSize.LargeFile:
                    return @"..\..\..\large.in";
                case InputFileSize.SmallFile:
                    return @"..\..\..\small.in";
                case InputFileSize.TinyInput:
                    return @"..\..\..\tiny.in";
                case InputFileSize.NoInput:
                    throw new InvalidOperationException("No input file exists. You shouldn't call this method.");
                default:
                    throw new InvalidOperationException("Input file size is not supported!");
            }
        }

        public static string OutputFile()
        {
            switch (Config._FileSize)
            {
                case InputFileSize.LargeFile:
                    return @"..\..\..\large.out";
                case InputFileSize.SmallFile:
                    return @"..\..\..\small.out";
                case InputFileSize.TinyInput:
                    return @"..\..\..\tiny.out";
                case InputFileSize.NoInput:
                    throw new InvalidOperationException("No input file exists. You are not supposed to output a file.");
                default:
                    throw new InvalidOperationException("File size is not supported!");
            }
        }

        public static List<List<String>> ReadInputFile(out int CaseNo, params char[] seperator)
        {
            List<List<String>> caseListArray = new List<List<string>>(200);
            using (StreamReader streamReader = new StreamReader(InputFile()))
            {
                var inputLine = streamReader.ReadLine();
                CaseNo = Convert.ToInt32(inputLine.Split(seperator).ToList().Single());

                while (String.IsNullOrEmpty(inputLine = streamReader.ReadLine()) != true)
                {
                    caseListArray.Add(inputLine.Split(seperator).ToList());
                }
            }
            return caseListArray;
        }


        /// <summary>
        /// Write output
        /// </summary>
        /// <param name="outputList">A list of result(string) in order of case number</param>
        public static void WriteOutputFile(List<String> outputList)
        {
            int i = 0;
            using (StreamWriter sw = new StreamWriter(OutputFile()))
                foreach (var caseResult in outputList)
                {
                    i++;
                    sw.WriteLine("Case #{0}: {1}", i.ToString(), caseResult.ToString());
                }
        }

        /// <summary>
        /// Write result to console
        /// </summary>
        /// <param name="outputList">A list of result(string) in order of case number</param>
        public static void WriteOutputToConsole(List<List<string>> inputList, List<string> outputList)
        {
            int caseNo = outputList.Count();
            int inputLineNo = inputList.Count();
            int i = 0;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Program with {0} runs sucessfully.", Config._FileSize.ToString());
            if (Config._FileSize == InputFileSize.NoInput)
            {
                Console.ForegroundColor = ConsoleColor.White;
                return;
            }

            if (inputLineNo != caseNo)
            {
                Console.WriteLine("Here is only the output:");
                Console.ForegroundColor = ConsoleColor.White;
                foreach (var caseResult in outputList)
                {
                    i++;
                    Console.WriteLine("Case #{0}: {1}", i.ToString(), caseResult.ToString());
                }
            }
            else
            {
                Console.WriteLine("Here is input with output:");
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine("------------------------------------------------------------");
                foreach (var caseResult in outputList)
                {
                    i++;
                    Console.WriteLine("Case #{0}:", i.ToString());
                    Console.WriteLine("Input :  {0}", String.Join(" ", inputList[i - 1].ToArray()));
                    Console.WriteLine("output:  {0}", caseResult.ToString());
                    Console.WriteLine("------------------------------------------------------------");
                }
            }
        }
    }

}
