namespace CodeJam
{
  public interface ICodeJamMain
  {
    void Execute();
  }
}