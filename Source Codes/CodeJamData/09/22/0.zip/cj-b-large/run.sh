#!/bin/sh
CCAN_TARBALL=ccan-cj2009-20090902.tar.bz2
CCAN_DL="http://www.funsitelots.com/static/$CCAN_TARBALL"
if [ -e $CCAN_TARBALL ] ; then : ; else
	echo '*** Downloading ccan ***'
	if wget "$CCAN_DL" ; then : ; else
		echo "It appears wget is either not working or not installed."
		echo "Please download the following to this directory, then run this script again:"
		echo "$CCAN_DL"
		exit 1
	fi
fi
echo '*** Building code ***'
make clean
rm -rf ccan
tar -xjf $CCAN_TARBALL
make
echo '*** Generating outputs using inputs ***'
(
	cd in
	for i in * ; do
		#Ignore file extensions when deciding the program.
		#  This lets us have multiple inputs per file, like
		#  alien_numbers.large and alien_numbers.small .
		prog=$(echo "$i" | sed 's/\..*$//')
		
		echo "Generating out/$i.out from in/$i"
		cat "$i" | "../g/$prog" > "../out/$i.out"
	done
)
echo 'Done.'
