package lib;

import java.util.stream.LongStream;

public class LongArrayFromInput {
    public static long[] next(Input in, int length) {
        return LongStream.generate(in::nextLong).limit(length).toArray();
    }
}
