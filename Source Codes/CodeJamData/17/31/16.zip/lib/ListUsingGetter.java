package lib;

import java.util.AbstractList;
import java.util.List;
import java.util.function.IntFunction;

public class ListUsingGetter {

    public static <T> List<T> create(final int size, final IntFunction<T> getter) {
        return new AbstractList<T>() {
            @Override
            public T get(int index) {
                return getter.apply(index);
            }

            @Override
            public int size() {
                return size;
            }
        };
    }
}
