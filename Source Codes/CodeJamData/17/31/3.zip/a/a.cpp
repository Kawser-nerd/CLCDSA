#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <math.h>
#include <assert.h>
#include <stack>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <functional>
#include <vector>
#include <deque>
#include <utility>
#include <bitset>
#include <limits.h>
#include <time.h>
#include <functional>
#include <numeric>
#include <iostream>

using namespace std;
typedef long long ll;
typedef unsigned long long llu;
typedef double lf;
typedef unsigned int uint;
typedef long double llf;
typedef pair<int, int> pii;
typedef pair<ll, int> pli;
typedef pair<ll, ll> pll;

#define debug(format, ...) printf(format, __VA_ARGS__);

llf PI = acos(-1);
const int MOD = (int)1e9 + 7;

class modint {
  int v;
public:
  modint (): v(0) { }
  modint (ll v): v((v + MOD) % MOD) { }

  bool operator== (modint x) { return v == x.v; }
  bool operator!= (modint x) { return v != x.v; }

  modint operator+ (modint x) { return v + x.v; }
  modint operator- (modint x) { return v - x.v; }
  modint operator* (modint x) { return (ll)v * x.v; }

  modint& operator+= (const modint x) { return *this = (*this + x); }
  modint& operator-= (const modint x) { return *this = (*this - x); }
  modint& operator*= (const modint x) { return *this = (*this * x); }

  int operator* () { return v; }
};

int N, K;
pll D[1050];
ll S[1050];
long long ans;

int main() {
  cin >> N >> K;
  for(int i = 0; i < N; i++) {
    cin >> D[i].first >> D[i].second;
  }

  sort(D, D+N);
  for(int i = 0; i < N; i++) S[i] = 2 * D[i].first * D[i].second;
  for(int i = K-1; i < N; i++) {
    // i가 바닥에 있음
    long long cr = D[i].first * D[i].first + S[i];
    sort(S, S+i, greater<ll>());
    for(int j = 0; j < K-1; j++) cr += S[j];
    if(cr > ans) ans = cr;
  }

  printf("%.20Lf\n", ans * PI);
  return 0;
}
