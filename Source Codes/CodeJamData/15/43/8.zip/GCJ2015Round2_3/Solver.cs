﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;

namespace GCJ2015Round2_3
{
	enum Language
	{
		UNKNOWN, ENGLISH, FRENCH, BOTH
	}
	public class Solver : SolverBase
	{
		public const string INPUT_NAME = "small3";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = false;

		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		int N;
		Dictionary<string, Language> wordLanguage;
		List<string[]> sentences;
		public override string SolveTestCase(int testCase)
		{
			N = GetInt();
			wordLanguage = new Dictionary<string, Language>();
			sentences = new List<string[]>();

			var englishSentence = GetLine().Split(' ');
			var frenchSentence = GetLine().Split(' ');

			for (int i = 0; i < N - 2; i++)
			{
				sentences.Add(GetLine().Split(' '));
			}

			SetSentence(wordLanguage, englishSentence, Language.ENGLISH, int.MaxValue);
			SetSentence(wordLanguage, frenchSentence, Language.FRENCH, int.MaxValue);
			int bothLanguagesSure = wordLanguage.Count(kvp => kvp.Value == Language.BOTH);

			var perm = new Permutator<Language>(new[] { Language.ENGLISH, Language.FRENCH }, Language.UNKNOWN);
			var least = int.MaxValue;
			foreach (var languageAssign in perm.GetArrayPermutations(N - 2))
			{
				var cloneLang = new Dictionary<string, Language>(wordLanguage);
				int bothLanguages = FillViaAssign(languageAssign, cloneLang, least);
				if (bothLanguages < least)
					least = bothLanguages;
			}

			return (bothLanguagesSure + least).ToString();
		}

		private int FillViaAssign(Language[] languageAssign, Dictionary<string, Language> cloneLang, int least)
		{
			int added = 0;
			for (int i = 0; i < N - 2; i++)
			{
				added += SetSentence(cloneLang, sentences[i], languageAssign[i], least - added);
				if (added >= least)
					return least + 1;
			}

			return added;
		}

		private int SetSentence(Dictionary<string, Language> wordLang, string[] sentence, Language lang, int least)
		{
			int added = 0;
			foreach (var word in sentence)
			{
				if (SetLanguage(wordLang, word, lang))
				{
					added++;
					if (added == least)
						return least + 1;
				}
			}
			return added;
		}

		private bool SetLanguage(Dictionary<string, Language> wordLang, string word, Language language)
		{
			Language lang;
			if (wordLang.TryGetValue(word, out lang))
			{
				if (lang != language && lang != Language.BOTH)
				{
					wordLang[word] = Language.BOTH;
					return true;
				}
			}
			else
				wordLang[word] = language;

			return false;
		}
	}
}
