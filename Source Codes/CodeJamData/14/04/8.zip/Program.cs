﻿using GoogleCodeJam.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeceitfulWar
{
	class Program
	{
		static void Main(string[] args)
		{
			InputFile input = new InputFile("input.txt");
			OutputFile output = new OutputFile("output.txt");

			int[] values = input.ReadIntArray();
			int TEST_COUNT = values[0];

			for (int i = 0; i < TEST_COUNT; i++)
			{
				WarGame game = new WarGame(input);
				int cheatingScore = game.GetCheatingGameScore();
				int fairScore = game.GetFairGameScore();

				output.WriteCase(i + 1, String.Format("{0} {1}", cheatingScore, fairScore));
			}

			output.Close();
		}
	}
}
