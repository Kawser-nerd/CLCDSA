using System.IO;

namespace CodeJam2010FairWarning
{
    public class MultipleTextWriters
    {
        public MultipleTextWriters(params TextWriter[] writers)
        {
            _writers = writers;
        }

        public void Write(string value)
        {
            foreach (TextWriter writer in _writers)
                writer.Write(value);
        }

        private readonly TextWriter[] _writers;
    }
}