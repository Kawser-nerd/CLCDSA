import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;

public class Fly extends Template {

	private class LiveCell {
		double x;
		double y;
		double w;

		public LiveCell(int i, int j) {
			x = r + f + (i * step);
			y = r + f + (j * step);
			w = livespace;
		}

		public boolean isDamaged() {
			double rr = Math.hypot(x + w, y + w);
			if (rr > inr) {
				return true;
			} else {
				return false;
			}
		}

		public boolean isDead() {
			double rr = Math.hypot(x, y);
			if (rr > inr) {
				return true;
			} else {
				return false;
			}
		}

		public double getLive() {
			return getLive(x, y, w, 0);
		}

		private double getLive(double x, double y, double w, int lvl) {
			if (Math.hypot(x, y) >= inr) {
				return 0;
			}
			if (w<5e-6) {
				return w * w * 0.5;
				//return 0;
			}
			double w2 = w * 0.5;
			double s = w2 * w2;
			double ret = 0.0;
			int lvl1 = lvl + 1;
			double xw = x + w;
			double yw = y + w;
			double xw2 = x + w2;
			double yw2 = y + w2;

			if (Math.hypot(xw2, yw2) < inr) {
				ret = s + getLive(xw2, yw2, w2, lvl1);

				if (Math.hypot(xw, yw2) < inr) {
					ret = ret + s;
				} else {
					ret = ret + getLive(xw2, y, w2, lvl1);
				}

				if (Math.hypot(xw2, yw) < inr) {
					ret = ret + s;
				} else {
					ret = ret + getLive(x, yw2, w2, lvl1);
				}
			} else {
				return getLive(x, y, w2, lvl1) + getLive(xw2, y, w2, lvl1)
						+ getLive(x, yw2, w2, lvl1);
			}
			return ret;
		}
	}

	private double sq;
	private double f;
	private double R;
	private double t;
	private double r;
	private double inr;
	private double g;
	private double livespace;
	private double step;

	@Override
	public void runCase(BufferedReader in, BufferedWriter out)
			throws IOException {

		sq = 0.0;

		String fRtrg[] = in.readLine().split(" ");
		f = Double.parseDouble(fRtrg[0]);
		R = Double.parseDouble(fRtrg[1]);
		t = Double.parseDouble(fRtrg[2]);
		r = Double.parseDouble(fRtrg[3]);
		g = Double.parseDouble(fRtrg[4]);
		f = f / R;
		t = t / R;
		r = r / R;
		g = g / R;

		inr = 1 - t-f;

		step = 2 * r + g;

		out.append(' ');
		livespace = g - 2 * f;
		if (livespace < 1e-8) {
			out.append("1.00000000");
			out.newLine();
			return;
		}
		double s0 = livespace * livespace;
		int j = 0;
		while (true) {
			int i = 0;
			LiveCell liveCell = new LiveCell(i, j);
			if (liveCell.isDead()) {
				break;
			}
			while (true) {
				LiveCell cell = new LiveCell(i, j);
				if (cell.isDamaged()) {
					if (cell.isDead()) {
						break;
					}
					sq = sq + cell.getLive();
				} else {
					sq = sq + s0;
				}
				i++;
			}
			j++;
		}
		sq = sq / (0.25 * Math.PI);
		sq = 1.0 - sq;
		if (sq<0) {
			sq=0;
		}
		if (sq>1) {
			sq=1;
		}
		String outs = String.format("%.8f", sq);
		out.append(outs);
		out.newLine();
	}

	public static void main(String[] args) {
		new Fly().start();
	}
}