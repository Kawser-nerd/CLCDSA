﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    public abstract class Problem
    {
        public abstract object Solve();

        public FileWrapper FileWrapper { get; set; }

        public T In<T>()
        {
            return In<T>(new string[] { " " }, StringSplitOptions.None);
        }

        public T In<T>(string[] seperator, StringSplitOptions options)
        {
            var item = FileWrapper.ReadLine<T>(seperator, options);
            LastIn = item;
            return item;
        }

        public T[] In<T>(int numLines)
        {
            return In<T>(numLines, new string[] { " " }, StringSplitOptions.None);
        }

        public T[] In<T>(int numLines, string[] seperator, StringSplitOptions options)
        {
            T[] lines = new T[numLines];
            for (int i = 0; i < numLines; i++)
            {
                lines[i] = In<T>(seperator, options);
            }
            LastIn = lines;
            return lines;
        }

        public T Last<T>()
        {
            return (T)LastIn;
        }

        private object LastIn { get; set; }
    }

    public class FileWrapper : IDisposable
    {
        public static void Process<P>(string[] args) where P : Problem, new()
        {
            string infile = args[0];
            string outfile = (infile.EndsWith(".in", StringComparison.OrdinalIgnoreCase) ? infile.Substring(0, infile.Length - 3) : infile) + ".out";
            bool echo = infile.IndexOf("sample", StringComparison.OrdinalIgnoreCase) >= 0;
            using (var fw = new FileWrapper(infile, outfile, echo))
            {
                int T = fw.ReadLine<int>();
                for (int i = 0; i < T; i++)
                {
                    var problem = new P { FileWrapper = fw };
                    var val = problem.Solve();
                    fw.WriteLine("Case #{0}: {1}", i + 1, val);
                }
            }
        }

        public FileWrapper(string infile, string outfile, bool echo = false)
        {
            Reader = new StreamReader(File.OpenRead(infile));
            Writer = new StreamWriter(File.Open(outfile, FileMode.Create, FileAccess.Write));
            Echo = echo;
        }

        public T ReadLine<T>()
        {
            return ReadLine<T>(new string[] { " " }, StringSplitOptions.None);
        }

        public T ReadLine<T>(string[] seperator, StringSplitOptions options)
        {
            var line = Reader.ReadLine();
            if (typeof(T).IsArray)
            {
                var aT = typeof(T).GetElementType();
                var items = line.Split(seperator, options).Select(t => Convert.ChangeType(t, aT)).ToArray();
                var arr = Array.CreateInstance(aT, items.Length);
                Array.Copy(items, arr, items.Length);
                return (T)(object)arr;
            }
            else
            {
                return (T)Convert.ChangeType(line, typeof(T));
            }
        }

        public void WriteLine(string format, params object[] args)
        {
            Writer.WriteLine(format, args);
            if (Echo)
            {
                Console.WriteLine(format, args);
            }
        }

        private StreamReader Reader { get; set; }
        private StreamWriter Writer { get; set; }
        private bool Echo { get; set; }

        public void Dispose()
        {
            Reader.Dispose();
            Writer.Dispose();
        }
    }

    public static class Extensions
    {
        public static V Get<K, V>(this Dictionary<K, V> dict, K key)
        {
            return dict.ContainsKey(key) ? dict[key] : default(V);
        }

        public static bool Has<K, V>(this Dictionary<K, V> dict, K key)
        {
            return dict.ContainsKey(key);
        }
    }
}
