#! /usr/bin/env python
from __future__ import print_function, division
try:
    range = xrange
except NameError:
    pass

# import numpy as np

# import collections
# import functools
# import itertools as it
# import numpy as np # See http://www.numpy.org
# import sympy as sp # See http://sympy.org/en/index.html
# import gmpy2 # See https://code.google.com/p/gmpy/
# import networkx as nx # See http://networkx.github.io/

import os
import sys
# MY MODULES - available at https://github.com/lackofcheese/CodeJamLib/
sys.path.append(os.path.join(
    os.environ['GOOGLE_DRIVE'], 'Coding', 'GCJ', 'CodeJamLib'))
import codejam_io

def toks_line(f_in, fun=int):
    return [fun(k) for k in f_in.readline().split()]

def process_first(f_in):
    num_cases = int(f_in.readline())
    other_data = None
    return num_cases, other_data

def process_case(f_in, f_out, case_no, other_data=None):
    toks = f_in.readline().split()
    K = int(toks[1])
    cakes = [c == '+' for c in toks[0]]
    # cakes = [x == 1 for x in np.random.randint(2, size=1000)]
    ans = solve(cakes, K)
    if ans is None:
        ans = "IMPOSSIBLE"
    print("Case #{}: {}".format(case_no, ans), file=f_out)

def solve(cakes, K):
    num_flips = 0
    while True:
        try:
            ind = cakes.index(False)
        except ValueError:
            return num_flips
        if ind + K > len(cakes):
            return None
        for index in range(ind, ind+K):
            cakes[index] = not cakes[index]
        num_flips += 1

if __name__ == '__main__':
    codejam_io.process_input(process_case, process_first, __file__)
