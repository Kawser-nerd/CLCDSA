package jam;

import java.util.Scanner;

/**
 * @author Bergmann Gábor
 *
 */
public class B {
	
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in); 
		int cases = sc.nextInt();
	    for (int thisCase = 0; thisCase < cases; thisCase++ ) {
	    	int n = sc.nextInt();
	    	
	    	long sumX=0, sumY=0, sumZ=0, vX=0, vY=0, vZ=0;
	    	for (int i=0; i<n; i++) {
	    		sumX += sc.nextLong();
	    		sumY += sc.nextLong();
	    		sumZ += sc.nextLong();
	    		vX += sc.nextLong();
	    		vY += sc.nextLong();
	    		vZ += sc.nextLong();
	    	}
	    	
	    	long dotProduct = sumX*vX + sumY*vY + sumZ*vZ;
	    	if (dotProduct >= 0) {
	    		double dist = Math.sqrt(sumX*sumX + sumY*sumY + sumZ*sumZ)/n;
	    		System.out.println("Case #"+(thisCase+1)+": " + dist + " 0.0");
	    	} else {
	    		 double time = (-(double)dotProduct)/(vX*vX + vY*vY + vZ*vZ);
	    		 
	    		 double fX = sumX + time*vX;
	    		 double fY = sumY + time*vY;
	    		 double fZ = sumZ + time*vZ;
	    		 
	    		 double fDist = Math.sqrt(fX*fX + fY*fY + fZ*fZ)/n;
		    	System.out.println("Case #"+(thisCase+1)+": " + fDist + " " + time);
	    	}
	    	
	    	//System.out.println("Case #"+(thisCase+1)+": " + t + d);
		    		
	    }
	}

}
