﻿/* www.codertom.com  -  copyright Tom Harrison 2015 */
using System.Collections.Generic;
using System.IO;

namespace CoderTom.CodeJam
{
    public class FileParser
    {
        public ProblemFileInfo Parse(string filePath)
        {
            using (StreamReader stream = File.OpenText(filePath))
            {
                var testCaseCount = stream.ReadInt();
                var cases = new List<TestCase>();

                for (int testCaseIndex = 0; testCaseIndex < testCaseCount; testCaseIndex++)
                {
                    cases.Add(new TestCase(stream) {});
                }

                return new ProblemFileInfo()
                {
                    TestCaseCount = testCaseCount,
                    Cases = cases
                };
            }
        }
    }
}
