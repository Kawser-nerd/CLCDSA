namespace Q3
{
	public class Pair<T1, T2>
	{
		public T1 x;
		public T2 y;

		public Pair(T1 x, T2 y)
		{
			this.x = x;
			this.y = y;
		}

		public override bool Equals(object obj)
		{
			if (obj == null || GetType() != obj.GetType())
			{
				return false;
			}

			var other = obj as Pair<T1, T2>;
			return Equals(x, other.x) && Equals(y, other.y);

		}

		public override int GetHashCode()
		{
			var anon = new {x, y};
			return anon.GetHashCode();
		}
	}
}