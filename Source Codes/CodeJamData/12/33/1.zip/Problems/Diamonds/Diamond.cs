﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Google_Code_Jam.Problems.Diamonds
{
    class Diamond : Algorithm<Problem,bool>
    {
        public override Problem Parse(StreamReader reader)
        {
            var nodeCount = JamUtil.ReadInts(reader)[0];
            var nodes = Enumerable.Range(0, nodeCount).Select(index => new Node(new HashSet<Node>(), index)).ToList();
            for(var i=0;i<nodeCount;i++)
            {
                var parents = JamUtil.ReadInts(reader);
                var node = nodes[i];
                foreach (var parent in parents.Skip(1))
                    node.Parents.Add(nodes[parent-1]);
            }
            return new Problem(nodes);
        }
        
        public override bool Solve(Problem problem)
        {
            var ancestorDic = new Dictionary<Node, ISet<Node>>();
            foreach(var node in problem.Nodes)
            {
                if (HasDiamondInheritance(node, ancestorDic))
                    return true;
            }
            return false;
        }

        static bool HasDiamondInheritance(Node node, Dictionary<Node, ISet<Node>> ancestorDic)
        {
            if (ancestorDic.ContainsKey(node))
                return false;

            var ancestors = new HashSet<Node>();
            ancestors.Add(node);
            ancestorDic[node] = ancestors;
            foreach(var parent in node.Parents)
            {
                if (HasDiamondInheritance(parent, ancestorDic))
                    return true;

                foreach (var parentAncestor in ancestorDic[parent])
                {
                    if (!ancestors.Add(parentAncestor))
                        return true;
                }
            }
            return false;
        }

        public override string Print(bool solution)
        {
            return solution ? "Yes" : "No";
        }
    }
}
