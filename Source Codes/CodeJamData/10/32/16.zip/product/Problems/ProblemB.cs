﻿using System;
using Template;
using Template.Interfaces;

namespace Problems
{
  public class ProblemB : ProblemTemplate
  {
    public ProblemB(ICaseFormatter caseFormatter) : base(caseFormatter)
    {
    }

    protected override string SolveOneCase(IInput input)
    {
      var buff = input.ParseInt();
      int L = buff[0];
      int P = buff[1];
      int C = buff[2];

      double result = ((double) P)/((double) L);

      result = Math.Log(result)/Math.Log((double) C);
      result = Math.Log(result)/Math.Log(2);
      result = Math.Ceiling(result);

      int final = Convert.ToInt32(result);

      if (final < 0)
        final = 0;

      return final.ToString();
    }
  }
}