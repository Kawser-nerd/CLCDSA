﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using CodeJam.Round1C;

namespace CodeJam
{
    public class Engine
    {
        static readonly object _locker = new object();

        private string[] _results;
        private string[] _data;
        private Thread _thread1;
        private Thread _thread2;
        private Thread _thread3;
        private Thread _thread4;
        private int _pointer;
        private int _problemIndex;

        public event EventHandler ProcessingComplete;

        public string[] Results { get { return _results; } }

        protected virtual void OnProcessingComplete(EventArgs e)
        {
            EventHandler handler = ProcessingComplete;
            if (null != handler)
            {
                foreach (EventHandler singleCast in handler.GetInvocationList())
                {
                    var syncInvoke = singleCast.Target as ISynchronizeInvoke;
                    try
                    {
                        if ((null != syncInvoke) && (syncInvoke.InvokeRequired))
                            syncInvoke.Invoke(singleCast,
                                          new object[] { this, e });
                        else
                            singleCast(this, e);
                    }
                    catch
                    { }
                }
            }
        }

        public void Start(string[] data)
        {
            _data = data;
            int inputs = int.Parse(data[0]);
            
            _results = new string[inputs];
            _problemIndex = 0;
            _pointer = 1;

            _thread1 = new Thread(ExecuteSolution);
            _thread1.Start();

            _thread2 = new Thread(ExecuteSolution);
            //_thread2.Start();

            _thread3 = new Thread(ExecuteSolution);
            //_thread3.Start();

            _thread4 = new Thread(ExecuteSolution);
            //_thread4.Start();
        }

        public void ExecuteSolution()
        {
            while (_problemIndex < _results.Count())
            {
                ISolution solution = new SolutionB();
                lock (_locker)
                {
                    if (_problemIndex == _results.Count())
                        break;
                    _pointer = solution.GetProblem(_problemIndex++, _pointer, _data);
                }
                Result result = solution.ProcessProblem();
                _results[result.ProblemIndex] = result.Output;
            }

            if(AllSolutionsFound)
            {
                OnProcessingComplete(new EventArgs());
            }
        }

        public Boolean AllSolutionsFound
        {
            get { return !_results.Any(r => r == null); }
        }
    }
}
