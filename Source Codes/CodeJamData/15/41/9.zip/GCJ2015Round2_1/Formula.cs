﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace GCJ2015Round2_1
{
	public static class Formula
	{
		public static int SumOfSeries(int n)
		{
			return n * (n + 1) / 2;
		}

		public static int SumOfSeries(int first, int last, int members)
		{
			return (first + last) * members / 2;
		}

		public static BigInteger SumOfSeries(BigInteger n)
		{
			return n * (n + 1) / 2;
		}

		public static BigInteger SumOfSeries(BigInteger first, BigInteger last, BigInteger members)
		{
			return (first + last) * members / 2;
		}

		public static int SumOfSquares(int n)
		{
			return n * (n + 1) * (2 * n + 1) / 6;
		}

		public static BigInteger SumOfSquares(BigInteger n)
		{
			return n * (n + 1) * (2 * n + 1) / 6;
		}

		public static int SumOfCubes(int n)
		{
			int n1 = n + 1;
			return n * n * n1 * n1 / 4;
		}

		public static BigInteger SumOfCubes(BigInteger n)
		{
			BigInteger n1 = n + 1;
			return n * n * n1 * n1 / 4;
		}
	}
}
