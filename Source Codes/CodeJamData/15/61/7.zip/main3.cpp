#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cassert>
#include <algorithm>
#include <string>
#include <vector>
#include <deque>
#include <map>
#include <set>

using namespace std;

#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#define pb push_back
#define mp make_pair
#define sz(x) ((int)(x).size())
#define forn(i, n) for (int i = 0; i < (n); i++)

typedef long long ll;
typedef long double ld;
typedef vector<ll> vll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;
typedef pair<int, int> pii;

const int inf = int(1e9);
const int MAXN = int(1e6) + 10;
const int MAXANS = 185;

int n;
char s[MAXN];

int dyn[MAXN + 1][MAXANS + 1];

void solve() {
  scanf("%s", s);
  n = strlen(s);
  forn (i, n) s[i] -= '0';

  vvi las(n + 1, vi(10, -1));
  forn (i, n) {
    las[i][s[i]] = i;
    las[i + 1] = las[i];
  }

  for (int ans = 0; ans <= MAXANS; ans++)
    dyn[n][ans] = n - 1;

  for (int l = n - 1; l >= 0; l--) {
    for (int ans = 0; ans <= MAXANS; ans++) {
      dyn[l][ans] = l - 1;

      for (int v = 1; v <= 9 && v <= ans; v++) {
        int maxMid = dyn[l][ans - v] + 1;
        assert(l <= maxMid && maxMid <= n);
        int mid = las[maxMid][v];
        assert(mid < n);
        if (l <= mid) {
          dyn[l][ans] = max(dyn[l][ans], dyn[mid + 1][ans - v]);
        }
      }
    }
  }
  for (int a = 0; a <= MAXANS; a++)
    if (dyn[0][a] >= n - 1) {
      printf("%d\n", a);
      return;
    }
  assert(false);
}

bool endsWith(string a, string b) {
  return a.length() >= b.length() && string(a, a.length() - b.length()) == b;
}

int main(int argc, char *argv[]) {
  {
    string fn = "";
    if (argc >= 2) fn = argv[1];
    if (endsWith(fn, ".in")) fn = string(fn, 0, fn.length() - 3);
    assert(freopen((fn + ".in").c_str(), "r", stdin));
    freopen((fn + ".out").c_str(), "w", stdout);
  }

  int MARK;
  assert(scanf("%d", &MARK) >= 1);

  int START = 1, TC = MARK;
  if (MARK < 0) {
    START = TC = -MARK;
  }
  for (int TN = START; TN <= TC; TN++) {
    eprintf("Case #%d:\n", TN);
    printf("Case #%d: ", TN);
    try {
      solve();
    } catch (...) {
      eprintf("Caught exception at test case #%d\n", TN);
      return 1;
    }
    fflush(stdout);
    fflush(stderr);
  }
  eprintf("Time = %.3f\n", clock() * 1.0 / CLOCKS_PER_SEC);
  return 0;
}
