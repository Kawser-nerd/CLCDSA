﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Paraiba.IO;

namespace Round1A
{
	public class ProblemB
	{
		public static void Solve(TextReader input, TextWriter output) {
			var sc = new Scanner(input);
			var nTestCases = sc.NextInt32();
			for (int iTestCases = 0; iTestCases < nTestCases; iTestCases++) {
				var N = sc.NextInt32();
				var M = sc.NextInt32();
				var words = Enumerable.Range(0, N)
					.Select(i => sc.Next())
					.ToList();
				var ls = Enumerable.Range(0, M)
					.Select(i => sc.Next())
					.ToList();

				var result = "";
				var delimiter = "";

				foreach (var l in ls) {
					var max = -1;
					var maxWord = "";
					foreach (var word in words) {
						var p = GetLosePoint(word, words, l);
						if (max < p) {
							max = p;
							maxWord = word;
						}
					}
					result += delimiter + maxWord;
					delimiter = " ";
				}

				output.WriteLine("Case #" + (iTestCases + 1) + ": " + result);
			}
		}

		public static int GetLosePoint(string word, List<string> words, string chars) {
			words = words.Where(w => w.Length == word.Length).ToList();
			var count = 0;
			foreach (var c in chars) {
				if (words.Count <= 1) {
					if (words[0] != word)
						throw new Exception();
					break;
				}
				if (!words.Any(w => w.Contains(c)))
					continue;
				// fail
				if (!word.Contains(c)) {
					count++;
					words = words.Where(w => !w.Contains(c)).ToList();
					continue;
				}
				// success
				var indexes = IndexesOf(word, c).ToList();
				words = words.Where(w => indexes.SequenceEqual(IndexesOf(w, c))).ToList();
			}
			return count;
		}

		public static IEnumerable<int> IndexesOf(string word, char c) {
			var index = -1;
			while((index = word.IndexOf(c, index + 1)) >= 0) {
				yield return index;
			}
		} 
	}
}
