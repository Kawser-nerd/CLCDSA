package template;

import java.util.ArrayList;

public class TestCaseSolver implements Runnable {

    private ArrayList<TestCase> testCases;
    private int ref;

    public TestCaseSolver(ArrayList<TestCase> tcs, int ref) {
        testCases = tcs;
        this.ref = ref;
    }

    public TestCaseSolver(TestCase tc, int ref) {
        ArrayList<TestCase> tcs = new ArrayList<>();
        tcs.add(tc);
        testCases = tcs;
        this.ref = ref;
    }

    public int getRef() {
        return ref;
    }

    @Override
    public void run() {
        for (TestCase tc : testCases) {
            long startTime = System.nanoTime();
            solve(tc);
            long duration = System.nanoTime() - startTime;
            double secs = (double) duration / (1000000000d);
            tc.setTime(secs);
            System.out.println("Thread " + ref + " solved testcase " + tc.getRef() + " in " + String.format("%.2f", secs) + " secs.");
        }
    }

    private void solve(TestCase tc) {

        ArrayList<ArrayList<Integer>> m = tc.getIntegerMatrix("m");

        String res = "";

        for (ArrayList<Integer> prods : m) {
            res += System.lineSeparator();
            int high5 = 0;
            int high3 = 0;
            int high2 = 0;
            for (Integer prod : prods) {
                int this5 = 0;
                int p = prod;
                while (p % 5 == 0) {
                    p /= 5;
                    this5++;
                }
                if (this5 > high5) {
                    high5 = this5;
                }

                int this3 = 0;
                p = prod;
                while (p % 3 == 0) {
                    p /= 3;
                    this3++;
                }
                if (this3 > high3) {
                    high3 = this3;
                }

                int this2 = 0;
                p = prod;
                while (p % 2 == 0) {
                    p /= 2;
                    this2++;
                }
                if (this2 > high2) {
                    high2 = this2;
                }


            }
            System.out.println(high2 + " " + high3 + " " + high5);
            
            
            for (int i = 0; i < high5; i++) {
                res += "5";
            }
            for (int i = 0; i < high3; i++) {
                res += "3";
            }
            int remain = 3 - high5 - high3;
            int rem2 = remain;
            for (int i = high2; i > remain; i--) {
                res += "4";
                rem2--;
            }
            for (int i = 0; i < rem2; i++) {
                res += "2";
            }


        }

        System.out.println("res " + res);
        tc.setSolution(res);
    }
}
