package lib;

import java.util.function.Consumer;

public class FastLauncher {
    public static void run(Consumer<Input> solver) {
        Launcher.run(FastTokenizerFactory.INSTANCE, solver);
    }
}
