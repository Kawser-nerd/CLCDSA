namespace CodeJam
{
  public interface IProblemWrapper
  {
    void Setup();
    void Execute();
    void TearDown();
  }
}