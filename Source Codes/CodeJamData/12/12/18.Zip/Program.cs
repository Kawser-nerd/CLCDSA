using System;

namespace CodeJam2011
{
    using CodeJam.Problems;

    public class Program
    {
        static void Main(string[] args)
        {
            var problem = new ProblemB();

            problem.Solve(new InputHelper(Console.In), Console.Out);
        }
    }
}