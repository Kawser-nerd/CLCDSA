Compiled using C# 2.0
Operating System : Windows

To run the program, run the following command

Aliens.exe < inputFileName > outputFileName

Thanks