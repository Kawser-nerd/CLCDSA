package lib;

import java.util.Map;

public class MemoizationSolver {
    public static <T, S> Solver<T, S> of(MapFactory<T> mapFactory, final RecurrenceDefinition<T, S> def) {
        Map<T, S> map = mapFactory.create();
        return new Solver<T, S>() {
            @Override
            public S solve(T term) {
                S existOrNull = map.get(term);
                if (existOrNull == null) {
                    S solution = def.get(term, this);
                    map.put(term, solution);
                    return solution;
                } else {
                    return existOrNull;
                }
            }
        };
    }
}
