using System.IO;

namespace CodeJamLibrary.Interfaces
{
  public interface ITextReaderProvider
  {
    TextReader GetReader();

    void Open();
    void Close();
  }
}