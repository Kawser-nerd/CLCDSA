﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Numerics;
using Cmn.Util;
using Gcj.Util;
using System.Linq;

namespace Gcj.Y2013.R2.A
{
    internal class ASolver : GcjSolver
    {
        private const long mod = 1000002013;

        protected override IEnumerable<object> EnobjSolveCase()
        {
            long cStop;
            long cX;
            Fetch(out cStop, out cX);

            var prizeGet = new Func<BigInteger, BigInteger>(cTravel => cTravel * cStop - cTravel * (cTravel - 1) / 2);

            var rgcIn = new BigInteger[cStop];
            var rgcOut = new BigInteger[cStop];

            BigInteger sumAll=0;
            for(var i=0;i<cX;i++)
            {
                long iIn;
                long iOut;
                BigInteger c;
                Fetch(out iIn, out iOut, out c);
                iOut--;
                iIn--;
                rgcIn[iIn] += c;
                rgcOut[iOut] += c;
                sumAll += prizeGet(iOut - iIn) * c;
            }

            BigInteger sumCheat = 0;
            foreach(var vicOut in rgcOut.Select((v,i)=>new {v,i}))
            {
                var cOut = vicOut.v;
                var iOut = vicOut.i;

                //var c = U.Min(rgcIn[iOut], cOut);
                //if(c>0)
                //    sumCheat += prizeGet(iOut - iOut) * c;
                //cOut -= c;
                //rgcIn[iOut] -= c;
                //for(long iIn=0;iIn<iOut;iIn++)
                //{
                //    if(cOut==0)
                //        break;

                //    c = U.Min(rgcIn[iIn], cOut);
                //    if(c>0)
                //        sumCheat += prizeGet(iOut - iIn) * c;
                //    cOut -= c;
                //    rgcIn[iIn] -= c;
                //}

                for(var iIn=iOut;iIn>=0;iIn--)
                {
                    var c = U.Min(rgcIn[iIn], cOut);
                    if(c>0)
                        sumCheat += prizeGet(iOut - iIn) * c;
                    cOut -= c;
                    rgcIn[iIn] -= c;
                    if(cOut==0)
                        break;
                }
            }

            yield return BigInteger.Remainder((sumAll - sumCheat), mod);
        }
    }
}
