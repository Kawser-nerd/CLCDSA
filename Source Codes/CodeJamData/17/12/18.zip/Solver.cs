﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Runtime.ExceptionServices;
using System.Text;

namespace Q2
{
	public class Solver : SolverBase
	{
		public const string INPUT_NAME = "small1";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = false;
		public const bool PRINT_EVERY_RESULT = true;

		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		public override object SolveTestCase(int testCase)
		{
			var spl = GetIntList();
			var N = spl[0];
			var P = spl[1];
			var req = GetIntList();
			var ingPackages = new List<List<int>>(N);
			for (int i = 0; i < N; i++)
				ingPackages.Add(GetIntList());

			var ingPackagesMin = new int[N][];
			var ingPackagesMax = new int[N][];
			GetMinsAndMaxes(N, ingPackagesMin, P, ingPackagesMax, ingPackages, req);

			//Console.WriteLine();
			//Print(ingPackagesMin);
			//Console.WriteLine();
			//Print(ingPackagesMax);

			if (N > 2)
				return 0;

			if (N == 1)
			{
				var c = 0;
				for (int p = 0; p < P; p++)
				{
					var canMake = (ingPackages[0][p] / ((double)req[0]));
					var min = (int)Math.Ceiling(canMake / 1.1);
					var max = (int)Math.Floor(canMake / 0.9);
					if (max >= min)
						c++;
				}
				return c;
			}


			return GetBestForTwo(req, ingPackages, P);

			return 0;
		}

		private int GetBestForTwo(List<int> req, List<List<int>> ingPackages, int P, int startI = 0)
		{
			var bestSoFar = 0;
			for (var i = startI; i < P; i++)
			{
				for (var j = 0; j < P; j++)
				{
					if (!DoesMatch(req, ingPackages, i, j))
						continue;
					var got = 1 + GetBestForTwo(req, CopyWithout(ingPackages, i, j), P - 1, i);
					if (got > bestSoFar)
						bestSoFar = got;
				}
			}
			return bestSoFar;
		}

		private List<List<int>> CopyWithout(List<List<int>> ingPackages, int a, int b)
		{
			var res = new List<List<int>>(2);
			res.Add(new List<int>());
			res.Add(new List<int>());
			for (int i = 0; i < ingPackages[0].Count; i++)
			{
				if (i != a)
					res[0].Add(ingPackages[0][i]);
			}
			for (int j = 0; j < ingPackages[1].Count; j++)
			{
				if (j != b)
					res[1].Add(ingPackages[1][j]);
			}
			return res;
		}

		private bool DoesMatch(List<int> req, List<List<int>> ingPackages, int i, int j)
		{
			var canMake1 = (ingPackages[0][i] / ((double)req[0]));
			var canMake2 = (ingPackages[1][j] / ((double)req[1]));
			var min1 = (int)Math.Ceiling(canMake1 / 1.1);
			var min2 = (int)Math.Ceiling(canMake2 / 1.1);
			var max1 = (int)Math.Floor(canMake1 / 0.9);
			var max2 = (int)Math.Floor(canMake2 / 0.9);

			return max1 >= min2 && min1 <= max2;
		}

		private static void GetMinsAndMaxes(int N, int[][] ingPackagesMin, int P, int[][] ingPackagesMax, List<List<int>> ingPackages,
			List<int> req)
		{
			for (int i = 0; i < N; i++)
			{
				ingPackagesMin[i] = new int[P];
				ingPackagesMax[i] = new int[P];
				for (int p = 0; p < P; p++)
				{
					var canMake = (ingPackages[i][p] / ((double)req[i]));
					ingPackagesMin[i][p] = (int)Math.Ceiling(canMake / 1.1);
					ingPackagesMax[i][p] = (int)Math.Floor(canMake / 0.9);
				}
			}
		}
	}
}