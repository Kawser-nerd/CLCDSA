#include<iostream>
#include<cstring>
#include<algorithm>
#include<sstream>
#include<string>
#include<vector>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<cassert>
#include<numeric>
#include<set>
#include<map>
#include<queue>
#include<list>
#include<deque>
using namespace std;

#define FOR(i,a,b) for(int i = (a); i < (b); ++i)
#define REP(i,n) FOR(i,0,n)
#define FORE(it,x) for(typeof(x.begin()) it=x.begin();it!=x.end();++it)
#define pb push_back
#define all(x) (x).begin(),(x).end()
#define CLEAR(x,with) memset(x,with,sizeof(x))
#define sz size()
typedef vector<int> VI;
typedef vector<VI> VVI;
typedef long long ll;

const int M = 1000000007;
vector<ll> pal;
VI sol;

ll empty(ll slots)
{
    return (((slots+1)*(slots))/2) % M;
}

int main()
{
    FILE* fp = fopen("list.txt", "r");
    int n;
    fscanf(fp, "%d", &n);
    pal.resize(n+1);
    for(int i = 0; i < n; ++i)
        fscanf(fp, "%Ld", &pal[i]);
    pal.back() = 10000000000010LL;
    fprintf(stderr, "ready\n");
    int cases;
    cin >> cases;
    for(int cc = 0; cc < cases; ++cc)
    {
        ll L, R;
        cin >> L >> R;
        int A = lower_bound(all(pal), L) - pal.begin();
        int B = upper_bound(all(pal), R) - pal.begin();
        --B;
        fprintf(stderr, "L %Ld A %Ld B %Ld R %Ld\n", L, pal[A], pal[B], R);
        printf("Case #%d: ", cc+1);
        if(A > B)
        {
            printf("%Ld\n", empty(R-L+1));
            continue;
        }
        ll ret = 0;
        vector<ll> after[2];
        after[B%2].pb(R-pal[B]+1);
        for(int i = B-1; i >= A; --i)
        {
            after[i%2].pb(pal[i+1] - pal[i]);
        }

        (ret += empty(R-pal[B])) %= M;
        ll afterSum[2] = {0,0};
        REP(i,2) REP(j,after[i].sz) (afterSum[i] += after[i][j]) %= M;
        for(int i = A; i <= B; ++i)
        {
            afterSum[i%2] = (afterSum[i%2] + M - after[i%2].back()) % M;
            after[i%2].pop_back();
            ll before;
            if(i == A) 
                before = pal[i] - L + 1;
            else
                before = pal[i] - pal[i-1];
            (ret += empty(before-1)) %= M;
            (ret += (before * afterSum[(i+1)%2]) % M) %= M;
        }
        printf("%Ld\n", ret);
    }
}

