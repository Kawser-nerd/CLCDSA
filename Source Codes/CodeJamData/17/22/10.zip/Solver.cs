﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Runtime.ExceptionServices;
using System.Text;

namespace Q2
{
	public class Solver : SolverBase
	{
		public const string INPUT_NAME = "small1";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = false;
		public const bool PRINT_EVERY_RESULT = true;

		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		public override object SolveTestCase(int testCase)
		{
			var vals = GetIntList();
			var N = vals[0];
			var currCols = new Dictionary<Color, int>();
			currCols[Color.RED] = vals[1];
			currCols[Color.ORANGE] = vals[2];
			currCols[Color.YELLOW] = vals[3];
			currCols[Color.GREEN] = vals[4];
			currCols[Color.BLUE] = vals[5];
			currCols[Color.VIOLET] = vals[6];

			if (currCols[Color.ORANGE] > 0 || currCols[Color.GREEN] > 0 || currCols[Color.VIOLET] > 0)
				return "YBRGRB";
			if (currCols[Color.RED] > N / 2 || currCols[Color.YELLOW] > N / 2 || currCols[Color.BLUE] > N / 2)
				return IMPOSSIBLE;

			var cols = new List<Color>();
			var max = currCols.ArgMax(kvp => kvp.Value);
			cols.Add(max.Key);
			currCols[max.Key]--;
			while (cols.Count < N)
			{
				var prev = cols.Last();
				max = currCols.Where(kvp => !ShareColor(prev, kvp.Key)).ArgMax(kvp => kvp.Value + (kvp.Key == cols.First() ? 0.5 : 0));
				cols.Add(max.Key);
				currCols[max.Key]--;
			}
			return new string(cols.Select(ToChar).ToArray());
		}

		private bool ShareColor(Color c1, Color c2)
		{
			if (c1 == c2)
				return true;
			switch (c1)
			{
				case Color.RED:
					return c2 == Color.ORANGE || c2 == Color.VIOLET;
				case Color.BLUE:
					return c2 == Color.GREEN || c2 == Color.VIOLET;
				case Color.YELLOW:
					return c2 == Color.GREEN || c2 == Color.ORANGE;
				case Color.GREEN:
					return c2 == Color.BLUE || c2 == Color.YELLOW || c2 == Color.VIOLET || c2 == Color.ORANGE;
				case Color.ORANGE:
					return c2 == Color.RED || c2 == Color.YELLOW || c2 == Color.VIOLET || c2 == Color.GREEN;
				case Color.VIOLET:
					return c2 == Color.RED || c2 == Color.BLUE || c2 == Color.ORANGE || c2 == Color.GREEN;
			}
			throw new Exception();
		}

		private char ToChar(Color c)
		{
			switch (c)
			{
				case Color.RED:
					return 'R';
				case Color.BLUE:
					return 'B';
				case Color.YELLOW:
					return 'Y';
				case Color.GREEN:
					return 'G';
				case Color.ORANGE:
					return 'O';
				case Color.VIOLET:
					return 'V';
			}
			throw new Exception();
		}
	}

	internal enum Color
	{
		RED, ORANGE, YELLOW, GREEN, BLUE, VIOLET
	}
}
