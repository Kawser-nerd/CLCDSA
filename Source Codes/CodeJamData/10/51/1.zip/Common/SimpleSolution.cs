﻿/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CodeJam
{
    abstract class SimpleSolution : SolutionBase
    {
        public override void Solve()
        {
            int casesCount = Int32.Parse(Console.ReadLine());
            for (int cid = 0; cid < casesCount; cid++)
                Console.WriteLine("Case #{0}: {1}", cid + 1, SolveCase());
        }

        abstract public String SolveCase();
    }
}
