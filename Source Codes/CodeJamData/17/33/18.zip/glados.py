import jam
from operator import mul
from functools import reduce


def solve(K, units, cores):
    cores.sort()

    now = cores[0]
    caught = 1

    for core in cores[1:]:
        need = (core - now) * caught
        
        if units > need:
            units -= need
            now = core
            caught += 1

        else:
            break

    now += units / caught

    res = reduce(mul, [now]*caught + cores[caught:], 1)
    return res

def parse():
    N, K = jam.input_array_of(int)
    units = float(input().strip())
    cores = jam.input_array_of(float)

    return solve(K, units, cores)

# print(solve(2, 1.0, [0.5, 0.0]))
jam.run(parse)