﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Numerics;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading;

namespace Q3
{
	class Alignment
	{
		public char Shooter;
		public Tuple<int, int> ShooterLocation;
	}
	public class Solver : SolverBase
	{
		public const string INPUT_NAME = "small1-2";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = false;
		public const bool PRINT_EVERY_RESULT = true;

		private const string POSSIBLE = "POSSIBLE";

		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		public override bool ResultEqualityComparer(string result1, string result2)
		{
			var spl1 = result1.StartsWith(POSSIBLE) ? POSSIBLE : IMPOSSIBLE;
			var spl2 = result2.StartsWith(POSSIBLE) ? POSSIBLE : IMPOSSIBLE;
			return spl1 == spl2;
		}

		public override object SolveTestCase(int testCase)
		{
			var spl = GetIntList();
			var R = spl[0];
			var C = spl[1];
			var grid = new char[R, C];
			var shooterCoords = new List<Tuple<int, int>>();
			for (int r = 0; r < R; r++)
			{
				var rowData = GetLine();
				for (var c = 0; c < C; c++)
				{
					grid[r, c] = rowData[c];
					if (grid[r, c] == '-' || grid[r, c] == '|')
						shooterCoords.Add(new Tuple<int, int>(r, c));
				}
			}

			var multipossShooters = new List<Tuple<int, int>>();
			foreach (var shooter in shooterCoords)
			{
				var isHorizontalBad = false;
				var isVerticalBad = false;
				var isHorizontalUseful = false;
				var isVerticalUseful = false;
				grid[shooter.Item1, shooter.Item2] = '-';
				foreach (var target in GetTargets(grid, shooter))
				{
					if (IsShooter(grid, target))
					{
						isHorizontalBad = true;
						break;
					}
					if (grid[target.Item1, target.Item2] == '.')
						isHorizontalUseful = true;
				}
				grid[shooter.Item1, shooter.Item2] = '|';
				foreach (var target in GetTargets(grid, shooter))
				{
					if (IsShooter(grid, target))
					{
						isVerticalBad = true;
						break;
					}
					if (grid[target.Item1, target.Item2] == '.')
						isVerticalUseful = true;
				}

				if(isVerticalBad && isHorizontalBad)
					return IMPOSSIBLE;
				if (isVerticalBad)
					grid[shooter.Item1, shooter.Item2] = '-';
				else if (isHorizontalBad)
					grid[shooter.Item1, shooter.Item2] = '|';
				else
				{
					if (isHorizontalUseful && isVerticalUseful)
						multipossShooters.Add(shooter);
					else if (!isHorizontalUseful)
						grid[shooter.Item1, shooter.Item2] = '|';
					else if (!isVerticalUseful)
						grid[shooter.Item1, shooter.Item2] = '-';
				}
			}

			return BestPossibility(grid, shooterCoords, multipossShooters);
		}

		private string BestPossibility(char[,] grid, List<Tuple<int, int>> shooterCoords, List<Tuple<int, int>> multipossShooters)
		{
			if (!multipossShooters.Any())
			{
				return IsGood(grid, shooterCoords) ? Stringify(grid) : IMPOSSIBLE;
			}
				
			var R = grid.GetLength(0);
			var C = grid.GetLength(1);
			var staticShooters = shooterCoords.Where(s => !multipossShooters.Contains(s)).ToList();
			var isCovered = new bool[R, C];
			foreach (var shooter in staticShooters)
				foreach (var target in GetTargets(grid, shooter))
					isCovered[target.Item1, target.Item2] = true;

			var orphanDots = new List<Tuple<int, int>>();
			for (int r = 0; r < R; r++)
				for (int c = 0; c < C; c++)
					if(grid[r, c] == '.' && !isCovered[r, c])
						orphanDots.Add(new Tuple<int, int>(r, c));

			var dotsToShooters = DotsToShooters(grid, multipossShooters, orphanDots);

			if(dotsToShooters.Any(kvp => kvp.Value.Count == 0))
				return IMPOSSIBLE;

			var easyOrphans = dotsToShooters.Where(kvp => kvp.Value.Count == 1).ToList();
			foreach (var kvp in easyOrphans)
			{
				var alignment = kvp.Value.Single();
				grid[alignment.ShooterLocation.Item1, alignment.ShooterLocation.Item2] = alignment.Shooter;
				multipossShooters.Remove(alignment.ShooterLocation);
				staticShooters.Add(alignment.ShooterLocation);
				dotsToShooters.Remove(kvp.Key);
			}

			var irrelevantShooters = new List<Tuple<int, int>>();
			var alignments = dotsToShooters.SelectMany(kvp => kvp.Value);
			foreach (var shooter in multipossShooters)
			{
				var found = false;
				var neededAligns = alignments.Where(a => a.ShooterLocation == shooter).Select(a => a.Shooter).Distinct().ToList();
				if(!neededAligns.Any())
					irrelevantShooters.Add(shooter);
				else if (neededAligns.Count == 1)
				{
					var val = neededAligns.Single();
					irrelevantShooters.Add(shooter);
					grid[shooter.Item1, shooter.Item2] = val;
				}
			}

			foreach (var shooter in irrelevantShooters)
			{
				multipossShooters.Remove(shooter);
				staticShooters.Add(shooter);
			}

			return ActuallyTryOptions(grid, shooterCoords, multipossShooters, dotsToShooters);
		}

		private Dictionary<Tuple<int, int>, List<Alignment>> DotsToShooters(char[,] grid, List<Tuple<int, int>> multipossShooters, List<Tuple<int, int>> orphanDots)
		{
			var dotsToShooters = orphanDots.ToDictionary(d => d, d => new List<Alignment>());
			foreach (var shooter in multipossShooters)
			{
				var alignment = new Alignment {Shooter = '-', ShooterLocation = shooter};
				grid[shooter.Item1, shooter.Item2] = alignment.Shooter;
				foreach (var target in GetTargets(grid, shooter))
				{
					if (orphanDots.Contains(target))
						dotsToShooters[target].Add(alignment);
				}
				alignment = new Alignment {Shooter = '|', ShooterLocation = shooter};
				grid[shooter.Item1, shooter.Item2] = alignment.Shooter;
				foreach (var target in GetTargets(grid, shooter))
				{
					if (orphanDots.Contains(target))
						dotsToShooters[target].Add(alignment);
				}
			}
			return dotsToShooters;
		}

		private string ActuallyTryOptions(char[,] grid, List<Tuple<int, int>> shooterCoords, List<Tuple<int, int>> multipossShooters, Dictionary<Tuple<int, int>, List<Alignment>> dotsToShooters)
		{
			if (!multipossShooters.Any())
				return IsGood(grid, shooterCoords) ? Stringify(grid) : IMPOSSIBLE;

			var leastOptions = dotsToShooters.ArgMin(kvp => kvp.Value.Count);

			foreach (var alignment in leastOptions.Value)
			{
				multipossShooters.Remove(alignment.ShooterLocation);
				grid[alignment.ShooterLocation.Item1, alignment.ShooterLocation.Item2] = alignment.Shooter;
				var res = BestPossibility(grid, shooterCoords, multipossShooters);
				if (res != IMPOSSIBLE)
					return res;

				multipossShooters.Add(alignment.ShooterLocation);
			}

			return IMPOSSIBLE;
		}

		private bool IsShooter(char[,] grid, Tuple<int, int> target)
		{
			var c = grid[target.Item1, target.Item2];
			return c == '-' || c == '|';
		}

		private bool IsGood(char[,] grid, List<Tuple<int, int>> shooterCoords)
		{
			var R = grid.GetLength(0);
			var C = grid.GetLength(1);
			var isCovered = new bool[R, C];
			foreach (var shooter in shooterCoords)
				foreach (var target in GetTargets(grid, shooter))
					isCovered[target.Item1, target.Item2] = true;

			for (int r = 0; r < R; r++)
			{
				for (int c = 0; c < C; c++)
				{
					if (grid[r, c] == '.' && !isCovered[r, c])
						return false;
					if (grid[r, c] == '|' && isCovered[r, c])
						return false;
					if (grid[r, c] == '-' && isCovered[r, c])
						return false;
				}
			}

			return true;
		}

		private IEnumerable<Tuple<int, int>> GetTargets(char[,] grid, Tuple<int, int> shooter)
		{
			var R = grid.GetLength(0);
			var C = grid.GetLength(1);
			var r = shooter.Item1;
			var c = shooter.Item2;

			if (grid[r, c] == '-')
			{
				for (int c2 = c + 1; c2 < C; c2++)
				{
					if (grid[r, c2] == '#')
						break;
					yield return new Tuple<int, int>(r, c2);
				}
				for (int c2 = c - 1; c2 >= 0; c2--)
				{
					if (grid[r, c2] == '#')
						break;
					yield return new Tuple<int, int>(r, c2);
				}
				yield break;
			}

			if (grid[r, c] == '|')
			{
				for (int r2 = r + 1; r2 < R; r2++)
				{
					if (grid[r2, c] == '#')
						break;
					yield return new Tuple<int, int>(r2, c);
				}
				for (int r2 = r - 1; r2 >= 0; r2--)
				{
					if (grid[r2, c] == '#')
						break;
					yield return new Tuple<int, int>(r2, c);
				}
				yield break;
			}
		}

		private string Stringify(char[,] grid)
		{
			var res = new StringBuilder((grid.GetLength(0) + Environment.NewLine.Length) * grid.GetLength(1));
			for (int r = 0; r < grid.GetLength(0); r++)
			{
				for (int c = 0; c < grid.GetLength(1); c++)
					res.Append(grid[r, c]);
				if (r != grid.GetLength(0))
					res.Append(Environment.NewLine);
			}
			return POSSIBLE + Environment.NewLine + res.ToString();
		}
	}
}
