﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    public class QualifierB
    {
        int _cursor = 0;
        string[] _stringData;

        private string GetNextValue()
        {
            return _stringData[_cursor++];
        }

        public string Execute(string[] data)
        {
            _stringData = data;
            var output = new StringBuilder();

            // Read number of input
            int inputs = int.Parse(GetNextValue());

            for (int i = 0; i < inputs; i++)
            {
                List<int> values = GetNextValue().Split(' ').Select(int.Parse).ToList();
                int googlers = values[0];
                int surprisingScores = values[1];
                int score = values[2];
                int surprisesFound = 0;
                int result = 0;

                for (int j = 3; j < values.Count; j++)
                {
                    int average = (int)Math.Round(((double)values[j]) / 3);

                    int remainder = values[j] - (average*2);
                    if(average - remainder == 2 || remainder - average == 2)
                    {
                        surprisesFound++;
                    }
                    if (average >= score || remainder >= score)
                    {
                        result++;
                    }
                    else if(surprisesFound < surprisingScores)
                    {
                        if(average >= remainder && average + 1 >= score && average > 0)
                        {
                            result++;
                            surprisesFound++;
                        }
                    }
                }

                output.AppendLine(string.Format("Case #{0}: {1}", i + 1, result));
            }

            return output.ToString();
        }
    }
}
