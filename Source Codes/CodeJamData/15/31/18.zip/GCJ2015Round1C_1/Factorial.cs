﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCJ2015Round1C_1
{
	public class Factorial
	{
		#region Static

		private static int m_CacheWidth = 0;
		private static int m_CacheHeight = 0;
		private static int[][] m_Cache;

		public static void SetupCache(int width, int height)
		{
			m_CacheWidth = width;
			m_CacheHeight = height;
			m_Cache = new int[m_CacheWidth][];
			for (int i = 0; i < m_CacheWidth; i++)
			{
				int currSize = Math.Min(i + 1, m_CacheHeight);
				m_Cache[i] = new int[currSize];
				for (int j = 0; j < currSize; j++)
				{
					m_Cache[i][j] = -1;
				}
			}
		}

		public static int GetOptions(int x, int y)
		{
			if (x < y)
				throw new InvalidOperationException(string.Format("x cannot be smaller than y ({0}, {1})", x, y));

			if (x < m_CacheWidth && y < m_CacheHeight && m_Cache[x][y] != -1)
				return m_Cache[x][y];
			int result = 1;
			int workX = x;
			while (workX > y)
			{
				if (workX < m_CacheWidth &&
					y < m_CacheHeight)
				{
					if (m_Cache[workX][y] != -1)
					{
						result *= m_Cache[workX][y];
						break;
					}
				}

				result *= workX;
				workX--;
				if (x < m_CacheWidth && workX < m_CacheHeight)
					m_Cache[x][workX] = result;
			}

			if (x < m_CacheWidth && y < m_CacheHeight)
				m_Cache[x][y] = result;

			return result;
		}

		public static int Fact(int x)
		{
			int result = 1;
			for (; x > 1; x--)
			{
				result *= x;
			}
			return result;
		}

		#endregion
	}
}
