/*
        Copyright (c) 2009  Joseph A. Adams
        All rights reserved.
        
        Redistribution and use in source and binary forms, with or without
        modification, are permitted provided that the following conditions
        are met:
        1. Redistributions of source code must retain the above copyright
           notice, this list of conditions and the following disclaimer.
        2. Redistributions in binary form must reproduce the above copyright
           notice, this list of conditions and the following disclaimer in the
           documentation and/or other materials provided with the distribution.
        3. The name of the author may not be used to endorse or promote products
           derived from this software without specific prior written permission.
        
        THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
        IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
        OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
        IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
        INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
        NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
        DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
        THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
        (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
        THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "cjlib.h"
#include <ccan/block_pool/block_pool.h>
#include <ctype.h>

char *line, *word_scan;
size_t line_len;
size_t lines_read = 0;

array_char buf = {0,0,0};
FILE *stream = NULL;

char *read_line(void) {
	int c;
	
	if (!buf.item)
		array_init(buf, NULL);
	if (!stream)
		stream = stdin;
	buf.size = 0;
	
	c = getc(stream);
	if (c == EOF)
		return NULL;
	
	do {
		array_append(buf, c);
		if (c == '\n') {
			buf.size--;
			break;
		}
	} while ((c=getc(stream)) != EOF);
	
	array_append(buf, 0);
	
	line = buf.item;
	line_len = buf.size - 1;
	word_scan = line;
	lines_read++;
	
	return buf.item;
}

char *read_word(void) {
	char *ret = word_scan;
	while (*word_scan && *word_scan != ' ') word_scan++;
	if (*word_scan)
		*word_scan++ = 0;
	return *ret ? ret : NULL;
}

void cjlib_open(const char *filename) {
	if (stream && stream!=stdin)
		fclose(stream);
	
	if (!filename) {
		stream = stdin;
		return;
	} else {
		FILE *f = fopen(filename, "r");
		if (!f) {
			fprintf(stderr, "Couldn't open '%s': %s\n", filename, strerror(errno));
			exit(EXIT_FAILURE);
		}
		stream = f;
	}
}

static struct block_pool *block_pool = NULL;

static void free_block_pool(void) {
	block_pool_free(block_pool);
}

static void init_block_pool(void) {
	if (!block_pool) {
		block_pool = block_pool_new(NULL);
		atexit(free_block_pool);
	}
}

void *alloc(size_t size) {
	init_block_pool();
	return block_pool_alloc(block_pool, size);
}

char *fgulp(array_char *out, const char *filename) {
	FILE *f = fopen(filename, "r");
	size_t orig_size = out->size;
	
	if (!f)
		return NULL;
	
	for (;;) {
		size_t readlen;
		
		array_realloc(*out, out->size+4096);
		out->size += readlen = fread(out->item + out->size, 1, 4096, f);
		
		if (!readlen)
			break;
	}
	
	if (ferror(f)) {
		out->size = orig_size;
		return NULL;
	}
	
	array_append(*out, 0);
	out->size--;
	
	return out->item + orig_size;
}

char *strip_whitespace(const char *str) {
	size_t count = 0;
	const char *i;
	char *ret, *o;
	
	for (i=str; *i; i++) {
		if (!isspace(*i))
			count++;
	}
	
	ret = alloc(count+1);
	
	for (i=str, o=ret; *i; i++) {
		if (!isspace(*i))
			*o++ = *i;
	}
	*o = 0;
	
	assert(o-ret == count);
	return ret;
}

void status_print(uint64_t current, uint64_t max) {
	static int spin_cycle = 0;
	static const char spin_characters[4] = {'|','/','-','\\'};
	double progress = (double)current/(double)max;
	unsigned int width = 64, i;
	unsigned int cur = (unsigned int)(progress * (double)width);
	
	printf("\r|");
	for (i=0; i<width; i++) {
		if (i<cur)
			putchar('-');
		else if (i==cur) {
			putchar(spin_characters[spin_cycle]);
			spin_cycle++;
			spin_cycle &= 3;
		} else
			putchar(' ');
	}
	printf("| %.2f%%     ", progress*100.0);
	fflush(stdout);
}

void status_finished(void) {
	unsigned int width = 64, i;
	printf("\r|");
	for (i=0; i<width; i++)
		putchar('-');
	printf("| Finished\n");
	fflush(stdout);
}

void scramble(void *base, size_t nmemb, size_t size) {
   char *i = base;
   char *o;
   size_t sd;
   for (;nmemb>1;nmemb--) {
      o = i + size*(random()%nmemb);
      for (sd=size;sd--;) {
         char tmp = *o;
         *o++ = *i;
         *i++ = tmp;
      }
   }
}

void print_uints(unsigned int n[], size_t count) {
	unsigned int i;
	for (i=0; i<count-1; i++)
		printf("%u ", n[i]);
	if (count)
		printf("%u", n[count-1]);
	puts("");
}

void perm_start(unsigned int n[], unsigned int count) {
	unsigned int i;
	for (i=0; i<count; i++)
		n[i] = i;
}

//Returns 0 on wraparound
int perm_next(unsigned int n[], unsigned int count) {
	unsigned int tail, i, j;
	
	if (count <= 1)
		return 0;
	
	/* Find all terms at the end that are in reverse order.
	   Example: 0 3 (5 4 2 1) (i becomes 2) */
	for (i=count-1; i>0 && n[i-1] > n[i]; i--);
	tail = i;
	
	if (tail > 0) {
		/* Find the last item from the tail set greater than
			the last item from the head set, and swap them.
			Example: 0 3* (5 4* 2 1)
			Becomes: 0 4* (5 3* 2 1) */
		for (j=count-1; j>tail && n[j] <= n[tail-1]; j--);
		
		if (n[j] <= n[tail-1]) {
			fprintf(stderr,
				"BUG: perm_next: Permutation array was uninitialized/trashed.\n"
			);
			return 0;
		}
		
		swap(n[tail-1], n[j]);
	}
	
	/* Reverse the tail set's order */
	for (i=tail, j=count-1; i<j; i++, j--)
		swap(n[i], n[j]);
	
	/* If the entire list was in reverse order, tail will be zero. */
	return (tail != 0);
}

unsigned long size_primes(unsigned long pc) {
	unsigned long c = pc;
	unsigned int l = 0;
	unsigned long ret;
	if (pc<=2)
		return 4;
	while (c) {
		c >>= 1;
		l++;
	}
	ret = pc * (l+1) * 3/4;
	return ret;
}

unsigned long size_primes_upto(unsigned long upto) {
	unsigned long c = upto;
	unsigned int l = 0;
	unsigned long ret;
	if (upto <= 3)
		return 2;
	while (c) {
		c >>= 1;
		l++;
		if (c == 1)
			l--;
	}
	ret = upto * 5 / (3 * (l-1));
	return ret;
}

unsigned long get_primes_ex(unsigned long prime[], unsigned long count, unsigned long upto) {
	unsigned long max;
	char *p;
	unsigned long i, j;
	unsigned long pc = 0;
	
	if (upto != ULONG_MAX)
		upto++;
	if (count != ULONG_MAX) {
		max = size_primes(count);
		if (max > upto)
			max = upto;
	} else
		max = upto;
	
	p = malloc(max);
	
	memset(p, 0, max);
	p[0] = 1;
	p[1] = 1;
	
	for (i=2; i<max;) {
		if (pc < count)
			prime[pc++] = i;
		else
			break;
		
		for (j=i+i; j<max; j+=i)
			p[j] = 1;
		for (i++; i<max && p[i]==1; i++);
	}
	
	free(p);
	
	return pc;
}
