import time, math, operator, os.path
from helper import *

t1 = starttimer()

filename = "C%s.%s"
# 0 for test, 1 for small, 2 for large
is_large = 1

mode_str = '' if is_large == 0 else '-small-attempt1' if is_large == 1 else '-large'
infile = filename % (mode_str, 'in')
outfile = filename % (mode_str, 'out')

# parse input
inf = open(infile, 'r')
outf = open(outfile, 'w')

# find primes under 10000
primes = []
if os.path.exists('primes10000.txt'):
    primef = open('primes10000.txt', 'r')
    primes = [int(line.strip()) for line in primef]    
    primef.close()

if len(primes) == 0:
    MAX = 10000
    is_prime = [1 for i in range(MAX+1)]
    is_prime[0] = is_prime[1] = 0

    primes.extend((2, 3))
    for i in range(4, MAX+1, 2): is_prime[i] = 0
    for i in range(6, MAX+1, 3): is_prime[i] = 0

    for i in range(6, MAX+1, 6):
        for j in [i-1, i+1]:
            if is_prime[j]:
                primes.append(j)
                for k in range(2*j, MAX+1, j): is_prime[k] = 0

    primef = open('primes10000.txt', 'w')
    primef.write('\n'.join(map(str, primes)))
    primef.close()

def gcd(a, b):
    if a < b: a, b = b, a

    while b > 0:
        a, b = b, a%b

    return a

try:
    T = readI(inf)
    
    for case in range(1, T+1):
        N = readI(inf)

        wmin = 0
        for i in primes:
            if i > N: break
            wmin += 1

        # account for dude 1
        wmin = max(1, wmin)

        wmax = 1
        lcm = 1
        for i in range(1, N+1):
            if lcm % i <> 0:
                wmax += 1
                
            lcm = lcm * i / gcd(lcm, i)

        output = wmax - wmin
        print output, wmax, wmin
        outf.write("Case #%d: %d\n" % (case, output))
    
finally:
    inf.close()
    outf.close()

endtimer(t1)
