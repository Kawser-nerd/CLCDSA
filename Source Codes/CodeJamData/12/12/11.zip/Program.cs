﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ProblemB
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var input = new StreamReader(File.Open(args[0], FileMode.Open, FileAccess.Read)))
            using (var output = new StreamWriter(File.Open(args[1], FileMode.Create, FileAccess.Write)))
            {
                Program p = new Program();
                int T = int.Parse(input.ReadLine());
                for (int i = 0; i < T; i++)
                {
                    int N = int.Parse(input.ReadLine());
                    int[,] ab = new int[N, 2];
                    for (int j = 0; j < N; j++)
                    {
                        var ii = input.ReadLine().Split(' ').Select(ss => int.Parse(ss)).ToList();
                        ab[j, 0] = ii[0];
                        ab[j, 1] = ii[1];
                    }
                    int ans = p.Solve(N, ab);
                    output.WriteLine(String.Format("Case #{0}: {1}", i + 1, ans < 0 ? "Too Bad" : ans.ToString()));
                }
            }
        }

        Program()
        {

        }

        int Solve(int N, int[,] ab)
        {
            int ttl = 0, tg = 0;

            for (int i = 0; ttl < 2*N; i++)
            {
                int j = 0, bj = -1;

                for (; j < N; j++)
                {
                    if (ab[j, 1] < 0) continue;
                    if (ab[j, 1] <= ttl) break;
                    if (ab[j, 0] < 0) continue;
                    if (ab[j, 0] <= ttl && (bj == -1 || ab[j, 1] > ab[bj, 1])) bj = j;
                }

                if (j < N)
                {
                    if (ab[j, 0] != -1) { ab[j, 0] = -1; ttl++; }
                    ab[j, 1] = -1;
                    ttl++;
                }
                else if (bj >= 0)
                {
                    ab[bj, 0] = -1;
                    ttl++;
                }
                else
                {
                    return -1;
                }
                tg++;
            }

            return tg;
        }
    }
}
