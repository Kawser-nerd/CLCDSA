/**
 * 
 */
package gepa.gcj.main;

/**
 * @author gepa
 *
 */
public class Constants {

    private Constants() { }

    public static final String WHITESPACE_PATTERN = "\\s+";
    public static final String DOUBLE_FORMAT = "%.8f";
}
