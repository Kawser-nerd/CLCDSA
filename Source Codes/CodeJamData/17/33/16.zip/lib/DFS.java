package lib;

import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;

public class DFS {

    public static void traverse(int start, AdjacentListGetter adj, IntConsumer discoverHandler, Runnable finishHandler, BooleanSupplier stopper, MapFactory<Integer> vertexKeyMapFactory) {
        Set<Integer> visited = SetFromMapFactory.create(vertexKeyMapFactory); // TODO Set 을 쓰지말고, VertexWithVisitedFlag 를 도입하자
        traverseRecursively(adj, start, discoverHandler, finishHandler, stopper, visited);
    }

    private static void traverseRecursively(AdjacentListGetter adj, int current, IntConsumer discoverHandler, Runnable finishHandler, BooleanSupplier stopper, Set<Integer> visited) {
        if (stopper.getAsBoolean())
            return;
        visited.add(current);
        discoverHandler.accept(current);
        adj.forEach(current, adjacent -> {
            if (!visited.contains(adjacent))
                traverseRecursively(adj, adjacent, discoverHandler, finishHandler, stopper, visited);
        });
        finishHandler.run();
    }

}
