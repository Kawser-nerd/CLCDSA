using CodeJam.Providers;
using Problems;
using Template.Interfaces;

namespace CodeJam.Factories
{
  public class ProblemFactory : IProblemFactory
  {
    public IProblem CreateProblem(ProblemType problemType)
    {
      switch (problemType)
      {
        case ProblemType.ProblemA:
          return ObjectFactory.GetInstance<ProblemA>();

        case ProblemType.ProblemB:
          return ObjectFactory.GetInstance<ProblemB>();

        case ProblemType.ProblemC:
          return ObjectFactory.GetInstance<ProblemC>();

        case ProblemType.ProblemD:
          return ObjectFactory.GetInstance<ProblemD>();

        default:
          return ObjectFactory.GetInstance<NullProblem>();
      }
    }
  }
}