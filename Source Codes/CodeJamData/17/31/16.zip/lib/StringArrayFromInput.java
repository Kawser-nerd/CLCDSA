package lib;

public class StringArrayFromInput {

    public static String[] next(Input in, int n) {
        return ArrayFromInput.next(in, n, String.class, s -> s);
    }

}
