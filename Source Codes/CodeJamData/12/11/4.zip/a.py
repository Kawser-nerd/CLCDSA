import time, math, operator, re
from helper import *

t1 = starttimer()

filename = "A%s.%s"
# 0 for test, 1 for small, 2 for large
is_large = 1

mode_str = '' if is_large == 0 else '-small-attempt1' if is_large == 1 else '-large'
infile = filename % (mode_str, 'in')
outfile = filename % (mode_str, 'out')

# parse input
inf = open(infile, 'r')
outf = open(outfile, 'w')

try:
    T = readI(inf)
    
    for case in range(1, T+1):
        A, B = readIA(inf)
        P = map(float, readL(inf).split(' '))

        # enter right away
        best = B + 2.0
        print best        

        # correct last i
        pr_correct = 1.0
        for i in range(1, A):
            # i = # to keep
            # will never backspace them all - rather use 3
            pr_correct *= P[i-1]
            
            num_correct = B - A + 1 + 2*(A-i)
            num_incorrect = num_correct + B + 1

            ex = num_correct * pr_correct + num_incorrect * (1 - pr_correct)
            best = min(ex, best)
            print i, ex, num_correct, num_incorrect

        pr_correct *= P[A-1]

        # try finishing
        num_correct = B - A + 1
        num_incorrect = num_correct + B + 1
        ex = num_correct * pr_correct + num_incorrect * (1 - pr_correct)
        best = min(best, ex)

        print ex, num_correct, num_incorrect, pr_correct
        
        output = best
        print "Case #%d: %.8f" % (case, output)
        outf.write("Case #%d: %.8f\n" % (case, output))
    
finally:
    inf.close()
    outf.close()

endtimer(t1)
