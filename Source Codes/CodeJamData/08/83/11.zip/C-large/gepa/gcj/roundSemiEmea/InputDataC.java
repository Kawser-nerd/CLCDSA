/**
 * 
 */
package gepa.gcj.roundSemiEmea;

import java.util.List;

import gepa.gcj.main.InputData;
import gepa.gcj.main.LineParser;
import gepa.gcj.main.ParseException;

/**
 * @author gepa
 *
 */
public class InputDataC implements InputData {

    public int n;
    public int k;
    public int[][] g;

    @Override
    public void parse(LineParser parser) throws ParseException {
        long[] f = parser.getLongArray(2);
        n = (int)f[0];
        k = (int)f[1];
        int[][] buf = new int[n - 1][2];
        for (int i = 0; i < n - 1; i++) {
            long[] x= parser.getLongArray(2);
            buf[i][0] = (int)x[0] - 1;
            buf[i][1] = (int)x[1] - 1;
        }
        g = new int[n][];
        for (int i = 0; i < n; i++) {
            int c = 0;
            for (int j = 0; j < n - 1; j++) {
                if (buf[j][0] == i || buf[j][1] == i) {
                    c++;
                }
            }
            g[i] = new int[c];
            c = 0;
            for (int j = 0; j < n - 1; j++) {
                if (buf[j][0] == i) {
                    g[i][c] = buf[j][1];
                    c++;
                } else if (buf[j][1] == i) {
                    g[i][c] = buf[j][0];
                    c++;
                }
            }
        }
    }

}
