This code is Visual Studio 2008 project.  The .sln file is a composite of a variety of projects. Ignore the warning that several projects cannot be found - I have not included a handleful of test projects.  The remaining code should still compile and execute.

Also, there may or may not be additional source code included for the other problems in the contest.  Please disregard the source code that isn't relevant to the probelm in question.

Compile in Visual Studio.  The executable will be CodeJam.exe and can be found at:
products\CodeJam\bin

The problem algorithm will be found in the file ProblemX.cs, where X is A,B,C,D as appropriate.

To execute, place a problem input file in the directory marked Input/ found in the executable directory.
and run CodeJam.exe, the output will appear in the directory Output/.

Notes:
1) the input file must begin with the letter "A", "B", "C" or "D" as appropriate to the problem in question,
the main program will then execute the appopriate problem algorithm - ProblemA, ProblemB, ProblemC or ProblemD corresponding
to the name of the input file.
2) one and only input file should be in the Input/ directory while execution.
