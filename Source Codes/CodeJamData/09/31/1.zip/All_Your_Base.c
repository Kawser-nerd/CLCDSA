#include <stdio.h>
#include <stdlib.h>


int main(void)
{
	int		T, t;
	int		i, j, k;
	char	buf[64];
	char	s[64];
	char	r[256];
	char	n;
	long long	res;
	long long	mul;

	scanf("%d\n", &T);

	for(t = 0; t < T; t++)
	{
		gets(buf);
		memset(r, -1, 256);
		n = 1;
		for (i = 0; buf[i]; i++) {
			j = (unsigned int)buf[i];
			if (r[j] == -1) {
				r[j] = n;
				switch (n) {
				case 0:
					n = 2;
					break;
				case 1:
					n = 0;
					break;
				default:
					n++;
				}
			}
			s[i] = r[j];
		}
		
		res = 0;
		mul = 1;
		if (n < 2)
			n = 2;

		while (i > 0) {
			res += mul * ((long long)s[--i]);
			mul *= (long long)n;
		}

		printf("Case #%d: %lld\n", t + 1, res);
	}
	return 1;
}
