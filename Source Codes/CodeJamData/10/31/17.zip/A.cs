﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BigNum;

namespace gcj
{
    class A
    {
        class wire
        {
            public int x = 0;
            public int y = 0;
            public wire(int x, int y)
            {
                this.x = x;
                this.y = y;
            }
        }
        public void solve()
        {
            int notc = int.Parse(Console.ReadLine());
            for (int i = 1; i <= notc; i++)
            {
                int now = int.Parse(Console.ReadLine());
                List<wire> wires = new List<wire>();
                long totres = 0;
                for (int j = 0; j < now; j++)
                {
                    string[] vars = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    int lx = int.Parse(vars[0]);
                    int ry = int.Parse(vars[1]);
                    wire wr = new wire(lx,ry);
                    for (int k = 0; k < wires.Count; k++)
                    {
                        wire dwr = wires[k];
                        if (doIntersect(dwr, wr))
                            totres++;
                    }
                    wires.Add(wr);
                }
                Console.WriteLine("Case #" + i + ": " + totres);

            }
        }

        private bool doIntersect(wire dwr, wire wr)
        {
            if (dwr.x > wr.x && dwr.y < wr.y)
                return true;
            if (dwr.x < wr.x && dwr.y > wr.y)
                return true;

            return false;
        }
    }
}
