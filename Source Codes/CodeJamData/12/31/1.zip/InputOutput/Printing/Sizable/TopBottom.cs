﻿using System;
using Generic.InputOutput.Printing.Sized;

namespace Generic.InputOutput.Printing.Sizable
{
    internal class TopBottom : Document
    {
        readonly Document bottom;
        readonly Document top;

        public TopBottom(Document top, Document bottom)
        {
            this.top = top;
            this.bottom = bottom;
        }

        internal override int GetMinimumWidth()
        {
            return Math.Max(top.GetMinimumWidth(), bottom.GetMinimumWidth());
        }

        internal override SizedDocument GetSizedDocument(int? preferredWidth)
        {
            var pTop = top.GetSizedDocument(preferredWidth);
            var pBottom = bottom.GetSizedDocument(preferredWidth);
            return pTop ^ pBottom;
        }
    }
}
