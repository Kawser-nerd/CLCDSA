package lib;

import java.util.function.BinaryOperator;

public class FibonacciNumberTable {
    public static <T> Solver<Integer, T> create(T one, BinaryOperator<T> adder) {
        return MemoizationSolver.of(HashMapFactory.create(), (n, sub) -> {
            if (n == 1 || n == 2)
                return one;
            return adder.apply(sub.solve(n - 1), sub.solve(n - 2));
        });
    }
}
