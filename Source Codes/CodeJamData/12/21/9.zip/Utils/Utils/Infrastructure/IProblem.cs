﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Utils.Infrastructure {
    public interface IProblem {
        void Initialize(IProblemReader reader, IProblemWriter writer);
        int GetProblemsCount();
        IProblemSolver GetNextProblemSolver();
    }
}
