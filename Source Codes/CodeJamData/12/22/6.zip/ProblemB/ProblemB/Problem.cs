﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Utils.Infrastructure;

namespace ProblemB {
    public class Problem : IProblem {
        IProblemReader reader;
        IProblemWriter writer;
        public Problem() {
        }
        public void Initialize(IProblemReader reader, IProblemWriter writer) {
            this.reader = reader;
            this.writer = writer;
        }
        public IProblemSolver GetNextProblemSolver() {
            ProblemSolver solver = new ProblemSolver();
            //Read parameters here
            solver.H = reader.ReadInt();
            solver.N = reader.ReadInt();
            solver.M = reader.ReadInt();
            solver.Cij = new int[solver.N, solver.M];
            for (int i = 0; i < solver.N; i++) {
                int[] r = reader.ReadArray<int>(solver.M, () => reader.ReadInt());
                for(int j = 0; j < solver.M;j++) {
                    solver.Cij[i,j] = r[j];
                }
            }            
            
            solver.Hij = new int[solver.N, solver.M];
            for (int i = 0; i < solver.N; i++) {
                int[] r = reader.ReadArray<int>(solver.M, () => reader.ReadInt());
                for(int j = 0; j < solver.M;j++) {
                    solver.Hij[i,j] = r[j];
                }
            }            
            return solver;
        }

        public int GetProblemsCount() {
            return reader.ReadInt();
        }
    }
}
