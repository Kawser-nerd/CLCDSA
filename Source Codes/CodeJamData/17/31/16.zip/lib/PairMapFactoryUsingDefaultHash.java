package lib;

public class PairMapFactoryUsingDefaultHash {

    public static <T1, T2> MapFactory<Pair<T1, T2>> create() {
        HashMapMaterial<Pair<T1, T2>> material = PairHashMapMaterial.of(DefaultHashMapMaterial.create(), DefaultHashMapMaterial.create());
        return CustomHashMapFactory.create(material);
    }

}
