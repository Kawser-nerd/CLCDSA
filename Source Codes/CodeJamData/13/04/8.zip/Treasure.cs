﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class Treasure : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            FileWrapper.Process<Treasure>(args);
        }
        #endregion

        private int K { get; set; }
        private int N { get; set; }
        private int[] Keys { get; set; }
        private Chest[] Chests { get; set; }

        private bool[] Seen { get; set; }
        private Stack<int> Order { get; set; }

        public override object Solve()
        {
            LoadData();

            Seen = new bool[1 << 21];
            Order = new Stack<int>();
            
            if (!Walk(0, (1 << N) - 1, Keys))
                return "IMPOSSIBLE";

            return String.Join(" ", Order);
        }

        private bool Walk(int mask, int target, int[] keyring)
        {
            if (mask == target)
                return true;

            if (Seen[mask])
                return false;
            else
                Seen[mask] = true;

            for (int i = 0; i < N; i++)
                if ((mask & (1 << i)) == 0 && keyring[Chests[i].Opens] > 0)
                {
                    var nk = new int[keyring.Length];
                    for (int t = 0; t < keyring.Length; t++)
                        nk[t] = keyring[t] + Chests[i].Keys[t];
                    nk[Chests[i].Opens]--;
                    if (Walk(mask | (1 << i), target, nk))
                    {
                        Order.Push(i + 1);
                        return true;
                    }
                }

            return false;
        }

        private void LoadData()
        {
            K = In<int[]>()[0];
            N = Last<int[]>()[1];

            var rawkeys = In<int[]>();
            var rawchests = In<int[]>(N);
            var importantkeys = rawchests.Select(c => c[0]).Distinct().OrderBy(c => c).ToArray();
            var keyMap = Enumerable.Range(0, importantkeys.Length).ToDictionary(ix => importantkeys[ix], ix => ix);

            Keys = new int[importantkeys.Length];
            foreach (var k in rawkeys)
                if (keyMap.ContainsKey(k))
                    Keys[keyMap[k]]++;

            Chests = new Chest[N];
            for (int n = 0; n < N; n++)
            {
                var c = new Chest { Keys = new int[importantkeys.Length] };
                c.Opens = keyMap[rawchests[n][0]];
                for (int x = 2; x < rawchests[n].Length; x++)
                    if (keyMap.ContainsKey(rawchests[n][x]))
                        c.Keys[keyMap[rawchests[n][x]]]++;
                Chests[n] = c;
            }
        }

        public class Chest
        {
            public int Opens;
            public int[] Keys;
        }
    }
}
