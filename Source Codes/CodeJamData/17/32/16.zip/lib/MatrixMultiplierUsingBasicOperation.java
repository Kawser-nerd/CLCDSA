package lib;

import java.util.function.BinaryOperator;
import java.util.stream.IntStream;

// 느려서 쓰는데가 없다. 쓰는데가 생기려나?
public class MatrixMultiplierUsingBasicOperation {

    public static <T> BinaryOperator<Matrix<T>> create(BinaryOperator<T> elementAdder, BinaryOperator<T> elementMultiplier) {
        return (mat1, mat2) -> {
            Assertion.check(mat1.m == mat2.n);
            MatrixElementFunction<T> elementFunction = (i, j) -> IntStream.range(0, mat1.m)
                    .mapToObj(k -> elementMultiplier.apply(mat1.element.at(i, k), mat2.element.at(k, j)))
                    .reduce(elementAdder).get();
            return FlattenMatrix.create(new Matrix<>(mat1.n, mat2.m, elementFunction));
        };
    }

}
