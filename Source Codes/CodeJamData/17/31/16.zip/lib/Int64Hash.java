package lib;

public class Int64Hash {
    public static int hash(long v) {
        v = (~v) + (v << 18);
        v = v ^ (v >>> 31);
        v = v * 21;
        v = v ^ (v >>> 11);
        v = v + (v << 6);
        v = v ^ (v >>> 22);
        return (int) v;
    }
}
