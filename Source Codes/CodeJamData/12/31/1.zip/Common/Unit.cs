﻿namespace Generic.Common
{
    public class Unit
    {
        public static readonly Unit Null = null;
        private Unit()
        {
        }
    }
}
