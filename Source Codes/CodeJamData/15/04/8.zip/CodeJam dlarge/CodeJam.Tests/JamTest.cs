﻿/* www.codertom.com  -  copyright Tom Harrison 2015 */
using System.IO;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace CoderTom.CodeJam.Tests
{
    [TestFixture]
    public class JamTest
    {
        private ProblemFileInfo _input;

        [SetUp]
        public void ReadExampleFile()
        {
            var parser = new FileParser();
            _input = parser.Parse("ExampleInput.txt");
        }

        [Test]
        public void CanParseTestCaseCount()
        {
            Assert.AreEqual(4, _input.TestCaseCount);
        }

        [Test,
        TestCase(1, 3, 200, "GABRIEL", "1-ominos always fit"),
        TestCase(2, 3, 199, "RICHARD", "2-ominos never fit an odd board"),
        TestCase(2, 3, 198, "GABRIEL", "2-ominos always fit an even board"),
        TestCase(3, 600, 1, "RICHARD", "L shaped 3-ominos will not fit a width 1 board"),
        TestCase(3, 1, 300, "RICHARD", "L shaped 3-ominos will not fit a height 1 board"),
        TestCase(3, 15, 11, "GABRIEL", "3-ominos fit a mod 3 = 0 board with greater than 2 width & height"),
        TestCase(3, 14, 11, "RICHARD", "3-ominos do not fit a mod 3 != 0 board with greater than 2 width & height"),
        TestCase(4, 2, 20, "RICHARD", "4-ominos do not fit a width 2 board"),
        TestCase(5, 2, 20, "RICHARD", "5-ominos do not fit a width 2 board"),
        TestCase(4, 20, 2, "RICHARD", "4-ominos do not fit a width 2 board"),
        TestCase(5, 20, 2, "RICHARD", "5-ominos do not fit a width 2 board"),
        TestCase(5, 3, 5, "RICHARD", "5-ominos do not fit a width 3 board with 15 cells"),
        TestCase(5, 3, 10, "GABRIEL", "5-ominos do fit a width 3 board with 30 cells"),
        TestCase(5, 4, 5, "GABRIEL", "5-ominos do fit a width 4 board with 20 cells"),
        TestCase(6, 60, 3, "RICHARD", "6-ominos do not fit a width 3 board"),
        TestCase(6, 3, 24, "RICHARD", "6-ominos do not fit a width 3 board"),
        TestCase(6, 4, 6, "GABRIEL", "6-ominos fit a width 4 board with 24 or more cells"),
        TestCase(6, 6, 4, "GABRIEL", "6-ominos fit a width 4 board with 24 or more cells"),
        TestCase(7, 14, 18, "RICHARD", "7+-ominos can always be chosen to fail"),
        TestCase(20, 14, 18, "RICHARD", "7+-ominos can always be chosen to fail"),

        ]
        public void CanSolveAdditionalCases(int x, int r, int col, string result, string message)
        {
            var c = new TestCase() { XOminoCells = x, Rows = r, Columns = col};
            Assert.AreEqual(result.ToString(), c.Solve(), message);
        }
        
        [Test]
        public void CanSolveAll()
        {
            _input.SolveAll("Output.txt");
            var result = File.ReadAllText("Output.txt");
            var expected = File.ReadAllText("ExampleOutput.txt");
            Assert.AreEqual(expected, result);
        }
    }
}
