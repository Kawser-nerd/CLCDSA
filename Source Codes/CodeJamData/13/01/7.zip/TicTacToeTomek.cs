﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class TicTacToeTomek : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            FileWrapper.Process<TicTacToeTomek>(args);
        }
        #endregion

        private string[] Board { get; set; }

        public override object Solve()
        {
            Board = In<string>(4);
            try { In<string>(); } catch { }

            foreach (var c in new[] { 'X', 'O' })
            {
                for (int i = 0; i < 4; i++)
                {
                    if (Won(c, i, 0, 0, 1) || Won(c, 0, i, 1, 0))
                        return String.Format("{0} won", c);
                }
                if (Won(c, 0, 0, 1, 1) || Won(c, 0, 3, 1, -1))
                    return String.Format("{0} won", c);
            }

            return Board.Any(ln => ln.Any(ch => ch == '.')) ? "Game has not completed" : "Draw";
        }

        private bool Won(char c, int x, int y, int dx, int dy)
        {
            bool won = true;
            for (int i = 0; i < 4; i++, x += dx, y += dy)
            {
                won &= (Board[x][y] == 'T' || Board[x][y] == c);
            }
            return won;
        }
    }
}
