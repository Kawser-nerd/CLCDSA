//lib.go
/*Package main is the primary framework for solving
Google Code Jam-style problems. It provides a clean interface
for parsing the input, writing the output, and parallelizing
the execution of the solution.
Author: Eric Miller [eric@legoaces.org]
Version: 1.1 [4/17/2014 14:18]*/
package main

import (
	"bufio"
	"fmt"
	"io/ioutil"
	"os"
	"runtime"
	"strings"

//	"time"
)

var _ = runtime.BlockProfile

type Reader struct{ *strings.Reader }

func (in Input) split() ([]TestCase, int) {
	var numCases int
	var str Reader
	str = Reader{strings.NewReader(string(in))}
	fmt.Fscan(str, &numCases)

	var result []TestCase

	for i := 0; i < numCases; i++ {
		c := *new(TestCase)
		c.Number = i + 1
		c = c.parseFrom(str)
		result = append(result, c)
	}
	if str.Len() > 0 {
		panic(fmt.Errorf("Too many bytes of the input remain"))
	}

	return result, numCases
}

func getIO() (input string, outchan chan string, done chan bool) {
	outchan = make(chan string)
	done = make(chan bool)
	if FILENAME == "" || strings.Contains(FILENAME, "\n") {
		var err error
		if FILENAME == "" {
			input, err = bufio.NewReader(os.Stdin).ReadString('\n')
			if err != nil {
				panic(err)
			}
		} else {
			input = FILENAME
		}

		go func() {
			fmt.Println(<-outchan)
			done <- true
		}()
	} else { //Read input from file
		bytes, err := ioutil.ReadFile(FILENAME)
		if err != nil {
			panic(err)
		}
		input = string(bytes)
		go func() {
			fileOut := strings.Split(FILENAME, ".")[0] + ".out"

			s := <-outchan
			err := ioutil.WriteFile(fileOut, []byte(s), os.ModeExclusive)
			if err != nil {
				fmt.Println("Error writing to file")
			} else {
				fmt.Printf("Wrote to file: %s\n", fileOut)
			}
			//fmt.Println(s)
			done <- true
		}()
	}

	return input, outchan, done
}

//func monitor(numCases int, solved chan int) {
//	casesFinished := 0

//	//timeout := time.Tick(5 * time.Second)
//	lastCaseTime := time.Now()
//	casesFinishedAtTimeout := 0
//	for casesFinished < numCases {
//		<-solved
//		casesFinished++
//	}
//}

func main() {
	//var routines int
	//if SIMULTANEOUS_LIMIT < 1 {
	//	routines = 1
	//} else {
	//	routines = SIMULTANEOUS_LIMIT
	//}
	//if SIMULTANEOUS_LIMIT > 1 {
	//	runtime.GOMAXPROCS(runtime.NumCPU())
	//}
	//Read input from console or hardcoded
	input, outchan, donechan := getIO()

	var lines Input
	lines = Input(input)
	lines.sanitize()

	cases, numCases := lines.split()
	results := make([]string, numCases)
	//sem := make(chan bool, routines)
	//for i := 0; i < routines; i++ {
	//sem <- true
	//}
	//monitorChan := make(chan int, 9999999)
	//	go monitor(numCases, monitorChan)
	for _, c := range cases {
		//<-sem
		//go func(c TestCase) {
		s := c.solve()
		//if !strings.HasPrefix(s, "Case #") {
		//	s = fmt.Sprintf("Case #%d: %s", c.Number, s)
		//}
		results[c.Number-1] = s
		//monitorChan <- c.Number
		//sem <- true
		//}(c)
	}
	//for i := 0; i < routines; i++ {
	//	<-sem
	//}
	final := strings.Join(results, "\n")
	outchan <- final
	<-donechan
}

type Input string

func (lines *Input) sanitize() {
	*lines = Input(strings.TrimSpace(string(*lines)))
}
