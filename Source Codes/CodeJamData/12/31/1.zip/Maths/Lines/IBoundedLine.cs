﻿namespace Generic.Maths.Lines
{
    public interface IBoundedLine : ILine
    {
        double LeftX { get; }
        double RightX { get; }
        double TopY { get; }
        double BottomY { get; }
    }
}