/**
 * 
 */
package gepa.gcj.main;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * @author gepa
 *
 */
public class MainSolver {

    private InputData[] input;
    private Solver[] solver;
    private int numThreads = 0;

    private Result[] allResults;
    private int[] currentCase;
    private boolean[] initialized;
    private boolean allInitialized;

    private String inputFilename;
    private String testCases;
    private boolean waitForKeypress;

    private int nextCase;
    private BufferedReader inReader;
    private LineParser lp;
    private int numCases;

    private boolean warningsPresent = false;
    private boolean errorsPresent = false;
    public boolean initInstances(String inputDataClassname, String solverClassname, int numThreads) {
        this.numThreads = numThreads;
        input = new InputData[numThreads];
        solver = new Solver[numThreads];
        initialized = new boolean[numThreads];
        currentCase = new int[numThreads];
        allInitialized = false;
        try {
            Class<?> inputDataClass = Class.forName(inputDataClassname);
            Class<?> solverClass = Class.forName(solverClassname);
            for (int i = 0; i < numThreads; i++) {
                input[i] = (InputData) (inputDataClass.newInstance());
                solver[i] = (Solver) (solverClass.newInstance());
                initialized[i] = false;
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (InstantiationException e) {
            e.printStackTrace();
            return false;
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    synchronized void initReady(int id) {
        initialized[id] = true;
        System.err.println("Thread " + id + " ready with initialization.");
        for (int i = 0; i < numThreads; i++) {
            if (!initialized[i]) {
                return;
            }
        }
        allInitialized = true;
        System.err.println("All threads initialized!");
        if (waitForKeypress) {
            System.err.println("Press RETURN to continue...");
            BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
            try {
                r.readLine();
            } catch (IOException e) {
                // ignore
            }
        }
        notifyAll();
    }

    private void openInput() {
        try {
            inReader = new BufferedReader(new FileReader(inputFilename));
            lp = new LineParser(inReader);
            numCases = lp.getSingleInt();
            allResults = new Result[numCases];
        } catch (IOException e) {
            e.printStackTrace();
            closeInput();
        } catch (ParseException e) {
            e.printStackTrace();
            closeInput();
        }
    }

    private void closeInput() {
        if (inReader != null) {
            try {
                inReader.close();
            } catch (IOException e1) {
                // ignore
            }
        }
        inReader = null;
    }

    synchronized InputData getNextInput(int id) {
        while (waitForKeypress && !allInitialized) {
            try {
                wait();
            } catch (InterruptedException e) {
                // ignore
            }
        }
        if (nextCase == 0) {
            openInput();
        }
        if (nextCase == numCases || inReader == null) {
            return null;
        }
        do {
            if (nextCase >= numCases) {
                return null;
            }
            int firstLine = lp.getNextLineNumber();
            try {
                input[id].parse(lp);
            } catch (ParseException e) {
                System.err.println("Parse error during parsing of test case " + (nextCase + 1) + " (starting at line " + firstLine + "):");
                e.printStackTrace();
                closeInput();
                return null;
            }
            nextCase++;
        } while (!inRange(nextCase));
        currentCase[id] = nextCase - 1;
        return input[id];
    }

    synchronized void setResult(int id, Result result, Throwable e, String[] warnings) {
        int c = currentCase[id];
        System.err.printf("Thread %2d Case #%d:", id, c + 1);
        if (e == null) {
            allResults[c] = result;
            if (result == null || (warnings != null && warnings.length > 0)) {
                warningsPresent = true;
                System.err.println(" WARNINGS");
                for (String w : warnings) {
                    System.err.println(w);
                }
            } else {
                System.err.println(" OK");
            }
        } else {
            System.err.println(" ERRORS");
            errorsPresent = true;
            e.printStackTrace();
        }
    }

    private void checkResults(String expectedFilename) {
        if (expectedFilename == null) {
            return;
        }
        boolean allOk = true;
        boolean fatal = false;
        try {
            BufferedReader in = new BufferedReader(new FileReader(expectedFilename));
            if (in == null) {
                return;
            }
            LineParser expLP = new LineParser(in);
            int lastRead = 0;
            for (int i = 0; i < allResults.length; i++) {
                if (fatal) {
                    break;
                }
                if (!inRange(i + 1)) {
                    System.err.printf("Case #%d: NOT TESTED!\n", i + 1);
                    continue;
                }
                if (allResults[i] == null) {
                    System.err.printf("Case #%d: NO RESULT\n", i + 1);
                    allOk = false;
                } else {
                    try {
                        Result rExp = (Result) allResults[i].clone();
                        while (lastRead <= i) {
                            try {
                                if (rExp.isSingleLine()) {
                                    String line = expLP.getNextNotNull();
                                    String[] parts = line.split("\\s+", 3);
                                    if (parts.length < 3 || !parts[0].equalsIgnoreCase("case") || !parts[1].startsWith("#")) {
                                        System.err.printf("Case #%d: COULD NOT READ EXPECTED!", i + 1);
                                        allOk = false;
                                        fatal = true;
                                    } else {
                                        rExp.parse(new String[]{ parts[2] });
                                    }
                                } else {
                                    String line = expLP.getNextNotNull();
                                    String[] parts = line.split("\\s+", 2);
                                    if (parts.length < 2 || !parts[0].equalsIgnoreCase("case") || !parts[1].startsWith("#")) {
                                        System.err.printf("Case #%d: COULD NOT READ EXPECTED!", i + 1);
                                        allOk = false;
                                        fatal = true;
                                    } else {
                                        List<String> data = new ArrayList<String>();
                                        while ((line = expLP.getNextLine()) != null) {
                                            if (line.startsWith("Case #")) {
                                                expLP.unreadLine();
                                                break;
                                            } else {
                                                data.add(line);
                                            }
                                        }
                                        rExp.parse(data.toArray(new String[0]));
                                    }
                                }
                            } catch (ParseException e) {
                                System.err.printf("Case #%d: COULD NOT READ EXPECTED!", i + 1);
                                e.printStackTrace();
                                allOk = false;
                                fatal = true;
                            }
                            lastRead++;
                            if (fatal) {
                                break;
                            }
                        }
                        if (fatal) {
                            break;
                        }
                        if (!allResults[i].isSameAs(rExp)) {
                            allOk = false;
                            System.err.printf("Case #%d: UNEXPECTED RESULT!", i + 1);
                            if (rExp.isSingleLine()) {
                                System.err.println(" Expected: " + rExp.getAsStringArray()[0] +
                                        " Received: " + allResults[i].getAsStringArray()[0]);
                            } else {
                                System.err.printf("\n  Expected:\n");
                                for (String p : rExp.getAsStringArray()) {
                                    System.err.println(p);
                                }
                                System.err.println("\n  Received:\n");
                                for (String p : allResults[i].getAsStringArray()) {
                                    System.err.println(p);
                                }
                                
                            }
                        }
                    } catch (CloneNotSupportedException e) {
                        allOk = false;
                        e.printStackTrace();
                        fatal = true;
                    }
                }
            }
        } catch (IOException e) {
            return;
        }
        if (allOk) {
            System.err.println("--- ALL RESULTS AS EXPECTED ---");
        }
    }
    public void solveAll(String inputFilename, String outputFilename, String expectedFilename,
            String testCases, boolean waitForKeypress, boolean copyToStdOut) {
        this.inputFilename = inputFilename;
        this.testCases = testCases;
        this.waitForKeypress = waitForKeypress;

        this.warningsPresent = false;
        this.errorsPresent = false;

        this.nextCase = 0;

        Thread[] t = new Thread[numThreads];
        for (int i = 0; i < numThreads; i++) {
            t[i] = new Thread(new SolverWorker(solver[i], this, i));
            t[i].start();
        }

        for (int i = 0; i < numThreads; i++) {
            try {
                t[i].join();
            } catch (InterruptedException e) {
                // ignore
            }
        }

        closeInput();

        checkResults(expectedFilename);

        if (warningsPresent) {
            System.err.println("Please check the WARNINGS above!");
        }
        if (errorsPresent) {
            System.err.println("Please check the ERRORS above!");
        }
        PrintWriter outWriter = null;
        boolean printToStdOut = copyToStdOut;
        try {
            outWriter = new PrintWriter(new FileWriter(outputFilename, false));
            for (int i = 0; i < allResults.length; i++) {
                if (allResults[i] == null) {
                    continue;
                }
                if (allResults[i].isSingleLine()) {
                    outWriter.printf("Case #%d: %s\n", i + 1, allResults[i].getAsStringArray()[0]);
                } else {
                    outWriter.printf("Case #%d:\n", i + 1);
                    for (String p : allResults[i].getAsStringArray()) {
                        outWriter.println(p);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            printToStdOut = true;
        } finally {
            if (outWriter != null) {
                if (outWriter.checkError()) {
                    printToStdOut = true;
                }
                outWriter.close();
            }
        }
        if (printToStdOut) {
            for (int i = 0; i < allResults.length; i++) {
                if (allResults[i] == null) {
                    continue;
                }
                if (allResults[i].isSingleLine()) {
                    System.out.printf("Case #%d: %s\n", i + 1, allResults[i].getAsStringArray()[0]);
                } else {
                    System.out.printf("Case #%d:\n", i + 1);
                    for (String p : allResults[i].getAsStringArray()) {
                        System.out.println(p);
                    }
                }
            }
        }
    }

    private boolean inRange(int test) {
        if (testCases == null || testCases.trim().equals("")) {
            return true;
        }
        String[] parts = testCases.split(",");
        for (String p : parts) {
            String[] range = p.split("-", 2);
            int[] r = new int[range.length];
            for (int i = 0; i < r.length; i++) {
                r[i] = Integer.parseInt(range[i]);
            }
            if (r.length == 1 && test == r[0]) {
                return true;
            }
            if (r.length == 2 && test >= r[0] && test <= r[1]) {
                return true;
            }
        }
        return false;
    }
}

class SolverWorker implements Runnable {
    private final Solver solver;
    private final MainSolver parent;
    private final int id;

    SolverWorker(Solver solver, MainSolver parent, int id) {
        this.solver = solver;
        this.parent = parent;
        this.id = id;
    }

    @Override
    public void run() {
        solver.init();
        parent.initReady(id);
        InputData in = null;
        while ((in = parent.getNextInput(id)) != null) {
            Result result = null;
            String[] warnings = null;
            try {
                result = solver.solve(in);
                warnings = solver.getWarnings();
                solver.clearWarnings();
            } catch (Exception e) {
                parent.setResult(id, null, e, warnings);
            }
            parent.setResult(id, result, null, warnings);
        }
    }
    
}
