﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using Generic.Common;
using Generic.InputOutput.Printing;
using Generic.InputOutput.Printing.Sizable;

namespace Google_Code_Jam
{
    internal abstract class Algorithm<Problem, Solution>
    {
        public abstract Problem Parse(StreamReader reader);
        public abstract Solution Solve(Problem problem);
        public abstract string Print(Solution solution);
        public virtual IEnumerable<Problem> LargeProblems
        {
            get
            {
                return Enumerable.Empty<Problem>();
            }
        }

        public void SolveLargeProblems()
        {
            var problems = LargeProblems.ToList();
            for (int index = 0; index < problems.Count; index++)
            {
                ProcessProblem(problems, index);
            }
        }

        public string Run(Stream input)
        {
            var problems = GetProblems(input).ToList();
            Debug.AutoFlush = true;
            var outputWriter = new DocumentWriter();
            for (var index = 0; index < problems.Count; index++)
            {
                var line = ProcessProblem(problems, index);
                outputWriter.WriteLine(line);
            }
            return outputWriter.ToString();
        }

        string ProcessProblem(IList<Problem> problems, int index)
        {
            var algorithm = (Algorithm<Problem, Solution>)Activator.CreateInstance(GetType(), false);
            var problem = problems[index];
            JamUtil.DebugConsole(Document.Space ^ "Solving" ^ problem.Print());
            var solution = algorithm.Solve(problem);
            var line = string.Format("Case #{0}: {1}", index + 1, algorithm.Print(solution));
            Trace.WriteLine(line);
            return line;
        }

        IEnumerable<Problem> GetProblems(Stream input)
        {
            var result = new List<Problem>();
            var reader = new StreamReader(input);
            var caseCount = reader.ReadLine().ParseInt().FromJust;
            for (int i = 0; i < caseCount; i++)
            {
                result.Add(Parse(reader));
            }
            return result;
        }
    }
}
