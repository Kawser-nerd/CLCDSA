﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCJ2015Round1C_2
{
	public abstract class BruteForceSolverBase<TData> : SolverBase, IPermutatorBoardTrimmer<TData>
	{
		#region C'tor

		public BruteForceSolverBase(IEnumerator<string> enumerator)
			: base(enumerator)
		{
		}

		#endregion

		#region Properties

		public int Columns { get; set; }
		public int Rows { get; set; }

		public abstract IEnumerable<TData> PossibleDataValues { get; }

		public virtual TData WildCard
		{
			get
			{
				return default(TData);
			}
		}

		public virtual string NoValidResultFoundString
		{
			get
			{
				return "IMPOSSIBLE";
			}
		}

		#endregion

		#region Methods

		public override string SolveTestCase(int testCase)
		{
			CollectInput();

			int C = this.Columns;
			int R = this.Rows;

			Permutator<TData> permutator = new Permutator<TData>(this.PossibleDataValues, this.WildCard);
			IEnumerable<TData[][]> allPossibleBoards = permutator.GetBoardPermutations(R, C, this);
			foreach (TData[][] board in allPossibleBoards)
			{
				if (BoardMeetsRequirements(board))
					return StringifyBoard(board);
			}

			return this.NoValidResultFoundString;
		}

		public abstract void CollectInput();
		public virtual bool TrimNeeded(TData[][] currentBoard, int lastAddedI, int lastAddedJ, Dictionary<TData, int> appearanceCounter)
		{
			return false;
		}
		public abstract bool BoardMeetsRequirements(TData[][] board);
		public abstract string StringifyBoard(TData[][] board);

		#endregion
	}
}
