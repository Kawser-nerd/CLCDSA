package pl.javahussars.Infinite_House_of_Pancakes;

import java.io.FileWriter;
import java.util.List;

public class InfiniteHouseOfPancakes {

	public static void main(String[] args) throws Exception {
		DataLoader dataLoader = new DataLoader("sample.in");

		List<String> results = dataLoader.loadDataAndRun();
		FileWriter outWriter = dataLoader.getOutputFileWriter();

		int testCase = 1;
		for (String result : results) {
			String outLine = String.format("Case #%d: %s\n", testCase, result);
			System.out.print(outLine);

			if (outWriter != null) {
				outWriter.write(outLine);
			}

			testCase++;
		}

		outWriter.flush();
		outWriter.close();
	}

}
