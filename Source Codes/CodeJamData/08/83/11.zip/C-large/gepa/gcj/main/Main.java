/**
 * 
 */
package gepa.gcj.main;

import java.util.ArrayList;
import java.util.List;

/**
 * @author gepa
 *
 */
public class Main {

    private boolean waitForKeyPress = false;
    private boolean copyToStdOut = false;
    private String inputDataClassName = null;
    private String solverClassName = null;
    private String inputFileName = null;
    private String outputFileName = null;
    private String expectedFileName = null;
    private String testCases = null;
    private int numThreads = 1;

    private static void usage() {
        System.err.println();
        System.err.println("Usage: java gepa.gcj.main.Main [parameters]");
        System.err.println("");
        System.err.println("Parameters:");
        System.err.println("");
        System.err.println("--inputDataClass=<class>       Fully qualified class name of the class for parsing the input");
        System.err.println("                               (must implement gepa.gcj.main.InputData). Required!");
        System.err.println("--solverClass=<class>          Fully qualified class name of the class for solving an input");
        System.err.println("                               (must be a subclass of gepa.gcj.main.Solver). Required!");
        System.err.println("--inputFile=<filename>         File name of the file containing the input data. Required!");
        System.err.println("--outputFile=<filename>        File name of the file to write the results. Required!");
        System.err.println("--expectedFile=<filename>      File name of the expected results. Optional!");
        System.err.println("--numThreads=<num>             Number of threads to use. Optional (default: 1).");
        System.err.println("--testCases=<cases>            Test case numbers to solve, separated by \",\". Ranges can be given");
        System.err.println("                               by \"-\". Example: \"1,5,10-20,100\". Optional (default: all test cases).");
        System.err.println("--waitForKeyPress              If given, waits for keypress after solver(s) are initialized before reading");
        System.err.println("                               input file.");
        System.err.println("--copyToStdOut                 If given, prints results also to standard output.");
    }

    public boolean setBoolean(String param) {
        if (param.equals("waitForKeyPress")) {
            waitForKeyPress = true;
            return true;
        } else if (param.equals("copyToStdOut")) {
            copyToStdOut = true;
            return true;
        } else {
            System.err.println("Unknown option: " + param + " (or option requires an argument <param>=<value>).");
            return false;
        }
    }

    public boolean setParameter(String param, String val) {
        if (param.equals("inputDataClass")) {
            inputDataClassName = val;
        } else if (param.equals("solverClass")) {
            solverClassName = val;
        } else if (param.equals("inputFile")) {
            inputFileName = val;
        } else if (param.equals("outputFile")) {
            outputFileName = val;
        } else if (param.equals("expectedFile")) {
            expectedFileName = val;
        } else if (param.equals("numThreads")) {
            try {
                numThreads = Integer.parseInt(val);
            } catch (NumberFormatException e) {
                System.err.println("Parameter \"numThreads\" expects an integer argument!");
                return false;
            }
        } else if (param.equals("testCases")) {
            testCases = val;
        } else {
            System.err.println("Unknown parameter \"" + param + "\" (or parameter does not expect a value)!");
            return false;
        }
        return true;
    }

    public String[] missingParameters() {
        List<String> missing = new ArrayList<String>();
        if (inputDataClassName == null) {
            missing.add("inputDataClass");
        }
        if (solverClassName == null) {
            missing.add("solverClass");
        }
        if (inputFileName == null) {
            missing.add("inputFile");
        }
        if (outputFileName == null) {
            missing.add("outputFile");
        }
        return missing.toArray(new String[0]);
    }

    public void solve() {
        MainSolver s = new MainSolver();
        s.initInstances(inputDataClassName, solverClassName, numThreads);
        s.solveAll(inputFileName, outputFileName, expectedFileName, testCases, waitForKeyPress, copyToStdOut);
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        Main m = new Main();
        boolean argsOk = true;
        for (String a : args) {
            if (!a.startsWith("--")) {
                System.err.println("Illegal argument: " + a);
                argsOk = false;
            } else {
                String[] parts = a.substring(2).split("=", 2);
                if (parts.length == 1) {
                    if (!m.setBoolean(a.substring(2))) {
                        argsOk = false;
                    }
                } else if (parts.length == 2){
                    if (!m.setParameter(parts[0], parts[1])) {
                        argsOk = false;
                    }
                } else {
                    // shouldn't happen
                    System.err.println("Invalid parameter: " + a);
                    System.err.println("Unexpected number of parts: " + parts.length);
                }
            }
        }
        if (!argsOk) {
            usage();
            return;
        }
        String[] missing = m.missingParameters();
        if (missing.length != 0) {
            System.err.println("Following required parameters not given:");
            for (String p : missing) {
                System.err.println(p);
            }
            usage();
            return;
        }
        m.solve();
    }

}
