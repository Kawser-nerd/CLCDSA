package lib;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class PermutationsWithRepetition {

    public static Stream<int[]> of(int n, int r) {
        return IntStream.rangeClosed(0, (int) Math.pow(n, r) - 1)
                .mapToObj(i -> toPermutation(n, r, i));
    }

    // stream 쓰면 CLOCKSYNC 시간초과됨
    private static int[] toPermutation(int n, int r, int v) {
        int[] perm = new int[r];
        int remain = v;
        for (int i = 0; i < r; i++) {
            perm[i] = remain % n;
            remain /= n;
        }
        return perm;
    }


}
