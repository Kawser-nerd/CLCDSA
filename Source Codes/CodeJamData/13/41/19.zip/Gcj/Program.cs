﻿using Gcj.Util;
using Gcj.Y2013.R2.A;

namespace Gcj
{
    class Program
    {
        static void Main(string[] args)
        {
            GcjSolver.Solve<ASolver>();
            //ConcurrentGcjSolver.Solve<OutOfGasConcurrentSolver2>(true);
        }
    }
}
