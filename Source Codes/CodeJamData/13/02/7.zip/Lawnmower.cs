﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class Lawnmower : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            FileWrapper.Process<Lawnmower>(args);
        }
        #endregion

        private int N, M;
        private int[][] Lawn { get; set; }

        public override object Solve()
        {
            N = In<int[]>()[0];
            M = Last<int[]>()[1];
            Lawn = In<int[]>(N);

            for (int n = 0; n < N; n++)
                for (int m = 0; m < M; m++)
                    if (!check(n, m))
                        return "NO";

            return "YES";
        }

        private bool check(int nx, int mx)
        {
            if (Enumerable.Range(0, N).All(nn => Lawn[nn][mx] <= Lawn[nx][mx]))
                return true;

            if (Enumerable.Range(0, M).All(mm => Lawn[nx][mm] <= Lawn[nx][mx]))
                return true;

            return false;
        }
    }
}
