// parsetools.go
package main

import (
	"fmt"
)

func (in *Reader) GetInt(target *int) int {
	_, err := fmt.Fscan(*in, target)
	if err != nil {
		panic(err)
	}
	return *target
}

func (in *Reader) GetFloat(target *float64) float64 {
	_, err := fmt.Fscan(*in, target)
	if err != nil {
		panic(err)
	}
	return *target
}

func (in *Reader) GetIntGrid(target *[][]int, width, height int) [][]int {
	*target = make([][]int, height)
	for i := 0; i < height; i++ {
		(*target)[i] = make([]int, width)
		for j := 0; j < width; j++ {
			in.GetInt(&(*target)[i][j])
		}
	}
	return *target
}
