﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Numerics;
using Cmn.Util;
using Gcj.Util;
using System.Linq;

namespace Gcj.Y2013.R1A.A
{
    internal class ASolver : GcjSolver
    {
        protected override IEnumerable<object> EnobjSolveCase()
        {
            BigInteger rStart;
            BigInteger tMax;
            Fetch(out rStart, out tMax);

            var cCirlce = U.BinsearchBiginteger(c => t(c, rStart) <= tMax, 1, 1, 10) - 10;
            if(cCirlce<1)
                cCirlce = 1;
            Debug.Assert(t(cCirlce,rStart)<=tMax);
            for(;;)
            {
                if(t(cCirlce+1,rStart)>tMax)
                {
                    yield return cCirlce;
                    yield break;
                }
                cCirlce++;
            }
        }

        private BigInteger t(BigInteger cCirle, BigInteger rStart)
        {
            var tFirst = 2 * rStart + 1;
            var tLast = 2 * (rStart + (cCirle-1) * 2) + 1;
            return (tFirst + tLast) * cCirle / 2;
        }
    }
}
