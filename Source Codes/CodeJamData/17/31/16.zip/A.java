import lib.CodeJamLauncher;
import lib.IntPair;
import lib.MemoizationSolver;
import lib.NormalIntPairHashMapFactory;
import lib.Solver;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Random;
import java.util.stream.IntStream;

public class A {

    public static final Random RANDOM = new Random();
    private static int n;
    private static int k;
    private static IntPair[] p;

    public static void main(String[] ignored) throws Exception {
        CodeJamLauncher.run("A-large.in", (caseTitle, in) -> {
            n = in.nextInt();
            k = in.nextInt();
            p = new IntPair[n];
            IntStream.range(0, n).forEach(i -> {
                int r = in.nextInt();
                int h = in.nextInt();
                p[i] = new IntPair(r, h);
            });

//            n = 1000;
//            k = 1000;
//            p = new IntPair[n];
//            IntStream.range(0, n).forEach(i -> {
//                p[i] = new IntPair(RANDOM.nextInt(1000000), RANDOM.nextInt(1000000));
//            });

            Comparator<IntPair> cmp = Comparator.comparing(pair -> pair.v1);
            Arrays.sort(p, cmp.reversed());

            Solver<IntPair, Double> solver = MemoizationSolver.of(NormalIntPairHashMapFactory.INSTANCE, (terms, self) -> {
                int i = terms.v1; // i 번째부터
                int j = terms.v2; // j 개 선택할 수 있을 때.
                if (j == 0)
                    return 0.0;
                if (n - i < j)
                    return 0.0;
                double max = 0;
                for (int k1 = i + 1; k1 < n && 1 + (n - k1) >= j; k1++)
                    max = Math.max(max, self.solve(new IntPair(k1, j - 1)));
                return 2 * Math.PI * p[i].v1 * p[i].v2 + max;
            });

            double max = IntStream.range(0, n)
                    .mapToDouble(i -> Math.PI * Math.pow(p[i].v1, 2) + solver.solve(new IntPair(i, k)))
                    .max().getAsDouble();

            System.out.println(caseTitle + String.format("%.10f", max));

        });
    }

}
