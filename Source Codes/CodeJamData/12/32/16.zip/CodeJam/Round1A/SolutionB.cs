﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CodeJam.Round1A
{
    internal class SolutionB : ISolution
    {
        private int[] oneStar;
        private int[] twoStar;
        private int _problemIndex;

        public int GetProblem(int problemIndex, int startIndex, string[] data)
        {
            _problemIndex = problemIndex;
            int levels = int.Parse(data[startIndex++]);
            oneStar = new int[levels];
            twoStar = new int[levels];

            for (int i = 0; i < levels; i++)
            {
                int[] stars = data[startIndex++].Split(' ').Select(int.Parse).ToArray();
                oneStar[i] = stars[0];
                twoStar[i] = stars[1];
            }
            return startIndex;
        }

        public Result ProcessProblem()
        {
            string result = "Too Bad";

            int starCount = 0;
            int playCount = 0;
            while (notFinished())
            {
                starCount = finishLevel(starCount);
                playCount++;
                if(starCount == -1)
                {
                    break;
                }
            }

            if (starCount != -1)
            {
                result = playCount.ToString();
            }
            
            return new Result()
                           {
                               Output = result,
                               ProblemIndex = _problemIndex
                           };
        }

        private bool notFinished()
        {
            return twoStar.Any(t => t != -1);
        }

        private int finishLevel(int stars)
        {
            int foundIndex = -1;
            int foundStars = int.MaxValue;
            for (int i = 0; i < twoStar.Count(); i++)
            {
                if (twoStar[i] != -1)
                {
                    if (twoStar[i] <= stars)
                    {
                        if(oneStar[i] != -1)
                        {
                            foundIndex = i;
                            foundStars = twoStar[i];
                        }
                        else if(foundIndex == -1)
                        {
                            foundIndex = i;
                            foundStars = twoStar[i];
                        }
                    }
                }
            }
            if (foundIndex != -1)
            {
                twoStar[foundIndex] = -1;
                if(oneStar[foundIndex] == -1)
                {
                    return stars + 1;
                }
                return stars + 2;
            }
            int higestTwo = 0;
            for (int i = 0; i < oneStar.Count(); i++)
            {
                if (oneStar[i] != -1 && twoStar[i] != -1)
                {
                    if (oneStar[i] <= stars && twoStar[i] > higestTwo)
                    {
                        foundIndex = i;
                        higestTwo = twoStar[i];
                        foundStars = oneStar[i];
                    }
                }
            }
            if (foundIndex != -1)
            {
                oneStar[foundIndex] = -1;
                return stars + 1;
            }
            return -1;
        }
    }
}
