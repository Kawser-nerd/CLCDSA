﻿using System;

namespace CodeJam2011.Problems
{
    public class ProblemB : ProblemBase
    {
        protected override string SolveOneCase(InputHelper input)
        {
            int R = input.GetInt();
            int C = input.GetInt();
            int D = input.GetInt();

            int[,] grid = new int[R,C];

            for (int i = 0; i < R; i++)
            {
                var line = input.GetString();
                for (int j = 0; j < C; j++)
                {
                    grid[i, j] = int.Parse(line[j].ToString());
                }
            }




            for (int size = Math.Max(R,C);  size > 2; size--)
            {
                
            
                for (int i = 0; i + size <= R; i++)
                {
                    for (int j = 0; j + size <= C; j++)
                    {

                        int xAbove = 0;
                        int xBelow =0 ;

                        int yright = 0;
                        int yleft = 0;

                        int mid = (size - 1);

                        // now iterate ever element
                        for (int k = 0; k < size; k++)
                        {
                            for (int l = 0; l < size; l++)
                            {
                                if ((k == 0 && l == 0)
                                    || (k == 0 && l == size - 1)
                                    || (k == size - 1 && l == 0)
                                    || (k == size - 1 && l == size - 1)
                                )
                                {
                                    
//                                    Console.Write("X");
                                    continue;

                                }

                                int val = grid[i + k, j + l];

//                                Console.Write(val);

                                if (2*k > mid)
                                    xAbove += (2*k-mid)* val;
                                else if( 2*k< mid)
                                    xBelow += (mid-2 * k) * val;


                                if (2*l > mid)
                                    yright += (2*l-mid)*val;
                                else if(l<mid)
                                    yleft += (mid-2 * l) * val;

                            }
//                            Console.WriteLine();
                        }



                        if (xAbove == xBelow && yright == yleft)
                            return size.ToString();
//                        Console.WriteLine();
                    }
                }

            }

            return "IMPOSSIBLE";
        }
    }
}