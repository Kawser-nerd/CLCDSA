package lib;

import java.lang.reflect.Array;

public class ArrayClass {

    @SuppressWarnings("unchecked")
    static <T> Class<T[]> of(Class<T> clazz) {
        return (Class<T[]>) Array.newInstance(clazz, 0).getClass();
    }
}
