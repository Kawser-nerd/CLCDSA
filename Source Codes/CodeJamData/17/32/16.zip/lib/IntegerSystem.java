package lib;

public class IntegerSystem {

    public static final FloorDivisibleSystem<Integer> INSTANCE = new FloorDivisibleSystem<Integer>() {
        @Override
        public Integer one() {
            return 1;
        }

        @Override
        public Integer add(Integer a, Integer b) {
            return a + b;
        }

        @Override
        public Integer subtract(Integer a, Integer b) {
            return a - b;
        }

        @Override
        public Integer floorDivide(Integer a, Integer b) {
            return a / b;
        }

        @Override
        public int compare(Integer a, Integer b) {
            return a.compareTo(b);
        }
    };
}
