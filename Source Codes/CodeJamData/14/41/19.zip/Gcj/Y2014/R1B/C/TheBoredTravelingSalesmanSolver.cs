﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Cmn.Util;
using Gcj.Util;

namespace Gcj.Y2014.R1B.C
{
    internal class TheBoredTravelingSalesmanSolver : GcjSolver
    {
        private class Cy : IComparable<Cy>
        {
            public int i;
            public string code;
            public SortedDictionary<string, Cy> mpcyByCode=new SortedDictionary<string, Cy>();

            public int CompareTo(Cy other)
            {
                return code.CompareTo(other.code);
            }

            public override string ToString()
            {
                return code;
            }
        }

        private class Dst : IComparable<Dst>
        {
            public List<Cy> rgcy;

            public int CompareTo(Dst other)
            {
                for(int i=0;;i++)
                {
                    if(i == rgcy.Count || i == other.rgcy.Count)
                        return rgcy.Count.CompareTo(other.rgcy.Count);

                    var d = rgcy[i].CompareTo(other.rgcy[i]);
                    if(d != 0)
                        return d;
                }
            }

            public override string ToString()
            {
                return rgcy.StJoinToString("");
            }
        }

        private class Nd : IAstarNd<Dst>
        {
            public List<Cy> rgcyVisited;
            public List<Cy> rgcyPath;

            public Dst DistFromStart
            {
                get
                {
                    return new Dst {rgcy = rgcyVisited};
                }
            }
        }

        protected override IEnumerable<object> EnobjSolveCase()
        {
            int ccy;
            int cline;
            Fetch(out ccy, out cline);

            var mpcyByicy = ccy.Eni().Select(icy => new Cy {i = icy, code = Fetch<string>()}).ToDictionary(cy => cy.i+1);

            foreach(var i in cline.Eni())
            {
                int icy1;
                int icy2;
                Fetch(out icy1, out icy2);

                var cy1 = mpcyByicy[icy1];
                var cy2 = mpcyByicy[icy2];
                
                cy1.mpcyByCode[cy2.code] = cy2;
                cy2.mpcyByCode[cy1.code] = cy1;
            }

            yield return Astar2.Find<Nd,Dst>(
                mpcyByicy.Values.Select(cy => new Nd {rgcyPath = new List<Cy>{cy}, rgcyVisited = new List<Cy> {cy}}), 
                nd => nd.rgcyVisited.Count == ccy,
                enNext
                ).rgcyVisited.StJoin("", cy => cy.code);

        }

        private IEnumerable<Nd> enNext(Nd nd)
        {
            var hlmcyVisited = new HashSet<Cy>(nd.rgcyVisited);
            return from vicy in nd.rgcyPath.Select((v, i) => new {v, i}) from cy in vicy.v.mpcyByCode.Values.Where(cy => !hlmcyVisited.Contains(cy)) select new Nd
            {
                rgcyVisited = nd.rgcyVisited.Concat(cy.Encons()).ToList(),
                rgcyPath = nd.rgcyPath.Take(vicy.i+1).Concat(cy.Encons()).ToList()
            };
        }
    }
}
