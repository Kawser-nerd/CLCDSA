package lib;

public class RowVector {
    public static <T> Vector<T> of(Matrix<T> mat, int rowIndex) {
        return new Vector<>(mat.m, i -> mat.element.at(rowIndex, i));
    }
}
