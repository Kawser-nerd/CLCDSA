﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace GoogleCodeJam2013
{
    public partial class GCJ_A2010_R0Q_A_1 : Form
    {
        public GCJ_A2010_R0Q_A_1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtFile.Text = openFileDialog1.InitialDirectory;
        }

        private void btnFile_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            txtFile.Text = openFileDialog1.FileName;
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            txtOutput.Clear();
            StreamWriter sw = new StreamWriter(txtFile.Text.Replace(".in", ".out"), false, Encoding.ASCII);
            StreamReader sr = new StreamReader(txtFile.Text);
            string sResultLine = string.Empty;
            string sLine = string.Empty;
            int nTestCases = 0;

            sLine = sr.ReadLine();
            if (!int.TryParse(sLine, out nTestCases))
            {
                txtOutput.AppendText("Invalid number of test cases!");
                return;
            }
            txtOutput.AppendText("There are " + nTestCases.ToString() + " test cases.\n");

            //---------- for each test case - begin ----------
            double PI = 3.142; //Math.PI;

            for (int iTestCase = 0; iTestCase < nTestCases; iTestCase++)
            {
                //-------------------- test case - begin ----------
                DateTime date1 = DateTime.Now;

                //------------------------------ data preparation - begin ----------
                Regex reg = new Regex(" ");
                string[] splitted;

                sLine = sr.ReadLine();
                splitted = reg.Split(sLine);

                //double r = double.Parse(splitted[0]);
                //double t = double.Parse(splitted[1]);
                long r = long.Parse(splitted[0]);
                long t = long.Parse(splitted[1]);
                //------------------------------ data preparation - end ----------

                //------------------------------ algorithm - begin ----------
                long n = 0;
                while (t >= 0)
                {
                    //double r1 = PI * Math.Pow(r, 2);
                    //double r2 = PI * Math.Pow(++r, 2);
                    //double area = r2 - r1;
                    //t -= area / PI;
                    ////t -= r++ * PI;
                    long r1 = (long)Math.Pow(r, 2);
                    long r2 = (long)Math.Pow(++r, 2);
                    t -= (r2 - r1);
                    n++;
                    r++;
                }
                sResultLine = "Case #" + (iTestCase + 1).ToString() + ": " + (--n).ToString() + "\n";
                txtOutput.AppendText(sResultLine);
                sw.Write(sResultLine);
                sw.Flush();
                //------------------------------ algorithm - end ----------

                DateTime date2 = DateTime.Now;
                txtOutput.AppendText("Solved in " + (date2-date1).Milliseconds.ToString("#,##0") + " ms.\n");
                //-------------------- test case - end ----------
            }
            //---------- for each test case - end ----------

            sr.Close();
            sw.Close();
        }
    }
}
