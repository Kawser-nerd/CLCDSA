using System;
using System.IO;

namespace CodeJam.Providers
{
  public class FilePathProvider : IFilePathProvider
  {
    private readonly string inputDirectory;

    private const string outExtenstion = ".out";
    private readonly string outputDirectory;

    private readonly string timerFileName;

    public FilePathProvider(string inputDirectory, string outputDirectory, string timerFileName)
    {
      this.inputDirectory = inputDirectory;
      this.outputDirectory = outputDirectory;
      this.timerFileName = timerFileName;
    }

    public string InputFilePath()
    {
      return Directory.GetFiles(inputDirectory)[0];
    }

    public string OutputFilePath()
    {
      string outputPath = Path.Combine(outputDirectory, Path.GetFileName(InputFilePath()));

      return Path.ChangeExtension(outputPath, outExtenstion);
    }

    public string TimerFilePath()
    {
      return Path.Combine(outputDirectory, timerFileName);
    }
  }
}