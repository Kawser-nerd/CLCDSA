/* www.codertom.com  -  copyright Tom Harrison 2015 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace CoderTom.CodeJam
{
    public class TestCase
    {
        public TestCase()
        {
        }

        public TestCase(StreamReader stream)
        {
            var xrc = stream.ReadIntArray();
            XOminoCells = xrc[0];
            Rows = xrc[1];
            Columns = xrc[2];
        }

        public int Columns { get; set; }

        public int Rows { get; set; }

        public int XOminoCells { get; set; }

        public string Solve()
        {
            var canFindUnfittableOmino = CanIFindUnfittableOmino();
            
            return canFindUnfittableOmino ? "RICHARD" : "GABRIEL";
        }

        private bool CanIFindUnfittableOmino()
        {
            if ((Columns*Rows)%XOminoCells != 0)
                return true;

            switch (XOminoCells)
            {
                case 1:
                    return false;
                case 2:
                    return Columns%2 == 1 && Rows%2 == 1;
                case 3:
                    return (Columns == 1 || Rows == 1);
                case 4:
                    return CanFindUnfittable4Omino();
                case 5:
                    return CanFindUnfittable5Omino();
                case 6:
                    return CanFindUnfittable6Omino();
                default:
                    return true;
            }
        }

        private bool CanFindUnfittable6Omino()
        {
            if (Columns <= 3 || Rows <= 3)
            {
                return true;
            }

            return false;
        }

        private bool CanFindUnfittable5Omino()
        {
            if (Columns * Rows <= 15)
            {
                return true;
            }
            if (Columns <= 2 || Rows <= 2)
            {
                return true;
            }
            return false;
        }

        private bool CanFindUnfittable4Omino()
        {
            // Cannot fit every 4omino in 2xN for any N - in partiuclar the T 4omino
            // Can fit any 4onmino in 3x4
            // 4x4 obviously works therefore.
            // 3x4n n>=1 therefore is fine. 
            if (Columns + Rows < 7)
            {
                return true;
            }
            if (Columns <= 2 || Rows <= 2)
            {
                return true;
            }

            return false;
        }
    }
}
