﻿using GoogleCodeJam.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MagicTrick
{
	class Program
	{
		static void Main(string[] args)
		{
			InputFile input = new InputFile("input.txt");
			OutputFile output = new OutputFile("output.txt");

			int[] values = input.ReadIntArray();
			int TEST_COUNT = values[0];

			for (int i = 0; i < TEST_COUNT; i++)
			{
				CardGame game = new CardGame(input);
				output.WriteCase(i + 1, game.CalculateResult());
			}

			output.Close();
		}
	}
}
