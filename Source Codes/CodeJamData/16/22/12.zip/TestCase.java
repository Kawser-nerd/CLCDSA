package template;

//standard libraries potentially used:
//Apache commons http://http://commons.apache.org/
//Google Guava http://code.google.com/p/guava-libraries/
import java.util.Arrays;
import java.util.Scanner;
import java.util.concurrent.Callable;

public class TestCase implements Callable {

    int caseRef;
    Object result;

    String C;
    String J;
    int[] list;
    int len;
    int[][] grid;

    public void prepare(Scanner scanner) {
        C = scanner.next();
        J = scanner.next();
        len = C.length();

//        list = new int[N];
//        for (int i = 0; i < N; i++) {
//            list[i] = scanner.nextInt();
//        }
//        grid = new int[N][N];
//        for (int r = 0; r < N; r++) {
//            for (int c = 0; c < N; c++) {
//                grid[r][c] = scanner.nextInt();
//            }
//        }
    }

    private Object solve() {

        String[] Cs = new String[len + 1];
        String[] Js = new String[len + 1];

        String Cend = C.substring(len - 1);
        String Jend = J.substring(len - 1);

        if (Cend.equals("?") && Jend.equals("?")) {
            Cs[1] = "0";
            Js[1] = "0";
        }
        if (Cend.equals("?") && !Jend.equals("?")) {
            Cs[1] = Jend;
            Js[1] = Jend;
        }
        if (!Cend.equals("?") && Jend.equals("?")) {
            Cs[1] = Cend;
            Js[1] = Cend;
        }
        if (!Cend.equals("?") && !Jend.equals("?")) {
            Cs[1] = Cend;
            Js[1] = Jend;
        }

        for (int l = 2; l <= len; l++) {
            if (C.charAt(len - l) == '?' && J.charAt(len - l) == '?') {
                String c1 = "0" + Cs[l - 1];
                String j1 = "0" + Js[l - 1];
                long diff1 = Math.abs(Long.valueOf(c1) - Long.valueOf(j1));

                String bestc = c1;
                String bestj = j1;

                String c2 = "0" + maxTail(C, l - 1);
                String j2 = "1" + minTail(J, l - 1);
                long diff2 = Math.abs(Long.valueOf(c2) - Long.valueOf(j2));
                if (diff2 < diff1) {
                    bestc = c2;
                    bestj = j2;
                }

                String c3 = "1" + minTail(C, l - 1);
                String j3 = "0" + maxTail(J, l - 1);
                long diff3 = Math.abs(Long.valueOf(c3) - Long.valueOf(j3));
                if (diff3 < diff1 && diff3 < diff2) {
                    bestc = c3;
                    bestj = j3;
                }

                Cs[l] = bestc;
                Js[l] = bestj;

            }

            if (C.charAt(len - l) != '?' && J.charAt(len - l) == '?') {

                int known = Integer.valueOf(C.substring(len - l, len - l + 1));
                String bestc = "";
                String bestj = "";
                long diff1 = Long.MAX_VALUE;
                if (known > 0) {
                    String c1 = known + minTail(C, l - 1);
                    String j1 = (known - 1) + maxTail(J, l - 1);
                    diff1 = Math.abs(Long.valueOf(c1) - Long.valueOf(j1));
                    bestc = c1;
                    bestj = j1;
                }

                String c2 = known + Cs[l - 1];
                String j2 = known + Js[l - 1];
                long diff2 = Math.abs(Long.valueOf(c2) - Long.valueOf(j2));
                if (diff2 < diff1) {
                    bestc = c2;
                    bestj = j2;
                }

                if (known < 9) {
                    String c3 = known + maxTail(C, l - 1);
                    String j3 = (known + 1) + minTail(J, l - 1);
                    long diff3 = Math.abs(Long.valueOf(c3) - Long.valueOf(j3));
                    if (diff3 < diff1 && diff3 < diff2) {
                        bestc = c3;
                        bestj = j3;
                    }
                }

                Cs[l] = bestc;
                Js[l] = bestj;

            }

            
            if (C.charAt(len - l) == '?' && J.charAt(len - l) != '?') {

                int known = Integer.valueOf(J.substring(len - l, len - l + 1));
                String bestc = "";
                String bestj = "";
                long diff1 = Long.MAX_VALUE;
                if (known > 0) {
                    String c1 = (known - 1) + maxTail(C, l - 1);
                    String j1 = known + minTail(J, l - 1);
                    diff1 = Math.abs(Long.valueOf(c1) - Long.valueOf(j1));
                    bestc = c1;
                    bestj = j1;
                }

                String c2 = known + Cs[l - 1];
                String j2 = known + Js[l - 1];
                long diff2 = Math.abs(Long.valueOf(c2) - Long.valueOf(j2));
                if (diff2 < diff1) {
                    bestc = c2;
                    bestj = j2;
                }

                if (known < 9) {
                    String c3 = (known + 1) + minTail(C, l - 1);
                    String j3 = known + maxTail(J, l - 1);
                    long diff3 = Math.abs(Long.valueOf(c3) - Long.valueOf(j3));
                    if (diff3 < diff1 && diff3 < diff2) {
                        bestc = c3;
                        bestj = j3;
                    }
                }

                Cs[l] = bestc;
                Js[l] = bestj;

            }            
            
            if (C.charAt(len - l) != '?' && J.charAt(len - l) != '?') {

                int knownc = Integer.valueOf(C.substring(len - l, len - l + 1));
                int knownj = Integer.valueOf(J.substring(len - l, len - l + 1));
                
                if (knownc == knownj) {
                    Cs[l] = knownc + Cs[l - 1];
                    Js[l] = knownj + Js[l - 1];
                }

                if (knownc < knownj) {
                    Cs[l] = knownc + maxTail(C, l - 1);
                    Js[l] = knownj + minTail(J, l - 1);
                }

                if (knownc > knownj) {
                    Cs[l] = knownc + minTail(C, l - 1);
                    Js[l] = knownj + maxTail(J, l - 1);
                }

            }            
        }
        
        //System.out.println(Arrays.toString(Cs));
        //System.out.println(Arrays.toString(Js));

        return Cs[len] + " " + Js[len];
    }

    String maxTail(String in, int length) {
        String out = "";
        for (int i = len - length; i <= len - 1; i++) {
            if (in.charAt(i) == '?')
                out += "9";
            else
                out += in.charAt(i);
        }
        return out;
    }

    String minTail(String in, int length) {
        String out = "";
        for (int i = len - length; i <= len - 1; i++) {
            if (in.charAt(i) == '?')
                out += "0";
            else
                out += in.charAt(i);
        }
        return out;
    }

    /////////////////////////////////////////////////////////////////////
    public static void main(String[] args) {
        Utils.go(1);
    }

    @Override
    public Object call() throws Exception {
        return run();
    }

    public Object run() {
        System.out.println("Starting case " + this.getRef());
        Object solution = solve();
        assert solution != null : "Null result for testcase " + this.getRef();
        setResult(solution);
        System.out.println("Finished case " + this.getRef() + ", result: " + solution);
        return solution;
    }

    public int getRef() {
        return caseRef;
    }

    public void setRef(int ref) {
        this.caseRef = ref;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }

}
