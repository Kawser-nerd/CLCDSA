﻿/*
 * This file is made by Feng JIAO(Email: joephone1983@gmail.com) for solving Code Jam contest problems.
 * This file is licensed under The GNU General Public License (GPLv3). For more information, google "GPLv3"
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace Library
{
    public static class Config
    {
        public static int _StackSize = int.MaxValue / 16; //128MB
        public static ThreadPriority _ThreadPriority = ThreadPriority.AboveNormal;
        public static InputFileSize _FileSize = InputFileSize.SmallFile;
        public static Stopwatch stopWatch = new Stopwatch();
        public static int _ParallelThreadCount
        {
            get
            {
                return Parallel.ThreadsCount;
            }
            set
            {
                Parallel.ThreadsCount = value;
            }
        }
    }

    public enum InputFileSize
    {
        NoInput,
        TinyInput,
        LargeFile,
        SmallFile
    }
}
