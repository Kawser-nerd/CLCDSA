namespace CodeJamLibrary.Interfaces
{
  public interface IProblemTypeProvider
  {
    ProblemType GetProblemType();
  }
}