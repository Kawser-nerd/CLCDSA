﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aliens
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine().Trim());
            for (int i = 0; i < n; i++)
            {
                string input = Console.ReadLine().Trim();
                long output = Get(input);
                Console.WriteLine("Case #" + (i + 1).ToString() + ": " + output.ToString());
            }
        }

        private static long Get(string text)
        {
            long output = 0L;
            char[] chars = text.ToCharArray();

            IDictionary<char, int> map = new Dictionary<char, int>();
            int count = 0;
            for (int i = 0; i < chars.Length; i++)
            {
                if (!map.ContainsKey(chars[i]))
                {
                    if (count == 0)
                    {
                        map.Add(chars[i], 1);
                    }
                    else if (count == 1)
                    {
                        map.Add(chars[i], 0);
                    }
                    else
                    {
                        map.Add(chars[i], count);
                    }
                    count++;
                }
            }
            if (count == 1)
            {
                count++;
            }
            for (int i = 0; i < chars.Length; i++)
            {
                output = (output * count) + map[chars[i]];
            }
            return output;
        }
    }
}
