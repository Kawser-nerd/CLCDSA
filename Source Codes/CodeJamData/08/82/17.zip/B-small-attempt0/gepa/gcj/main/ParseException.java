/**
 * 
 */
package gepa.gcj.main;

/**
 * @author gepa
 *
 */
public class ParseException extends Exception {

    private static final long serialVersionUID = 547637520432727647L;

    public ParseException(String msg) {
        super(msg);
    }
    public ParseException(String msg, Throwable cause) {
        super(msg, cause);
    }
}
