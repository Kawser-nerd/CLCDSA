package lib;

import java.util.function.BiConsumer;
import java.util.function.Supplier;
import java.util.stream.Collector;

public class Accumulator {

    private static final Collector.Characteristics[] CHARS_FOR_PARALLEL = {Collector.Characteristics.CONCURRENT, Collector.Characteristics.UNORDERED};

    // R 을 이용해 T 를 완성한다.
    public static <T, R> Collector<T, R, R> of(final Supplier<R> supplier, final BiConsumer<R, T> accumulator, boolean parallelAccumulation) {
        return Collector.of(supplier, accumulator, (v1, v2) -> {
            throw new RuntimeException("패러럴 스트림은 accumulator 가 병렬을 지원하게 해라. reduce 정의가 없기 때문에 그렇지 않으면 parallel 의 의미가 없다.");
        }, parallelAccumulation ? CHARS_FOR_PARALLEL : new Collector.Characteristics[]{});
    }

}
