package lib;

import java.util.stream.DoubleStream;

public class DoubleArrayFromInput {
    public static double[] next(Input in, int length) {
        return DoubleStream.generate(in::nextDouble).limit(length).toArray();
    }
}
