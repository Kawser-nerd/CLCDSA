﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using Generic.InputOutput.Printing;

namespace Google_Code_Jam.Problems.Hills
{
    class Hill : Algorithm<Problem,IList<double>>
    {
        public override Problem Parse(StreamReader reader)
        {
            var dna = JamUtil.ReadWords(reader);
            var distance = double.Parse(dna[0],CultureInfo.InvariantCulture);
            var n = int.Parse(dna[1]);
            var a = int.Parse(dna[2]);
            var blockers = new List<BlockerMoment>();
            for(int i = 0;i<n;i++)
            {
                var values = JamUtil.ReadDoubles(reader);
                blockers.Add(new BlockerMoment(values[1], values[0]));
            }
            var accelerations = JamUtil.ReadDoubles(reader);
            return new Problem(blockers, accelerations,distance);
        }

        public override IList<double> Solve(Problem problem)
        {
            if (problem.BlockerMoments.Count == 1)
            {
                if (problem.BlockerMoments[0].Time != 0)
                    throw new InvalidOperationException();
                problem.BlockerMoments[0] = new BlockerMoment(problem.Distance, 0);
            }
            else
            {
                var lastIndex = problem.BlockerMoments.Count - 1;
                var lastBlock = problem.BlockerMoments[lastIndex];
                var secondLastBlock = problem.BlockerMoments[lastIndex-1];
                var finalVelocity = (lastBlock.Position - secondLastBlock.Position) / (lastBlock.Time - secondLastBlock.Time);
                var timeBlockReachesEnd = (problem.Distance - secondLastBlock.Position) / finalVelocity + secondLastBlock.Time;
                problem.BlockerMoments[lastIndex] = new BlockerMoment(problem.Distance, timeBlockReachesEnd);
            }
            return problem.Accelerations.Select(accel => SolveForAcceleration(problem, accel)).ToList();
        }

        static double SolveForAcceleration(Problem problem, double accel)
        {
            var startTime = 0.0;
            var distance = problem.Distance;
            var timeTillEnd = GetTimeRequired(accel, distance);
            foreach (var blocker in problem.BlockerMoments)
            {
                var timeTillHit = GetTimeRequired(accel, blocker.Position);
                // startTime + timeTillHit >= blocker.Time
                //startTime >= blocker.Time - timeTillHit
                startTime = Math.Max(startTime, blocker.Time - timeTillHit);
            }
            return startTime + timeTillEnd;
        }

        static double GetTimeRequired(double accel, double distance)
        {
            return Math.Sqrt(2*distance/accel);
        }

        public override string Print(IList<double> solution)
        {
            return Environment.NewLine + solution.Select(d => d.ToString(CultureInfo.InvariantCulture).Print()).VerticalConcat().ToString();
        }
    }
}
