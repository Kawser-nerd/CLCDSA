package lib;

import java.util.function.Supplier;

public class Assertion {

    static final Supplier<RuntimeException> FAIL = RuntimeException::new;

    public static void check(boolean c) {
        check(c, "");
    }

    public static void check(boolean c, String msg) {
        if (!c)
            throw new RuntimeException(msg);
    }

}
