using System.IO;
using CodeJamLibrary.Interfaces;

namespace CodeJamLibrary.Providers
{
  public class FileStream_TextWriterProvider : ITextWriterProvider
  {
    private readonly IFilePathProvider filePathProvider;
    private StreamWriter streamWriter;

    public FileStream_TextWriterProvider(IFilePathProvider filePathProvider)
    {
      this.filePathProvider = filePathProvider;
    }

    public TextWriter GetWriter()
    {
      return streamWriter;
    }

    public void Open()
    {
      streamWriter = new StreamWriter(filePathProvider.GetFilePath());
    }

    public void Close()
    {
      streamWriter.Close();
    }
  }
}