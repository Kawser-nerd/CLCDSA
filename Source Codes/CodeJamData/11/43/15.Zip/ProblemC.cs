﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace CodeJam2011.Problems
{
    public class ProblemC : ProblemBase
    {
        protected override string SolveOneCase(InputHelper input)
        {
            int N = input.GetInt();

            if (N == 1)
                return "0";
            GeneratePrimes(N);

            int best = 1;
            SortedDictionary<int, int> dict = new SortedDictionary<int, int>();
            for (int i = 2; i <= N; i++)
            {
                var facts = PrimeFactors(i);

                bool needed = false;
                foreach (var prime in facts.Keys)
                {
                    if (!dict.ContainsKey(prime))
                        dict.Add(prime, 0);

                    if( dict[prime] < facts[prime])
                    {
                        dict[prime] = facts[prime];
                        needed = true;
                    }
                }

                if( needed)
                    best++;
            }

            int least = 0;
            

            while( dict.Count != 0)
            {
                if( dict.Count == 1)
                {
                    least++;
                    break;
                }

                var list = new List<int>(dict.Keys);

                int first = pow(list[0], dict[list[0]]);

                for (int i = list.Count-1; i >0; i--)
                {
                    var second = pow(list[i], dict[list[i]]);

                    if( first* second <= N)
                    {
                        dict.Remove(list[i]);
                        break;
                    }

                }

                dict.Remove(list[0]);
                least++;
            }






            return (best-least).ToString();
        }

        private int pow(int n, int m)
        {
            int res = 1;
            for (int i = 0; i < m; i++)
            {
                res *= n;
            }
            return res;
        }


        private List<int> primes;

        public void GeneratePrimes(int N)
        {
            BitArray bits = new BitArray(N + 1, true);

            bits[0] = bits[1] = false;

            for (int i = 2; i <= N; i++)
                if (bits[i])
                    for (int j = 2; j * i <= N; j++)
                        bits[j * i] = false;

            primes = new List<int>();
            for (int i = 0; i <= N; i++)
                if (bits[i])
                    primes.Add(i);
        }

        public Dictionary<int, int> PrimeFactors(int N)
        {
            if (N < 2)
                throw new ArgumentException("Cannot find prime factors of N less than 2");

            Dictionary<int, int> primeFactors = new Dictionary<int, int>();

            for (int i = 0; primes[i] <= Math.Sqrt(N); i++)
            {
                int p = primes[i];
                if (N % p == 0)
                {
                    if( !primeFactors.ContainsKey(p))
                        primeFactors.Add(p, 0);

                    primeFactors[p] ++;
                    N = N / p;
                    i--;
                }
            }


                                if( !primeFactors.ContainsKey(N))
                        primeFactors.Add(N, 0);

                    primeFactors[N] ++;

            return primeFactors;
        }
    }
}