package problems;

import main.IOManager;
import main.Problem;

public class ManageYourEnergy extends Problem {

	public ManageYourEnergy(IOManager io) {
		super(io);
	}

	long e, r, n;
	long[] v;
	
	@Override
	protected String solveCase() {
		long[] line = io.readLongs();
		e = line[0];
		r = line[1];
		n = line[2];
		v = io.readLongs();
		return String.valueOf(solvePart(0, n, e, 0));
	}
	
	private long solvePart(long a, long b, long start, long end){
		
		if (a==b){
			
			if (start != end && a!=n)
				System.out.println("FEHLER");
			return 0;
				
		}
		long max = -1;
		long maxV = -1;
		for (int i = (int)a; i < b; ++i){
			if (v[i] > maxV){
				max = i;
				maxV = v[i];
			}
		}
		long eAtMax = Math.min(start+(max-a)*r,e);
		long eAfterMax = Math.max(0, end-(b-max)*r);
		long gain = (eAtMax -eAfterMax)*maxV; 
		
		
		
		return solvePart(a, max, start, eAtMax)+gain+solvePart(max+1, b, Math.min(eAfterMax+r, e), end);
	}

}
