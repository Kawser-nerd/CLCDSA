package lib;

import java.util.function.ToIntFunction;

public class MapFactoryUsing3DArray {

    public static <K> MapFactory<K> of(
            final int size1, final int size2, final int size3,
            final ToIntFunction<K> index1Getter, final ToIntFunction<K> index2Getter, final ToIntFunction<K> index3Getter) {
        return MapFactoryUsing2DArray.of(size1, size2 * size3, index1Getter, value -> {
            int i2 = index2Getter.applyAsInt(value);
            int i3 = index3Getter.applyAsInt(value);
            return i2 * size3 + i3;
        });
    }

}
