package lib;

import java.util.function.BinaryOperator;

public class LongModular {
    public static final BinaryOperator<Long> INSTANCE = (v1, v2) -> v1 % v2;
}
