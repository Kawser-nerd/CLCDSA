Compiled using C# 2.0
Operating System : Windows

To run the program, run the following command

Center.exe < inputFileName > outputFileName

Thanks