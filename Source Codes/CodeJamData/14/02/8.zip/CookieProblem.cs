﻿using GoogleCodeJam.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CookieCutter
{
	class CookieProblem
	{
		private readonly double FARM_COST;
		private readonly double CPS_PER_FARM;
		private readonly double TARGET_COOKIES;
		private const double CPS_BASE = 2.0;

		public CookieProblem(InputFile input)
		{
			double[] parameters = input.ReadDoubleArray();
			FARM_COST = parameters[0];
			CPS_PER_FARM = parameters[1];
			TARGET_COOKIES = parameters[2];
		}

		public double GetMinimumTime()
		{
			double cookiesSoFar = 0;
			double elapsedTime = 0;
			double cookiesPerSecond = CPS_BASE;

			while (true)
			{
				// Time before we reach the target, at current speed.
				double timeToFinish = (TARGET_COOKIES - cookiesSoFar) / cookiesPerSecond;

				// Time we must wait to buy a new farm.
				double timeToBuyNextFarm = FARM_COST / cookiesPerSecond;

				if (timeToFinish < timeToBuyNextFarm)
					return elapsedTime + timeToFinish; // We will finish even before having the chance to buy a new farm.

				// We have a chance to buy a new farm. Should we?
				double elapsedTimeWhenBuying = elapsedTime + timeToBuyNextFarm;
				double cookiesWhenBuying = cookiesSoFar + (cookiesPerSecond * timeToBuyNextFarm) - FARM_COST;
				double cookiesPerSecondWhenBuying = cookiesPerSecond + CPS_PER_FARM;

				// Simply consider that this is the only farm we would buy. Adding more later cannot hurt.
				double timeToFinishWhenBuying = timeToBuyNextFarm + (TARGET_COOKIES - cookiesWhenBuying) / cookiesPerSecondWhenBuying;
				
				if (timeToFinish > timeToFinishWhenBuying)
				{
					// Buy a new farm!
					elapsedTime = elapsedTimeWhenBuying;
					cookiesSoFar = cookiesWhenBuying;
					cookiesPerSecond = cookiesPerSecondWhenBuying;
				}
				else
				{
					// Don't buy, continue as before.
					return elapsedTime + timeToFinish;
				}
			}
		}
	}
}
