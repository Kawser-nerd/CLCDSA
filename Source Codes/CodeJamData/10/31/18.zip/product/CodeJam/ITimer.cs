namespace CodeJam
{
  public interface ITimer
  {
    void Start();
    void Stop();
    void WriteToFile();
  }
}