#file('C-large-practice.in').read()
#
def processAllInput(text, toFile = False):
    fileName = text
    if toFile:
        text = file(fileName).read()
    finalResult = []
    numTests = int(text.split('\n')[0])
    lines = text.split('\n')
    for i in range(numTests):
        #Problem-specific code starts here############
        
        message = lines[3*i+1:3*(i+1)+1]
        (N, L) = map(int,message[0].split(' '))
        outlets = [map(int, x) for x in message[1].split(' ')]
        devices = [map(int, x) for x in message[2].split(' ')]
        device1s = [0] * L
        outlet1s = [0] * L
        for d in devices:
            for x in range(len(d)):
                if d[x] == 1:
                    device1s[x] += 1
        for d in outlets:
            for x in range(len(d)):
                if d[x] == 1:
                    outlet1s[x] += 1
 #       print outlets, devices
#        print outlet1s, device1s
        
        maybeworks = True
        mustBeFlipped = []
        canBeFlipped = []
        for x in range(L):
            if (device1s[x] == outlet1s[x] or
                device1s[x] == N-outlet1s[x]):
                if device1s[x] == N/2.0:
                    canBeFlipped.append(x)
                elif device1s[x] == N-outlet1s[x]:
                    mustBeFlipped.append(x)
            else:
                maybeworks = False
#        print 'Maybeworks:',maybeworks, mustBeFlipped, canBeFlipped

        def partialWorks(p):
            assigned = [i for i in range(L) if p[i] is not None]
            #print 'a',assigned
            oMap = dict()
            for o in outlets:
                outlet = tuple()
                for i in range(len(o)):
                    if i not in assigned:
                        continue
                    outlet += (o[i] ^ p[i],)
                if outlet not in oMap:
                    oMap[outlet] = 0
                oMap[outlet] += 1
            dMap = dict()
            for o in devices:
                outlet = tuple()
                for i in range(len(o)):
                    if i not in assigned:
                        continue
                    outlet += (o[i],)
                if outlet not in dMap:
                    dMap[outlet] = 0
                dMap[outlet] += 1
            for x in dMap:
                if x not in oMap:
                    return False
                if dMap[x] != oMap[x]:
                    return False
            return True
        #print ('p',partialWorks([0,None,0]))

        def recurse(partial):
            if None not in partial:
                if partialWorks(partial):
                    return partial, sum(partial)
                else:
                    return None, 9989999999999
            nextUnset = partial.index(None)
            new0 = partial[:]
            new0[nextUnset] = 0
            len0 = 999999999
            result0 = None
            if partialWorks(new0):
                result0, len0 = recurse(new0)
            new1 = partial[:]
            new1[nextUnset] = 1
            len1 = 999999999
            result1 = None
            if partialWorks(new1):
                result1, len1 = recurse(new1)
            if not result0 and not result1:
                return None, 99999999
            if len0 < len1:
                return result0, len0
            else:
                return result1, len1

        partial = [0] * L
        for x in mustBeFlipped:
            partial[x] = 1
        for x in canBeFlipped:
            partial[x] = None

#        print ('final', recurse(partial))
        solution = None
        if maybeworks:
            solution, _ = recurse(partial)
        else:
            solution = None
        soltext = 'NOT POSSIBLE'
        if solution:
            assert partialWorks(solution)
            soltext = str(sum(solution))
        line = 'Case #{0}: {1}'.format(i+1, soltext)
        print line
        #Problem-specific code ends here##############
        if not toFile:
            print line
        finalResult.append(line)
    if toFile:
        file(fileName.split('.')[0]+'.out', 'w').write('\n'.join(finalResult))
