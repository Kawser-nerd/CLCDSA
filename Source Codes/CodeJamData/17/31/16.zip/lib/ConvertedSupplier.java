package lib;

import java.util.function.Function;
import java.util.function.Supplier;

class ConvertedSupplier {

    static <T> Supplier<T> of(Supplier<String> supplier, Function<String, T> converter) {
        return () -> converter.apply(supplier.get());
    }
}
