package pl.javahussars.Infinite_House_of_Pancakes;

import java.math.BigInteger;
import java.util.regex.Pattern;

public class IntTools {

	public static final Pattern SPACE_PATTERN = Pattern.compile(" ");

	public static int[] reverse(int[] tab) {
		if (tab == null || tab.length == 0 || tab.length == 1) {
			return tab;
		}

		for (int i = tab.length / 2; i < tab.length; i++) {
			int j = tab.length - 1 - i;
			int el = tab[i];
			tab[i] = tab[j];
			tab[j] = el;
		}

		return tab;
	}

	public static int[] toInts(String line) {
		String[] tab = SPACE_PATTERN.split(line);
		int[] res = new int[tab.length];

		for (int i = 0; i < tab.length; i++) {
			res[i] = Integer.parseInt(tab[i]);
		}

		return res;
	}

	public static long[] toLongs(String line) {
		String[] tab = SPACE_PATTERN.split(line);
		long[] res = new long[tab.length];

		for (int i = 0; i < tab.length; i++) {
			res[i] = Integer.parseInt(tab[i]);
		}

		return res;
	}

	/**
	 * @return from * (from+1) * (from+2) * ... * (to-1) * (to)
	 */
	public static BigInteger factor(int from, int to) {
		BigInteger factor = new BigInteger("" + from);
		for (int i = from + 1; i <= to; i++) {
			factor = factor.multiply(new BigInteger("" + i));
		}

		return factor;
	}

	public static BigInteger n_po_k(int n, int k) {
		if (k == 0 || k == n) {
			return BigInteger.ONE;
		}

		int min = Math.min(n - k, k);
		int max = n - min;

		BigInteger first = factor(max + 1, n);
		BigInteger second = factor(1, min);

		return first.divide(second);
	}
}
