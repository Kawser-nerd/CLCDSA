package lib;

public class Double2DArrayFromInput {

    public static double[][] next(Input in, int length1, int length2) {
        return ArrayConstructor.create(length1, double[].class, () -> DoubleArrayFromInput.next(in, length2));
    }
}
