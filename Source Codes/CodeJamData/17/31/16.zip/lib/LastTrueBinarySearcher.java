package lib;

import java.util.Optional;
import java.util.function.Predicate;

public class LastTrueBinarySearcher {

    public static <T> Optional<T> find(T start, T end, FloorDivisibleSystem<T> ns, Predicate<T> predicate) {
        return LastFalseBinarySearcher.find(start, end, ns, predicate.negate());
    }

}
