import time, math, operator
from helper import *

t1 = starttimer()

filename = "A%s.%s"
# 0 for test, 1 for small, 2 for large
is_large = 1

mode_str = '' if is_large == 0 else '-small-attempt0' if is_large == 1 else '-large'
infile = filename % (mode_str, 'in')
outfile = filename % (mode_str, 'out')

# parse input
inf = open(infile, 'r')
outf = open(outfile, 'w')

try:
    T = readI(inf)
    
    for case in range(1, T+1):
        X, S, R, t, N = readIA(inf)
        w = [readIA(inf) for _ in range(N)]

        w.sort()

        segments = []


        base_time = 0.0
        prev_pos = 0.0
        for i in range(N):
            segments.append((w[i][0] - prev_pos, S))
            segments.append((w[i][1] - w[i][0], w[i][2] + S))
            prev_pos = w[i][1]
            
        segments.append((X - prev_pos, S))

        segments.sort(key=operator.itemgetter(1))
        output = 0.0
        for i in range(len(segments)):
            s = segments[i]
            if t > 0:
                time_used = float(s[0]) / float(s[1] + R - S)
                
                if t >= time_used:
                    output += time_used
                    t -= time_used
                else:
                    d_travelled = float(s[1] + R - S) * t
                    d_left = s[0] - d_travelled
                    output += t + d_left / float(s[1])
                    t = 0
            else:
                output += float(s[0]) / s[1]
        
        print output
        outf.write("Case #%d: %.7f\n" % (case, output))
    
finally:
    inf.close()
    outf.close()

endtimer(t1)
