package lib;

import java.util.HashSet;

public class HashSetFactory {
    public static <T> SetFactory<T> create() {
        return HashSet::new;
    }
}
