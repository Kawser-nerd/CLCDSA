package lib;

import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

public class TreeMapFactory {
    public static <T> MapFactory<T> create(final Comparator<T> keyComparator) {
        return new MapFactory<T>() {
            @Override
            public <V> Map<T, V> create() {
                return new TreeMap<>(keyComparator);
            }
        };
    }
}
