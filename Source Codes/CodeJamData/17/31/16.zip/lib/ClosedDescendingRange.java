package lib;

import java.util.stream.IntStream;

public class ClosedDescendingRange {
    public static IntStream of(int biggest, int smallest) {
        return IntStream.iterate(biggest, i -> i - 1).limit(biggest - smallest + 1);
    }
}
