﻿using System.Collections.Generic;
using Gcj.Util;

namespace Gcj.Y2013.R1A.B
{
    internal class BSolver : GcjSolver
    {
        protected override IEnumerable<object> EnobjSolveCase()
        {
            yield break;
        }

    }
}
