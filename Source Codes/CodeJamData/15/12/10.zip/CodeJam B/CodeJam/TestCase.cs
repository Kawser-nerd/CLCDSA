/* www.codertom.com  -  copyright Tom Harrison 2015 */

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography.X509Certificates;

namespace CoderTom.CodeJam
{
    public class TestCase
    {
        public TestCase()
        {
        }

        public TestCase(StreamReader stream)
        {
            var bn = stream.ReadIntArray();

            Count = bn[0];
            Position = bn[1];
            Barbers = stream.ReadIntArray();
        }

        public int[] Barbers { get; set; }

        public long Position { get; set; }

        public int Count { get; set; }

        public long inTimeXServed(long time)
        {
            return Barbers.Select(x => 1 + (time/x)).Sum();
        }

        public string Solve()
        {
            if (Position <= Count)
                return Position.ToString();

            var maxEstimate = Barbers.Min()*(long)Position;

            var minEstimate = 0;

            var lastMin = GetEstimate(minEstimate, maxEstimate);

            var served = inTimeXServed(lastMin);

            var BarberState = Barbers.Select((x, i) => new Barber{pos = i + 1, duration = x, state = x - (lastMin%x)}).OrderBy(x => x.pos).ToList();

            var bIndex = 0;
            while (served < Position)
            {
                var mins = BarberState.Min(x => x.state);
                var nextBarber = BarberState.First(x => x.state == mins);
                nextBarber.state += nextBarber.duration;
                bIndex = nextBarber.pos;

                served++;
            }

            return bIndex.ToString();
        }

        private long GetEstimate(long minEstimate, long maxEstimate)
        {
            while (minEstimate < maxEstimate )
            {
                var test = (maxEstimate + minEstimate)/2;

                var served = inTimeXServed(test);
                if (served < Position)
                {
                    minEstimate = test + 1;
                }
                else
                {
                    maxEstimate = test - 1;
                }
            }
            return minEstimate -1;
        }
    }

    public class Barber
    {
        public int pos { get; set; }
        public int duration { get; set; }
        public long state { get; set; }
    }
}