/**
 * 
 */
package gepa.gcj.main.result;

import gepa.gcj.main.ParseException;
import gepa.gcj.main.Result;

/**
 * @author gepa
 *
 */
public abstract class SingleLineResult extends Result {

    @Override
    public boolean isSingleLine() {
        return true;
    }
    @Override
    public final void parse(String[] data) throws ParseException {
        if (data.length != 1) {
            throw new IllegalArgumentException("data must contain exactly one element (contained " + data.length + ")");
        }
        parseSingle(data[0]);
    }
    @Override
    public final String[] getAsStringArray() {
        return new String[]{ getAsString() };
    }

    public abstract void parseSingle(String data) throws ParseException;
    public abstract String getAsString();
}
