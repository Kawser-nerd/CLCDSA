package codejam.r1c;

import codejam.ProblemSolver;
import java.io.BufferedReader;
import java.io.IOException;

public class A implements ProblemSolver {

    @Override
    public String solve(BufferedReader in, int testNum) throws IOException {
        String[] parts = in.readLine().split(" ");
        int r = Integer.parseInt(parts[0]);
        int c = Integer.parseInt(parts[1]);
        int w = Integer.parseInt(parts[2]);
        int testsPerRow = c / w;
        int tests = r * testsPerRow + w;
        if((c % w) == 0) {
            tests--;
        }
        return tests + "";
    }
}
