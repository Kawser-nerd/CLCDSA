package lib;

import java.util.Optional;
import java.util.function.Predicate;

public class LastFalseBinarySearcher {

    public static <T> Optional<T> find(T start, T end, FloorDivisibleSystem<T> ns, Predicate<T> predicate) {
        T two = ns.add(ns.one(), ns.one());
        while (ns.compare(ns.subtract(end, start), ns.one()) > 0) {
            T mid = ns.floorDivide(ns.add(start, end), two);
            if (predicate.test(mid))
                end = mid;
            else
                start = mid;
        }
        return !predicate.test(start) ? Optional.of(start) : Optional.empty();
    }

}
