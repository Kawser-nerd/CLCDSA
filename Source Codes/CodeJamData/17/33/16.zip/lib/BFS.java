package lib;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Set;
import java.util.function.BooleanSupplier;

public class BFS {

    public static void traverse(int start, AdjacentListGetter adj, WalkDown walkDown, BooleanSupplier stopper, MapFactory<Integer> mf) {
        Set<Integer> visited = SetFromMapFactory.create(mf);
        Deque<Integer> q = new ArrayDeque<>();
        q.add(start);
        visited.add(start);
        while (!q.isEmpty() && !stopper.getAsBoolean()) {
            int cv = q.pop();
            adj.forEach(cv, nv -> {
                if (!visited.contains(nv) && !stopper.getAsBoolean()) {
                    visited.add(nv);
                    walkDown.on(cv, nv);
                    q.add(nv);
                }
            });
        }
    }

}
