import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Date: May 23, 2010
 * Time: 1:16:34 PM
 *
 * @author Timur Abishev (ttim@)
 */
public class    B extends Solution {
    private static final int INFI = Integer.MAX_VALUE / 3;

    @Override
    void runOneTest(Scanner input, PrintWriter output) {
        int p = input.nextInt();
        int n = 1 << p;
        int[] m = new int[n];
        for (int i = 0; i < n; i++) {
            m[i] = p-input.nextInt();
        }
        int[][] prices = new int[p][];
        int cur = n / 2;
        for (int i = 0; i < p; i++) {
            prices[i] = new int[cur];
            for (int j = 0; j < prices[i].length; j++) {
                prices[i][j] = input.nextInt();
            }
            cur /= 2;
        }

        int[][] d = new int[n][p + 1];
        cur = n;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m[i]; j++) d[i][j] = INFI;
            for (int j = m[i]; j <= p; j++) d[i][j] = 0;
        }

        for (int i = 0; i < p; i++) {
            cur /= 2;

            int[][] newD = new int[cur][p + 1];

            for (int j = 0; j < cur; j++) {
                // j*2 j*2+1
                for (int k = 0; k <= p; k++) {
                    // calc  newD[j][k]
                    newD[j][k] = INFI;
                    // if +
                    if (k != p) {
                        newD[j][k] = Math.min(newD[j][k], prices[i][j] + d[j * 2][k + 1] + d[j * 2 + 1][k + 1]);
                    }
                    // if -
                    newD[j][k] = Math.min(newD[j][k], d[j * 2][k] + d[j * 2 + 1][k]);
                }
            }

            d = newD;
        }

        output.println(d[0][0]);
    }

    public static void main(String[] args) {
        (new B()).run();
    }
}