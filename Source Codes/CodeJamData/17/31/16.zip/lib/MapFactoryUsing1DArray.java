package lib;

import java.util.Map;
import java.util.function.ToIntFunction;

public class MapFactoryUsing1DArray {

    public static <K> MapFactory<K> of(final int size, final ToIntFunction<K> indexGetter) {
        return new MapFactory<K>() {
            @Override
            public <V> Map<K, V> create() {
                Object[] a = new Object[size];
                return MapUsingGetterPutter.of(key -> (V) a[indexGetter.applyAsInt(key)], (key, value) -> {
                    int index = indexGetter.applyAsInt(key);
                    Object old = a[index];
                    a[index] = value;
                    return (V) old;
                });
            }
        };
    }

}
