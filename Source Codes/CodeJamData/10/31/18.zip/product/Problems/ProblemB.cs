﻿using Template;
using Template.Interfaces;

namespace Problems
{
  public class ProblemB : ProblemTemplate
  {
    public ProblemB(ICaseFormatter caseFormatter) : base(caseFormatter)
    {
    }

    protected override string SolveOneCase(IInput input)
    {
      var buff = input.ParseInt();

      return "";
    }
  }
}