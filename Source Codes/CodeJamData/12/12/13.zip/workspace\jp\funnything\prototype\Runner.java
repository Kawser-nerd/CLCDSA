package jp.funnything.prototype;

import java.io.File;
import java.io.IOException;

import jp.funnything.competition.util.CompetitionIO;
import jp.funnything.competition.util.Packer;

import org.apache.commons.io.FileUtils;

public class Runner {
    public static void main( final String[] args ) throws Exception {
        new Runner().run();
    }

    void pack() {
        try {
            final File dist = new File( "dist" );

            if ( dist.exists() ) {
                FileUtils.deleteQuietly( dist );
            }

            final File workspace = new File( dist , "workspace" );

            FileUtils.copyDirectory( new File( "src/main/java" ) , workspace );
            FileUtils.copyDirectory( new File( "../../../../CompetitionUtil/Lib/src/main/java" ) , workspace );

            Packer.pack( workspace , new File( dist , "sources.zip" ) );
        } catch ( final IOException e ) {
            throw new RuntimeException( e );
        }
    }

    void run() throws Exception {
        final CompetitionIO io = new CompetitionIO();

        final int t = io.readInt();

        for ( int index = 0 ; index < t ; index++ ) {
            final int n = io.readInt();
            final int[] a = new int[ n ];
            final int[] b = new int[ n ];
            for ( int i = 0 ; i < n ; i++ ) {
                final int[] values = io.readInts();
                a[ i ] = values[ 0 ];
                b[ i ] = values[ 1 ];
            }

            io.write( index + 1 , solve( n , a , b ) );
        }

        io.close();

        pack();
    }

    String solve( final int n , final int[] a , final int[] b ) {
        final int[] took = new int[ n ];

        int star = 0;

        for ( int step = 1 ; ; step++ ) {
            int iFor1 = -1;
            int cost2for1 = 0;
            int iFor2 = -1;

            for ( int i = 0 ; i < n ; i++ ) {
                if ( star >= b[ i ] && took[ i ] < 2 ) {
                    iFor2 = i;
                    break;
                }

                if ( star >= a[ i ] && took[ i ] < 1 ) {
                    if ( b[ i ] > cost2for1 ) {
                        iFor1 = i;
                        cost2for1 = b[ i ];
                    }
                }
            }

            if ( iFor2 != -1 ) {
                star += 2 - took[ iFor2 ];
                took[ iFor2 ] = 2;

                if ( star == n * 2 ) {
                    return Integer.toString( step );
                }
            } else if ( iFor1 != -1 ) {
                star++;
                took[ iFor1 ] = 1;
            } else {
                return "Too Bad";
            }
        }
    }
}
