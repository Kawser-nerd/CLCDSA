﻿using System;

namespace Generic.Containers.Maybes
{
    [Serializable]
    public class Just<A> : Maybe<A>
    {
        private readonly A data;

        public Just(A data)
        {
            this.data = data;
        }

        public override bool IsJust
        {
            get { return true; }
        }

        public override A FromJust
        {
            get { return data; }
        }

        public override R Eval<R>(Func<R> nothing, Func<A, R> just)
        {
            return just(data);
        }

        public override void Exec(Action<A> just, Action nothing)
        {
            just(data);
        }

        public override Maybe<R> Select<R>(Func<A, R> func)
        {
            return new Just<R>(func(data));
        }

        public override Maybe<A> Clone(Func<A, A> cloneElement)
        {
            return MaybeUtil.Just(cloneElement(data));
        }
    }
}