Compiled using C# 2.0
Operating System : Windows

To run the program, run the following command

Prisoner.exe < inputFileName > outputFileName

Thanks