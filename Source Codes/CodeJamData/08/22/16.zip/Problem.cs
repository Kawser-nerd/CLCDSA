using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;


public class Problem
{
    static public string InputName = "../../B-small-attempt0.in";

    public void Solve(TextReader rdr, TextWriter wr)
    {
        int probnum =int.Parse(rdr.ReadLine());
        for (int cs = 1; cs <= probnum; cs++)
        {
            string[] prts = rdr.ReadLine().Split(' ');
            int A = int.Parse(prts[0]);
            int B = int.Parse(prts[1]);
            int P = int.Parse(prts[2]);
            Dictionary<int, List<int>> factoredbypmore = new Dictionary<int, List<int>>();
            Dictionary<int, int> set = new Dictionary<int, int>();
            bool[] prime = new bool[B + 1];
            for (int i = 2; i <= B; i++)
                prime[i] = true;
            for (int i = 2; i <= B; i++)
            {
                if (prime[i])
                {
                    for (int a = 2; a <= B / i; a++)
                    {
                        prime[a * i] = false;
                    }
                }
            }
            for (int i = A; i <= B; i++)
            {
                List<int> f = new List<int>();                                
                for (int div = P; div <= i; div++)
                {
                    if (i % div == 0 && prime[div])
                    {

                        f.Add(div);                        
                    }
                }                
                factoredbypmore.Add(i,f);
                set.Add(i, i);
            }
            bool changed;
            do
            {
                changed = false;
                for(int x=A;x<=B;x++)
                    for (int y = x + 1; y <= B; y++)
                    {
                        if (set[x] == set[y])
                            continue;
                        List<int> xf = factoredbypmore[x];
                        List<int> yf = factoredbypmore[y];
                        foreach (int xfac in xf)
                        {
                            if (yf.Contains(xfac))
                            {
                                int sety=set[y];
                                for (int i = A; i <= B; i++)
                                {
                                    if (set[i] == sety)
                                        set[i] = set[x];
                                }                                
                                changed = true;
                                break;
                            }
                        }
                    }
            }
            while (changed == true);
            Dictionary<int, int> known = new Dictionary<int, int>();
            foreach (int i in set.Keys)
            {
                if (!known.ContainsKey(set[i]))
                    known.Add(set[i],0);
            }

            wr.WriteLine("Case #{0}: {1}", cs, known.Count);
        }
    }   

    public string Solve(string problem)
    {
        StringWriter wr = new StringWriter();
        StringReader rdr = new StringReader(problem);
        Solve(rdr, wr);
        return wr.ToString();
    }   
}


