import cPickle, copy, time

prod = cPickle.load(open("database", "r"))
occ = cPickle.load(open("occdata"))

R = 8000

print "Case #1:"
raw_input()
raw_input()
st = time.time()
for x in xrange(R):
    subs = map(int,raw_input().split())
    subs.sort()
    subs.reverse()
    t = copy.copy(prod[subs[0]])
    for k in subs[1:]:
        for s in t:
            t[s] *= prod[k].get(s,0)

    for s in t:
        t[s] *= occ[s]

    l = list(t.keys())
    l.sort(key=lambda x:t[x])
    print "".join(map(str,max(l , key=t.__getitem__)))