﻿/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    class C_incorrect : ParallelSolution
    {
        struct Rect { 
            public Rect(int[] coords) : this() { X1 = coords[0]; Y1 = coords[1]; X2 = coords[2]+1; Y2 = coords[3]+1; }
            public int X1 { get; set; } public int X2 { get; set; } public int Y1 { get; set; } public int Y2 { get; set; }
            public bool Touches(Rect other)
            {
                if (other.X2 + 1 < X1)
                    return false;
                if (other.Y2 + 1 < Y1)
                    return false;
                if (X2 + 1 < other.X1)
                    return false;
                if (Y2 + 1 < Y1)
                    return false;
                return true;
            }
        }

        struct State
        {
            public int rectId { get; set; }
            public int minX { get; set; }
            public int minY { get; set; }
        }

        override public Func<String> StartSolving()
        {
            int R = ReadInt();

            Rect[] rects = Array.ConvertAll(ReadLines(R), line => new Rect(Array.ConvertAll(line.Trim().Split(' '), int.Parse)));

            return () =>
            {
                return Enumerable.Range(0, rects.Length).Max(i =>
                    {
                        Rect r = rects[i];

                        Dictionary<int, int> leftEntry = new Dictionary<int, int>();
                        Dictionary<int, int> topEntry = new Dictionary<int,int>();

                        Queue<int> q = new Queue<int>();

                        leftEntry[i] = r.Y1;
                        topEntry[i] = r.X1;
                        q.Enqueue(i);

                        while (q.Count > 0)
                        {
                            int j = q.Dequeue();

                            Rect r1 = rects[j];

                            int te = topEntry[j];
                            int le = leftEntry[j];

                            foreach (var k in Enumerable.Range(0, rects.Length))
                            {
                                Rect r2 = rects[k];
                                Action<int, int> tryAdd = (xx,yy) =>
                                    {
                                        if (r2.X1 >= xx && r2.X1 <= r1.X2 && r2.Y1 <= r1.Y2 && r2.Y2 > yy)
                                        {
                                            if (improve(leftEntry, k, Math.Max(yy, r1.Y1)))
                                                q.Enqueue(k);
                                        }
                                        if (r2.Y1 >= yy && r2.Y1 <= r1.Y2 && r2.X1 <= r1.X2 && r2.X2 > xx)
                                        {
                                            if (improve(topEntry, k, Math.Max(xx, r1.X1)))
                                                q.Enqueue(k);
                                        }
                                    };

                                tryAdd(r1.X1, le);
                                tryAdd(te, r1.Y1);
                            }
                        }


                        return leftEntry.Keys.Union(topEntry.Keys).Max(j =>
                            (rects[j].Y2 - rects[i].Y1) + (rects[j].X2 - rects[i].X1) 
                            );
                    }).ToString();
            };
        }

        private bool improve<K>(Dictionary<K, int> d, K key, int value)
        {
            int old;
            if (d.TryGetValue(key, out old))
                if (old <= value)
                    return false;
            d[key] = value;
                return true;
        }
    }
}
