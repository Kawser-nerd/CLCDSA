namespace CodeJam.Providers
{
  public enum ProblemType
  {
    Default, 
    ProblemA,
    ProblemB,
    ProblemC,
    ProblemD
  }
}