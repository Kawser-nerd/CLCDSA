#include <math.h>
#include <vector>
#include <list>
#include <sstream>

#include "FlySwatter.h"
#include "Utils.h"

#ifndef	M_PI
#define M_PI        3.14159265358979323846
#define M_PI_2      1.57079632679489661923
#define M_PI_4      0.785398163397448309616
#endif

FlySwatter::FlySwatter(std::istream &in, std::string &out, boost::condition &c, char &f)
	: Task(out, c, f)
{
	std::istringstream	input;
	std::string			str;

	GetString(in, str);
	input.str(str);

	input >> F >> R >> t >> r >> g;
}

FlySwatter::FlySwatter(FlySwatter &n) : Task(n)
{
	F = n.F;
	R = n.R;
	t = n.t;
	r = n.r;
	g = n.g;
}


FlySwatter::~FlySwatter()
{
}

void FlySwatter::operator()()
{
	std::ostringstream	output;
	double				x;
	double				y;
	double				x_limit;
	double				y_limit;
	double				d;
	double				a;
	double				rad;
	double				miss_area;

	output.precision(7);
	output << std::fixed << std::showpoint;

	if(g <= 2 * F)
	{
		output << (double)1.;
		result = output.str();
		flag = 1;
		finish.notify_all();
		return;
	}

	miss_area = 0;
	rad = (R - t - F);
	d = (2 * r + g);
	a = g - 2 * F;
	x_limit = sqrt(rad * rad - (r + F) * (r + F));
	for(x = r + F; x < x_limit; x += d)
	{
		y_limit = sqrt(rad * rad - x * x);
		for(y = r + F; y < y_limit; y += d)
			miss_area += RectCircleCrossing(rad, x, y, a);
	}

	output << (1 - miss_area / (M_PI_4 * R * R));
	result = output.str();
	flag = 1;
	finish.notify_all();
}

double FlySwatter::RectCircleCrossing(double rad, double x, double y, double a)
{
	if((rad * rad) <= (x * x + y * y))
		return 0.;
	if((rad * rad) >= ((x + a) * (x + a) + (y + a) * (y + a)))
		return a * a;

	return CircleTruncatedSector(rad, x, y) - CircleTruncatedSector(rad, x + a, y) - CircleTruncatedSector(rad, x, y + a);
}

double FlySwatter::CircleTruncatedSector(double rad, double x, double y)
{
	if((rad * rad) <= (x * x + y * y))
		return 0.;

	return x * y - (sqrt(rad * rad - x * x) * x + sqrt(rad * rad - y * y) * y) / 2
		+ ((acos(x / rad) + acos(y / rad)) /2 -  M_PI_4) * rad * rad;
}

