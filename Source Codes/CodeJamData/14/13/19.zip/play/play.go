// play
package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"math/rand"
	"os"
)

var _ = json.Marshal

const (
	N = 1000
)

func main() {

	_ = rand.Float64()
	fmt.Println("Hello World!")
	j, err := json.Marshal(stat(2000000))
	if err != nil {
		panic(err)
	}
	err = ioutil.WriteFile("memo2.json", j,
		os.ModeExclusive)
	if err != nil {
		panic(err)
	}
}

func stat(num int) (sums [N][N]int) {
	printint := num / 20
	for i := 0; i < num; i++ {
		if i%printint == 0 {
			fmt.Println("Rounds completed", i/printint, i)
		}
		perm := badPermute()
		for k, v := range perm {
			sums[k][v]++
		}
	}
	return sums
}

var perm [N]int

func badPermute() [N]int {
	for i := 0; i < N; i++ {
		perm[i] = i
	}
	for i := 0; i < N; i++ {
		r := rand.Int31n(N)
		perm[i], perm[r] = perm[r], perm[i]
	}
	return perm
}
