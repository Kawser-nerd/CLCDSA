package lib;

import java.util.function.ToIntFunction;

public class MapFactoryUsing2DArray {

    public static <K> MapFactory<K> of(final int size1, final int size2, final ToIntFunction<K> index1Getter, final ToIntFunction<K> index2Getter) {
        return MapFactoryUsing1DArray.of(size1 * size2, k -> {
            int i1 = index1Getter.applyAsInt(k);
            int i2 = index2Getter.applyAsInt(k);
            return i1 * size2 + i2;
        });
    }

}
