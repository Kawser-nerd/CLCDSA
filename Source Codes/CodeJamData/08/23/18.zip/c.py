""" Milkshakes

:Abstract: Solution to Google Code Jam 2008 round 1A
:Authors:  iki
:Contact:  jan.killian at (g)mail.com

Problem sample:

>>> test(
...   testlabel='sample via parse()',
...   testinput='''2
... 5
... 5 1 2 3 4 5
... 15
... 4 3 4 7 10
... ''')
Case #1: 1 3 2 5 4
Case #2: 2 8 13 4

"""
__docformat__ = 'restructuredtext en'

from codejam import *
from collections import deque

def solve(K, indices):
    d = perfect(K)
    return [d[i-1]+1 for i in indices]

def perfect(K):
    r = deque()
    p = 0
    k = 0
    while k < K-1:
        p = (p + k) % (K - k)
        k += 1
        r.append(p)

    if log.debug: log.debug(r)

    l = [k]
    while k:
        k -= 1
        l.insert(r.pop(), k)

    if log.debug: log.debug(l)
    return l

def format(result):
    return ' '.join(map(str, result))

def parse(fi, require=1):
    nl = fi.next
    K = int(nl().strip())
    indices = map(int, nl().strip().split())
    assert len(indices) > require
    assert len(indices) == indices[0]+1
    return K, indices[1:]

main(solve, parse, format)
