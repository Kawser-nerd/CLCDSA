#include <stdio.h>
#include <stdlib.h>

int		P, Q;
int		q[102];
int		p[102][102];

int calc(int f, int t)
{
	int m, i, r;
	
	if (p[f][t] != -1)
		return p[f][t];

	if (t == f + 1)
		return p[f][t] = 0;
	m = 0x7fffffff;
	for (i = f + 1; i < t; i++) {
		r = calc(f, i) + calc(i, t);
		if (r < m)
			m = r;
	}
	return p[f][t] = m + q[t] - q[f] - 2;
}

int main(void)
{
	int		T, t;
	int		i, j, k;
	char	buf[64];

	scanf("%d\n", &T);

	for(t = 0; t < T; t++)
	{
		memset(p, -1, 102 * 102 * sizeof(int));
		scanf("%d%d\n", &P, &Q);
		q[0] = 0;
		for(i = 1; i <= Q; i++)
			scanf("%d", &q[i]);
		q[i] = P + 1;
		gets(buf);

		printf("Case #%d: %d\n", t + 1, calc(0, i));
	}
	return 1;
}
