import java.io.PrintStream;
import java.math.BigInteger;
import java.util.Scanner;
import java.util.function.Supplier;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import java.util.stream.Stream;
import java.math.BigInteger;


public class CoinJam {
    static void run() {
        int n = rdInt();
        int j = rdInt();

        long range = 1L << n;
        int count = 0;

        for (long x = (range / 2) + 1;; x += 2) {
            assert x < range;

            int[] divs = new int[9];
            boolean prime = false;
            for (int i = 0; i < 9; ++i) {
                int d = findDivisor(x, i + 2);
                if (d == -1) {
                    prime = true;
                    break;
                }
                divs[i] = d;
            }
            if (!prime) {
                String s = Long.toBinaryString(x);
                assert s.length() == n;
                assert s.startsWith("1");
                assert s.endsWith("1");
                for (int b = 0; b < 9; ++b) {
                    assert new BigInteger(s, b + 2).mod(BigInteger.valueOf(divs[b])).longValueExact() == 0;
                }

                wrLn();
                wrVal(s);
                for (int d : divs) wrVal(d);
                ++count;
                if (count == j) break;
            }
        }
    }

    private static final int[] PRIMES;
    private static final BigInteger[] BIGPRIMES;

    static {
        PRIMES = new int[1000];
        PRIMES[0] = 2;
        int n = 1;
        int p = 3;
        while (n < PRIMES.length) {
            boolean prime = true;
            for (int i = 0; i < n; ++i) {
                if (p % PRIMES[i] == 0) {
                    prime = false;
                    break;
                }
            }
            if (prime) {
                PRIMES[n++] = p;
            }
            p += 2;
        }

        BIGPRIMES = new BigInteger[PRIMES.length];
        for (int i = 0; i < PRIMES.length; ++i) BIGPRIMES[i] = BigInteger.valueOf(PRIMES[i]);
    }

    private static int findDivisor(long x, int base) {
        long t0 = x;
        long t = 0;
        while (t0 > 0) {
            t = (t << 1) | (t0 & 1);
            t0 >>>= 1;
        }

        BigInteger v = BigInteger.ZERO;
        BigInteger bbase = BigInteger.valueOf(base);

        while (t > 0) {
            v = v.multiply(bbase);
            if ((t & 1) != 0) v = v.add(BigInteger.ONE);
            t >>>= 1;
        }

        for (BigInteger p : BIGPRIMES) {
            if (v.mod(p).equals(BigInteger.ZERO)) return p.intValueExact();
        }

        return -1;
    }

    public static void main(String[] args) {
        int n = rdInt();
        for (int i = 0; i < n; ++i) {
            output.print("Case #" + (i + 1) + ":");
            outputSep = " ";
            run();
            output.print("\n");
        }
        output.flush();
    }

    static Scanner input = new Scanner(System.in);
    static int rdInt() { return rdT(() -> input.nextInt()); }
    static long rdLong() { return rdT(() -> input.nextLong()); }
    static double rdDbl() { return rdT(() -> input.nextDouble()); }
    static BigInteger rdBigInt() { return rdT(() -> input.nextBigInteger()); }
    static String rdStr() { return rdT(() -> input.next()); }
    static String rdLine() { return input.nextLine(); }
    static String[] rdStrs(int n) { return Stream.generate(() -> rdStr()).limit(n).toArray(x -> new String[x]); }
    static int[] rdInts(int n) { return IntStream.generate(() -> rdInt()).limit(n).toArray(); }
    static long[] rdLongs(int n) { return LongStream.generate(() -> rdLong()).limit(n).toArray(); }
    static double[] rdDbls(int n) { return DoubleStream.generate(() -> rdDbl()).limit(n).toArray(); }
    private static <T> T rdT(Supplier<T> supplier) { T t = supplier.get(); input.skip(" |\n|\r\n"); return t; }

    static PrintStream output = new PrintStream(System.out, true);
    static String outputSep = " ";
    static void wrVal(String v) { wrT(v); }
    static void wrVal(int v) { wrT(v); }
    static void wrVal(long v) { wrT(v); }
    static void wrVal(BigInteger v) { wrT(v); }
    static void wrVal(double v) { wrVal(v, 10); }
    static void wrVal(double v, int fracdigs) { wrT(String.format("%." + fracdigs + "f", v)); }
    static void wrVals(int[] vs) { for (int v : vs) wrVal(v); }
    static void wrVals(long[] vs) { for (long v : vs) wrVal(v); }
    static void wrVals(double[] vs) { for (double v : vs) wrVal(v); }
    static void wrVals(double[] vs, int fracdigs) { for (double v : vs) wrVal(v, fracdigs); }
    static void wrVals(String[] vs) { for (String v : vs) wrVal(v); }
    static void wrLn() { output.print("\n"); outputSep = ""; }
    private static void wrT(Object v) { output.print(outputSep); output.print(v); outputSep = " "; }
}
