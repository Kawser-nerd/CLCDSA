﻿namespace CodeJam2013.B
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;

    /// <summary>
    /// Manages a case of the problem
    /// </summary>
    internal class Case
    {
        private const long N = 700;
        private static readonly Score[,] Scores = new Score[N,N];

        private readonly long x, y;

        private object answer;

        static Case()
        {
            try
            {
                if (File.Exists("Table.bin"))
                {
                    using (var br = new BinaryReader(File.OpenRead("Table.bin")))
                    {
                        for (var i = 0; i < N; ++i)
                        {
                            for (var j = 0; j < N; ++j)
                            {
                                var count = br.ReadInt64();
                                Scores[i, j] = new Score(count);
                            }
                        }
                    }
                    return;
                }

                // Calculate table.
                Scores[0, 0] = new Score(0);
                var prev = new[] { new Position(0, 0) };

                for (var i = 1; i < N; ++i)
                {
                    var newPrev = new List<Position>();
                    foreach (var p in prev)
                    {
                        {
                            var x = p.X;
                            var y = p.Y + i;
                            RegisterScore(x, y, i, newPrev);
                        }
                        {
                            var x = p.X;
                            var y = Math.Abs(p.Y - i);
                            RegisterScore(x, y, i, newPrev);
                        }
                        {
                            var x = Math.Abs(p.X - i);
                            var y = p.Y;
                            RegisterScore(x, y, i, newPrev);
                        }
                        {
                            var x = p.X + i;
                            var y = p.Y;
                            RegisterScore(x, y, i, newPrev);
                        }
                    }

                    prev = newPrev.ToArray();
                }
                /*
                for (var i = 0; i < N; ++i)
                {
                    for (var j = 0; j < N; ++j)
                    {
                        Console.Write(
                            "{0}\t",
                            Scores[i, j] == null ? "-" : Scores[i, j].Count.ToString(CultureInfo.InvariantCulture));
                    }
                    Console.WriteLine();
                }*/
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private static void RegisterScore(long x, long y, int i, List<Position> newPrev)
        {
            if (x >= N || y >= N || Scores[x, y] != null)
            {
                return;
            }
            
            Scores[x, y] = new Score(i);
            newPrev.Add(new Position(x, y));
        }

        /// <summary>
        /// Prevents a default instance of the <see cref="Case" /> class from being created.
        /// </summary>
        private Case(long x, long y)
        {
            this.x = x;
            this.y = y;
            this.answer = null;
        }

        #region Pre-implemented code
        /// <summary>
        /// Gets a value indicating whether this case <see cref="Case" /> has been solved.
        /// </summary>
        public bool IsSolved
        {
            get { return this.answer != null; }
        }

        /// <summary>
        /// Gets the answer.
        /// </summary>
        /// <exception cref="System.InvalidOperationException">The problem has not been solved yet.</exception>
        public object Answer
        {
            get
            {
                if (!this.IsSolved)
                {
                    throw new InvalidOperationException("The problem has not been solved yet.");
                }

                return this.answer;
            }
        }
        #endregion Pre-implemented code

        /// <summary>
        /// Loads a new test case from the stream.
        /// </summary>
        /// <param name="sr">The stream reader object which the case is to be loaded from.</param>
        /// <returns>A new instance of <see cref="Case"/> class.</returns>
        // ReSharper disable PossibleNullReferenceException
        public static Case Load(StreamReader sr)
        {
            var line = new Tokeniser(sr.ReadLine());
            var x = line.ReadInt64();
            var y = line.ReadInt64();

            return new Case(x, y);
        }
        // ReSharper restore PossibleNullReferenceException

        /// <summary>
        /// Solves this case.
        /// </summary>
        public void Solve()
        {
            if (this.IsSolved)
            {
                return;
            }

            var s = new List<char>();
            var cx = this.x;
            var cy = this.y;
            while (!(cx == 0 && cy == 0))
            {
                var i = GetCount(cx, cy);
                if (CanComeFrom(cx - i, cy, i - 1))
                {
                    s.Add('E'); cx = cx - i; continue;
                }
                if (CanComeFrom(cx + i, cy, i - 1))
                {
                    s.Add('W'); cx = cx + i; continue;
                }
                if (CanComeFrom(cx, cy - i, i - 1))
                {
                    s.Add('N'); cy = cy - i; continue;
                }
                if (CanComeFrom(cx, cy + i, i - 1))
                {
                    s.Add('S'); cy = cy + i; continue;
                }

                throw new Exception("Unexpected");
            }

            s.Reverse();
            this.answer = new string(s.ToArray());
        }

        private static long GetCount(long x, long y)
        {
            var xx = Math.Abs(x);
            var yy = Math.Abs(y);
            if (xx >= N || yy >= N || Scores[xx, yy] == null)
            {
                return -1;
            }

            return Scores[xx, yy].Count;
        }

        private static bool CanComeFrom(long x, long y, long count)
        {
            var xx = Math.Abs(x);
            var yy = Math.Abs(y);
            if (xx >= N || yy >= N)
            {
                return false;
            }

            return Scores[xx, yy] != null && Scores[xx, yy].Count == count;
        }

        private class Score
        {
            public readonly long Count;

            public Score(long count)
            {
                this.Count = count;
            }

            public override string ToString()
            {
                return this.Count.ToString(CultureInfo.InvariantCulture);
            }
        }
    }

    public class Position
    {
        public long X, Y;
        public Position(long x, long y)
        {
            this.X = x;
            this.Y = y;
        }

        public override string ToString()
        {
            return X + "," + Y;
        }
    }
}
