﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cmn.Util;
using Gcj.Util;

namespace Gcj.Y2014.R1B.B
{
    internal class BSolver : GcjSolver
    {
        protected override IEnumerable<object> EnobjSolveCase()
        {
            yield break;
        }

    }
}
