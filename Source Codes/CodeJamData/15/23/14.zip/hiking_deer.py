#! /usr/bin/env python
from __future__ import print_function, division
try:
    range = xrange
except NameError:
    pass

# import collections
# import functools
# import itertools as it
# import numpy as np # See http://www.numpy.org
# import sympy as sp # See http://sympy.org/en/index.html
import gmpy2 # See https://code.google.com/p/gmpy/
# import networkx as nx # See http://networkx.github.io/

import os
import sys
# MY MODULES - available at https://github.com/lackofcheese/CodeJamLib/
sys.path.append(os.path.join(
    os.environ['GOOGLE_DRIVE'], 'Coding', 'GCJ', 'CodeJamLib'))
import codejam_io

def toks_line(f_in, fun=int):
    return [fun(k) for k in f_in.readline().split()]

def process_first(f_in):
    num_cases = int(f_in.readline())
    other_data = None
    return num_cases, other_data

def process_case(f_in, f_out, case_no, other_data=None):
    N = int(f_in.readline())
    groups = []
    for i in range(N):
        D, H, M = toks_line(f_in)
        groups.append((D, H, M))
    ans = solve(groups)
    print("Case #{}: {}".format(case_no, ans), file=f_out)

def solve(groups):
    times = []
    for D, H, M in groups:
        arrival = M * gmpy2.mpq(360-D, 360)
        period = M
        times.append((arrival, period))
    times.sort()

    if len(times) <= 1:
        return 0
    # print(times)

    min_encounters = float('inf')
    for i, (arrival, period) in enumerate(times):
        # print(arrival, period)
        num_encounters = 0
        for j, (a, p) in enumerate(times):
            if i == j:
                continue
            if a > arrival:
                num_encounters += 1
            else:
                tm = (arrival - a) / p
                # print(a, p, "=>", tm)
                q, r = gmpy2.f_divmod(tm.numerator, tm.denominator)
                num_encounters += q
                if r == 0:
                    # If they're slower and arrive at the same time,
                    # we don't encounter them.
                    if p > period:
                        num_encounters -= 1
            # print("encounters:", num_encounters)
        if num_encounters < min_encounters:
            min_encounters = num_encounters
    return min_encounters

if __name__ == '__main__':
    codejam_io.process_input(process_case, process_first, __file__)
