package lib;

import java.util.function.BiPredicate;
import java.util.function.ToIntFunction;

public class HashMapMaterial<T> {
    public final ToIntFunction<T> hashFunction;
    public final BiPredicate<T, T> equalTester;

    public HashMapMaterial(ToIntFunction<T> hashFunction, BiPredicate<T, T> equalTester) {
        this.hashFunction = hashFunction;
        this.equalTester = equalTester;
    }
}
