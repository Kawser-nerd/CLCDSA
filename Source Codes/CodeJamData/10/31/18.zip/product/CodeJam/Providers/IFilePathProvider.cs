namespace CodeJam.Providers
{
  public interface IFilePathProvider
  {
    string InputFilePath();
    string OutputFilePath();
    string TimerFilePath();
  }
}