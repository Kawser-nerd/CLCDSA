""" Bribe the Prisoners

:Abstract: Solution to Google Code Jam 2009 Round 1C
:Authors:  iki
:Contact:  jan.killian at (g)mail.com

.. contents::

Problem statement
=================

Input
-----

Output
------

Limits
------

Doctest
=======

>>> test(
...   testlabel='sample via parse()',
...   testinput='''2
... 8 1
... 3
... 20 3
... 3 6 14
... ''')  #doctest: +NORMALIZE_WHITESPACE
Case #1: 7
Case #2: 35

"""
__docformat__ = 'restructuredtext en'

from codejam import *

def solve(P, Q):
    if log.debug: log.debug('P: %d | Q[%d]: %r' % (P, len(Q), Q))
    Q = [q-1 for q in Q]
    Q.sort()
    return solve1(0, P, 0, len(Q), Q, {})

def solve1(a, b, c, d, Q, C):
    if d <= c or b <= a: return 0
    if (a, b, c, d) in C: return C[a, b, c, d]
    r = (b-a) * (d-c)
    for p in range(c, d):
        q = Q[p]
        t = solve1(a, q, c, p, Q, C) + solve1(q+1, b, p+1, d, Q, C)
        if t < r:
            r = t
            n = q

    if log.debug: log.debug('%d-%d: %d [%d+%d] | %d-%d: %r' % (a, b, n, b-a-1, r, c, d, Q[c:d]))
    C[a, b, c, d] = b - a - 1 + r
    return b - a - 1 + r


def parse(fi):
    nl = fi.next
    P, Ql = map(int, nl().split())
    assert 1 <= Ql <= P

    Q = map(int, nl().split())
    assert len(Q) == Ql

    return P, Q

main(solve, parse)
