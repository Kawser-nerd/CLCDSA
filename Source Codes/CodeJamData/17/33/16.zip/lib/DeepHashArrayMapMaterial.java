package lib;

import java.util.Arrays;

public class DeepHashArrayMapMaterial {
    public static <T> HashMapMaterial<T[]> create() {
        return new HashMapMaterial<>(Arrays::deepHashCode, Arrays::deepEquals);
    }
}
