﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam_TrainTimetable
{
    class csTestCase
    {
        public int TurnaroundTime, NA, NB;

        public List<csTrip> A = new List<csTrip>();
        public List<csTrip> B = new List<csTrip>();

        public int SolA = -1, SolB = -1;
    }
}
