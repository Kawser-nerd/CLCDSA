﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright>
//    Copyright © 2013 Daisuke Takahashi
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace CodeJam2013.C
{
    using System;

    /// <summary>
    /// Provides convenient methods to read numeric values from a string.
    /// </summary>
    internal class Tokeniser
    {
        private readonly string[] tokens;

        private int currentIndex;

        /// <summary>
        /// Initializes a new instance of the <see cref="Tokeniser" /> class.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <remarks>This constructor assumes that a white space is specified as the separator.</remarks>
        public Tokeniser(string source)
            : this(source, ' ')
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Tokeniser" /> class.
        /// </summary>
        /// <param name="source">The source string.</param>
        /// <param name="separators">List of characters that separate two consecutive tokens.</param>
        public Tokeniser(string source, params char[] separators)
        {
            this.tokens = source.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            this.currentIndex = 0;
        }

        /// <summary>
        /// Reads an <see cref="Int32"/> value from the string.
        /// </summary>
        /// <returns>An <see cref="Int32"/> value.</returns>
        public int ReadInt32()
        {
            return int.Parse(this.tokens[this.currentIndex++]);
        }

        /// <summary>
        /// Reads an <see cref="Int64"/> value from the string.
        /// </summary>
        /// <returns>An <see cref="Int64"/> value.</returns>
        public long ReadInt64()
        {
            return long.Parse(this.tokens[this.currentIndex++]);
        }

        /// <summary>
        /// Reads a <see cref="UInt32"/> value from the string.
        /// </summary>
        /// <returns>A <see cref="UInt32"/> value.</returns>
        public uint ReadUInt32()
        {
            return uint.Parse(this.tokens[this.currentIndex++]);
        }

        /// <summary>
        /// Reads a <see cref="UInt64"/> value from the string.
        /// </summary>
        /// <returns>A <see cref="UInt64"/> value.</returns>
        public ulong ReadUInt64()
        {
            return ulong.Parse(this.tokens[this.currentIndex++]);
        }

        /// <summary>
        /// Reads a <see cref="Double"/> value from the string.
        /// </summary>
        /// <returns>A <see cref="Double"/> value.</returns>
        public double ReadDouble()
        {
            return double.Parse(this.tokens[this.currentIndex++]);
        }
    }
}
