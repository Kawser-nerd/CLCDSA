namespace CodeJamLibrary.Interfaces
{
  public interface IProblem
  {
    void Solve(IProblemInput problemInput, IProblemOutput problemOutput);
  }
}