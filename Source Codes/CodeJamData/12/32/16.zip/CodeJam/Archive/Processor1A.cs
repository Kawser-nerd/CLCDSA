﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    public class Processor1A
    {
        int cursor = 0;
        string[] stringData;

        private string getNextValue()
        {
            return stringData[cursor++];
        }

        private void appendString(StringBuilder output, string add) {
            if (output.Length > 0)
            {
                if (output[output.Length - 1] == add[0])
                {
                    output.Append(" ");
                }
            }
            output.Append(add);
        }

        public string Execute(string[] data)
        {
            stringData = data;
            StringBuilder output = new StringBuilder();

            // Read number of input
            int inputs = int.Parse(getNextValue());
            
            for (int i = 0; i < inputs; i++)
            {
                long result = 0;
                int count = int.Parse(getNextValue());
                var xValues = getNextValue().Split(' ').Select(item => long.Parse(item)).Take(count).OrderBy(value => value).ToList();
                var yValues = getNextValue().Split(' ').Select(item => long.Parse(item)).Take(count).OrderByDescending(value => value).ToList();

                for (int j = 0; j < xValues.Count(); j++)
                {
                    result += xValues[j] * yValues[j];
                }

                output.AppendLine(string.Format("Case #{0}: {1}", i + 1, result.ToString()));
            }

            return output.ToString();
        }
    }
}
