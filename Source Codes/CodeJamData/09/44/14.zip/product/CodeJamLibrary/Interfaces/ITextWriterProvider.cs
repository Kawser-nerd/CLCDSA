using System.IO;

namespace CodeJamLibrary.Interfaces
{
  public interface ITextWriterProvider
  {
    TextWriter GetWriter();

    void Open();
    void Close();
  }
}