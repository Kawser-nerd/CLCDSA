package lib;

public interface MatrixElementFunction<T> {
    T at(int i, int j);
}
