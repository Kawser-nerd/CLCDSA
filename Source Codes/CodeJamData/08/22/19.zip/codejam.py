""" Code runner for Google Codejam 2008

:Abstract: Code competition solution wrapper
:Authors:  iki
:Contact:  jan.killian at (g)mail.com

Adds multiple cases processing to coderun.py
"""
__docformat__ = 'restructuredtext en'
__all__ = ['main', 'test', 'log']

import coderun
from coderun import * # export
from itertools import izip, count

def format_cases(solutions):
    return '\n'.join('Case #%d: %s' % (c, format(s)) for s,c in izip(solutions, count(1)))

def solve_cases(cases):
    return [solve(*case) for case in cases]

def parse_cases_expanded(fi, require=1):
    N = n = int(fi.next().strip())
    if n < require:
        raise AssertionError, 'not enough cases: %d < %d' % (n, require)

    while n:
        n -= 1
        log.info('FILE: %s: case %d/%d' % (getattr(fi, 'name', type(fi).__name__), N-n, N))
        yield(parse(fi))

def parse_cases(fi, require=1):
    return [parse_cases_expanded(fi, require)]

def main(solve, parse, format=str, *args, **kwargs):
    globals().update(solve=solve, parse=parse, format=format)
    return coderun.main(solve_cases, parse_cases, format_cases, *args, **kwargs)
