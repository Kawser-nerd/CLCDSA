package lib;

public class InRange {
    public static boolean in(long value, long start, long end) {
        return start <= value && value < end;
    }
}
