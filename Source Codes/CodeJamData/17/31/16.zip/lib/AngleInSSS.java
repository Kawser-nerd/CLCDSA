package lib;

public class AngleInSSS {
    public static double calc(double side1, double side2, double opposite) {
        return Math.acos((side1 * side1 + side2 * side2 - opposite * opposite) / (2 * side1 * side2));
    }
}
