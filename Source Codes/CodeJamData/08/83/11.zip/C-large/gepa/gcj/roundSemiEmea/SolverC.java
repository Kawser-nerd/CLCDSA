/**
 * 
 */
package gepa.gcj.roundSemiEmea;

import gepa.gcj.main.InputData;
import gepa.gcj.main.Result;
import gepa.gcj.main.Solver;
import gepa.gcj.main.result.LResult;

/**
 * @author gepa
 *
 */
public class SolverC extends Solver {
    
    private static long MODULO = 1000000009;

    private long comb(int n, int k) {
        if (k == 0) {
            return 1;
        }
        if (n <= 0) {
            return 0;
        }
        if (k > n) {
            return 0;
        }
        long res = 1;
        for (int i = 1; i <= k; i++) {
            res = (res * (n + 1 - i)) % MODULO;
        }
        return res;
//        VFrac f = new VFrac(1);
//        for (int i = 1; i <= k; i++) {
//            f.mult(n + 1 - i);
////            f.div(i);
//        }
//        return f.getNumerator(MODULO);
    }

    @Override
    public void init() {
    }

    private long compute(InputDataC d, int from, int to) {
        int c1 = d.g[from].length;
        int c2 = d.g[to].length;
        long res = comb(d.k - c1, c2 - 1);
        for (int i = 0; i < d.g[to].length; i++) {
            if (d.g[to][i] == from) {
                continue;
            }
            res = (res * compute(d, to, d.g[to][i])) % MODULO;
        }
        return res;
    }

    @Override
    public Result solve(InputData data) {
        InputDataC d = (InputDataC)data;
//        System.out.println(d.n);
//        System.out.println(d.k);
//        for (int i = 0; i < d.g.length; i++) {
//            for (int j = 0; j < d.g[i].length; j++) {
//                System.out.print(" " + d.g[i][j] + " ");
//            }
//            System.out.println();
//        }

        long res = comb(d.k, d.g[0].length);
        for (int i = 0; i < d.g[0].length; i++) {
            res = (res * compute(d, 0, d.g[0][i])) % MODULO;
        }
        return new LResult(res);
    }

}
