import java.util.*
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Created by niyaz on 13.05.17.
 */


fun main(args: Array<String>) {

    class Input(val test: Int, val c: Array<CharArray>)

    class Output(val answer: Boolean, val c: Array<CharArray>)

    fun solve(test: Input): Output {
        val c = test.c
        val n = c.size
        val m = c[0].size
        var cnt = 0
        val id = Array(n, { IntArray(m, { -1 }) })
        for (i in 0..n - 1) {
            for (j in 0..m - 1) {
                if (c[i][j] == '|' || c[i][j] == '-') {
                    id[i][j] = cnt++
                }
            }
        }
        val g = TwoSATSolver(cnt)
        val DX = arrayOf(-1, 0, 1, 0)
        val DY = arrayOf(0, 1, 0, -1)
        fun getID(i_: Int, j_: Int, dir_: Int): Int {
            var cx = i_
            var cy = j_
            var dir = dir_
            while (true) {
                if (cx < 0 || cy < 0 || cx >= n || cy >= m || c[cx][cy] == '#') return Int.MIN_VALUE
                if (id[cx][cy] >= 0) {
                    return if ((dir and 1) == 0) id[cx][cy] else (id[cx][cy] xor -1)
                }
                if (c[cx][cy] == '/') {
                    dir = when (dir) {
                        0 -> 1
                        1 -> 0
                        2 -> 3
                        3 -> 2
                        else -> {
                            -1
                        }
                    }
                }
                if (c[cx][cy] == '\\') {
                    dir = when (dir) {
                        0 -> 3
                        3 -> 0
                        1 -> 2
                        2 -> 1
                        else -> {
                            -1
                        }
                    }
                }
                cx += DX[dir]
                cy += DY[dir]
            }
        }
        val ids = IntArray(2)
        for (i in 0..n - 1) {
            for (j in 0..m - 1) {
                if (c[i][j] != '.') continue
                for (sdir in 0..1) {
                    val id1 = getID(i, j, sdir)
                    val id2 = getID(i, j, sdir xor 2)
                    if ((id1 == Int.MIN_VALUE) == (id2 == Int.MIN_VALUE)) {
                        ids[sdir] = Int.MIN_VALUE
                    } else {
                        ids[sdir] = if (id1 == Int.MIN_VALUE) id2 else id1
                    }
                }
                if (ids[0] == Int.MIN_VALUE && ids[1] == Int.MIN_VALUE) {
                    return Output(false, c)
                }
                if (ids[0] == Int.MIN_VALUE) {
                    g.addClause(ids[1], ids[1])
                } else if (ids[1] == Int.MIN_VALUE) {
                    g.addClause(ids[0], ids[0])
                } else {
                    g.addClause(ids[0], ids[1])
                }
            }
        }
        for (i in 0..n - 1) {
            for (j in 0..m - 1) {
                if (id[i][j] >= 0) {
                    for (sdir in 0..3) {
                        if (getID(i + DX[sdir], j + DY[sdir], sdir) != Int.MIN_VALUE) {
                            val v = if ((sdir and 1) == 0) id[i][j] else (id[i][j] xor -1)
                            g.addClause(v xor -1, v xor -1)
                        }
                    }
                }
            }
        }
        val ans = g.solve() ?: return Output(false, c)
        for (i in 0..n - 1) {
            for (j in 0..m - 1) {
                if (id[i][j] >= 0) {
                    if (ans[id[i][j]]) {
                        c[i][j] = '|'
                    } else {
                        c[i][j] = '-'
                    }
                }
            }
        }
        return Output(true, c)
    }

    fun read(test: Int, input: Scanner): Input {
        val n = input.nextInt()
        input.nextInt()
        return Input(test, Array(n, { input.next().toCharArray() }))
    }

    fun write(test: Int, result: Output) {
        println("Case #$test: ${if (result.answer) "POSSIBLE" else "IMPOSSIBLE"}")
        if (result.answer) {
            result.c.forEach { println(String(it)) }
        }
    }

    val programStart = System.currentTimeMillis()

    val testsProcessed = AtomicInteger(0)
    val totalTime = AtomicLong(0)
    val input = Scanner(System.`in`)
    val t = input.nextInt()
    val threadManager = Executors.newFixedThreadPool(3)
    val futures = Array(t, { i -> read(i + 1, input) }).map { x ->
        threadManager.submit(Callable<Output> {
            val start = System.currentTimeMillis()
            val ret = solve(x)
            val time = System.currentTimeMillis() - start
            System.err.println("Finished testcase #${x.test} in ${time}ms, processed ${testsProcessed.incrementAndGet()} tests")
            totalTime.addAndGet(time)
            ret
        })
    }
    for ((i, f) in futures.withIndex()) {
        write(i + 1, f.get())
    }
    threadManager.shutdownNow()
    System.err.println("Processed $testsProcessed in ${System.currentTimeMillis() - programStart}ms, and ${totalTime}ms of total time")
}
