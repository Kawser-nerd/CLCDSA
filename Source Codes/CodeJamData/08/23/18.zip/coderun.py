""" Code runner

:Abstract: Code competition solution wrapper
:Authors:  iki
:Contact:  jan.killian at (g)mail.com

Usage
=====

* import:

    .. python::

        from coderun import *

* main execution:

    .. python::

        if __name__=='__main__':
            main(solve, parse, format, precompile=[])

    .. python::

        main(solve)

* doctest:

    .. this is sample only, do not run doctest on this module,

    .. python::

        >>> test('arg1', 'argn', kwarg1='kwarg1', kwargn='kwargn')
        result via format()

    .. python::

        >>> test('arg1', 'arg2', kwarg1='kwarg1', kwargn='kwargn',
        ...    testlabel = "sample")
        result via format()

    .. python::

        >>> test(
        ...    testlabel = "sample (parse)",
        ...    testinput = '''first line
        ... second line
        ... third line
        ... '''))
        result via format()

    .. python::

        >>> n, k = 500, 16
        >>> test(ring_graph(n, cyclic_distribution(k)),
        ...   testresult = range(k) + range(k-2, -1, -1),
        ...   testlabel = "ring of %d nodes with cyclic distribution of %d values" % (n,k))
"""
__docformat__ = 'restructuredtext en'
__all__ = ['main', 'test', 'log']

import sys


### logger

class logproxy:
    exception = error = warn = warning = info = str # do nothing
    debug = None

log = logproxy() #  exported log proxy


### time measurement

def timed(func, timer=None):
    """ decorates func() by logging execution time
    """
    funcname = getattr(func, '__name__', '?')

    if timer is None:
        import time
        if sys.platform == "win32":
            # on windows, the best timer is time.clock()
            timer = time.clock
        else:
            # on most other platforms the best timer is time.time()
            timer = time.time

    def timedfunc(*args, **kwargs):
        t0 = timer()

        try:
            r = func(*args, **kwargs)
        except:
            log.info('TIME: %s: %g (ERROR)' % (funcname, timer()-t0))
            raise

        log.info('TIME: %s: %g' % (funcname, timer()-t0))
        return r

    try:
        timedfunc.__name__ = func.__name__
    except:
        pass

    return timedfunc


### testing

def test(*args, **kwargs):
    """ doctest shortcut to test results of solve()

          * solve() parameters:

            - by default \*args and \*\*kwargs are used (except test related kwargs lower)
            - alternatively, testfile kwarg may be used as input stream for parse()
            - alternatively, testinput kwarg may be used as input string for parse()

          * result testing:

            - by default the output of `print format(stdout, solve())` is compared by doctest
            - alternatively, testresult kwarg may be used for testing large or special results
,             by `(assert testresult == solve())`

          * test related kwargs are not passed to solve():

            - testfile      .. input stream for parse()
            - testinput     .. input string for parse()
            - testlabel     .. log label before test
            - testresult    .. assert equal to result of solve()
    """
    expected  = kwargs.pop('testresult', test) # expected==test => no assertion
    label     = kwargs.pop('testlabel',  None)
    infile    = kwargs.pop('testfile',   None)
    if 'testinput' in kwargs:
        from cStringIO import StringIO
        infile = StringIO(kwargs.pop('testinput'))

    if label: log.info('TEST: %s' % label)

    if infile:
        result = solve(*parse(infile))
    else:
        result = solve(*args, **kwargs)

    if expected == test: # expected==test => no assertion
        print format(result)
    elif expected != result:
        raise AssertionError, result


### default i/o

def expressions(fi):
    """ basic parser that reads one valid python expression per non-empty line
    """
    return (eval(line) for line in fi if line.strip())


### exec

def run(fi, fo=None):
    """ runs fo.write(format(solve(\*parse(fi))),
        or skips format if fo is None and returns result
    """
    if fo is None:
        return solve(*parse(fi))
    else:
        return fo.write(format(solve(*parse(fi))))

def main(solve, parse=expressions, format=str, log='', precompile=None,
    logformat='%(asctime)s %(levelname)7s: %(message)s'):
    """ main execution

          * initializes logging
          * parses command line arguments
          * optionally adds timer to solve()
          * optionally precompiles solve+parse+format and functions called within
            (default if psyco available)
          * sets module global solve, parse, format, log, debug
          * call run() on stdin (default) or on filemask arguments,
            or execute doctest on solution module (__main__) if requested
    """
    __globals = globals()

    if not 'logging' in __globals:
        import logging
        logging.basicConfig(level=logging.INFO, format=logformat)

    if not isinstance(log, logging.Logger):
        log = logging.getLogger(log)

    from optparse import OptionParser
    optparser = OptionParser(
        usage="%prog [-dtTn] [FILELIST]",
        version="%prog 0.1")

    optparser.add_option("-d", "--debug",
        action="store_true",
        help="log debug messages")

    optparser.add_option("-t", "--timer",
        action="store_true",
        help="log execution time")

    optparser.add_option("-T", "--test",
        action="store_true",
        help="run doctests instead of processing input")

    optparser.add_option("-n", "--nocompile",
        action="store_false", default=True, dest="precompile",
        help="do not precompile functions using psyco")

    optparser.add_option("-o", "--stdout",
        action="store_true",
        help="use (stdout|stderr) instead of {inputfilename}.(out|log)")

    optparser.add_option("-O", "--overwrite",
        action="store_true",
        help="overwrite existing {inputfilename}.out")

    options, files = optparser.parse_args()

    # update global exported log proxy
    glog = __globals['log']
    [setattr(glog, m, getattr(log, m)) for m in dir(glog) if not m.startswith('__')]

    if options.debug:
        log.setLevel(logging.DEBUG)
        if options.stdout or not files:
            # much faster shortcut, when stderr is enough
            glog.debug=lambda message: sys.stderr.write('# DEBUG:  %s\n' % message)
    else:
        glog.debug = None

    if options.precompile:
        try:
            import psyco
        except ImportError, e:
            log.warning('psyco not imported: %s' % e)

        if precompile is None:
            precompile = []
        elif not isinstance(precompile, list):
            precompile = list(precompile)
        precompile[0:0] = [solve, parse, format]

        log.info('precompiling using psyco: %s' % ', '.join([f.__name__ for f in precompile]))
        [psyco.bind(f) for f in precompile]

    if options.timer:
        solve = timed(solve)

    __globals.update(solve=solve, parse=parse, format=format)

    if options.test:
        import doctest
        doctest.testmod()

    else:
        if files:
            import glob
            for mask in files:
                try:
                    fins = glob.glob(mask)
                except:
                    fins = None

                if not fins:
                    log.error("input filemask '%s' not found" % gin)

                elif options.stdout:
                    for fin in fins:
                        try:
                            run(open(fin, 'rU'), sys.stdout)
                        except:
                            log.exception("file '%s':" % fin)

                else:
                    import os, os.path
                    for fin in fins:
                        fl = None
                        try:
                            fn = os.path.splitext(fin)[0]
                            fon = '%s.out' % fn
                            if not options.overwrite and os.path.exists(fon):
                                log.warning("skipped '%s': output file already exists" % fin)
                                continue
                            fl = logging.FileHandler('%s.log' % fn)
                            fl.setFormatter(logging.Formatter(logformat))
                            log.addHandler(fl)
                            fi = open(fin, 'rU')
                            fo = open(fon, 'w')
                            run(fi, fo)
                        except:
                            log.exception("file '%s':" % fin)
                            try:
                                fi.close()
                                fo.close()
                                os.remove(fon)
                            except:
                                c, e, t = sys.exc_info()
                                log.error("file '%s': unable to remove invalid output: %s: %s" % \
                                    (fin, getattr(c, '__name__', c), e))
                        finally:
                            if not fl is None:
                                try:
                                    log.removeHandler(fl)
                                except:
                                    log.exception("file '%s':" % fin)
        else:
            try:
                run(sys.stdin, sys.stdout)
            except:
                log.exception("file <stdin>:")
