﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class CounterCulture : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            ProblemSet<CounterCulture>.Solve(args);
        }
        #endregion

        public override void Parse(ProblemReader file)
        {
            file.Read(out N);
        }

        // ReSharper disable InconsistentNaming
        ulong N;
        // ReSharper restore InconsistentNaming

        public override object Solve()
        {
            if (N == 1) return 1;

            var next = new HashSet<ulong> {1};
            var saw = new HashSet<ulong>();

            for (var i = 2;; i++)
            {
                var now = next;
                next = new HashSet<ulong>();

                foreach (var x in now)
                {
                    var a = A(x);
                    if (saw.Add(a))
                    {
                        if (a == N) return i;
                        next.Add(a);
                    }

                    var b = B(x);
                    if (saw.Add(b))
                    {
                        if (b == N) return i;
                        next.Add(b);
                    }
                }
            }
        }

        static ulong A(ulong x)
        {
            return x + 1;
        }

        static ulong B(ulong x)
        {
            ulong y = 0;
            while (x > 0)
            {
                y = (y*10) + (x%10);
                x = x/10;
            }
            return y;
        }


        public override IEnumerable<Action> StaticInitialize()
        {
            yield return () =>
            {

            };
        }
    }
}
