﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace GCJ2015Round2_3
{
	public class Node<T> : IComparable<Node<T>>
		where T : IComparable<T>
	{
		#region Fields

		private List<Edge<T>> m_Edges = new List<Edge<T>>();

		#endregion

		#region Public Properties

		public int Index { get; private set; }

		public int Degree
		{
			get
			{
				return m_Edges.Count;
			}
		}

		public IEnumerable<Edge<T>> Edges
		{
			get
			{
				return m_Edges;
			}
		}

		public T Data { get; set; }

		public IEnumerable<Node<T>> Neighbours
		{
			get
			{
				return m_Edges.Select(e => e.Target == this ? e.Source : e.Target);
			}
		}

		#endregion

		#region C'tor

		public Node(int index, T data)
		{
			this.Index = index;
			this.Data = data;
		}

		#endregion

		#region Public Methods

		public int CompareTo(Node<T> other)
		{
			return this.Data.CompareTo(other.Data);
		}

		public void AddEdge(Edge<T> edge)
		{
			m_Edges.Add(edge);
		}

		public void RemoveEdge(Node<T> n1)
		{
			m_Edges.RemoveAll(_ => _.Source == n1 || _.Target == n1);
		}

		public IEnumerable<Node<T>> DFS(HashSet<Node<T>> visited = null)
		{
			yield return this;

			if (visited == null)
			{
				visited = new HashSet<Node<T>>();
			}
			visited.Add(this);

			foreach (var neighbour in Neighbours)
			{
				if (!visited.Contains(neighbour))
				{
					foreach (var node in neighbour.DFS(visited))
					{
						yield return node;
					}
				}
			}
		}

		public IEnumerable<Node<T>> BFS()
		{
			Queue<Node<T>> toHandle = new Queue<Node<T>>(10);
			HashSet<Node<T>> visited = new HashSet<Node<T>>();
			toHandle.Enqueue(this);

			while (toHandle.Count != 0)
			{
				Node<T> next = toHandle.Dequeue();
				if (visited.Contains(next))
					continue;

				yield return next;
				visited.Add(next);
				foreach (var neighbour in next.Neighbours)
				{
					if (!visited.Contains(neighbour))
						toHandle.Enqueue(neighbour);
				}
			}
		}

		public void BFS(Action<Node<T>, int> handler)
		{
			var toHandle = new Queue<Tuple<Node<T>, int>>(10);
			HashSet<Node<T>> visited = new HashSet<Node<T>>();
			toHandle.Enqueue(new Tuple<Node<T>, int>(this, 0));

			while (toHandle.Count != 0)
			{
				var next = toHandle.Dequeue();
				if (visited.Contains(next.Item1))
					continue;

				handler(next.Item1, next.Item2);
				visited.Add(next.Item1);
				foreach (var neighbour in next.Item1.Neighbours)
				{
					if (!visited.Contains(neighbour))
						toHandle.Enqueue(new Tuple<Node<T>, int>(neighbour, next.Item2 + 1));
				}
			}
		}

		public Edge<T> GetEdge(Node<T> node)
		{
			return m_Edges.Where(e => e.Source == node || e.Target == node).FirstOrDefault();
		}

		public IEnumerable<Path<T>> GetAllPaths(HashSet<Node<T>> visited = null)
		{
			if (visited == null)
			{
				visited = new HashSet<Node<T>>();
			}
			if (visited.Contains(this))
				yield break;


			Path<T> currentPath = new Path<T>();
			currentPath.ConcatToPath(this);
			visited.Add(this);
			foreach (var neighbour in this.Neighbours)
			{
				if (visited.Contains(neighbour))
				{
					continue;
				}

				foreach (var path in neighbour.GetAllPaths())
				{
					Path<T> result = currentPath.Clone();
					result.ConcatToPath(path);
					yield return result;
				}
			}
		}

		public override string ToString()
		{
			StringBuilder result = new StringBuilder(string.Format("{0}: {1}", this.Index, this.Data));
			if (this.Degree > 0)
			{
				result.Append("   ");
				result.Append(string.Join(" ", this.Neighbours.Select(n => n.Index)));
			}

			return result.ToString();
		}

		#endregion
	}
}
