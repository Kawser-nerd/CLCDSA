import jam

def solve(actA, actB):
    solidB = 0
    solidA = 0
    free = 0

    rigidA = []
    rigidB = []

    actAll  = [(start, stop, False) for start, stop in actA]
    actAll += [(start, stop, True)  for start, stop in actB]

    actAll.sort()

    switches = 0

    _, last_stop, wasA = actAll[-1]
    last_stop -= 24 * 60

    for start, stop, isA in actAll:
        if wasA == isA:
            if isA:
                rigidB += [start - last_stop]
            else:
                rigidA += [start - last_stop]
        else:
            switches += 1
            free += start - last_stop

        if isA:
            solidB += stop - start
        else:
            solidA += stop - start

        last_stop = stop
        wasA = isA

    
    dumbA = solidA + sum(rigidA)
    dumbB = solidB + sum(rigidB)

    toEliminate = 0
    data = []

    if dumbA > 720:
        toEliminate = dumbA - 720
        data = rigidA

    if dumbB > 720:
        toEliminate = dumbB - 720
        data = rigidB

    data.sort(reverse=True)
    for interval in data:
        # print(toEliminate)
        if toEliminate <= 0: break

        toEliminate -= interval
        switches += 2

    return switches




def parse():
    Ac, Aj = [int(x) for x in input().strip().split()]

    activityA = [
        [int(x) for x in input().strip().split()]
        for _ in range(Ac)
    ]

    activityB = [
        [int(x) for x in input().strip().split()]
        for _ in range(Aj)
    ]

    return solve(activityA, activityB)


# res = solve(
#     [(540, 600)],
#     [(840, 900)]
# )

# case4 = [(0, 10), (1420, 1440), (90, 100)], [(550, 600), (900, 950), (100, 150), (1050, 1400)]

# print(solve(*case4))

jam.run(parse)