﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam_FlySwatter
{
    class csPoint
    {
        public double X,Y;

        public csPoint(double X, double Y)
        {
            this.X = X;
            this.Y = Y;
        }
    }
}
