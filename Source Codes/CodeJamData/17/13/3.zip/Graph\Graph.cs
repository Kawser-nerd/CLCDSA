﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q3
{
	public class Graph<T>
		where T : IComparable<T>
	{
		#region Fields

		private List<Node<T>> m_AllNodes = new List<Node<T>>();
		private List<Edge<T>> m_AllEdges = new List<Edge<T>>();

		#endregion

		#region Public Properties

		public IEnumerable<Node<T>> Nodes
		{
			get
			{
				return m_AllNodes;
			}
		}

		public int V
		{
			get
			{
				return m_AllNodes.Count;
			}
		}

		public IEnumerable<Edge<T>> Edges
		{
			get
			{
				return m_AllEdges;
			}
		}

		public int E
		{
			get
			{
				return m_AllEdges.Count;
			}
		}

		#endregion

		#region C'tor

		public Graph()
		{
		}

		#endregion

		#region Public Methods

		public int AddNode(T data)
		{
			int index = m_AllNodes.Count;
			this.m_AllNodes.Add(new Node<T>(index + 1, data));

			return index;
		}

		public Edge<T> AddEdge(int index1, int index2)
		{
			Node<T> n1 = GetNode(index1);
			if (n1 == null)
			{
				throw new ArgumentException(string.Format("Index {0} is not in graph", index1));
			}

			Node<T> n2 = GetNode(index2);
			if (n2 == null)
			{
				throw new ArgumentException(string.Format("Index {0} is not in graph", index2));
			}

			Edge<T> edge = new Edge<T>(n1, n2);
			n1.AddEdge(edge);
			n2.AddEdge(edge);
			m_AllEdges.Add(edge);

			return edge;
		}

		public void RemoveNode(int index)
		{
			Node<T> n1 = GetNode(index);
			if (n1 == null)
			{
				throw new ArgumentException(string.Format("Index {0} is not in graph", index));
			}

			foreach (var edge in n1.Edges)
			{
				m_AllEdges.Remove(edge);
			}

			foreach (var neighbour in n1.Neighbours)
			{
				neighbour.RemoveEdge(n1);
			}

			m_AllNodes.Remove(n1);
		}

		public bool RemoveEdge(int index1, int index2)
		{
			Node<T> n1 = GetNode(index1);
			if (n1 == null)
			{
				throw new ArgumentException(string.Format("Index {0} is not in graph", index1));
			}

			Node<T> n2 = GetNode(index2);
			if (n2 == null)
			{
				throw new ArgumentException(string.Format("Index {0} is not in graph", index2));
			}

			n1.RemoveEdge(n2);
			n2.RemoveEdge(n1);

			return m_AllEdges.RemoveAll(_ => (_.Source == n1 && _.Target == n2) || (_.Source == n2 && _.Target == n1)) > 0;
		}

		public IEnumerable<Node<T>> DFS(int root)
		{
			Node<T> n1 = GetNode(root);
			return n1.DFS();
		}

		public IEnumerable<Node<T>> BFS(int root)
		{
			Node<T> n1 = GetNode(root);
			return n1.BFS();
		}

		public void BFS(int root, Action<Node<T>, int> handler)
		{
			Node<T> n1 = GetNode(root);
			n1.BFS(handler);
		}

		public Node<T> GetNode(int index)
		{
			if (index < 1 || index > m_AllNodes.Count)
				return null;
			return m_AllNodes[index - 1];
		}

		public Node<T> GetNodeByData(T data)
		{
			return m_AllNodes.Where(n => n.Data.Equals(data)).FirstOrDefault();
		}

		public override string ToString()
		{
			StringBuilder result = new StringBuilder();
			foreach (var node in m_AllNodes)
			{
				result.Append(node.ToString());
				result.AppendLine(";");
			}
			return result.ToString();
		}

		#endregion
	}
}
