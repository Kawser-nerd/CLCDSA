﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;

namespace Q3
{
	public class Solver : SolverBase
	{
		public const string INPUT_NAME = "small1-2";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = false;
		public const bool PRINT_EVERY_RESULT = true;

		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		public override object SolveTestCase(int testCase)
		{
			var spl = GetIntList();
			var Hd = spl[0];
			var Ad = spl[1];
			var Hk = spl[2];
			var Ak = spl[3];
			var B = spl[4];
			var D = spl[5];

			var minTurns = -1;
			for (int d = 0; d < 100; d++)
			{
				for (int b = 0; b < 100; b++)
				{
					var t = GetTurnsFor(Hd, Ad, Hk, Ak, B, D, b, d);
					if (t == -1)
						continue;
					if (minTurns == -1 || t < minTurns)
						minTurns = t;
				}
			}

			return minTurns == -1 ? IMPOSSIBLE : minTurns.ToString();
		}

		private int GetTurnsFor(int hd, int ad, int hk, int ak, int B, int D, int buffs, int debuffs)
		{
			var currHealth = hd;
			var turns = 0;

			for (int i = 0; i < debuffs; i++)
			{
				if (ak - D >= currHealth)
				{
					turns++;
					currHealth = hd - ak;
					if (ak - D >= currHealth)
						return -1;
				}
				ak -= D;
				turns++;
				currHealth -= ak;
			}

			for (int i = 0; i < buffs; i++)
			{
				if (ak >= currHealth)
				{
					turns++;
					currHealth = hd - ak;
					if (ak >= currHealth)
						return -1;
				}
				ad += B;
				turns++;
				currHealth -= ak;
			}

			while (hk > 0)
			{
				if (hk <= ad)
				{
					turns++;
					break;
				}

				if (ak >= currHealth)
				{
					turns++;
					currHealth = hd - ak;
					if (ak >= currHealth)
						return -1;
				}

				hk -= ad;
				turns++;
				currHealth -= ak;
			}

			return turns;
		}
	}
}