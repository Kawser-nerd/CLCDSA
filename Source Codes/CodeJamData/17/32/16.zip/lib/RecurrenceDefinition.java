package lib;


public interface RecurrenceDefinition<T, S> {
    S get(T terms, Solver<T, S> self);
}
