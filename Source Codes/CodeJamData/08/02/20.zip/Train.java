import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.PriorityQueue;

public class Train extends Template {
	
	public final static int max = 48*60;

	private int readTime(String str) {
		int i1 = str.charAt(0) - '0';
		int i2 = str.charAt(1) - '0';
		int i3 = str.charAt(3) - '0';
		int i4 = str.charAt(4) - '0';
		return i4 + (10 * i3) + (60 * i2) + (600 * i1);
	}

	@Override
	public void runCase(BufferedReader in, BufferedWriter out)
			throws IOException {
		int t = Integer.parseInt(in.readLine());
		String[] nanb = in.readLine().split(" ");
		int na = Integer.parseInt(nanb[0]);
		int nb = Integer.parseInt(nanb[1]);
		PriorityQueue<Integer> fromA = new PriorityQueue<Integer>();
		PriorityQueue<Integer> toA = new PriorityQueue<Integer>();
		PriorityQueue<Integer> fromB = new PriorityQueue<Integer>();
		PriorityQueue<Integer> toB = new PriorityQueue<Integer>();
		for (int i = 0; i < na; i++) {
			String[] ab = in.readLine().split(" ");
			fromA.add(readTime(ab[0]));
			toB.add(readTime(ab[1])+t);
		}
		for (int i = 0; i < nb; i++) {
			String[] ba = in.readLine().split(" ");
			fromB.add(readTime(ba[0]));
			toA.add(readTime(ba[1])+t);
		}
		int depoA=0;
		int depoB=0;
		int inA = 0;
		int inB = 0;
		//System.out.println(fromA + " " + fromB + " " + toA+ " "+ toB + " " + inA + " " + inB+" " + depoA+" "+ depoB);
		while (!(fromA.isEmpty()&&fromB.isEmpty())) {
			/* peek */
			int min = max;
			Integer minQ = fromA.peek();
			if ((minQ!=null)&&(minQ<min)) {
				min=minQ;
			}
			minQ = fromB.peek();
			if ((minQ!=null)&&(minQ<min)) {
				min=minQ;
			}
			minQ = toA.peek();
			if ((minQ!=null)&&(minQ<min)) {
				min=minQ;
			}
			minQ = toB.peek();
			if ((minQ!=null)&&(minQ<min)) {
				min=minQ;
			}
			//System.out.println(min);
			/* poll */
			minQ = toA.peek();
			if ((minQ!=null)&&(minQ==min)) {
				toA.poll();
				inA++;
				//System.out.println("inA");
			}
			minQ = toB.peek();
			if ((minQ!=null)&&(minQ==min)) {
				toB.poll();
				inB++;
				//System.out.println("inB");
			}
			minQ = fromA.peek();
			if ((minQ!=null)&&(minQ==min)) {
				//System.out.println("fromA");
				if (inA==0) {
					depoA++;
				} else {
					inA--;
				}
				fromA.poll();
			}
			minQ = fromB.peek();
			if ((minQ!=null)&&(minQ==min)) {
				//System.out.println("fromB");
				if (inB==0) {
					depoB++;
				} else {
					inB--;
				}
				fromB.poll();
			}
			//System.out.println(fromA + " " + fromB + " " + toA+ " "+ toB + " " + inA + " " + inB+" " + depoA+" "+ depoB);
		}
		out.append(' ');
		out.append(String.valueOf(depoA));
		out.append(' ');
		out.append(String.valueOf(depoB));
		out.newLine();
	}

	public static void main(String[] args) {
		new Train().start();
	}
}