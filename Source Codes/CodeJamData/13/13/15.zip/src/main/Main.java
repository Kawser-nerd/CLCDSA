package main;

import java.util.Calendar;

import problems.*;

public class Main {
    public static void main(String[] args){
    	long c = Calendar.getInstance().getTimeInMillis();
    	new GoodLuck(new IOManager()).solve();

    	System.out.println(Calendar.getInstance().getTimeInMillis() - c);
    }   
}
