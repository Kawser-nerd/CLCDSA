import java.util.ArrayList;
import java.util.List;

import generic.InUtils;
import generic.Solver;

// Unsolved

public class QA implements Solver {

	@Override
	public String solveCase() {
		String[]	tokens = InUtils.oneLineStringArray();
		int numberOfActions = Integer.parseInt(tokens[0]);
		List<Action> bActions = new ArrayList<Action>();
		List<Action> oActions = new ArrayList<Action>();
		for(int i=0; i<numberOfActions; i++){
			Action newAction = new Action();
			newAction.number = i;
			newAction.button = Integer.parseInt(tokens[i*2 + 2]);
			if(tokens[i*2 + 1].equals("O"))
				oActions.add(newAction);
			else
				bActions.add(newAction);
		}
		int oCount = 0;
		int bCount = 0;
		int oPosition = 1;
		int bPosition = 1;
		int globalCount = 0;
		int time = 0;
		boolean pushing = false;
		while(globalCount<numberOfActions){
			time++;
			pushing = false;
			if(oCount<oActions.size()){
				if(oActions.get(oCount).button > oPosition)
					oPosition++;
				else if (oActions.get(oCount).button < oPosition)
					oPosition--;
				else if(globalCount == oActions.get(oCount).number){
					globalCount++;
					oCount++;
					pushing = true;
				}
			}
			if(bCount<bActions.size()){
				if(bActions.get(bCount).button > bPosition)
					bPosition++;
				else if (bActions.get(bCount).button < bPosition)
					bPosition--;
				else if(globalCount == bActions.get(bCount).number && !pushing){
					globalCount++;
					bCount++;
				}
			}
		}
		return Integer.toString(time);
	}
	
	public class Action {
		int number;
		int button;
	}
}
