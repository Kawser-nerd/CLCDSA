﻿using System;

namespace Generic.Maths
{
    public static class FloatMath
    {
        public static float Sqrt(float x)
        {
            return (float) Math.Sqrt(x);
        }
    }
}
