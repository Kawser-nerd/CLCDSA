﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using Generic.Containers.Collections.Dictionaries;
using Generic.Containers.Collections.List;

namespace Google_Code_Jam.Problems.Factories
{
    class Factory : Algorithm<Problem, long>
    {
        public override Problem Parse(StreamReader reader)
        {
            var nm = JamUtil.ReadInts(reader);
            var boxOrderValues = JamUtil.ReadLongs(reader);
            var toyOrderValues = JamUtil.ReadLongs(reader);
            var boxOrders = GetOrders(boxOrderValues, nm[0]);
            var toyOrders = GetOrders(toyOrderValues, nm[1]);
            return new Problem(boxOrders, toyOrders);
        }

        static List<Order> GetOrders(IList<long> boxOrderValues, int totalBoxOrders)
        {
            var boxOrders = new List<Order>();
            for (var i = 0; i < totalBoxOrders; i++)
            {
                var j = i * 2;
                boxOrders.Add(new Order(boxOrderValues[j], boxOrderValues[j + 1]));
            }
            return boxOrders;
        }

        IDictionary<Tuple<int, int>,long> subSolutions;
        public override long Solve(Problem problem)
        {
            subSolutions = new Dictionary<Tuple<int, int>, long>();
            return GetPackageCount(true, 0, problem.BoxOrders, 0, problem.ToyOrders);
        }

        long GetPackageCount(bool boxMainline, int mainIndex, IList<Order> mainLine, int secondIndex, IList<Order> secondLine)
        {
            var subProblem = boxMainline ? Tuple.Create(mainIndex,secondIndex) : Tuple.Create(secondIndex,mainIndex);
            var mbCache = subSolutions.Get(subProblem);
            if (mbCache.IsJust)
                return mbCache.FromJust;

            var result = GetPackageCount(mainLine[mainIndex].Count, boxMainline, mainIndex, mainLine, secondIndex, secondLine);
            subSolutions[subProblem] = result;
            return result;
        }

        long GetPackageCount(long mainItemsLeft, bool boxMainline, int mainIndex, IList<Order> mainLine, int secondIndex, IList<Order> secondLine)
        {
            if (secondIndex == secondLine.Count)
                return 0;

            var mainOrder = mainLine[mainIndex];
            var secondOrder = secondLine[secondIndex];
            if (mainOrder.Type == secondOrder.Type)
            {
                var packageCount = Math.Min(mainItemsLeft, secondOrder.Count);
                if (packageCount == mainItemsLeft)
                {
                    return packageCount + GetPackageCount(secondOrder.Count - packageCount, !boxMainline, secondIndex,
                        secondLine, mainIndex + 1, mainLine);
                }
                return packageCount + GetPackageCount(mainItemsLeft - packageCount, boxMainline, mainIndex,
                    mainLine, secondIndex + 1, secondLine);
            }
            var throwAwayMainScore = GetPackageCount(!boxMainline, secondIndex,secondLine, mainIndex + 1, mainLine);
            var throwAwaySecondScore = GetPackageCount(mainItemsLeft, boxMainline, mainIndex, mainLine, secondIndex + 1, secondLine);
            return Math.Max(throwAwayMainScore, throwAwaySecondScore);
        }

        public override string Print(long solution)
        {
            return solution.ToString(CultureInfo.InvariantCulture);
        }

        public override IEnumerable<Problem> LargeProblems
        {
            get 
            { 
                var random = new Random(0);
                return ListUtil.New(new Problem(GetRandomOrders(random),GetRandomOrders(random))); 
            }
        }

        static List<Order> GetRandomOrders(Random random)
        {
            return Enumerable.Range(0,100).Select(i =>
            {
                var count = random.Next(1,int.MaxValue);
                var type = random.Next(1,100);
                return new Order(count,type);
            }).ToList();
        }
    }
}
