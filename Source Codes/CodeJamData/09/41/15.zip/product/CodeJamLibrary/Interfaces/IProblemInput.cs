namespace CodeJamLibrary.Interfaces
{
  public interface IProblemInput
  {
    string ReadLine();
    string[] SplitLine();
    int[] ParseInt();
  }
}