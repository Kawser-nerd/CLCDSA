﻿using System;
using System.Collections;
using System.Collections.Generic;
using CodeJamLibrary;
using CodeJamLibrary.Interfaces;

namespace Problems
{
  public class ProblemC : ProblemTemplate
  {
    public class Stock : IComparable
    {
      public List<int> Inters { get; set; }

      public int[] Values { get; set; }

      public Stock(int[] values)
      {
        Values = values;
        Inters = new List<int>();
      }

      public bool intersect(Stock other)
      {
        for (int i = 0; i < Values.Length - 1; i++)
        {
          if (Values[i] == other.Values[i])
            return true;
          if (Values[i + 1] == other.Values[i + 1])
            return true;

          if ((Values[i] > other.Values[i]) &&
            Values[i + 1] < other.Values[i + 1])
            return true;

          if ((Values[i] < other.Values[i]) &&
              Values[i + 1] > other.Values[i + 1])
            return true;
        }

        return false;
      }


      public int CompareTo(object obj)
      {
        var c = (Stock) obj;
        return this.Inters.Count.CompareTo(c.Inters.Count);
      }
    }

    protected override string Solve(IProblemInput problemInput)
    {
      var b = problemInput.ParseInt();
      int N = b[0];
      int K = b[1];

      var stocks = new Stock[N];

      for (int i = 0; i < N; i++)
      {
        var buff = problemInput.ParseInt();
        stocks[i] = new Stock(buff);
      }

            for (int i = 0; i < N; i++)
            {
              for (int j = 0; j < N; j++)
              {
                if(i==j)
                  continue;
      
                if(stocks[i].intersect(stocks[j]))
                  stocks[i].Inters.Add(j);
              }
            }


      Array.Sort(stocks);

      ArrayList l = new ArrayList();



      for (int i = N-1; i >= 0; i--)
      {


        bool added = false;
        foreach (var list in l)
        {
          var m = (List<int>)list;
          bool cant = false;
          foreach (var t in m)
          {
            if (stocks[i].intersect(stocks[t]))
            {
              cant = true;
              break;
            }
          }
          if (!cant)
          {
            m.Add(i);
            added = true;
            break;
          }

        }

        if (added == false)
          l.Add(new List<int>() { i });

      }




      return l.Count.ToString();
    }
  }
}
