﻿using System;
using Generic.InputOutput.Printing;
using Generic.InputOutput.Printing.Sizable;
using Generic.Maths.Vectors;

namespace Generic.Maths.Lines
{
    class TwoPointBoundedLine : IBoundedLine, INonVertical, IPrintable
    {
        private DoubleVector2 left;
        private DoubleVector2 right;

        internal TwoPointBoundedLine(DoubleVector2 first, DoubleVector2 second)
        {
            if (first.X < second.X)
            {
                left = first;
                right = second;
            }
            else
            {
                left = second;
                right = first;
            }
        }

        public double DyDx { get { return (right.Y - left.Y)/(right.X - left.X); } }

        public double Y0
        {
            get { return Y(0); }
        }

        public double Y(double x)
        {
            return DyDx*(x - left.X) + left.Y;
        }

        public double X(double y)
        {
            return (y - left.Y)/DyDx + left.X;
        }

        public double LeftX
        {
            get { return left.X; }
        }

        public double RightX
        {
            get { return right.X; }
        }

        public double TopY
        {
            get { return Math.Max(left.Y,right.Y); }
        }

        public double BottomY
        {
            get { return Math.Min(left.Y,right.Y); }
        }

        public override string ToString()
        {
            return "(" + left + "," + right + ")";
        }

        public Document Print()
        {
            return (left.Print() + Document.Comma + right.Print()).InBrackets();
        }
    }
}
