﻿using Gcj.Util;
using Gcj.Y2014.R1B.B;
using Gcj.Y2014.R1B.C;

namespace Gcj
{
    internal class Program
    {

        static void Main(string[] args)
        {
            ConcurrentGcjSolver.Solve<CSolver>(true);
        }
    }
}
