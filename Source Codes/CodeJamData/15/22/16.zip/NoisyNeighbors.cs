﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class NoisyNeighbors : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            ProblemSet<NoisyNeighbors>.Solve(args);
        }
        #endregion

        public override void Parse(ProblemReader file)
        {
            file.Read(out R, out C, out N);
        }

        // ReSharper disable InconsistentNaming
        private int R, C, N;
        // ReSharper restore InconsistentNaming

        public override object Solve()
        {
            var min = int.MaxValue;
            var rc = R*C;
            var rcx = 1 << rc;
            for (var i = 0; i < rcx; i++)
            {
                if (BitCount(i) != N) continue;
                var me = 0;
                for (var x = 0; x < rc; x++)
                    if (IsSet(i, x))
                    {
                        if ((x + 1)%C != 0 && IsSet(i, x + 1)) me++;
                        if ((x + C) < rc && IsSet(i, x + C)) me++;
                    }
                if (me < min) min = me;
            }
            return min;
        }

        int BitCount(int i)
        {
            i = i - ((i >> 1) & 0x55555555);
            i = (i & 0x33333333) + ((i >> 2) & 0x33333333);
            return (((i + (i >> 4)) & 0x0F0F0F0F) * 0x01010101) >> 24;
        }

        bool IsSet(int i, int bit)
        {
            return ((i >> bit) & 1) == 1;
        }

        public override IEnumerable<Action> StaticInitialize()
        {
            yield return () =>
            {

            };
        }
    }
}
