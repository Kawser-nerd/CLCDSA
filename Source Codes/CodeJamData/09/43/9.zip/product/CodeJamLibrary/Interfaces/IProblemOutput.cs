namespace CodeJamLibrary.Interfaces
{
  public interface IProblemOutput
  {
    void WriteCase(string value);
  }
}