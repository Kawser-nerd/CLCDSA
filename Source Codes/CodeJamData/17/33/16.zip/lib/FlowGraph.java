package lib;

public class FlowGraph {

    private final int[] en;
    private final int[][] e;
    private final int[][] flowMatrix;
    private final int[][] capacityMatrix;

    public FlowGraph(int n) {
        en = new int[n];
        e = new int[n][n];
        flowMatrix = new int[n][n];
        capacityMatrix = new int[n][n];
    }

    public void setCapacity(int from, int to, int capacity) {
        e[from][en[from]++] = to;
        e[to][en[to]++] = from;
        capacityMatrix[from][to] = capacity;
    }

    public void addCapacity(int from, int to, int addition) {
        capacityMatrix[from][to] += addition;
    }

    public AdjacentListGetter getAdjacentListGetter() {
        return (v, visitor) -> {
            for (int i = 0; i < en[v]; i++)
                visitor.accept(e[v][i]);
        };
    }

    public GetterOnEdge getCapacityGetter() {
        return (from, to) -> capacityMatrix[from][to];
    }

    public GetterOnEdge getFlowGetter() {
        return (from, to) -> flowMatrix[from][to];
    }

    public AdderOnEdge getFlowAdder() {
        return (from, to, value) -> flowMatrix[from][to] += value;
    }
}
