﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using GCJ2015Round2_1;
using System.Diagnostics;

namespace GCJ2015Round2_1
{
	public class Program : IDisposable
	{
		#region Consts

		private const int FILE_HISTORY_SIZE = 10;

		#endregion

		#region Fields

		private StreamWriter m_OutputWriter;
		private static string InputFilePath
		{
			get
			{
				return string.Format(@"../../in/{0}.in", Solver.INPUT_NAME);
			}
		}

		private static string OutputFilePath
		{
			get
			{
				return string.Format(@"../../out/{0}.out", Solver.INPUT_NAME);
			}
		}

		#endregion

		#region Properties

		public LineEnumerator InputReader
		{
			get;
			private set;
		}

		#endregion

		#region C'tor

		static void Main(string[] args)
		{
			TestCaseInfo info;
			using (Program program = new Program())
			{
				program.Run();
				info = program.InputReader.TestCaseInfo;
			}

			PrintOut("Solution complete!");
			string olderFilePath = GetPreviousFilePath(OutputFilePath);
			if (File.Exists(olderFilePath))
			{
				PrintOut("Comparing with previous solution results...");
				using (FileComparer comparer = new FileComparer(OutputFilePath, olderFilePath, info))
				{
					comparer.PrintComparisonResults();
				}
			}

			string correctFilePath = GetCorrectFilePath(OutputFilePath);
			if (File.Exists(correctFilePath))
			{
				PrintOut("Comparing with correct solution results...");
				using (FileComparer comparer = new FileComparer(OutputFilePath, correctFilePath, info))
				{
					comparer.PrintComparisonResults();
				}
			}

			PrintOut("All done!");
			Console.ReadKey();
		}

		public Program()
		{
			InputReader = new LineEnumerator(InputFilePath);

			PushBackOldOutputFilesIfNeeded(OutputFilePath);

			m_OutputWriter = new StreamWriter(OutputFilePath);
		}

		#endregion

		#region Methods

		private void Run()
		{
			int testCount = int.Parse(InputReader.Current);
			InputReader.MoveNext();

			SolverBase solver = SolverBase.Create(InputReader);
			for (int t = 1; t <= testCount; t++)
			{
				PrintOut("Solving test case #{0}...", t);
				this.InputReader.UpdateTestCase(t);

				string result = solver.SolveTestCase(t);

				OutputResult(t, result);
				PrintOut("Test case #{0} solved! Result:", t);
				PrintOut(result);
			}
		}

		private void OutputResult(int t, string result)
		{
			m_OutputWriter.Write("Case #{0}:", t);

			if (Solver.SKIP_LINE_AFTER_CASE_OUTPUT)
			{
#pragma warning disable 0162
				m_OutputWriter.WriteLine();
#pragma warning restore 0162
			}
			else
			{
				m_OutputWriter.Write(" ");
			}

			m_OutputWriter.WriteLine(result);
		}

		private void PushBackOldOutputFilesIfNeeded(string filePath, int depth = 1)
		{
			if (!File.Exists(filePath))
				return;

			if (depth >= FILE_HISTORY_SIZE)
			{
				File.Delete(filePath);
				return;
			}

			string newFilePath = GetPreviousFilePath(filePath);

			PushBackOldOutputFilesIfNeeded(newFilePath, depth + 1);
			File.Move(filePath, newFilePath);
		}

		private static string GetPreviousFilePath(string filePath)
		{
			string oldFileName = Path.GetFileName(filePath);
			string oldFileDir = Path.GetDirectoryName(filePath);

			string[] fileComponents = oldFileName.Split('.');
			string filePrefix = fileComponents[0];
			string fileExtension = fileComponents.Last();
			int fileCounter;
			if (fileComponents.Length == 2 || !int.TryParse(fileComponents[1], out fileCounter))
			{
				fileCounter = 1;
			}

			string newFileName = string.Format("{0}.{1}.{2}", filePrefix, fileCounter + 1, fileExtension);

			return Path.Combine(oldFileDir, newFileName);
		}

		private static string GetCorrectFilePath(string filePath)
		{
			string oldFileName = Path.GetFileName(filePath);
			string oldFileDir = Path.GetDirectoryName(filePath);

			string[] fileComponents = oldFileName.Split('.');

			string filePrefix = fileComponents[0];
			string fileExtension = fileComponents.Last();

			string newFileName = string.Format("{0}.correct.{1}", filePrefix, fileExtension);

			return Path.Combine(oldFileDir, newFileName);
		}

		public static void PrintOut(string str, params object[] param)
		{
			string formatted = string.Format(str, param);
			Console.WriteLine(formatted);
			Debug.WriteLine(formatted);
		}

		public void Dispose()
		{
			InputReader.Dispose();
			m_OutputWriter.Dispose();
		}

		#endregion
	}
}
