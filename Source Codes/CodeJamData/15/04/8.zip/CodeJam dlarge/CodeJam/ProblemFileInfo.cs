/* www.codertom.com  -  copyright Tom Harrison 2015 */
using System.Collections.Generic;
using System.IO;

namespace CoderTom.CodeJam
{
    public class ProblemFileInfo
    {
        public int TestCaseCount { get; set; }
        public List<TestCase> Cases { get; set; }

        public void SolveAll(string writeToPath)
        {
            using (var stream = File.CreateText(writeToPath))
            {
                for (int i = 0; i < TestCaseCount; i++)
                {
                    stream.WriteLine(string.Format("Case #{0}: {1}", i+1, Cases[i].Solve()));
                }
            }
        }
    }
}