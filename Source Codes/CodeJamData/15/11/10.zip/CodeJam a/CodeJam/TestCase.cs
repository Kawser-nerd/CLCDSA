/* www.codertom.com  -  copyright Tom Harrison 2015 */

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography.X509Certificates;

namespace CoderTom.CodeJam
{
    public class TestCase
    {
        public TestCase()
        {
        }

        public TestCase(StreamReader stream)
        {
            Count = stream.ReadInt();
            Shrooms = stream.ReadIntArray();
        }

        public int Count { get; set; }

        public int[] Shrooms { get; set; }

        public string Solve()
        {
            return MinimumAnyTime() + " " + MinimumConstantRate().ToString();
        }

        private int MinimumAnyTime()
        {
            var eaten = 0;
            var previous = 0;
            foreach (var c in Shrooms)
            {
                eaten += c < previous ? previous - c : 0;
                previous = c;
            }
            return eaten;
        }

        private int MinimumConstantRate()
        {
            var maxRate = 0;
            var previous = 0;
            foreach (var c in Shrooms)
            {
                var rate = (previous - c);
                if (maxRate < rate)
                    maxRate = rate;
                previous = c;
            }

            var onPlate = 0;
            previous = 0;
            var eaten = 0;
            foreach (var c in Shrooms)
            {
                onPlate -= maxRate;
                if (onPlate <= 0)
                    onPlate = 0;

                eaten += previous - onPlate;
                onPlate = c;
                    previous = c;
            }



            return eaten;
        }
    }
}
