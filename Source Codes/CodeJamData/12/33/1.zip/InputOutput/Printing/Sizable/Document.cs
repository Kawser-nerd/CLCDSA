﻿using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using Generic.InputOutput.Printing.Sized;

namespace Generic.InputOutput.Printing.Sizable
{
    public abstract class Document : IPrintable
    {
        public static readonly Document Space = " ";
        public static readonly Document Empty = new WrappedDocument(SizedDocument.Empty);

        public override string ToString()
        {
            return Render(null);
        }

        public Document Print()
        {
            return this;
        }

        public bool IsEmpty
        {
            get { return GetMinimumWidth() == 0; }
        }

        int? minimumWidth;
        public static readonly Document Comma = ',';

        internal int MinimumWidth
        {
            get
            {
                if (minimumWidth.HasValue)
                    return minimumWidth.Value;
                minimumWidth = GetMinimumWidth();
                return minimumWidth.Value;
            }
        }
        internal abstract int GetMinimumWidth();
        internal abstract SizedDocument GetSizedDocument(int? preferredWidth);

        public static implicit operator Document(char input)
        {
            return input.ToString(CultureInfo.InvariantCulture);
        }

        public static implicit operator Document(string input)
        {
            return new WrappedDocument(new Text(input));
        }

        public static Document operator +(Document left, Document right)
        {
            if (left.IsEmpty)
                return right;
            if (right.IsEmpty)
                return left;
            return new LeftRight(left, right);
        }

        public static Document operator -(Document left, Document right)
        {
            return left.Concat(Space, right);
        }

        public Document Concat(Document seperator, Document right)
        {
            if (IsEmpty || right.IsEmpty)
                return this + right;
            return this + seperator + right;
        }

        public static Document operator ^(Document top, Document bottom)
        {
            if (top.IsEmpty)
                return bottom;
            if (bottom.IsEmpty)
                return top;
            return new TopBottom(top, bottom);
        }

        public static String WhiteSpace(int i)
        {
            return new string(Enumerable.Repeat(' ', i).ToArray());
        }

        public Document Indent(int i)
        {
            return new WrappedDocument(new WhiteSpace(i, 0)) + this;
        }

        public string Render(int? size)
        {
            var printingDoc = GetSizedDocument(size);
            var builder = new StringBuilder(printingDoc.Size.X * printingDoc.Size.Y);
            var writer = new StringWriter(builder);
            var line = 0;
            for (; line < printingDoc.Size.Y-1; line++)
            {
                printingDoc.RenderLine(writer, line);
                builder.AppendLine();
            }
            printingDoc.RenderLine(writer, line);
            return builder.ToString();
        }

        public static Document Seperated(Document seperator, params object[] items)
        {
            return items.Seperated(seperator);
        }
    }
}
