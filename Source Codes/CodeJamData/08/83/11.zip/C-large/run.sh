#!/bin/bash
for f in `find . -name \*.java`; do javac $f; done
java gepa.gcj.main.Main --inputDataClass=gepa.gcj.roundSemiEmea.InputDataC --solverClass=gepa.gcj.roundSemiEmea.SolverC --inputFile=C-large.in --outputFile=C-large.out
