package lib;

import java.util.function.BinaryOperator;
import java.util.function.UnaryOperator;

// [0, m) 범위를 반환한다
public class ModularAdjuster {

    public static <T> UnaryOperator<T> of(final BinaryOperator<T> adder, final BinaryOperator<T> modular, final T modulus) {
        return original -> {
            // 이걸 하는셈 (n % m + m) % m
            T canBeNegative = modular.apply(original, modulus);
            T nonNegative = modular.apply(adder.apply(canBeNegative, modulus), modulus);
            return nonNegative;
        };
    }
}
