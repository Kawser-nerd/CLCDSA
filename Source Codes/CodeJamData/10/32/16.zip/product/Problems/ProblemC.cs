﻿using Template;
using Template.Interfaces;

namespace Problems
{
  public class ProblemC : ProblemTemplate
  {
    public ProblemC(ICaseFormatter caseFormatter)
      : base(caseFormatter)
    {
    }

    protected override string SolveOneCase(IInput input)
    {
      var buff = input.ParseInt();

      return "";
    }
  }
}
