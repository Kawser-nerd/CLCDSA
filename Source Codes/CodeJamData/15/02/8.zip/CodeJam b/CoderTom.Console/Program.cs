﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CoderTom.CodeJam;

namespace CoderTom.Console
{
    public class Program
    {
        static void Main(string[] args)
        {
            string filepathin;
            if (args.Count() > 0)
            {
                filepathin = args[0];
            }
            else
            {
                filepathin = System.Console.ReadLine();
            }

            var filepathout = filepathin.Replace(".in", ".out");

            var start = DateTime.Now;

            var parser = new FileParser();
            var input = parser.Parse(filepathin);
            input.SolveAll(filepathout);

            var end = DateTime.Now;

            System.Console.WriteLine("done in "  + (end - start).TotalSeconds + "s");
        }
    }
}
