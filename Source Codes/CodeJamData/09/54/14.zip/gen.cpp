#include<iostream>
#include<cstring>
#include<algorithm>
#include<sstream>
#include<string>
#include<vector>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<cassert>
#include<numeric>
#include<set>
#include<map>
#include<queue>
#include<list>
#include<deque>
using namespace std;

#define FOR(i,a,b) for(int i = (a); i < (b); ++i)
#define REP(i,n) FOR(i,0,n)
#define FORE(it,x) for(typeof(x.begin()) it=x.begin();it!=x.end();++it)
#define pb push_back
#define all(x) (x).begin(),(x).end()
#define CLEAR(x,with) memset(x,with,sizeof(x))
#define sz size()
typedef vector<int> VI;
typedef vector<VI> VVI;
typedef long long ll;

vector<long long> a;

const int M = 1000*1000*10;
const ll MAX = 10000000000000ll;

int main()
{
    a.reserve(M*2);
    for(int i = 1; i < M; ++i)
    {
        long long A = i;
        int t = i / 10;

        while(t > 0) 
        {
            A = A * 10 + t % 10;
            t /= 10; 
        }        
        a.pb(A);
    }
    for(int i = 1; i < M/10; ++i)
    {
        long long A = i;
        int t = i;
        while(t > 0) 
        {
            A = A * 10 + t % 10;
            t /= 10; 
        }
        a.pb(A);
    }
    fprintf(stderr, "%d entries. sorting...\n", a.sz);
    sort(all(a));
    printf("%d\n", a.sz);
    REP(i,a.sz) printf("%Ld\n", a[i]);
}

