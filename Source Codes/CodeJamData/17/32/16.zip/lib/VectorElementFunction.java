package lib;

public interface VectorElementFunction<T> {
    T at(int i);
}
