package generic;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileProcessor {

	public static void process(String problemName, String fileName){
		try {
		Class<?> solverClass = null;
			solverClass = Class.forName(problemName);
			System.out.println("Processing file \"" + fileName + "\"");
				Solver solver = (Solver) solverClass.newInstance();
			File inFile = new File(fileName);
			Scanner inScanner = new Scanner(inFile);
			InUtils.setScanner(inScanner);
			File outFile = new File(fileName.replace(".in", ".out"));
			PrintWriter outWriter = new PrintWriter(outFile);
			if(!inScanner.hasNext())
				System.out.println("Empty file");
				else{
				int numberOfCases = Integer.parseInt(inScanner.nextLine());
				for(int i=1; i<=numberOfCases; i++){
					outWriter.print("Case #" + i + ": ");
					String caseSolution = solver.solveCase();
					outWriter.print(caseSolution);
					if(i != numberOfCases)
						outWriter.println();
					}
					inScanner.close();
					outWriter.flush();
					outWriter.close();	
				}
			} catch (FileNotFoundException e) {
				System.out.println("Error: test file not found.");
		} catch (InstantiationException e) {
			System.out.println("Problem at solver class instantiation.");
		} catch (IllegalAccessException e) {
			System.out.println("Problem at solver class instantiation.");
		} catch (ClassNotFoundException e1) {
			System.out.println("Solver class not found.");
			} catch (Exception e){
				e.printStackTrace();
		}
	}

}
