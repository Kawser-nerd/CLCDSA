package pl.javahussars.Standing_Ovation;

class TestCase {

	int[] people;

	public TestCase(int[] people) {
		this.people = people;
	}

	String resolve() {
		int addedPeople = 0;
		int amountOfStandingPeople = people[0];

		for (int i = 1; i < people.length; i++) {
			if (amountOfStandingPeople < i) {
				addedPeople++;
				amountOfStandingPeople++;
			}

			amountOfStandingPeople += people[i];
		}

		return "" + addedPeople;
	}

}
