package lib;

import java.util.Arrays;

public class Circle {
    public final Point center;
    public final double radius;

    public Circle(Point center, double radius) {
        this.center = center;
        this.radius = radius;
    }

    @Override
    public String toString() {
        return Arrays.asList(center, radius).toString();
    }
}
