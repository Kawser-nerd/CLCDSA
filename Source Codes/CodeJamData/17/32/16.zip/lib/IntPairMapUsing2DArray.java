package lib;

public class IntPairMapUsing2DArray {
    public static MapFactory<IntPair> of(int size1, int size2) {
        return MapFactoryUsing2DArray.of(size1, size2, pair -> pair.v1, pair -> pair.v2);
    }
}
