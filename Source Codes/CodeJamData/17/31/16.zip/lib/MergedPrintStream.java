package lib;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

public class MergedPrintStream {

    static PrintStream of(PrintStream ps1, PrintStream ps2) {
        return new PrintStream(new OutputStream() {
            @Override
            public void write(int b) throws IOException {
                ps1.write(b);
                ps2.write(b);
            }

            @Override
            public void flush() throws IOException {
                ps1.flush();
                ps2.flush();
            }

            @Override
            public void close() throws IOException {
                ps1.close();
                ps2.close();
            }
        }, true);
    }
}
