﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Google_Code_Jam.Problems
{
    class OsmosProblem
    {
        int startingSize;
        IList<int> otherSizes;

        public OsmosProblem(int startingSize, IList<int> otherSizes)
        {
            this.startingSize = startingSize;
            this.otherSizes = otherSizes;
        }

        public int StartingSize
        {
            get { return startingSize; }
        }

        public IList<int> OtherSizes
        {
            get { return otherSizes; }
        }
    }

    class SimpleOsmosis :  Algorithm<OsmosProblem,int>
    {
        public override OsmosProblem Parse(StreamReader reader)
        {
            var ints = JamUtil.ReadInts(reader);
            var otherSizes = JamUtil.ReadInts(reader);
            return new OsmosProblem(ints[0], otherSizes);
        }

        public override int Solve(OsmosProblem problem)
        {
            return (int)StepsRequired(problem.StartingSize, problem.OtherSizes.OrderBy(x => x).ToList());
        }

        static long StepsRequired(long currentSize, IList<int> enemiesLeft)
        {
            if (enemiesLeft.Count == 0)
                return 0;

            var nextEnemy = enemiesLeft[0];
            if (currentSize > nextEnemy)
                return StepsRequired(currentSize + nextEnemy,enemiesLeft.Skip(1).ToList());

            long sizeAfterGrowing = currentSize;
            long stepsRequiredToGrow = 0;
            if (sizeAfterGrowing > 1)
            {
                while (sizeAfterGrowing <= nextEnemy)
                {
                    sizeAfterGrowing += sizeAfterGrowing - 1;
                    stepsRequiredToGrow++;
                }
            }
            else
                stepsRequiredToGrow = int.MaxValue;
            sizeAfterGrowing += nextEnemy;
            return Math.Min(enemiesLeft.Count, stepsRequiredToGrow + StepsRequired(sizeAfterGrowing, enemiesLeft.Skip(1).ToList()));
        }

        public override string Print(int solution)
        {
            return solution.ToString();
        }
    }
}
