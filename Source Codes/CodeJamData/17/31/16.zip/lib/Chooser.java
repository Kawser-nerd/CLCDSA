package lib;

public interface Chooser<T> {
    void update(T v);

    T get();
}
