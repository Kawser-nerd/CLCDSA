﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Security.Policy;
using Cmn.Util;
using Gcj.Util;

namespace Gcj.Y2014.R1B.C
{
    public class CSolver : IConcurrentSolver
    {
        public int CCaseGet(Pparser pparser)
        {
            return pparser.Fetch<int>();
        }

        public ConcurrentGcjSolver.DgSolveCase DgSolveCase(Pparser pparser)
        {
            int n;
            int l;
            pparser.Fetch(out n, out l);

            var rgin = pparser.Fetch<string[]>();
            var rgout = pparser.Fetch<string[]>();
            return () => Solve(rgin, rgout);
        }

        private IEnumerable<object> Solve(string[] rgin, string[] rgout)
        {

            yield break;

        }
    }
}
