﻿using System.Collections.Generic;
using Gcj.Util;

namespace Gcj.Y2014.R2.C
{
    internal class CSolver : GcjSolver
    {

        protected override IEnumerable<object> EnobjSolveCase()
        {
            yield break;
        }

    }
}
