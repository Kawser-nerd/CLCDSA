﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Marius.CodeJam
{
    public class CruiseControl: IParalelSolver
    {
        private class Car
        {
            public int Name;
            public char Lane;
            public decimal Position;
            public decimal Speed;
            public decimal Time;

            public Car Clone()
            {
                return (Car)MemberwiseClone();
            }
        }

        private Car[] _cars;
        private decimal _answer = -1m;

        public void ReadInput()
        {
            var n = int.Parse(Console.ReadLine());
            _cars = new Car[n];

            for (int i = 0; i < _cars.Length; i++)
            {
                var input = Console.ReadLine().Split().ToArray();
                _cars[i] = new Car();
                _cars[i].Name = i;
                _cars[i].Lane = input[0][0];
                _cars[i].Speed = int.Parse(input[1]);
                _cars[i].Position = int.Parse(input[2]);
            }
        }

        public void WriteAnswer(int caseNumber)
        {
            Console.Write("Case #{0}: ", caseNumber);
            if (_answer < 0m)
                Console.WriteLine("Possible");
            else
                Console.WriteLine("{0:F5}", _answer);
        }

        public void SolveAsync()
        {
            var cars = Clone(_cars);
            var q = new Queue<Car[]>();
            q.Enqueue(cars);

            var run = 0m;
            var set = new HashSet<string>();
            while (q.Count > 0)
            {
                cars = q.Dequeue();

                var hash = GetHash(cars);
                if (set.Contains(hash))
                    continue;

                set.Add(hash);

                var t = decimal.MaxValue;

                var left = cars.Where(s => s.Lane == 'L').OrderBy(s => s.Position).ToArray();
                var right = cars.Where(s => s.Lane == 'R').OrderBy(s => s.Position).ToArray();

                t = Time(t, left);
                t = Time(t, right);

                if (t == decimal.MaxValue)
                    return;

                var clone = Run(cars, t);
                var index = Find(clone, _cars[0]);
                if (clone[index].Position - _cars[0].Position > run)
                    run = clone[index].Position - _cars[0].Position;

                Drive(q, clone);
            }

            _answer = run / _cars[0].Speed;
        }

        private static Car[] Run(Car[] cars, decimal t)
        {
            var clone = cars.OrderBy(s => s.Position).Select(s => s.Clone()).ToArray();
            for (int i = 0; i < clone.Length; i++)
            {
                clone[i].Position += clone[i].Speed * t;
                clone[i].Time += t;
            }
            return clone;
        }

        private string GetHash(Car[] cars)
        {
            return string.Join(",", cars.Where(s => s.Lane == 'R').OrderBy(s => s.Position).Select(s => s.Name)) + "|" + string.Join(",", cars.Where(s => s.Lane == 'L').OrderBy(s => s.Position).Select(s => s.Name));
        }

        private static decimal Time(decimal t, Car[] lane)
        {
            for (int i = 1; i < lane.Length; i++)
            {
                if (lane[i - 1].Speed > lane[i].Speed)
                {
                    var time = (lane[i].Position - lane[i - 1].Position - 5) / (lane[i - 1].Speed - lane[i].Speed);
                    if (time < t)
                        t = time;
                }
            }
            return t;
        }

        private static void Drive(Queue<Car[]> list, Car[] original)
        {
            var cars = original.OrderBy(s => s.Position).ToArray();
            var left = original.Where(s => s.Lane == 'L').OrderBy(s => s.Position).ToArray();
            var right = original.Where(s => s.Lane == 'R').OrderBy(s => s.Position).ToArray();

            for (int i = 1; i < left.Length; i++)
            {
                if (left[i - 1].Speed > left[i].Speed)
                {
                    var time = (left[i].Position - left[i - 1].Position - 5) / (left[i - 1].Speed - left[i].Speed);
                    if (time < 0.000000000001m)
                    {
                        Switch(list, cars, left[i - 1]);
                        Switch(list, cars, left[i]);
                    }
                }
            }

            for (int i = 1; i < right.Length; i++)
            {
                if (right[i - 1].Speed > right[i].Speed)
                {
                    var time = (right[i].Position - right[i - 1].Position - 5) / (right[i - 1].Speed - right[i].Speed);
                    if (time < 0.000000000001m)
                    {
                        Switch(list, cars, right[i - 1]);
                        Switch(list, cars, right[i]);
                    }
                }
            }
        }

        private static void Switch(Queue<Car[]> list, Car[] cars, Car target)
        {
            var index = Find(cars, target);
            var less = FindLaneLess(cars, target.Lane, index);
            var more = FindLaneMore(cars, target.Lane, index);

            if (less == -1 || (cars[less].Position + 5) <= cars[index].Position)
            {
                if (more == -1 || cars[more].Position >= (cars[index].Position + 5))
                {
                    var clone = Clone(cars);
                    Switch(clone, index);
                    list.Enqueue(clone);
                }
            }
        }

        private static void Switch(Car[] clone, int index)
        {
            clone[index].Lane = clone[index].Lane == 'R' ? 'L' : 'R';
        }

        private static int Find(Car[] cars, Car current)
        {
            for (int i = 0; i < cars.Length; i++)
            {
                if (cars[i].Name == current.Name)
                    return i;
            }

            throw new Exception();
        }

        private static int FindLaneMore(Car[] cars, char lane, int index)
        {
            for (int i = index + 1; i < cars.Length; i++)
            {
                if (cars[i].Lane != lane)
                    return i;
            }
            return -1;
        }

        private static int FindLaneLess(Car[] cars, char lane, int index)
        {
            for (int i = index - 1; i >= 0; i--)
            {
                if (cars[i].Lane != lane)
                    return i;
            }
            return -1;
        }


        private static Car[] Clone(Car[] input)
        {
            var result = new Car[input.Length];
            for (int i = 0; i < input.Length; i++)
            {
                result[i] = input[i].Clone();
            }

            return result;
        }
    }
}
