package pl.javahussars.Dijkstra;

import java.util.Arrays;

class TestCase {

	Quat[] input, extInput, extInputLeft, extInputRight;
	long X;

	Quat inputReduced;

	public TestCase(String in, long x) {
		this.X = x;
		this.input = new Quat[in.length()];

		for (int i = 0; i < input.length; i++) {
			input[i] = Quat.get(in.charAt(i));
		}

		inputReduced = mutliply(input, 0, input.length - 1);

		if (x <= 6L) {
			this.extInput = new Quat[in.length() * (int) x];

			for (int l = 0; l < x; l++) {
				System.arraycopy(input, 0, extInput, l * input.length, input.length);
			}

		} else { // 3 for left, 3 for right
			this.extInputLeft = new Quat[3 * in.length()];
			this.extInputRight = new Quat[3 * in.length()];

			for (int l = 0; l < 3; l++) {
				System.arraycopy(input, 0, extInputLeft, l * input.length, input.length);
				System.arraycopy(input, 0, extInputRight, l * input.length, input.length);
			}
		}

	}

	MultiplicationResult multiplyUpToI(Quat[] array, Quat startingProduct) {
		Quat product = startingProduct;

		for (int n = 0; n < array.length; n++) {
			product = product.mult(array[n]);
			if (product == Quat.i || product == Quat._i) {
				return new MultiplicationResult(product, n);
			}
		}

		return new MultiplicationResult(product, -1);
	}

	MultiplicationResult multiplyUoToK(Quat[] array, Quat startingProduct) {
		Quat product = startingProduct;

		for (int n = array.length - 1; n >= 0; n--) {
			product = array[n].mult(product);
			if (product == Quat.k || product == Quat._k) {
				return new MultiplicationResult(product, n);
			}
		}

		return new MultiplicationResult(product, -1);
	}

	Quat mutliply(Quat[] chunk, int from, int to) {
		Quat res = chunk[from];

		for (int i = from + 1; i <= to; i++) {
			res = res.mult(chunk[i]);
		}

		return res;
	}

	String resolve() {
		if (inputReduced == Quat.ONE) {
			return "NO";
		}

		if (extInput != null) {
			return resolveSimple();
		} else {
			return resolveComplex();
		}
	}

	private String resolveComplex() {
		MultiplicationResult resultToI = multiplyUpToI(extInputLeft, Quat.ONE);
		MultiplicationResult resultToK = multiplyUoToK(extInputRight, Quat.ONE);

		if (!resultToI.found() || !resultToK.found()) {
			return "NO";
		}

		int jLeftIdx = resultToI.idx + 1;
		int jRightIdx = resultToK.idx - 1;

		Quat leftOnLeft = Quat._ONE;
		Quat leftOnRight = Quat.ONE;

		if (jLeftIdx < extInputLeft.length - 1) {
			leftOnLeft = mutliply(extInputLeft, jLeftIdx, extInputLeft.length - 1);
		}

		if (jRightIdx >= 0) {
			leftOnRight = mutliply(extInputRight, 0, jRightIdx);
		}

		Quat middle = power(this.inputReduced, X - 6L);

		Quat jExpected = leftOnLeft.mult(middle).mult(leftOnRight);

		return reconcileNegtive(resultToI, resultToK, jExpected);
	}

	Quat power(Quat quat, long pow) {
		if (pow < 1L) {
			throw new IllegalArgumentException();
		}

		boolean isEven = pow % 2L == 0L;
		int mod = (int) (pow % 4L);

		if (quat == Quat.ONE || mod == 0L) {
			return Quat.ONE;
		} else if (quat == Quat._ONE) {
			return isEven ? Quat.ONE : Quat._ONE;
		}

		switch (mod) {
		case 1:
			return quat;
		case 2:
			return quat.mult(quat);
		case 3:
			return quat.mult(quat).mult(quat);
		}

		throw new IllegalStateException();
	}

	private String resolveSimple() {
		MultiplicationResult resultToI = multiplyUpToI(extInput, Quat.ONE);
		MultiplicationResult resultToK = multiplyUoToK(extInput, Quat.ONE);

		if (!resultToI.found() || !resultToK.found()) {
			return "NO";
		}

		int jLeftIdx = resultToI.idx + 1;
		int jRightIdx = resultToK.idx - 1;

		if (jRightIdx < jLeftIdx) {
			return "NO";
		}

		Quat jExpected = mutliply(extInput, jLeftIdx, jRightIdx);
		return reconcileNegtive(resultToI, resultToK, jExpected);
	}

	private String reconcileNegtive(MultiplicationResult resultToI, MultiplicationResult resultToK, Quat jExpected) {
		if (jExpected != Quat.j && jExpected != Quat._j) {
			return "NO";
		}

		int evenVer = 0;
		if (!resultToI.quat.positive) {
			evenVer++;
		}

		if (!resultToK.quat.positive) {
			evenVer++;
		}

		if (!jExpected.positive) {
			evenVer++;
		}

		return evenVer % 2 == 0 ? "YES" : "NO";
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TestCase [input=").append(Arrays.toString(input)).append(", X=").append(X).append("]");
		return builder.toString();
	}
}

class MultiplicationResult {
	Quat quat;
	int idx;

	public MultiplicationResult(Quat quat, int idx) {
		this.quat = quat;
		this.idx = idx;
	}

	boolean found() {
		return idx != -1;
	}
}
