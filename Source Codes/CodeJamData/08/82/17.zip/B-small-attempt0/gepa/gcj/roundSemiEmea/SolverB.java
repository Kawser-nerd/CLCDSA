/**
 * 
 */
package gepa.gcj.roundSemiEmea;

import gepa.gcj.main.InputData;
import gepa.gcj.main.Result;
import gepa.gcj.main.Solver;
import gepa.gcj.main.result.SResult;

/**
 * @author gepa
 *
 */
public class SolverB extends Solver {

    int[][] segment;

    @Override
    public void init() {
    }

    int[] buf;

    int getMin(int last) {
        if (last == 0) {
            return 0;
        }
        if (buf[last] >= 0) {
            return buf[last];
        }
        int xMin = Integer.MAX_VALUE - 10000;
        for (int i = 0; i < segment.length; i++) {
            if (segment[i][0] <= last && segment[i][1] >= last) {
                int x = 1 + getMin(segment[i][0] - 1);
                if (x < xMin) {
                    xMin = x;
                }
            }
        }
        buf[last] = xMin;
        return buf[last];
    }
    
    @Override
    public Result solve(InputData data) {
        InputDataB d = (InputDataB)data;
        int aMin = Integer.MAX_VALUE;
        for (int c1 = 0; c1 < d.nextC; c1++) {
            for (int c2 = 0; c2 < d.nextC; c2++) {
                for (int c3 = 0; c3 < d.nextC; c3++) {
                    int c = 0;
                    for (int i = 0; i < d.from.length; i++) {
                        if (d.col[i] == c1 || d.col[i] == c2 || d.col[i] == c3) {
                            c++;
                        }
                    }
                    segment = new int[c][2];
                    c = 0;
                    for (int i = 0; i < d.from.length; i++) {
                        if (d.col[i] == c1 || d.col[i] == c2 || d.col[i] == c3) {
                            segment[c][0] = d.from[i];
                            segment[c][1] = d.to[i];
                            c++;
                        }
                    }
                    buf = new int[11000];
                    for (int i = 0; i < 11000; i++) buf[i] = -1;
                    int a = getMin(10000);
                    if (a < aMin) {
                        aMin = a;
                    }
                }
            }
        }
        if (aMin > 1000000) {
            return new SResult("IMPOSSIBLE");
        }
        return new SResult("" + aMin);
    }

}
