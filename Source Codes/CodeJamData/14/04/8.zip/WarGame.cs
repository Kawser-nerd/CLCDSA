﻿using GoogleCodeJam.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeceitfulWar
{
	class WarGame
	{
		private readonly int BLOCK_COUNT;
		private decimal[] m_NaomiBlocks;
		private decimal[] m_KenBlocks;

		public WarGame(InputFile input)
		{
			BLOCK_COUNT = input.ReadIntArray()[0];
			m_NaomiBlocks = input.ReadDecimalArray();
			m_KenBlocks = input.ReadDecimalArray();
		}

		public int GetFairGameScore()
		{
			KenWarStrategy ken1 = new KenWarStrategy(m_KenBlocks);
			NaomiWarStrategy naomi1 = new NaomiWarStrategy(m_NaomiBlocks);
			return PlayGame(ken1, naomi1);
		}

		public int GetCheatingGameScore()
		{
			KenWarStrategy ken2 = new KenWarStrategy(m_KenBlocks);
			NaomiDeceitfulWarStrategy naomi2 = new NaomiDeceitfulWarStrategy(m_NaomiBlocks, m_KenBlocks);
			return PlayGame(ken2, naomi2);
		}

		private int PlayGame(KenWarStrategy ken, INaomiStrategy naomi)
		{
			// Play game, returning Naomi's score.
			int naomiScore = 0;

			for (int i = 0; i < BLOCK_COUNT; i++)
			{
				WarMove naomiMove = naomi.PlayNext();
				WarMove kenMove = ken.RespondTo(naomiMove);

				// For sanity, check that Naomi hasn't broken the rules.
				if (m_KenBlocks.Contains(naomiMove.ClaimedWeight))
					throw new Exception("You're cheating, Naomi!");
				if ((naomiMove.RealWeight > kenMove.RealWeight) != (naomiMove.ClaimedWeight > kenMove.RealWeight))
					throw new Exception("You're cheating, Naomi!");

				if (naomiMove.RealWeight > kenMove.RealWeight)
					naomiScore++;
			}

			return naomiScore;
		}
	}

	public class WarMove
	{
		public readonly decimal RealWeight;
		public readonly decimal ClaimedWeight;

		public WarMove(decimal weight)
		{
			RealWeight = weight;
			ClaimedWeight = weight;
		}

		public WarMove(decimal weight, decimal claimed)
		{
			RealWeight = weight;
			ClaimedWeight = claimed;
		}
	}

	public class KenWarStrategy
	{
		private readonly List<decimal> m_RemainingBlocks;

		public KenWarStrategy(decimal[] blocks)
		{
			// Order by weight (smaller first).
			m_RemainingBlocks = blocks.OrderBy(d => d).ToList();
		}

		public WarMove RespondTo(WarMove naomiMove)
		{
			// (Remember Ken cannot access RealWeight).
			decimal enemyBlock = naomiMove.ClaimedWeight;

			if (enemyBlock > m_RemainingBlocks[m_RemainingBlocks.Count - 1])
			{
				// If Naomi's block is bigger than any of mine, discard the lowest one.
				decimal played = m_RemainingBlocks[0];
				m_RemainingBlocks.RemoveAt(0);
				return new WarMove(played);
			}
			else
			{
				// Otherwise play the lowest one (first in the collection) among all that beat it.
				decimal played = m_RemainingBlocks.Find(b => b > enemyBlock);
				m_RemainingBlocks.Remove(played);
				return new WarMove(played);
			}
		}
	}

	public interface INaomiStrategy
	{
		WarMove PlayNext();
	}

	public class NaomiWarStrategy : INaomiStrategy
	{
		private readonly List<decimal> m_RemainingBlocks;

		public NaomiWarStrategy(decimal[] blocks)
		{
			// Order by weight (smaller first).
			m_RemainingBlocks = blocks.OrderBy(d => d).ToList();
		}

		public WarMove PlayNext()
		{
			// Always play biggest.
			decimal played = m_RemainingBlocks[m_RemainingBlocks.Count - 1];
			m_RemainingBlocks.RemoveAt(m_RemainingBlocks.Count - 1);
			return new WarMove(played);
		}
	}

	public class NaomiDeceitfulWarStrategy : INaomiStrategy
	{
		private readonly List<decimal> m_RemainingBlocks;
		private readonly List<decimal> m_KenRemainingBlocks;
		private KenWarStrategy m_KenStrategy;

		private static readonly decimal SAFE_MARGIN = new Decimal(Math.Pow(10, -7));


		public NaomiDeceitfulWarStrategy(decimal[] blocks, decimal[] kenBlocks)
		{
			// Order by weight (smaller first).
			m_RemainingBlocks = blocks.OrderBy(d => d).ToList();
			m_KenRemainingBlocks = kenBlocks.OrderBy(d => d).ToList();

			// This is just to avoid replicating Ken's respondTo() method.
			m_KenStrategy = new KenWarStrategy(kenBlocks);
		}

		public WarMove PlayNext()
		{
			WarMove move = ChooseNext();

			// After choosing a move, update the list of Ken's blocks.
			WarMove kenMove = m_KenStrategy.RespondTo(move);
			m_KenRemainingBlocks.Remove(kenMove.ClaimedWeight);

			return move;
		}

		private WarMove ChooseNext()
		{
			decimal myLowest = m_RemainingBlocks[0];
			decimal kensLowest = m_KenRemainingBlocks[0];
			decimal kensHighest = m_KenRemainingBlocks[m_KenRemainingBlocks.Count - 1];

			if (myLowest > kensHighest)
			{
				// No need to lie, play lowest and win.
				WarMove move = new WarMove(myLowest);
				m_RemainingBlocks.RemoveAt(0);
				return move;
			}
			else if (myLowest > kensLowest)
			{
				// If my lowest weight is higher than Ken's lowest weight, falsely claim it's greatest 
				// than his highest weight. That way we will win a round with it, because he will play his 
				// lowest weight thinking the round is already lost.
				WarMove move = new WarMove(myLowest, kensHighest + SAFE_MARGIN);
				m_RemainingBlocks.RemoveAt(0);
				return move;
			}
			else
			{
				// Otherwise, play lowest weight falsely claiming it's ALMOST as much as Ken's highest
				// (thus he will be forced to use it to win).
				decimal claimed = kensHighest - SAFE_MARGIN;
				WarMove move = new WarMove(myLowest, claimed);
				m_RemainingBlocks.RemoveAt(0);
				return move;
			}


			/*
			// 2) Play lowest weight to win the round, and either force Ken to discard highest one, or win the round.
			if (myLowest > kensHighest)
			{
				// No need to lie.
				WarMove move = new WarMove(myLowest);
				m_RemainingBlocks.RemoveAt(0);
				return move;
			}


			else
			{
				decimal claimed = kensHighest - SAFE_MARGIN;
				WarMove move = new WarMove(myLowest, claimed);
				m_RemainingBlocks.RemoveAt(0);
				return move;
			}
			 */ 
		}
	}
}
