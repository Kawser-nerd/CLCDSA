﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using JamHelpers;

namespace R1b_B_Hotdog
{

	class Program : ProgramBase
	{
		static void Main(string[] args)
		{
			new Program().Run();
		}

		public override void RunCase()
		{
			int[] header = ReadLine().Split().ToInt();
			int lineCount = header[0];
			int d = header[1];
			List<Int64> startingPositions = new List<Int64>();
			for (int i = 0; i < lineCount; i++)
			{
				var line = ReadLine().Split().ToInt();
				int p = line[0];
				int c = line[1];
				for (int j = 0; j < c; j++)
					startingPositions.Add(p);
			}
			long prevTarget = long.MinValue;
			long worstDist = 0;
			foreach (long start in startingPositions)
			{
				long target = prevTarget + d;
				if (target < start)
					target = start;
				long dist = target - start;
				if (dist > worstDist)
					worstDist = dist;
				prevTarget = target;
			}
			WriteLine(CaseStr + " " + (worstDist * 0.5).ToStringInv());
		}
	}
}
