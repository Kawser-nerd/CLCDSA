﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Generic.Common;

namespace Google_Code_Jam.Problems.Diamonds
{
    class Problem : DefaultObject
    {
        IList<Node> nodes;

        public Problem(IList<Node> nodes)
        {
            this.nodes = nodes;
        }

        public IList<Node> Nodes
        {
            get { return nodes; }
        }
    }

    class Node : DefaultObject
    {
        ISet<Node> parents;
        int index;

        public Node(ISet<Node> parents, int index)
        {
            this.parents = parents;
            this.index = index;
        }

        public ISet<Node> Parents
        {
            get { return parents; }
        }

        public int Index
        {
            get { return index; }
        }
    }
}
