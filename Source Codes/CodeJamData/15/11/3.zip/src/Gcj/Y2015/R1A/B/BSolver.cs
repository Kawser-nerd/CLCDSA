﻿using System.Collections.Generic;
using Gcj.Util;

namespace Gcj.Y2015.R1A.B
{
    class BSolver : GcjSolver
    {
        protected override IEnumerable<object> EnobjSolveCase()
        {
            yield break;
        }

    }
}
