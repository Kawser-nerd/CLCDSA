﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Generic.Maths.Vectors;
using Generic.Containers.Collections.Dictionaries;

namespace Google_Code_Jam.Problems
{
    class WallProblem
    {
        IList<WallTribe> tribes;

        public WallProblem(IList<WallTribe> tribes)
        {
            this.tribes = tribes;
        }

        public IList<WallTribe> Tribes
        {
            get { return tribes; }
        }
    }

    class WallTribe
    {
        int startingDay;
        int attackCount;
        IntVector2 startEnd;
        int initialStrength;
        int dayDelta;
        int distanceDelta;
        int strengthDelta;

        public WallTribe(int startingDay, int attackCount, IntVector2 startEnd, int initialStrength, int dayDelta, int distanceDelta, int strengthDelta)
        {
            this.startingDay = startingDay;
            this.attackCount = attackCount;
            this.startEnd = startEnd;
            this.initialStrength = initialStrength;
            this.dayDelta = dayDelta;
            this.distanceDelta = distanceDelta;
            this.strengthDelta = strengthDelta;
        }

        public int StartingDay
        {
            get { return startingDay; }
        }

        public int AttackCount
        {
            get { return attackCount; }
        }

        public IntVector2 StartEnd
        {
            get { return startEnd; }
        }

        public int InitialStrength
        {
            get { return initialStrength; }
        }

        public int DayDelta
        {
            get { return dayDelta; }
        }

        public int DistanceDelta
        {
            get { return distanceDelta; }
        }

        public int StrengthDelta
        {
            get { return strengthDelta; }
        }
    }

    class GreatWall : Algorithm<WallProblem,int>
    {
        public override WallProblem Parse(StreamReader reader)
        {
            var tribeCount = JamUtil.ReadInts(reader)[0];
            var tribes = new List<WallTribe>();
            for(var i = 0 ;i<tribeCount;i++)
            {
                var tribeInts = JamUtil.ReadInts(reader);
                tribes.Add(new WallTribe(tribeInts[0], tribeInts[1], new IntVector2(tribeInts[2], tribeInts[3]), tribeInts[4], tribeInts[5], tribeInts[6], tribeInts[7]));
            }
            return new WallProblem(tribes);
        }

        public override int Solve(WallProblem problem)
        {
            var result = 0;
            var day = 0;
            var attacksLeft = problem.Tribes.ToDictionary(tribe => tribe, tribe => tribe.AttackCount);
            var nextAttack = problem.Tribes.ToDictionary(tribe => tribe, tribe => tribe.StartingDay);
            var wall = new Dictionary<int, int>();
            var newWallHeights = new Dictionary<int, int>();
            var tribePositions = problem.Tribes.ToDictionary(tribe => tribe, tribe => tribe.StartEnd);
            var attackHeights = problem.Tribes.ToDictionary(tribe => tribe, tribe => tribe.InitialStrength);
            while(nextAttack.Any())
            {
                newWallHeights.Clear();
                day = nextAttack.Values.OrderBy(x => x).First();
                var attackingTribes = nextAttack.Where(kv => kv.Value == day).Select(kv => kv.Key).ToList();
                foreach(var tribe in attackingTribes)
                {
                    var attacksLeftForTribe = attacksLeft[tribe];
                    if (attacksLeftForTribe == 0)
                    {
                        nextAttack.Remove(tribe);
                        continue;
                    }

                    var currentPosition = tribePositions[tribe];
                    var success = false;
                    var attackHeight = attackHeights[tribe];
                    for(int wallSpot = currentPosition.X;wallSpot < currentPosition.Y;wallSpot++)
                    {
                        var spotHeight = wall.GetOrDefault(wallSpot);
                        if (spotHeight < attackHeight)
                        {
                            success = true;
                            newWallHeights[wallSpot] = Math.Max(newWallHeights.GetOrDefault(wallSpot),attackHeight);
                        }
                    }
                    if (success)
                        result++;

                    attacksLeft[tribe] = attacksLeftForTribe - 1;
                    nextAttack[tribe] = day + tribe.DayDelta;
                    attackHeights[tribe] = attackHeight + tribe.StrengthDelta;
                    tribePositions[tribe] = currentPosition + new IntVector2(tribe.DistanceDelta, tribe.DistanceDelta);
                }

                foreach (var kv in newWallHeights)
                    wall[kv.Key] = kv.Value;
            }
            return result;
        }

        public override string Print(int solution)
        {
            return solution.ToString();
        }
    }
}
