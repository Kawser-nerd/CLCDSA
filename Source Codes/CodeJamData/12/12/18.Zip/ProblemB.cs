﻿namespace CodeJam.Problems
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using CodeJam2011;

    public class ProblemB : ProblemBase
    {
        private class Level
        {
            public int A { get; set; }
            public int B { get; set; }
            public bool solvedA { get; set; }
            public bool solvedB { get; set; }

            public int solveB()
            {
                int x = 0;
                if (!solvedA)
                    x++;
                if (!solvedB)
                    x++;
                solvedA = true;
                solvedB = true;
                return x;
            }

            public int solveA()
            {
                int x = 0;
                if (!solvedA)
                    x++;
                solvedA = true;
                return x;
            }
        }

        private class CompA : IComparer<Level>
        {
            public int Compare(Level x, Level y)
            {
                int a = x.A.CompareTo(y.A);

                if (a == 0)
                    return -x.B.CompareTo(y.B);

                return a;
            }
        }

        private class CompB : IComparer<Level>
        {
            public int Compare(Level x, Level y)
            {
                return x.B.CompareTo(y.B);
            }
        }

        protected override string SolveOneCase(InputHelper input)
        {
            int N = input.GetInt();

            var sa = new List<Level>();
            var sb = new List<Level>();

            for (int i = 0; i < N; i++)
            {
                var l = new Level() {A = input.GetInt(), B = input.GetInt()};
                sa.Add(l);
                sb.Add(l);
            }

            sa.Sort(new CompA());
            sb.Sort(new CompB());

            int b = 0;
            int a = 0;

            int stars = 0;
            int moves = 0;

//            try
//            {
                while (stars < N*2)
                {
                    if (sb[b].B <= stars)
                    {
                        int t = sb[b].solveB();
                        stars += t;
                        b++;

                        if (t > 0) moves++;
                        continue;
                    }

                    int stars1 = stars;
                    var yy = (from x in sa
                              where x.A <= stars1 && !x.solvedA
                              orderby x.B descending
                              select x);
                    var y = yy.FirstOrDefault(); 



                    if (y == null)
                        return "Too Bad";


                    int v = y.solveA();
                    stars += v;
                    if (v > 0)
                        moves++;

                    continue;


                }





                return moves.ToString();
//            }
//            catch (Exception e)
//            {
//                int x;
//            }
//            return "";
        }


    }
}