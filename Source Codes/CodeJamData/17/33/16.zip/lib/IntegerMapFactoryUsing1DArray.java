package lib;

public class IntegerMapFactoryUsing1DArray {
    public static MapFactory<Integer> of(int size) {
        return MapFactoryUsing1DArray.of(size, v -> v);
    }
}
