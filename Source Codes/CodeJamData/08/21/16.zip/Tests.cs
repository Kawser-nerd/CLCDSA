using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace tc1
{
    [TestFixture]
    public class Tests
    {
        [Test]
        public void Test()
        {
            Problem t = new Problem();
            //Assert.AreEqual(@"", t.Solve(@""));
            Assert.AreEqual(
@"Case #1: 1
Case #2: 2", 
              t.Solve(
@"2
4 10 7 1 2 0 1 20
6 2 0 2 1 1 2 11"));
        }


        const double cmpE = 1E-7;
        const double cmpD = 1E-7;
        bool AssertRealEq(double a1, double a2)
        {
            bool res = false;
            if (a1 == a2) return true;
            bool abs = Math.Abs(a1 - a2) < cmpE;
            if (a1 == -a2)
                res = abs;
            else
            {
                bool rel = Math.Abs(a1 - a2) < cmpE * (a1 + a2);
                res = abs;// && rel;
            }
            if (!res)
                throw new ArgumentException(string.Format("Expected {0}, got {1}", a1, a2));
            return res;
        }
    }
}


