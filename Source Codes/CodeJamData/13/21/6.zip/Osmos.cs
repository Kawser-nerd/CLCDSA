﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class Osmos : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            FileWrapper.Process<Osmos>(args);
        }
        #endregion

        public override object Solve()
        {
            var A = In<int[]>()[0];
            var N = Last<int[]>()[1];
            var sz = In<int[]>();

            Array.Sort(sz);

            if (A == 1)
            {
                return N;
            }

            int best = N, curr = 0;
            for (int i = 0; i < N; i++)
            {
                while (sz[i] >= A)
                {
                    A += (A - 1);
                    curr++;
                }
                A += sz[i];
                best = Math.Min(best, curr + N - (i + 1));
            }

            return best;
        }
    }
}
