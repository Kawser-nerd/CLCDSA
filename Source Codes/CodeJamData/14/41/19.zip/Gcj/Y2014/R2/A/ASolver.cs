﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cmn.Util;
using Gcj.Util;

namespace Gcj.Y2014.R2.A
{
    internal class ASolver : GcjSolver
    {

        protected override IEnumerable<object> EnobjSolveCase()
        {
            int cf;
            int max;
            Fetch(out cf, out max);

            var rgs = Fetch<List<int>>();
            rgs.Sort();
            rgs.Reverse();

            var cdisc = 0;
            for(;;)
            {
                cdisc++;
                var f1 = rgs.First();
                rgs.RemoveAt(0);
                if (!rgs.Any())
                    break;
                var f2 = rgs.Last();
                if(f1+f2<=max)
                    rgs.RemoveAt(rgs.Count-1);
                if(!rgs.Any())
                    break;
            }
            yield return cdisc;
        }

    }
}
