#file('C-large-practice.in').read()
#

LINES_PER_RECORD = 1 #Can be an integer or a function f(allLines) = list(startLines) or a generator function

def solve(testNum, lines):
    #Problem-specific code
    arg1 = int(lines[0])
    for i in xrange(10**8): pass
    
    return 'Case #{0}: {1} {2}'.format(testNum, 'hi', 'bye')

        

#Problem-specific code ends here##############
    
from multiprocessing import Process, Queue
import time; time.time()
def processAllInput(text, toFile = False, parallel=False):
    fileName = text
    if toFile:
        text = file(fileName).read()
    numTests = int(text.split('\n')[0])
    finalResult = [None]*numTests
    lines = text.split('\n')
    while not lines[-1] or lines[-1].isspace():
        lines.pop()
    
    q = Queue()
    
    it = None
    if type(LINES_PER_RECORD) == int:
        it = xrange(1, numTests*LINES_PER_RECORD+1, LINES_PER_RECORD).__iter__()
    else:
        it = LINES_PER_RECORD().__iter__()
    ranges = [next(it) for _ in range(numTests)]
    ranges.append(len(lines))
    if ranges[-1] <= ranges[-2]:
        raise Exception("The file isn't long enough")
    
    if parallel:
        for i in range(numTests): #queue up solvers
            message = lines[ranges[i]:ranges[i+1]]

            p = Process(target=wrapper, args=(q, i, message) )
            p.start()
            
    laststatustime = 0
    for j in range(numTests): #read off solutions
        if parallel:
            i, line = q.get()
            finalResult[i] = line
        else:
            finalResult[j] = solve(j+1, lines[ranges[j]:ranges[j+1]])
            
        if time.time() - laststatustime > 5 or j+1 is numTests: #print debug information every 5s
            laststatustime = time.time()
            print '{0}/{1} cases tested'.format(j+1, numTests)
        
    if toFile:
        file(fileName.split('.')[0]+'.out', 'w').write('\n'.join(finalResult))
    else:
        print '\n'.join(finalResult)

def wrapper(q, i, lines):
    q.put([i, solve(i+1, lines)])
