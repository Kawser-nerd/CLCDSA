﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam_FlySwatter
{
    class csTestCase
    {
        public double f=0,g=0,R=0,r=0,t=0;
        public double gp, Rp, rp;
        public double Solution = -1;
        
        public void fix()
        {
            gp = g - 2 * f;
            rp = r + f;
            Rp = R - t - f;
        }
    }
}
