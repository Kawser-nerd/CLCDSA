using System;
using CodeJamLibrary.Interfaces;

namespace CodeJamLibrary.Providers
{
  public class AutoLoadFromDirectory_FilePathProvider : IFilePathProvider
  {
    private readonly string directoryPath;

    public AutoLoadFromDirectory_FilePathProvider(string directoryPath)
    {
      this.directoryPath = directoryPath;
    }

    public string GetFilePath()
    {
      return System.IO.Directory.GetFiles(directoryPath)[0];
    }
  }
}