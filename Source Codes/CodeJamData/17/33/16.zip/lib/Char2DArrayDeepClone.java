package lib;

import java.util.Arrays;

public class Char2DArrayDeepClone {
    public static char[][] clone(char[][] original) {
        return Arrays.stream(original)
                .map(char[]::clone)
                .toArray(char[][]::new);
    }
}
