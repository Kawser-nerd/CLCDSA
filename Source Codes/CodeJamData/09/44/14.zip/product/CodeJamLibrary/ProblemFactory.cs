using System;
using System.IO;
using System.Reflection;
using CodeJamLibrary.Interfaces;

namespace CodeJamLibrary
{
  public class ProblemFactory : IProblemFactory
  {
    public const string problemAssembly = "Problems";

    public IProblem GetProblem(ProblemType problemType)
    {
      IProblem problem;

      switch (problemType)
      {
        case ProblemType.ProblemA:
        case ProblemType.ProblemB:
        case ProblemType.ProblemC:
        case ProblemType.ProblemD:

          problem = CreateInstance(problemType.ToString());
          break;

        default:
          problem = new NullProblem();
          break;
      }
      return problem;
    }

    private IProblem CreateInstance(string problemClassName)
    {
      string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, problemAssembly + ".dll");
      Assembly assembly = Assembly.LoadFile(path);

      Type problemType = assembly.GetType(problemAssembly + "." + problemClassName);
      return (IProblem) Activator.CreateInstance(problemType);
    }
  }
}