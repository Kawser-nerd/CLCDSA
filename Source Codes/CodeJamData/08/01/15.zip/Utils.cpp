#if		defined(WIN32)
#include <windows.h>

#elif	defined(unix)
#include <>

#else
#error "Not supported compiler or OS."
#endif

#include "Utils.h"

unsigned long		GetTime()
{
#if	defined(WIN32)

	return GetTickCount();

#elif	defined(unix)

	struct timeval	tval;

	gettimeofday(&tval);

	return tval.tv_sec * 1000 + tval.tv_usec / 1000;
#endif

}

unsigned int		GetCpusNumber()
{
#if	defined(WIN32)

	SYSTEM_INFO		SysInfo;

	GetSystemInfo(&SysInfo);
	return SysInfo.dwNumberOfProcessors;

#elif	defined(__NetBSD__)

#else
	
	return 1;
#endif
}

void	GetString(std::istream &in, std::string &str)
{
	char			buf[129];
	size_t			pos;

	str.erase();

	do
	{
		in.get(buf, 129);
		str.append(buf);
	} while(!in.eof() && in.peek() != '\n');
	if(!in.eof())
		in.get();


	while((pos = str.find(0x09)) != std::string::npos)
		str[pos] = ' ';
	while((pos = str.find("  ")) != std::string::npos)
		str.erase(pos, 1);
	
	if(str[0] == ' ')
		str.erase(0, 1);
	if(str[str.size() - 1] == ' ')
		str.erase((size_t)(str.size() - 1));
}
