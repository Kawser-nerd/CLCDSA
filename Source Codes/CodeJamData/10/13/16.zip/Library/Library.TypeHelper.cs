﻿/*
 * This file is made by Feng JIAO(Email: joephone1983@gmail.com) for solving Code Jam contest problems.
 * This file is licensed under The GNU General Public License (GPLv3). For more information, google "GPLv3"
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public static class TypeHelper
    {
        public static int ToInt32(this string input)
        {
            return Int32.Parse(input);
        }

        public static double ToDouble(this string input)
        {
            return double.Parse(input);
        }

        public static long ToLong(this string input)
        {
            return long.Parse(input);
        }

        public static ulong ToULong(this string input)
        {
            return ulong.Parse(input);
        }

        public static List<T> Initialize<T>(this List<T> list, T value, int length) where T : struct
        {
            if (list.Count() != 0)
            {
                throw new InvalidOperationException("Looks like this List has been initialized.");
            }

            for (int i = 0; i < length; i++)
            {
                list.Add(value);
            }

            return list;
        }

        public static T[] Initialize<T>(this T[] array, T value) where T : struct
        {

            for (int i = 0; i < array.Length; i++)
            {
                array[i] = value;
            }

            return array;
        }
    }
}
