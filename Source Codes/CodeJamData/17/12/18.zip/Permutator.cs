﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
	public interface IPermutatorArrayTrimmer<T>
	{
		bool TrimNeeded(T[] currentBoard, int lastAddedI, Dictionary<T, int> appearanceCounter);
	}

	public interface IPermutatorBoardTrimmer<T>
	{
		bool TrimNeeded(T[][] currentBoard, int lastAddedI, int lastAddedJ, Dictionary<T, int> appearanceCounter);
	}

	public class Permutator<T>
	{
		#region Fields

		private T m_WildCard;
		private IEnumerable<T> m_Values;

		#endregion

		#region C'tor

		public Permutator(IEnumerable<T> values, T wildCard = default(T))
		{
			this.m_WildCard = wildCard;
			this.m_Values = values;
		}

		#endregion

		#region Methods

		public IEnumerable<T[]> GetArrayPermutations(int n, IPermutatorArrayTrimmer<T> trimmer = null)
		{
			T[] result = new T[n];
			if (!object.Equals(m_WildCard, default(T)))
			{
				for (int i = 0; i < n; i++)
				{
					result[i] = m_WildCard;
				}
			}

			Dictionary<T, int> appearanceCounter = new Dictionary<T, int>();
			foreach (T value in m_Values)
			{
				appearanceCounter.Add(value, 0);
			}

			if (m_WildCard != null)
				appearanceCounter.Add(m_WildCard, n);

			return GetArrayPermutationsInternal(result, 0, appearanceCounter, trimmer);
		}

		public IEnumerable<T[][]> GetBoardPermutations(int n, int m, IPermutatorBoardTrimmer<T> trimmer = null)
		{
			T[][] result = new T[n][];
			for (int i = 0; i < n; i++)
			{
				result[i] = new T[m];
				for (int j = 0; j < m; j++)
				{
					result[i][j] = m_WildCard;
				}
			}

			Dictionary<T, int> appearanceCounter = new Dictionary<T, int>();
			foreach (T value in m_Values)
			{
				if (value != null)
					appearanceCounter.Add(value, 0);
			}

			if (m_WildCard != null)
				appearanceCounter.Add(m_WildCard, n * m);

			return GetBoardPermutationsInternal(result, 0, 0, appearanceCounter, trimmer);
		}

		private IEnumerable<T[]> GetArrayPermutationsInternal(T[] result, int i, Dictionary<T, int> appearanceCounter, IPermutatorArrayTrimmer<T> trimmer)
		{
			if (i >= result.Length)
			{
				yield return DeepClone(result);
				yield break;
			}

			T previousValue = m_WildCard;
			foreach (T value in m_Values)
			{
				result[i] = value;

				if (previousValue != null)
					appearanceCounter[previousValue]--;
				if (value != null)
					appearanceCounter[value]++;

				previousValue = value;
				if (trimmer != null && trimmer.TrimNeeded(result, i, appearanceCounter))
					continue;
				foreach (var complete in GetArrayPermutationsInternal(result, i + 1, appearanceCounter, trimmer))
					yield return complete;
			}

			result[i] = m_WildCard;

			if (previousValue != null)
				appearanceCounter[previousValue]--;
			if (m_WildCard != null)
				appearanceCounter[m_WildCard]++;
		}

		private IEnumerable<T[][]> GetBoardPermutationsInternal(T[][] result, int i, int j, Dictionary<T, int> appearanceCounter, IPermutatorBoardTrimmer<T> trimmer)
		{
			if (i >= result.Length)
			{
				yield return DeepClone(result);
				yield break;
			}

			T previousValue = m_WildCard;
			foreach (T value in m_Values)
			{
				result[i][j] = value;

				if (previousValue != null)
					appearanceCounter[previousValue]--;
				if (value != null)
					appearanceCounter[value]++;

				previousValue = value;
				if (trimmer != null && trimmer.TrimNeeded(result, i, j, appearanceCounter))
					continue;
				int nextI = j == result[i].Length - 1 ? i + 1 : i;
				int nextJ = j == result[i].Length - 1 ? 0 : j + 1;
				foreach (var complete in GetBoardPermutationsInternal(result, nextI, nextJ, appearanceCounter, trimmer))
					yield return complete;
			}

			result[i][j] = m_WildCard;
			if (previousValue != null)
				appearanceCounter[previousValue]--;
			if (m_WildCard != null)
				appearanceCounter[m_WildCard]++;
		}

		private T[][] DeepClone(T[][] source)
		{
			T[][] res = new T[source.Length][];
			for (int i = 0; i < source.Length; i++)
			{
				res[i] = new T[source[i].Length];
				for (int j = 0; j < source[i].Length; j++)
				{
					res[i][j] = CloneIfPossible(source[i][j]);
				}
			}
			return res;
		}

		private T[] DeepClone(T[] source)
		{
			T[] res = new T[source.Length];
			for (int i = 0; i < source.Length; i++)
			{
				res[i] = CloneIfPossible(source[i]);
			}

			return res;
		}

		private T CloneIfPossible(T t)
		{
			if (t is ICloneable)
			{
				return (T)(t as ICloneable).Clone();
			}

			return t;
		}

		#endregion
	}
}
