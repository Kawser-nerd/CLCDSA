﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Cmn.Util;
using Gcj.Util;

namespace Gcj.Y2014.R1A.A
{
    internal class ANotSolver : GcjSolver
    {
        private class Nd
        {
            public int ich;
            public char ch;
            public Dictionary<char, Nd> mpndByCh = new Dictionary<char, Nd>();
            public int c0;
            public int c1;
        }

        protected override IEnumerable<object> EnobjSolveCase()
        {
            Fetch<int[]>();

            var rgconfFlow = Fetch<string[]>();
            var ndFlowRoot = new Nd();
            int cch = rgconfFlow.First().Length;
            var rgc1Flow = new int[cch];
            fill(rgconfFlow, ndFlowRoot, rgc1Flow);

            var rgconfTarget = Fetch<string[]>();
            var ndTargetRoot = new Nd();
            var rgc1Target = new int[cch];
            fill(rgconfTarget, ndTargetRoot, rgc1Target);
            int cconf = rgconfFlow.Length;
            Debug.Assert(cconf == rgconfTarget.Length);
            Debug.Assert(cch == rgconfTarget.First().Length);

            var hlmiSwitched = new HashSet<int>();
            var rgiFree = new List<int>();

            for(var i=0;i<cch;i++)
            {
                var c1Flow = rgc1Flow[i];
                var c1Target = rgc1Target[i];

                var fOk = c1Flow == c1Target;
                var fOkSwitched = (cconf - c1Flow) == c1Target;

                if(fOk)
                {
                    if(fOkSwitched)
                    {
                        rgiFree.Add(i);
                    }
                }
                else
                {
                    if(fOkSwitched)
                    {
                        hlmiSwitched.Add(i);
                    }
                    else
                    {
                        yield return "NOT POSSIBLE";
                        yield break;
                    }
                }
            }

            Func<Nd, Nd,bool> dgFOk = null;
            dgFOk = (ndFlow, ndTarget) =>
            {
                var c1Flow = hlmiSwitched.Contains(ndFlow.ich) ? ndFlow.c0 : ndFlow.c1;
                if(c1Flow != ndTarget.c1)
                    return false;
                if(!ndFlow.mpndByCh.Any())
                {
                    Debug.Assert(!ndTarget.mpndByCh.Any());
                    return true;
                }

                return dgFOk(hlmiSwitched.Contains(ndFlow.ich) ? ndFlow.mpndByCh.EnsureGet('1') : ndFlow.mpndByCh.EnsureGet('0'), ndTarget.mpndByCh.EnsureGet('0'))
                       && dgFOk(hlmiSwitched.Contains(ndFlow.ich) ? ndFlow.mpndByCh.EnsureGet('0') : ndFlow.mpndByCh.EnsureGet('1'), ndTarget.mpndByCh.EnsureGet('1'));
            };

            Func<int, bool> dgTry = null;
            dgTry = iifree =>
            {
                if(iifree == rgiFree.Count)
                    return dgFOk(ndFlowRoot, ndTargetRoot);

                if(dgTry(iifree+1))
                    return true;

                hlmiSwitched.Add(rgiFree[iifree]);

                var fokswitched = dgTry(iifree + 1);

                if(!fokswitched)
                    hlmiSwitched.Remove(rgiFree[iifree]);

                return fokswitched;
            };

            if(dgTry(0))
                yield return hlmiSwitched.Count;
            else
            {
                yield return "NOT POSSIBLE";
            }
        }

        private static void fill(string[] rgconfFlow, Nd ndFlowRoot, int[] rgcOneFlow)
        {
            foreach(var conf in rgconfFlow)
            {
                var nd = ndFlowRoot;
                foreach(var vich in conf.Select((v, i) => new {v, i}))
                {
                    if(vich.v == '1')
                    {
                        rgcOneFlow[vich.i]++;
                        nd.c1++;
                    }
                    else
                    {
                        nd.c0++;
                    }
                    nd = nd.mpndByCh.EnsureGet(vich.v, () => new Nd {ch = vich.v, ich = vich.i + 1});
                }
            }
        }
    }
}
