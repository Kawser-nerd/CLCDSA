#ifndef	__GCJ__UTILS_H__
#define	__GCJ__UTILS_H__

#include <string>
#include <iostream>

#ifdef __cplusplus
extern "C"{
#endif 


unsigned long		GetTime();
unsigned int		GetCpusNumber();

#ifdef __cplusplus
}
#endif 

#if		defined(WIN32)
typedef	unsigned __int64	uint64;
#endif

void	GetString(std::istream&, std::string&);

#endif /*__GCJ__UTILS_H__*/
