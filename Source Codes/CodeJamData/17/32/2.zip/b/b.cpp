#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <math.h>
#include <assert.h>
#include <stack>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <functional>
#include <vector>
#include <deque>
#include <utility>
#include <bitset>
#include <limits.h>
#include <time.h>
#include <functional>
#include <numeric>
#include <iostream>

using namespace std;
typedef long long ll;
typedef unsigned long long llu;
typedef double lf;
typedef unsigned int uint;
typedef long double llf;
typedef pair<int, int> pii;
typedef pair<ll, int> pli;
typedef pair<ll, ll> pll;

llf PI = acos(-1);
#define debug(format, ...) printf(format, __VA_ARGS__);

const int MOD = (int)1e9 + 7;

class modint {
  int v;
public:
  modint (): v(0) { }
  modint (ll v): v((v + MOD) % MOD) { }

  bool operator== (modint x) { return v == x.v; }
  bool operator!= (modint x) { return v != x.v; }

  modint operator+ (modint x) { return v + x.v; }
  modint operator- (modint x) { return v - x.v; }
  modint operator* (modint x) { return (ll)v * x.v; }

  modint& operator+= (const modint x) { return *this = (*this + x); }
  modint& operator-= (const modint x) { return *this = (*this - x); }
  modint& operator*= (const modint x) { return *this = (*this * x); }

  int operator* () { return v; }
};

int AC, AJ, A[24*60+10];
int tb[24*60 + 1][12 * 60 + 1][3];
int ans;

int main() {
  scanf("%d%d", &AC, &AJ);
  for(int r = 1; r <= 2; r++) {
    int n = (r == 1) ? AC : AJ;
    for(int i = 0; i < n; i++) {
      int s, e; scanf("%d%d", &s, &e);
      for(int t = s; t < e; t++) A[t] = r;
    }
  }

  ans = 1e9;

  // 각 시각 t마다 A[t]를 쓰면 안 됨. A[t]는 [t, t+1) 구간의 여부

  // tb[t, c, l]: [0, t) 동안 Cameron이 c만큼 일함. 마지막에 일한 사람은 l임.
  for(int r = 1; r <= 2; r++) {
    for(int t = 0; t < 24*60; t++) {
      for(int c = 0; c <= 720; c++) tb[t][c][1] = tb[t][c][2] = 1e9;
    }

    if(A[0] != r) {
      tb[0][r == 1][r] = 0;
    }

    for(int t = 1; t < 24*60; t++) {
      for(int c = 0; c <= 720 && c <= t+1; c++) {
        if(c > 0 && A[t] != 1) {
          tb[t][c][1] = min(tb[t-1][c-1][1], tb[t-1][c-1][2] + 1);
        }
        if(A[t] != 2) {
          tb[t][c][2] = min(tb[t-1][c][2], tb[t-1][c][1] + 1);
        }
      }
    }

    ans = min(ans,
      min(tb[24*60-1][720][3-r] + 1, tb[24*60-1][720][r])
    );
  }

  printf("%d\n", ans);

  return 0;
}
