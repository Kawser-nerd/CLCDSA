﻿/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    class D : ParallelSolution
    {
        override public Func<String> StartSolving()
        {
            long N; int B;
            String [] line = ReadLine().Split();
            N = long.Parse(line[0]);
            B = int.Parse(line[1]);

            return () =>
            {
                int maxNumerals = (int)(Math.Log(N, B)+1);
                HashSet<int>[] taken = new HashSet<int>[maxNumerals];
                for (int i = 0; i < taken.Length; i++)
                    taken[i] = new HashSet<int>();
                return ways(N, B, 0, taken).ToString();
            };
        }

        private static int[] getNumerals(long x, int B)
        {
            List<int> res = new List<int>();
            while (x > 0)
            {
                res.Add((int)(x % B));
                x /= B;
            }
            return res.ToArray();
        }

        private long ways(long N, int B, int last, HashSet<int>[] taken)
        {
            long result = 0;
            if (N == 0)
                return 1;
            for (int next = last + 1; next <= N; next++)
            {
                long newN = N - next;

                int[] numerals = getNumerals(next, B);
                bool bad = false;
                for(int i=0;i<numerals.Length;i++)
                    if (taken[i].Contains(numerals[i]))
                    {
                        bad = true;
                        break;
                    }
                if (!bad)
                {
                    for(int i=0;i<numerals.Length;i++)
                        taken[i].Add(numerals[i]);

                    result += ways(newN, B, next, taken);

                    for(int i=0;i<numerals.Length;i++)
                        taken[i].Remove(numerals[i]);
                }
            }

            return result % 1000000007;
        }
    }
}
