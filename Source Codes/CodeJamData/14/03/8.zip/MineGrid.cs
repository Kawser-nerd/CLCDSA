﻿using GoogleCodeJam.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinesweeperMaster
{
	class MineGrid
	{
		private readonly int ROWS;
		private readonly int COLUMNS;
		private readonly int MINE_COUNT;
		private readonly int CLEAR_COUNT;

		private const char CELL_EMPTY = '.';
		private const char CELL_MINE = '*';
		private const char CELL_CLICK = 'c';

		private const string ANSWER_IMPOSSIBLE = "Impossible\r\n";

		public MineGrid(InputFile input)
		{
			int[] parameters = input.ReadIntArray();
			ROWS = parameters[0];
			COLUMNS = parameters[1];
			MINE_COUNT = parameters[2];
			CLEAR_COUNT = ROWS * COLUMNS - MINE_COUNT;
		}

		public string CalculateAnswer()
		{
			// Special cases.
			// a) No mines, trivial.
			if (MINE_COUNT == 0)
				return GetBoardStringWithCornerClick(BuildBoard(CELL_EMPTY));

			// b) Mines everywhere but one place.
			if (CLEAR_COUNT == 1)
				return GetBoardStringWithCornerClick(BuildBoard(CELL_MINE));

			// c) 1-row grid.
			if (ROWS == 1)
			{
				char[,] board = BuildBoard(CELL_EMPTY);
				for (int i = 0; i < MINE_COUNT; i++)
					board[0, COLUMNS - i - 1] = CELL_MINE;

				return GetBoardStringWithCornerClick(board);
			}

			// d) 1-column grid.
			if (COLUMNS == 1)
			{
				char[,] board = BuildBoard(CELL_EMPTY);
				for (int i = 0; i < MINE_COUNT; i++)
					board[ROWS - i - 1, 0] = CELL_MINE;

				return GetBoardStringWithCornerClick(board);
			}

			// Now we know the grid is at least 2x2.
			// Let's consider that mines are bunched together, and the clear area starts on the (0,0) position.
			// We need to have ALL non-zero cells adjacent to at least ONE zero-cell. This happens if:
			// * The free cells can be distributed in a rectangle with each side >=2, OR
			// * The free cells can be distributed in a rectangle with each side >=2 PLUS an adjacent area of 
			// at least length 2 (only one square left outside means it's adjacent to non-zero cells and therefore
			// won't be shown with the first click.

			// We need at least 4 spaces to build a rectangle.
			if (CLEAR_COUNT < 4)
				return ANSWER_IMPOSSIBLE;

			for (int rectRows = 2; rectRows <= ROWS; rectRows++)
			{
				for (int rectCols = 2; rectCols <= COLUMNS; rectCols++)
				{
					int extras = CLEAR_COUNT - (rectRows * rectCols);

					if (extras > rectRows + 1 && extras > rectCols + 1)
						continue; // We can fill one more row or col and still have enough extras for a strip of length > 1.

					// Possible solution. Draw the initial rectangle.
					char[,] board = BuildBoard(CELL_MINE);
					SetBoardRectangleCells(board, 0, 0, rectRows - 1, rectCols - 1, CELL_EMPTY);

					if (extras == 0)
					{
						// Found a solution with a perfect rectangle. Draw it.
						return GetBoardStringWithCornerClick(board);
					}
					else if (extras >= 2)
					{
						// Try to fit the extra clear cells.
						if (rectRows < ROWS && extras <= rectCols)
						{
							// Place them in a row, below.
							SetBoardRectangleCells(board, rectRows, 0, rectRows, extras - 1, CELL_EMPTY);
							return GetBoardStringWithCornerClick(board);
						}
						else if (rectCols < COLUMNS && extras <= rectRows)
						{
							// Place them in a column, to the right.
							SetBoardRectangleCells(board, 0, rectCols, extras - 1, rectCols, CELL_EMPTY);
							return GetBoardStringWithCornerClick(board);
						}
						else if (rectRows < ROWS - 1 && extras >= 4 && extras <= 2 * rectCols)
						{
							// We don't need to consider more than 2 extra rows (thanks to "continue" condition above).
							int firstExtraRow = extras / 2 + extras % 2;
							int secondExtraRow = extras / 2;
							SetBoardRectangleCells(board, rectRows, 0, rectRows, firstExtraRow - 1, CELL_EMPTY);
							SetBoardRectangleCells(board, rectRows + 1, 0, rectRows + 1, secondExtraRow - 1, CELL_EMPTY);
							return GetBoardStringWithCornerClick(board);
						}
						else if (rectCols < COLUMNS - 1 && extras >= 4 && extras <= 2 * rectRows)
						{
							// We don't need to consider more than 2 extra rows (thanks to "continue" condition above).
							int firstExtraColumn = extras / 2 + extras % 2;
							int secondExtraColumn = extras - firstExtraColumn;
							SetBoardRectangleCells(board, 0, rectCols, firstExtraColumn - 1, rectCols, CELL_EMPTY);
							SetBoardRectangleCells(board, 0, rectCols + 1, secondExtraColumn - 1, rectCols, CELL_EMPTY);
							return GetBoardStringWithCornerClick(board);
						}
					}
				}
			}

			return ANSWER_IMPOSSIBLE;
		}

		private static string GetBoardStringWithCornerClick(char[,] board)
		{
			board[0, 0] = CELL_CLICK;
			return MatrixToString(board);
		}

		private char[,] BuildBoard(char cell)
		{
			char[,] board = new char[ROWS, COLUMNS];
			SetBoardRectangleCells(board, 0, 0, ROWS - 1, COLUMNS - 1, cell);
			return board;
		}

		private void SetBoardRectangleCells(char[,] board, int startRow, int startCol, int endRow, int endCol, char cell)
		{
			for (int i = startRow; i <= endRow; i++)
			{
				for (int j = startCol; j <= endCol; j++)
					board[i, j] = cell;
			}
		}

		private static string MatrixToString(char[,] cells)
		{
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < cells.GetLength(0); i++)
			{
				for (int j = 0; j < cells.GetLength(1); j++)
					sb.Append(cells[i, j]);

				sb.AppendLine();
			}

			return sb.ToString();
		}
	}
}
