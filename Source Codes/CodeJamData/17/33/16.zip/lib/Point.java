package lib;

import java.util.Arrays;

public class Point {
    public final double x, y;

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() {
        return Arrays.asList(x, y).toString();
    }
}
