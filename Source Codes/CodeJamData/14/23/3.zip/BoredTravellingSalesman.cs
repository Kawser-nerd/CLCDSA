﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic;
using System.Globalization;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class BoredTravellingSalesman : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            ProblemSet<BoredTravellingSalesman>.Solve(args);
        }
        #endregion

        public override void Parse(ProblemReader file)
        {
            int[] zips;
            int[][] graph;
            file.Read(out N, out M).Read(N, out zips).Read(M, out graph);
            var Gs = zips.Select(z => new Graph(z)).ToList();
            foreach (var gg in graph)
            {
                var a = gg[0] - 1;
                var b = gg[1] - 1;
                Gs[a].Next.Add(Gs[b]);
                Gs[b].Next.Add(Gs[a]);
            }
            foreach (var g in Gs)
            {
                g.Next.Sort();
            }
            Gs.Sort();
            Seen = new HashSet<Graph>();
            Unseen = new HashSet<Graph>(Gs);
            Curr = new List<Graph>();
            Lock(Gs[0]);
        }

        // ReSharper disable InconsistentNaming
        private int N, M;
        private HashSet<Graph> Seen;
        private HashSet<Graph> Unseen;
        private string Ans;
        private List<Graph> Curr;
        // ReSharper restore InconsistentNaming

        public override object Solve()
        {
            if (Unseen.Any())
            {
                Lock(Curr[0].Next[0]);
            }
            while (Unseen.Any())
            {
                var corr = Curr.Where(c => c.Next.Any()).OrderBy(c => c.Next[0].Zip).ToArray();
                var cx = corr.FirstOrDefault(c => CanFill(Curr.IndexOf(c) + 1));
                if (cx != null)
                {
                    Lock(cx.Next[0]);
                }
                else
                {
                    throw new Exception(":(");
                }
            }
            return Ans;
        }

        public bool CanFill(int p)
        {
            var seen = new HashSet<Graph>();
            var todo = new List<Graph>(Curr.Take(p));
            while (todo.Any())
            {
                var g = todo.First();
                todo.RemoveAt(0);
                foreach (var n in g.Next)
                {
                    if (seen.Add(n)) todo.Add(n);
                }
            }
            return seen.Count == Unseen.Count;
        }

        void Lock(Graph g)
        {
            Ans += g.Zip.ToString(CultureInfo.InvariantCulture);
            Seen.Add(g);
            Unseen.Remove(g);
            while (Curr.Count > 0 && !Curr.Last().Next.Contains(g)) Curr.RemoveAt(Curr.Count - 1);
            Curr.Add(g);
            foreach (var u in Unseen) u.Next.Remove(g);
            foreach (var u in Seen) u.Next.Remove(g);
        }

        public class Graph : IComparable<Graph>, IEquatable<Graph>
        {
            public Graph(int zip)
            {
                Zip = zip;
                Next = new List<Graph>();
            }

            public int Zip { get; private set; }
            public List<Graph> Next { get; private set; }

            public int CompareTo(Graph other)
            {
                return Zip.CompareTo(other.Zip);
            }

            public bool Equals(Graph other)
            {
                return Zip.Equals(other.Zip);
            }

            public override int GetHashCode()
            {
                return Zip.GetHashCode();
            }

            public override string ToString()
            {
                return "Graph " + Zip;
            }
        }

        public override IEnumerable<Action> StaticInitialize()
        {
            yield return () =>
            {

            };
        }
    }
}
