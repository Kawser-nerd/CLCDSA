package lib;

import java.util.function.BinaryOperator;

public class Power {
    public static <T> T calc(T value, int exponent, BinaryOperator<T> multiplier) {
        Assertion.check(exponent >= 1);
        T r = null;
        T f = value;
        for (int mask = 1; ; mask <<= 1) {
            if ((exponent & mask) != 0)
                r = (r == null) ? f : multiplier.apply(r, f);
            if (mask == Integer.highestOneBit(exponent))
                break;
            f = multiplier.apply(f, f);
        }
        return r;
    }
}
