﻿/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace CodeJam
{
    class A : ParallelSolution
    {
        int[] primes = createPrimes();
        static int[] createPrimes()
        {
            int max = 1000000;
            bool[] notPrime = new bool[max];
            List<int> primes = new List<int>();
            for (int i = 2; i < max; i++)
            {
                if (!notPrime[i])
                {
                    primes.Add(i);
                    if (i <= 1000)
                        for (int j = i * i; j < max; j += i)
                            notPrime[j] = true;
                }
            }
            return primes.ToArray();
        }

        int tenToD(int D)
        {
            int res = 1;
            for (int i = 0; i < D; i++)
                res *= 10;
            return res;
        }

        void swap(ref int a, ref int b)
        {
            int tmp = a;
            a = b;
            b = tmp;
        }

        static int modSafe(long a, int p)
        {
            while (a < 0)
                a += p * (long)1000000;
            return (int)(a % p);
        }

        int multSafe(int a, int b, int p)
        {
            return modSafe(a * (long)b, p);
        }

        int inverse(int n, int p)
        {
            int x = n;
            int y = p;

            // a*x + b*y = 1%p
            int al = 1;
            int bl = 0;
            int ar = 0;
            int br = 1;

            while (true)
            {
                if (x > y)
                {
                    swap(ref al, ref ar);
                    swap(ref bl, ref br);
                    swap(ref x, ref y);
                }
                if (x == 0)
                    break;
                int d = y / x;
                y -= x * d;
                ar = modSafe(ar - al * (long)d,p);
                br = modSafe(br - bl * (long)d, p);
                ar %= p;
                br %= p;
            }

            if ((ar * (long)n) % p == 1)
                return ar;
            else
                throw new Exception(":(");
        }

        override public Func<String> StartSolving()
        {
            int D,K;
            ReadInts(out D, out K);
            var outputs = ReadInts(K);

            return () =>
                {
                    if (outputs.Length < 2)
                        return "I don't know.";
                    for(int i=0;i<outputs.Length;i++)
                        for(int j=i+1;j<outputs.Length;j++)
                            if(outputs[i] == outputs[j])
                            {
                                return outputs[outputs.Length-(j-i)].ToString();
                            }


                    List<int> possible = new List<int>();
                    int SN = -1;
                    foreach (int p in primes.Where(prime => prime < tenToD(D)))
                    {
                        bool pBad = false;
                        for (int i = 0; i < K; i++)
                            if (outputs[i] >= p)
                                pBad = true;

                        if (pBad)
                            continue;

                        int BM = modSafe(-outputs[0], p);
                        int BA = modSafe(outputs[1], p);

                        int a = -1;

                        for (int i = 1; i < K; i++)
                        {
                            int AM = modSafe(outputs[i - 1] + BM, p);
                            int AR = modSafe(outputs[i] - BA, p);

                            if (AM == 0)
                            {
                                if(AR != 0)
                                    goto pBad;
                            }
                            else
                            {
                                int newA = multSafe(AR, inverse(AM, p), p);
                                if(a!=-1 && a!=newA)
                                    goto pBad;
                                a = newA;
                            }
                        }

                        int sn;
                        if(a==-1) // :(
                        {
                            return "I don't know.";
                            throw new Exception("should happen only when they are equal");
                        }
                        else
                        {
                            sn = (multSafe(outputs.Last(), a, p) + multSafe(a, BM, p) + BA)%p;
                        }

                        if(SN != -1 && SN!=sn)
                            return "I don't know.";
                        SN = sn;

                    pBad: ;
                    }
                    return SN.ToString();
                };
        }
    }
}
