package lib;

import java.util.Arrays;
import java.util.stream.IntStream;

public class Int4DArrayFiller {
    public static void fill(int[][][][] a, int value) {
        IntStream.range(0, a.length).forEach(i -> fill(a[i], value));
    }

    private static void fill(int[][][] a, int value) {
        IntStream.range(0, a.length).forEach(j -> fill(a[j], value));
    }

    private static void fill(int[][] a, int value) {
        IntStream.range(0, a.length).forEach(k -> Arrays.fill(a[k], value));
    }
}
