import time, math, operator, re
from helper import *

starttime = starttimer()

filename = "C%s.%s"
# 0 for test, 1 for small, 2 for large
is_large = 1

mode_str = '' if is_large == 0 else '-small-attempt0' if is_large == 1 else '-large'
infile = filename % (mode_str, 'in')
outfile = filename % (mode_str, 'out')

# parse input
inf = open(infile, 'r')
outf = open(outfile, 'w')

def simulate(N, cars, after=0.0, cant_swap=None):
    # returns change speed time or None
    # each car 5 m long       

    # (time, i, j, C), i from behind
    time, back, front, lane = None, None, None, None
    for i in range(N):
        for j in range(i+1, N):
            if cars[i][0] <> cars[j][0]: continue
            if (cars[i][1] - cars[j][1]) * (cars[i][2] - cars[j][2]) < 0:
                ntime = 1.0 * (abs(cars[j][2] - cars[i][2]) - 5) / abs(cars[j][1] - cars[i][1])
                # look for collisions at or after the after time (so multiple lane changes at once can happen)
                if cmp(ntime, after) >= 0 and (time == None or ntime < time):
                    if cars[i][2] < cars[j][2]: time, back, front, lane = (ntime, i, j, cars[i][0])
                    else: time, back, front, lane = (ntime, j, i, cars[i][0])

    if time == None: return None    

    if case == 9:
        print time, back, front, lane, cant_swap
        
    
    # check no problems
    back_pos = cars[back][2] + cars[back][1] * time
    bchange = True
    fchange = True
    for i in range(N):
        if cars[i][0] == lane: continue
        nback_pos = cars[i][2] + cars[i][1] * time
        if cmp(nback_pos, back_pos) > 0 and cmp(nback_pos, back_pos+5) < 0:
            # neither car can change lanes
            return time
        
        bchange1 = cmp(nback_pos, back_pos - 5) <= 0 or cmp(nback_pos, back_pos + 5) >= 0
        fchange1 = cmp(nback_pos, back_pos) <= 0 or cmp(nback_pos, back_pos + 10) >= 0
        assert bchange1 or fchange1
        bchange = bchange and bchange1
        fchange = fchange and fchange1

    if case == 9:
        print '   ', bchange, fchange

    if not bchange and not fchange: return time

    # move back car and simulate
    best = time
    if bchange and back <> cant_swap:
        assert cars[back][0] == lane
        cars[back][0] = 1 - lane
        change_time = simulate(N, cars, time, back)
        cars[back][0] = lane
        if change_time == None: return None
        best = max(best, change_time)

    if fchange and front <> cant_swap:
        assert cars[front][0] == lane
        cars[front][0] = 1 - lane
        change_time = simulate(N, cars, time, front)
        cars[front][0] = lane
        if change_time == None: return None
        best = max(best, change_time)

    return best

try:
    T = readI(inf)

    for case in range(1, T+1):
        N = readI(inf)
        cars = []
        for i in range(N):
            line = readL(inf).split(' ')
            if line[0] == 'L': cars.append([0, int(line[1]), int(line[2])])
            else: cars.append([1, int(line[1]), int(line[2])])

        if case == 9: print cars
        
        output = simulate(N, cars)                       

        if output == None:
            outf.write("Case #%d: %s\n" % (case, "Possible"))
            print("Case #%d: %s" % (case, "Possible"))
        else:
            outf.write("Case #%d: %.7f\n" % (case, output))
            print("Case #%d: %.7f" % (case, output))        
        
finally:
    inf.close()
    outf.close()

endtimer(starttime)
