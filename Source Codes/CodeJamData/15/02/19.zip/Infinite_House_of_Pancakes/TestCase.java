package pl.javahussars.Infinite_House_of_Pancakes;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

class TestCase {

	int[] pancakesOnPlates; // descending order

	public TestCase(int[] pancakesOnPlates) {
		this.pancakesOnPlates = pancakesOnPlates;
		Arrays.sort(this.pancakesOnPlates);
		IntTools.reverse(this.pancakesOnPlates);
	}

	Integer[] generateMaxOnPlates() {
		Set<Integer> maxOnPlates = new HashSet<>();
		int maxAmountOfPancakes = pancakesOnPlates[0];

		for (int i = 1; i <= maxAmountOfPancakes; i++) {
			maxOnPlates.add(maxAmountOfPancakes / i);
		}

		return maxOnPlates.toArray(new Integer[0]);
	}

	String resolve() {
		int minResult = pancakesOnPlates[0];
		int nextResult;

		for (int maxOnPlate = pancakesOnPlates[0]; maxOnPlate >= 1; maxOnPlate--) {
			nextResult = maxOnPlate + movesRequired(maxOnPlate);
			if (nextResult <= minResult) {
				minResult = nextResult;
			}
		}

		return "" + minResult;
	}

	int movesRequired(int maxOnPlate) {
		int movesRequired = 0;

		for (int pancakes : pancakesOnPlates) {
			if (pancakes <= maxOnPlate) {
				break;
			}

			movesRequired += pancakes / maxOnPlate;

			if (pancakes % maxOnPlate == 0) {
				movesRequired--;
			}
		}

		return movesRequired;
	}

}
