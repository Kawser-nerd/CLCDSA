﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class FairAndSquare : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            FAS = Heuristic(105).ToArray();
            FileWrapper.Process<FairAndSquare>(args);
        }
        #endregion

        private static BigInteger[] FAS { get; set; }

        private BigInteger A { get; set; }
        private BigInteger B { get; set; }

        public override object Solve()
        {
            A = BigInteger.Parse(In<string[]>()[0]);
            B = BigInteger.Parse(Last<string[]>()[1]);

            return FAS.Count(x => x >= A && x <= B);
        }

        private static IEnumerable<BigInteger> BruteForce(int exp)
        {
            var z = (long)BigInteger.Pow(new BigInteger(10), exp);
            for (long i = 1, ix; (ix = i * i) < z; i++)
                if (IsPalindrome(i.ToString()) && IsPalindrome(ix.ToString()))
                    yield return new BigInteger(i);
        }

        private static bool IsPalindrome(string s)
        {
            int i = 0, j = s.Length - 1;
            for (; i <= j && s[i] == s[j]; i++, j--) ;
            return i > j;
        }

        private static bool IsPalindromeSquared(string s)
        {
            var big = BigInteger.Parse(s);
            s = (big * big).ToString();
            int i = 0, j = s.Length - 1;
            for (; i <= j && s[i] == s[j]; i++, j--) ;
            return i > j;
        }

        private static IEnumerable<BigInteger> Heuristic(int exp)
        {
            HashSet<string>[] valid = new HashSet<string>[exp / 2 + 1];
            valid[0] = new HashSet<string> { "1", "2", "3" };

            for (int i = 1; i < exp / 2 + 1; i++)
            {
                valid[i] = new HashSet<string>();
                foreach (var x in valid[i - 1])
                {
                    if (i % 2 == 1)
                    {
                        string cand = x.Substring(0, i / 2 + 1) + x.Substring(i / 2, i / 2 + 1);
                        if (IsPalindromeSquared(cand))
                            valid[i].Add(cand);
                    }
                    else
                    {
                        foreach (var mid in new[] { "0", "1", "2" })
                        {
                            string cand = x.Substring(0, i / 2) + mid + x.Substring(i / 2, i / 2);
                            if (IsPalindromeSquared(cand))
                                valid[i].Add(cand);
                        }
                    }
                }
            }

            return valid.SelectMany(hs => hs.Select(s => BigInteger.Parse(s) * BigInteger.Parse(s)));
        }
    }
}
