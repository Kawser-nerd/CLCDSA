﻿using System.Numerics;
using System.Text;

namespace Q2
{
	public static class StringUtils
	{
		public static string Repeat(this string s, int n)
		{
			StringBuilder builder = new StringBuilder(s.Length * n);

			for (int i = 0; i < n; i++)
			{
				builder.Append(s);
			}

			return builder.ToString();
		}

		public static T[] Repeat<T>(this T t, int n)
		{
			var res = new T[n];
			for (int i = 0; i < n; i++)
				res[i] = t;

			return res;
		}
	}
}
