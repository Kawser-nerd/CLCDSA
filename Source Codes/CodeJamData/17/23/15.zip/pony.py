#! /usr/bin/env python
from __future__ import print_function, division
try:
    range = xrange
except NameError:
    pass

# import collections
# import functools
# import itertools as it
import numpy as np # See http://www.numpy.org
# import sympy as sp # See http://sympy.org/en/index.html
import gmpy2 # See https://code.google.com/p/gmpy/
# import networkx as nx # See http://networkx.github.io/

import os
import sys
# MY MODULES - available at https://github.com/lackofcheese/CodeJamLib/
sys.path.append(os.path.join(
    os.environ['GOOGLE_DRIVE'], 'Coding', 'GCJ', 'CodeJamLib'))
import codejam_io

def toks_line(f_in, fun=int):
    return [fun(k) for k in f_in.readline().split()]

def process_first(f_in):
    num_cases = int(f_in.readline())
    other_data = None
    return num_cases, other_data

def process_case(f_in, f_out, case_no, other_data=None):
    N, Q = toks_line(f_in)

    horses = []
    for i in range(N):
        E, S = toks_line(f_in)
        horses.append((E, S))

    dists = []
    for i in range(N):
        Ds = toks_line(f_in)
        dists.append(Ds)

    pairs = []
    for i in range(Q):
        U, V = toks_line(f_in)
        pairs.append((U-1, V-1))

    times = solve(N, Q, horses, dists, pairs)
    print("Case #{}: ".format(case_no), file=f_out, end='')
    for t in times:
        print("{:.10f} ".format(t), file=f_out, end='')
    print("", file=f_out)

def solve(N, Q, horses, dists, pairs):
    dists = np.array(dists, dtype=object)
    for i in range(N):
        dists[i, i] = gmpy2.mpz(0)
    for i in range(N):
        for j in range(N):
            d = dists[i, j]
            if d == -1:
                dists[i,j] = np.inf
            else:
                dists[i,j] = gmpy2.mpz(d)
    # print(dists.astype('float'))
    for k in range(N):
        for i in range(N):
            for j in range(N):
                other = dists[i,k] + dists[k,j]
                if dists[i,j] > other:
                    dists[i,j] = other
    # print(dists.astype('float'))


    times = np.ones((N, N)) * np.inf
    for i in range(N):
        times[i, i] = 0
    for start in range(N):
        E, S = horses[start]
        for end in range(N):
            d = dists[start, end]
            if d <= E:
                times[start, end] = d / S
    for k in range(N):
        for i in range(N):
            for j in range(N):
                other = times[i,k] + times[k,j]
                if times[i,j] > other:
                    times[i,j] = other
    # print(times)

    pair_times = []
    for U, V in pairs:
        pair_times.append(times[U, V])
    return pair_times

def solve_small(N, Q, horses, dists, pairs):
    # print(N, Q, horses, dists, pairs)
    dists2 = []
    for i in range(N-1):
        dists2.append(gmpy2.mpz(dists[i][i+1]))

    pair_dists = np.zeros((N, N), dtype=object)
    for i in range(N):
        pair_dists[i, i] = gmpy2.mpz(0)
        for j in range(i+1, N):
            pair_dists[i, j] = pair_dists[i, j-1] + dists2[j-1]
    # print(pair_dists)

    fastest_times = np.ones(N) * np.inf
    fastest_times[N-1] = 0
    for start in range(N-2, -1, -1):
        best_time = np.inf
        E, S = horses[start]
        for end in range(start+1, N):
            dist = pair_dists[start, end]
            # print(start, end, dist)
            if dist > E:
                continue
            time = (dist / S) + fastest_times[end]
            if time < best_time:
                best_time = time
        fastest_times[start] = best_time
    # print(fastest_times)
    return [fastest_times[0]]

if __name__ == '__main__':
    codejam_io.process_input(process_case, process_first, __file__)
