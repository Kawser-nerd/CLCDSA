﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class UpAndDown : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            ProblemSet<UpAndDown>.Solve(args);
        }
        #endregion

        public override void Parse(ProblemReader file)
        {
            file.Read(out N).Read(out A);
        }

        // ReSharper disable InconsistentNaming
        private int N;
        private int[] A;
        // ReSharper restore InconsistentNaming

        public override object Solve()
        {
            var best = int.MaxValue;

            for (var n = 0; n < N; n++)
            {
                var next = 0;
                var narr = A.ToList();
                while (narr.Count > 2)
                {
                    var mn = narr.Min();
                    var ix = narr.IndexOf(mn);
                    next += Math.Min(ix, narr.Count - 1 - ix);
                    narr.RemoveAt(ix);
                }
                best = Math.Min(best, next);
            }

            return best;
        }

        public override IEnumerable<Action> StaticInitialize()
        {
            yield return () =>
            {

            };
        }
    }
}
