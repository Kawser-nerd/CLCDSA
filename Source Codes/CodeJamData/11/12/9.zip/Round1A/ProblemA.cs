﻿using System.IO;
using System.Numerics;
using Paraiba.IO;

namespace Round1A {
	public class ProblemA {
		public static void Solve(TextReader input, TextWriter output) {
			var sc = new Scanner(input);
			var nTestCases = sc.NextInt32();
			for (int iTestCases = 0; iTestCases < nTestCases; iTestCases++) {
				var n = sc.NextBigInteger();
				var pd = sc.NextBigInteger();
				var pg = sc.NextBigInteger();

				if (pg == 100) {
					if (pd == 100)
						output.WriteLine("Case #" + (iTestCases + 1) + ": Possible");
					else
						output.WriteLine("Case #" + (iTestCases + 1) + ": Broken");
					continue;
				}

				if (pd == 0) {
					output.WriteLine("Case #" + (iTestCases + 1) + ": Possible");
					continue;
				}

				if (pg == 0) {
					output.WriteLine("Case #" + (iTestCases + 1) + ": Broken");
					continue;
				}

				var ld = Lcm(pd, 100);
				var wd = ld / pd;

				if (wd <= n)
					output.WriteLine("Case #" + (iTestCases + 1) + ": Possible");
				else
					output.WriteLine("Case #" + (iTestCases + 1) + ": Broken");
			}
		}

		public static BigInteger Gcd(BigInteger a, BigInteger b)
		{
			if (a == 0)
				return b;
			return Gcd(b % a, a);
		}

		public static BigInteger Lcm(BigInteger a, BigInteger b)
		{
			return a * b / Gcd(a, b);
		}
	}
}