package lib;

import java.util.List;

public class ReversedList {
    public static <T> List<T> of(List<T> o) {
        return ListUsingGetter.create(o.size(), i -> o.get(o.size() - 1 - i));
    }
}
