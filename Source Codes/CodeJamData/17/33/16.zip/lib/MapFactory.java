package lib;

import java.util.Map;

// TODO 그냥 put, get 만 있는 타입을 도입할까. Dictionary. 
public interface MapFactory<K> {
    <V> Map<K, V> create();
}
