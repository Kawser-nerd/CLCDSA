import sys
def run(f):
    T = int(input())

    for case in range(T):
        res = f()
        
        if res is None:
            res = "IMPOSSIBLE"

        print("Case #{}: {}".format(case+1, res))
        print("Case #{} solved".format(case+1), file=sys.stderr)

def input_array_of(f):
    return [f(x) for x in input().strip().split()]