import generic.InUtils;
import generic.Solver;

// Unsolved

public class QC implements Solver {

	@Override
	public String solveCase() {
		InUtils.oneInt();
		int[] values = InUtils.oneLineIntArray();
		int result = 0;
		int lowestValue = Integer.MAX_VALUE;
		int sum = 0;
		for(int value : values){
			result = result ^ value;
			if(value<lowestValue)
				lowestValue = value;
			sum += value;
		}
		if(result != 0)
			return "NO";
		return Integer.toString(sum-lowestValue);
	}
}
