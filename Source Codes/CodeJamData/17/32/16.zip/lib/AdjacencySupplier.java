package lib;

import java.util.stream.Stream;

public interface AdjacencySupplier<V> {
    Stream<TargetAndWeight<V>> get(V source);
}
