package lib;

public class LongSystem {

    public static final FloorDivisibleSystem<Long> INSTANCE = new FloorDivisibleSystem<Long>() {
        @Override
        public Long one() {
            return 1L;
        }

        @Override
        public Long add(Long a, Long b) {
            return a + b;
        }

        @Override
        public Long subtract(Long a, Long b) {
            return a - b;
        }

        @Override
        public Long floorDivide(Long a, Long b) {
            return a / b;
        }

        @Override
        public int compare(Long a, Long b) {
            return a.compareTo(b);
        }
    };
}
