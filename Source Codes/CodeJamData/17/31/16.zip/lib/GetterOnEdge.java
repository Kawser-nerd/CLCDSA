package lib;

public interface GetterOnEdge {
    int get(int v1, int v2);
}
