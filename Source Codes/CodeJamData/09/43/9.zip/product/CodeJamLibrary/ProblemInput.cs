﻿using CodeJamLibrary.Interfaces;

namespace CodeJamLibrary
{
  public class ProblemInput : IProblemInput
  {
    private readonly ITextReaderProvider textReaderProvider;


    public ProblemInput(ITextReaderProvider textReaderProvider)
    {
      this.textReaderProvider = textReaderProvider;
    }

    public string ReadLine()
    {
      return textReaderProvider.GetReader().ReadLine();
    }

    public string[] SplitLine()
    {
      return this.ReadLine().Split(' ');
    }

    public int[] ParseInt()
    {
      var tokens = SplitLine();
      var length = tokens.Length;

      var values = new int[length];

      for (int i = 0; i < length; i++)
      {
        values[i] = int.Parse(tokens[i]);
      }

      return values;
    }
  }
}