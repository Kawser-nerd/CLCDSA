﻿using Gcj.Util;
using Gcj.Y2014.R1B.A;

namespace Gcj
{
    internal class Program
    {

        static void Main(string[] args)
        {
            ConcurrentGcjSolver.Solve<ASolver>(false);
        }
    }
}
