﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace codejam
{
    class ml
    {

        /// <summary>
        /// Convierte cualquier valor de base 10 a base bas
        /// </summary>
        /// <param name="val">valor en base 10</param>
        /// <param name="bas">base de destino, de 2 a 9</param>
        /// <returns></returns>
        public static string Conv2Base(int val, int bas)
        {
            string res = "";

            if (bas == 10)
                return val.ToString();

            while (true)
            {
                int x = val % bas;
                res = x.ToString() + res;

                val = (val - x) / bas;

                if (val == 0)
                    break;
            }

            return res;
        }

        /// <summary>
        /// Devuelve todas las combinaciones de sierta longitud con caracteres de s
        /// </summary>
        /// <param name="s"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public static IEnumerable<string> GetCombinations(string s, int length)
        {
            if (length > s.Length || length == 0)
            {
                return new[] { String.Empty };
            }
            if (length == 1)
            {
                return s.Select(c => new string(new[] { c }));
            }
            return from c in s
                   from combination in GetCombinations(
                       s.Remove(s.IndexOf(c), 1),
                       length - 1
                   )
                   where (c+combination).Length == length
                   select c + combination;
        }

        /// <summary>
        /// Devuelve todas las combinaciones de sierta longitud con caracteres de s
        /// </summary>
        /// <param name="s"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public static IEnumerable<string> GetCombinationsReducidos(string s, int length)
        {
            if (length > s.Length || length == 0)
            {
                return new[] { String.Empty };
            }
            if (length == 1)
            {
                return s.Select(c => new string(new[] { c }));
            }
            return from c in s
                   from combination in GetCombinationsReducidos(
                       s.Remove(0, s.IndexOf(c) + 1),
                       length - 1
                   )
                   where (c + combination).Length == length
                   select c + combination;
        }


        ///Convierte cualquier valor a un int32
        public static int toi<T>(T s) { return Convert.ToInt32(s); }

        public static int[] toi<T>(T[] s)
        {
            int[] res = new int[s.Length];
            for (int i = 0; i < s.Length; i++)
            {
                res[i] = Convert.ToInt32(s[i]);
            }
            return res;
        }

        ///Escribe un mensaje en la consola
        public static T tell<T>(T msg) { Console.WriteLine(msg.ToString()); return msg; }

        #region puts

        /// Coloca los promeros dos valores de la matriz en las variables a y b
        public static void put<T>(T[] s, out int a, out int b)
        {
            int i = 0;
            a = toi(s[i++]);
            b = toi(s[i++]);
        }
        /// Coloca los promeros tres valores de la matriz en las variables a, b y c
        public static void put<T>(T[] s, out int a, out int b, out int c)
        {
            int i = 0;
            a = toi(s[i++]);
            b = toi(s[i++]);
            c = toi(s[i++]);
        }

        /// Coloca los promeros cuatro valores de la matriz en las variables a, b, c y d
        public static void put<T>(T[] s, out int a, out int b, out int c, out int d)
        {
            int i = 0;
            a = toi(s[i++]);
            b = toi(s[i++]);
            c = toi(s[i++]);
            d = toi(s[i++]);
        }

        /// Coloca los promeros cinco valores de la matriz en las variables a, b, c, d y e
        public static void put<T>(T[] s, out int a, out int b, out int c, out int d, out int e)
        {
            int i = 0;
            a = toi(s[i++]);
            b = toi(s[i++]);
            c = toi(s[i++]);
            d = toi(s[i++]);
            e = toi(s[i++]);
        }
        /// Coloca los promeros cinco valores de la matriz en las variables a, b, c, d, e y f
        public static void put<T>(T[] s, out int a, out int b, out int c, out int d, out int e, out int f)
        {
            int i = 0;
            a = toi(s[i++]);
            b = toi(s[i++]);
            c = toi(s[i++]);
            d = toi(s[i++]);
            e = toi(s[i++]);
            f = toi(s[i++]);
        }
        #endregion

        #region Funcion split
        ///Genera una matriz a partir de subcadenas en s, separadas por espacios ' '
        public static string[] split(string s)
        {
            char[] c = { ' ' };
            return s.Split(c);
        }

        ///Genera una matriz a partir de subcadenas en s, separadas por caracter c1
        public static string[] split(string s, char c1)
        {
            char[] c = { c1 };
            return s.Split(c);
        }

        ///Genera una matriz a partir de subcadenas en s, separadas por caracter c1, c2
        public static string[] split(string s, char c1, char c2)
        {
            char[] c = { c1, c2 };
            return s.Split(c);
        }

        ///Genera una matriz a partir de subcadenas en s, separadas por caracter c1, c2, c3
        public static string[] split(string s, char c1, char c2, char c3)
        {
            char[] c = { c1, c2, c3 };
            return s.Split(c);
        }

        ///Genera una matriz a partir de la primera linea del flujo s, separadas por espacios ' '
        public static string[] split(System.IO.StreamReader s)
        {
            char[] c = { ' ' };
            return s.ReadLine().Split(c);
        }

        ///Genera una matriz a partir de la primera linea del flujo s, separadas por caracter c1
        public static string[] split(System.IO.StreamReader s, char c1)
        {
            char[] c = { c1 };
            return s.ReadLine().Split(c);
        }

        ///Genera una matriz a partir de la primera linea del flujo s, separadas por caracter c1, c2
        public static string[] split(System.IO.StreamReader s, char c1, char c2)
        {
            char[] c = { c1, c2 };
            return s.ReadLine().Split(c);
        }

        ///Genera una matriz a partir de la primera linea del flujo s, separadas por caracter c1,c2,c3
        public static string[] split(System.IO.StreamReader s, char c1, char c2, char c3)
        {
            char[] c = { c1, c2, c3 };
            return s.ReadLine().Split(c);
        }
        #endregion
    }

    public class myStreamWriter : System.IO.StreamWriter
    {
        public myStreamWriter(string path) : base(path) { }
        public myStreamWriter(Stream sr) : base(sr) { }
        public myStreamWriter(string path, bool debug) : base(path) { _Debug = debug; ml.tell("Debuging " + path); }
        public myStreamWriter(Stream sr, bool debug) : base(sr) { _Debug = debug; ml.tell("Debuging ..."); }

        private bool _Debug = false;
        public bool Debug { get { return _Debug; } }

        public class TIPO { }

        /// AUTOMATRIX = {"default"};
        public static myStreamWriter operator +(myStreamWriter sw, object s)
        {
            sw.Write(s.ToString());
            if (sw._Debug)
                Console.Write(s.ToString());
            return sw;
        }
        public static myStreamWriter operator -(myStreamWriter sw, object s)
        {
            sw.WriteLine();
            sw.Write(s.ToString());
            if (sw._Debug)
            {
                Console.WriteLine();
                Console.Write(s.ToString());
            }
            return sw;
        }

        /// <summary>
        /// Escribe un salto de linea
        /// </summary>
        public string nl { get { this.WriteLine(); if (_Debug)Console.WriteLine(); return ""; } }
    }


}
