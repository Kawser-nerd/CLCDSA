﻿using System;
using System.IO;
using Template.Interfaces;

namespace Template
{
  public class Output : IOutput
  {
    private readonly TextWriter textWriter;

    public Output(TextWriter textWriter)
    {
      this.textWriter = textWriter;
    }

    public void Close()
    {
      textWriter.Close();
    }

    public void WriteLine(string value)
    {
      textWriter.WriteLine(value);
      Console.WriteLine(value);
    }
  }
}