﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;

namespace Q3
{
	public abstract class SolverBase
	{
		public const string IMPOSSIBLE = "IMPOSSIBLE";
		private readonly IEnumerator<string> m_InputEnumerator;

		protected SolverBase(IEnumerator<string> enumerator)
		{
			m_InputEnumerator = enumerator;
		}

		public static SolverBase Create(IEnumerator<string> enumerator)
		{
			return new Solver(enumerator);
		}

		public abstract object SolveTestCase(int testCase);

		public virtual bool ResultEqualityComparer(string result1, string result2)
		{
			return result1.Equals(result2) || EqualAsDoubleList(result1, result2);
		}

		protected bool EqualAsDoubleList(string val1, string val2)
		{
			var spl1 = val1.Split(' ');
			var spl2 = val2.Split(' ');
			if (spl1.Length != spl2.Length)
				return false;
			return Enumerable.Range(0, spl1.Length).Select(i => new Tuple<string, string>(spl1[i], spl2[i])).All(t => EqualAsDoubles(t.Item1, t.Item2));
		}

		protected bool EqualAsDoubles(string val1, string val2)
		{
			// Taken from code jam FAQ: https://codejam.withgoogle.com/codejam/resources/faq#5-9
			double val1AsDouble;
			double val2AsDouble;
			if (!double.TryParse(val1, out val1AsDouble) || !double.TryParse(val2, out val2AsDouble))
				return false;

			const double epsilon = 1e-6;

			var absDiff = Math.Abs(val1AsDouble - val2AsDouble);
			if (absDiff <= epsilon)
				return true;

			var abs1 = Math.Abs(val1AsDouble);
			var abs2 = Math.Abs(val2AsDouble);
			if (abs1 <= epsilon || abs2 <= epsilon)
				return false;

			return absDiff / abs1 <= epsilon || absDiff / abs2 <= epsilon;
		}

		protected string GetLine()
		{
			string line = m_InputEnumerator.Current;

			m_InputEnumerator.MoveNext();

			return line;
		}

		protected int GetInt()
		{
			return int.Parse(GetLine());
		}

		protected string[] GetStringList()
		{
			return GetLine().Split(' ');
		}

		protected List<int> GetIntList()
		{
			return GetStringList().Select(int.Parse).ToList();
		}

		protected long GetLong()
		{
			return long.Parse(GetLine());
		}

		protected List<long> GetLongList()
		{
			return GetStringList().Select(long.Parse).ToList();
		}

		protected List<BigInteger> GetBigIntList()
		{
			return GetStringList().Select(BigInteger.Parse).ToList();
		}

		protected BigInteger GetBigInt()
		{
			BigInteger value;
			BigInteger.TryParse(GetLine(), out value);
			return value;
		}

		protected double GetDouble()
		{
			return double.Parse(GetLine());
		}

		protected List<double> GetDoubleList()
		{
			return GetStringList().Select(double.Parse).ToList();
		}

		protected Neighbours<T> GetNeighbours<T>(T[][] board, int x, int y, T defaultValue = default(T))
		{
			return new Neighbours<T>(board, x, y, defaultValue);
		}

		protected T[][] DeepClone<T>(T[][] source, Func<T, T> cloneFunc = null)
		{
			if (cloneFunc == null)
				cloneFunc = t => t;

			T[][] res = new T[source.Length][];
			for (int i = 0; i < source.Length; i++)
			{
				res[i] = new T[source[i].Length];
				for (int j = 0; j < source[i].Length; j++)
				{
					res[i][j] = cloneFunc(source[i][j]);
				}
			}
			return res;
		}

		protected T[] DeepClone<T>(T[] source, Func<T, T> cloneFunc = null)
		{
			if (cloneFunc == null)
				cloneFunc = t => t;

			T[] res = new T[source.Length];
			for (int i = 0; i < source.Length; i++)
			{
				res[i] = cloneFunc(source[i]);
			}

			return res;
		}

		protected void Print<T>(T[] array)
		{
			string toPrint = string.Join(", ", array);
			Program.PrintOut(toPrint);
		}

		protected void Print<T>(T[][] array)
		{
			string toPrint = string.Join(Environment.NewLine, array.Select(arr => string.Join(", ", arr)));
			Program.PrintOut(toPrint);
		}

		protected static IEnumerable<int> Range(int fromInclusive, int toInclusive)
		{
			for (var i = fromInclusive; i <= toInclusive; i++)
			{
				yield return i;
			}
		}
	}
}
