package codejam;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

public class Main {

    public static void main(String[] args) throws Exception {
        if(args.length != 3) {
            System.out.println("Usage: " + Main.class.getName() + " <problemSolverClass> <inputFile> <outputFile>");
        }
        Class cls = Class.forName(args[0]);
        try(BufferedReader in = new BufferedReader(new FileReader(args[1]))) {
            int testCount = Integer.parseInt(in.readLine().trim());
            try(PrintWriter out = new PrintWriter(new FileWriter(args[2]))) {
                for(int i = 1; i <= testCount; i++) {
                    ProblemSolver solver = (ProblemSolver)cls.newInstance();
                    try {
                        out.println("Case #" + i + ": " + solver.solve(in, i));
                    } catch(Throwable t) {
                        System.err.println("Exception during test " + i);
                        t.printStackTrace();
                    }
                    out.flush();
                }
            }
        }
    }
}
