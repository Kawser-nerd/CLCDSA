﻿/*
 * This file(or template) is made by Feng JIAO(Email: joephone1983@gmail.com) for solving Code Jam contest problems.
 * This file(or template) is licensed under The GNU General Public License (GPLv3). For more information, google "GPLv3"
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
using Library;
using System.Threading;
using System.Diagnostics;

namespace Number_Game
{
    class Program
    {

        #region Routine

        static int cn = 0;
        static List<List<String>> inputListD2 = new List<List<String>>();
        static SynchronizedCache<int, String> outputCache = new SynchronizedCache<int, string>();
        static char[] inputSeperators = new char[] { ' ' };
        static void Main(string[] args)
        {
            Console.BufferHeight = 2000;
            Console.BufferWidth = 100;
            Console.WindowHeight = 50;
            Console.WindowWidth = 100;

            if (Config._FileSize != InputFileSize.NoInput)
            {
                inputListD2 = IOHelper.ReadInputFile(out cn, inputSeperators);
            }
            Thread WorkerThread = new Thread(new ThreadStart(Run), Config._StackSize);
            WorkerThread.Priority = ThreadPriority.AboveNormal;

            Config.stopWatch.Reset();
            Config.stopWatch.Start();
            Console.WriteLine("Worker thread is runing...");
            WorkerThread.Start();

            WorkerThread.Join();
            Config.stopWatch.Stop();
            if (Config._FileSize != InputFileSize.NoInput)
            {
                IOHelper.WriteOutputFile(outputCache.ToSortedValueList(true));
            }
            IOHelper.WriteOutputToConsole(inputListD2, outputCache.ToSortedValueList(true));
            Console.WriteLine("Time used in this run: {0}", Config.stopWatch.Elapsed.ToString());
            Console.Beep(1000, 1000);
            Console.ReadLine();
        }

        static List<int> FindIndex()
        {
            throw new NotImplementedException("FindIndex function need to be implemented.");
            //List<int> index = new List<int>(cn);
            //int tempindex = 0;
            //for (int i = 0; i < cn; i++)
            //{
            //    index.Add(tempindex);
            //    tempindex += inputListD2[tempindex][1].ToInt32();
            //    tempindex++;
            //}
            //return index;
        }
        #endregion Routine

        static Program()
        {
            //program configuration here
            Config._StackSize = int.MaxValue / 16;
            Config._ThreadPriority = ThreadPriority.Normal;
            Config._FileSize = InputFileSize.SmallFile;
            Config._ParallelThreadCount = 1;// System.Environment.ProcessorCount;
        }
        //---------------------------------------------------------------------------------------------
        //Main code here:
        public static SynchronizedCache<Pair<int, int>, bool> cache = new SynchronizedCache<Pair<int, int>, bool>();


        private static void Run()
        {
            //List<int> CaseIndex = FindIndex();
            
            Parallel.For(0, cn, delegate(int t)
            {
                int a1 =  inputListD2[t][0].ToInt32();
                int a2 = inputListD2[t][1].ToInt32();
                int b1 = inputListD2[t][2].ToInt32();
                int b2 = inputListD2[t][3].ToInt32();
                int count =0 ;
                for(int i=a1; i<=a2;i++)
                {
                    for (int j = b1; j <= b2; j++)
                    {

                            if (IsAright(i, j))
                            {
                                count++;
                            }

                    }
                }
                outputCache.Add(t, count.ToString());
            });

        }

        private static bool IsAright(int i, int j)
        {
            if(i<j)
            {
                int temp = i;
                i=j;
                j=temp;
            }
            
            if(i==j)
            {
            return false;
            }

            if(i%j==0)
            {
                return true;
            }

            bool returns;
            if(cache.TryGetValue(new Pair<int,int>(i,j),out returns))
            {
                return returns;
            }
            int d = i/j;
                returns = true;
                for (int ii = d; ii >= 1; ii--)
                {
                    returns &= IsAright(i - ii * j, j);
                    if (!returns)
                    {
                        cache.Add(new Pair<int, int>(i, j), true);
                        return true;
                    }
                }

                    cache.Add(new Pair<int, int>(i, j), false);
                    return false;


        }

    }
}