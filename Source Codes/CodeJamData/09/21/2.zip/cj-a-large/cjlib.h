/*
        Copyright (c) 2009  Joseph A. Adams
        All rights reserved.
        
        Redistribution and use in source and binary forms, with or without
        modification, are permitted provided that the following conditions
        are met:
        1. Redistributions of source code must retain the above copyright
           notice, this list of conditions and the following disclaimer.
        2. Redistributions in binary form must reproduce the above copyright
           notice, this list of conditions and the following disclaimer in the
           documentation and/or other materials provided with the distribution.
        3. The name of the author may not be used to endorse or promote products
           derived from this software without specific prior written permission.
        
        THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
        IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
        OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
        IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
        INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
        NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
        DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
        THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
        (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
        THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef CJLIB_H
#define CJLIB_H

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <math.h>
#include <limits.h>
#include <ccan/array/array.h>
#include <ccan/stringmap/stringmap.h>
#include <ccan/array_size/array_size.h>

char *read_line(void);
extern char *line, *word_scan;
extern size_t line_len;
extern size_t lines_read;
char *read_word(void);

#define open cjlib_open
void cjlib_open(const char *filename);

//allocate memory, but don't worry about freeing it
void *alloc(size_t size);
static inline void *alloc_zero(size_t size) {
	void *ret = alloc(size);
	memset(ret, 0, size);
	return ret;
}

//appends the contents of the file at 'filename' to the array
//on success, returns the pointer to the string
//on failure, returns NULL and leaves the array_char alone (other than maybe reallocing it)
char *fgulp(array_char *out, const char *filename);

char *strip_whitespace(const char *str);

void status_print(uint64_t current, uint64_t max);
void status_finished(void);

void scramble(void *base, size_t nmemb, size_t size);

/* Prints the array of unsigned integers with spaces in between and with no
   trailing space.  Prints a newline character afterwards.
	Example: {0,1,2,3} will print as "0 1 2 3\n". */
void print_uints(unsigned int n[], size_t count);

/* Initializes a lexicographic permutation by filling n with
   ascending integers.
	Example: count = 6 sets n[6] to {0,1,2,3,4,5} */
void perm_start(unsigned int n[], unsigned int count);

/* Increments n[count] to the next lexicographic permutation.
   If n[count] is the last permutation (e.g. {5,4,3,2,1,0}), n[count] is reset
     (e.g. {0,1,2,3,4,5}) and perm_next returns 0.
   Otherwise, perm_next returns 1.

   Example:

	unsigned int p[5];
	perm_start(p, 5);
	do {
		print_uints(p, 5);
	} while (perm_next(p, 5));
	
	Outputs:

	0 1 2 3 4
	0 1 2 4 3
	0 1 3 2 4
	...
	4 3 1 2 0
	4 3 2 0 1
	4 3 2 1 0
*/
int perm_next(unsigned int n[], unsigned int count);

//get up to count primes or to the upto mark, whichever comes first
//returns the number of primes generated
unsigned long get_primes_ex(unsigned long prime[], unsigned long count, unsigned long upto);

//stores 'count' prime numbers into 'prime' starting from 2 (e.g. count=4 yields 2 3 5 7)
static inline void get_primes(unsigned long prime[], unsigned long count) {
	unsigned long c = get_primes_ex(prime, count, ULONG_MAX);
	assert(c == count);
}

//stores prime numbers into 'prime' starting at 2 and ending at 'upto' (inclusive)
//Example: get_primes_upto(array, 11) yields 2 3 5 7 11
//To determine storage space, use size_primes_upto
static inline unsigned long get_primes_upto(unsigned long prime[], unsigned long upto) {
	return get_primes_ex(prime, ULONG_MAX, upto);
}

//approximates the number of primes from 2 to upto inclusive
//always overestimates
unsigned long size_primes_upto(unsigned long upto);

//approximates the order of magnitude of 'pc' prime numbers
//always overestimates
unsigned long size_primes(unsigned long pc);

#define countof(array) ARRAY_SIZE(array)

#define swap(a,b) do { \
		typeof(a) __tmp = (a); \
		(a) = (b); \
		(b) = __tmp; \
	} while(0)

//todo:  merge me into the array module
#define array_tail(array) ((array).item[(array).size - 1])

typedef array(char*) array_string;

#endif
