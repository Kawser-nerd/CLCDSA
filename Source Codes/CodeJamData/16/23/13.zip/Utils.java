package template;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;
import java.util.concurrent.*;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.LUDecomposition;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.util.ArithmeticUtils;

public class Utils {
    
    public static void go(int numThreads) {
        long startTime = System.currentTimeMillis();

        try (Scanner scanner = new Scanner(new File("data.in"));
                PrintWriter writer = new PrintWriter(new File("data.out"))) {
            int numTestCases = Integer.valueOf(scanner.nextLine());
            TestCase[] testCases = new TestCase[numTestCases];

            //prepare
            for (int i = 0; i < numTestCases; i++) {
                testCases[i] = new TestCase();
                testCases[i].prepare(scanner);
                testCases[i].setRef(i + 1);
            }
            assert !scanner.hasNext() : "Unexpected text at end of input file";

            //solve
            if (numThreads == 1)
                runAll(testCases);
            else
                runAllMultiThreaded(testCases, numThreads);

            //write
            for (int i = 0; i < numTestCases; i++) {
                writer.print("Case #" + (i + 1) + ": ");
                Object result = testCases[i].getResult();
                writer.println(result);
            }
        }
        catch (FileNotFoundException ex) {
            System.out.println(ex.toString());
        }
        
        long millis = System.currentTimeMillis() - startTime;
        System.out.println("All done, elapsed time " + millis + "ms");        
    }
    

    public static void runAll(TestCase[] testCases) {
        for (int i = 0; i < testCases.length; i++) {
            testCases[i].run();
        }
    }

    public static void runAllMultiThreaded(TestCase[] testCases, int numThreads) {
        ExecutorService executorService = Executors.newFixedThreadPool(numThreads);
        int numTestCases = testCases.length;
        Future<Object>[] futureResults = new Future[numTestCases];
        for (int i = 0; i < numTestCases; i++) {
            futureResults[i] = executorService.submit(testCases[i]);
        }
        executorService.shutdown();
        try {
            executorService.awaitTermination(1, TimeUnit.HOURS);
        } catch (InterruptedException ex) {
        }
        for (int i = 0; i < numTestCases; i++) {
            try {
                futureResults[i].get();
            } catch (InterruptedException | ExecutionException ex) {
                System.out.println("Exception in test case " + (i + 1) + ": " + ex.getCause());
            }
        }
    }

    public static <E extends Comparable<E>> E min(Iterable<E> l) {
        E best = null;
        for (E e : l) {
            if (e == null) continue;
            if (best == null || best.compareTo(e) > 0)
                best = e;
        }
        return best;
    }

    public static <E extends Comparable<E>> E max(Iterable<E> l) {
        E best = null;
        for (E e : l) {
            if (e == null) continue;
            if (best == null || best.compareTo(e) < 0)
                best = e;
        }
        return best;
    }

    public static <E> String join(Iterable<E> l, String delim) {
        StringBuilder sb = new StringBuilder();
        Iterator<E> iter = l.iterator();
        while (iter.hasNext()) {
            E e = iter.next();
            assert e != null;
            sb.append(e.toString());
            if (iter.hasNext())
                sb.append(delim);
        }
        return sb.toString();
    }

    public static String join(int[] l, String delim) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.length; i++) {
            sb.append(l[i]);
            if (i < l.length - 1) sb.append(delim);
        }
        return sb.toString();
    }

    public static String join(long[] l, String delim) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.length; i++) {
            sb.append(l[i]);
            if (i < l.length - 1) sb.append(delim);
        }
        return sb.toString();
    }
    
    public static String join(double[] l, String delim) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.length; i++) {
            sb.append(l[i]);
            if (i < l.length - 1) sb.append(delim);
        }
        return sb.toString();
    }
    
    public static ArrayList<Integer> splitToDigits(long in) {
        return splitToDigits(in, 10);
    }

    public static ArrayList<Integer> splitToDigits(long in, int base) {
        ArrayList<Integer> out = new ArrayList<>();
        while (in > 0) {
            out.add((int) (in % base));
            in /= base;
        }
        Collections.reverse(out);
        return out;
    }

    public static long recombineFromDigits(ArrayList<Integer> digits) {
        return recombineFromDigits(digits, 10);
    }

    public static long recombineFromDigits(ArrayList<Integer> digits, int base) {
        long tot = 0L;
        for (int i = 0; i < digits.size(); i++) {
            tot *= base;
            tot += digits.get(i);
        }
        return tot;
    }

    public static ArrayList<ArrayList<Integer>> allPairs(int lower1, int upper1, int lower2, int upper2, int style) {
        //Style:
        //0 all pairs
        //1 (1) <= (2)
        //2 (1) < (2)

        ArrayList<ArrayList<Integer>> out = new ArrayList<>();

        for (int index1 = lower1; index1 <= upper1; index1++) {
            for (int index2 = lower2; index2 <= upper2; index2++) {
                ArrayList<Integer> thisPair = new ArrayList<>();
                thisPair.add(new Integer(index1));
                thisPair.add(new Integer(index2));

                switch (style) {
                    case 0:
                        out.add(thisPair);
                        break;
                    case 1:
                        if (index1 <= index2)
                            out.add(thisPair);
                        break;
                    case 2:
                        if (index1 < index2)
                            out.add(thisPair);
                        break;
                    default:
                        throw new IllegalStateException("Unrecognised case in allPairs");
                }


            }
        }

        return out;
    }

    public static ArrayList<ArrayList<Integer>> cloneALALI(ArrayList<ArrayList<Integer>> in) {
        ArrayList<ArrayList<Integer>> out = new ArrayList<>();
        for (ArrayList<Integer> inALI : in) {
            ArrayList<Integer> outALI = new ArrayList<>(inALI);
            out.add(outALI);
        }
        return out;
    }

    public static int[][] cloneInt2D(int[][] in) {
        if (in.length == 0)
            return new int[0][0];

        int[][] out = new int[in.length][];
        for (int i = 0; i < in.length; i++) {
            out[i] = new int[in[i].length];
            System.arraycopy(in[i], 0, out[i], 0, in[i].length);
        }
        return out;
    }

    public static double[][] cloneDouble2D(double[][] in) {
        if (in.length == 0)
            return new double[0][0];

        double[][] out = new double[in.length][];
        for (int i = 0; i < in.length; i++) {
            out[i] = new double[in[i].length];
            System.arraycopy(in[i], 0, out[i], 0, in[i].length);
        }
        return out;
    }

    public static boolean[][] cloneBoolean2D(boolean[][] in) {
        if (in.length == 0)
            return new boolean[0][0];

        boolean[][] out = new boolean[in.length][];
        for (int i = 0; i < in.length; i++) {
            out[i] = new boolean[in[i].length];
            System.arraycopy(in[i], 0, out[i], 0, in[i].length);
        }
        return out;
    }

    public static ArrayList<ArrayList<Integer>> allPerms(int n) {
        //returns an arraylist of arraylists of integers
        //showing all permutations of Integers 0 to n-1
        //works realistically up to n=10
        if (n == 0)
            return new ArrayList<>();
        return allPerms_recurse(n, n);
    }

    public static ArrayList<ArrayList<Integer>> allPerms_recurse(int level, int n) {
        if (level == 1) {
            ArrayList<Integer> single = new ArrayList<>();
            single.add(new Integer(n - level));
            ArrayList<ArrayList<Integer>> list = new ArrayList<>();
            list.add(single);
            return list;
        }

        ArrayList<ArrayList<Integer>> prev = allPerms_recurse(level - 1, n);
        ArrayList<ArrayList<Integer>> out = new ArrayList<>();


        for (int placeAt = 0; placeAt < level; placeAt++) {
            //clone prev
            ArrayList<ArrayList<Integer>> prevClone = cloneALALI(prev);

            //insert
            for (ArrayList<Integer> prevItem : prevClone) {
                prevItem.add(placeAt, new Integer(n - level));
            }

            //append to out
            out.addAll(prevClone);
        }
        return out;
    }

    public static ArrayList<ArrayList<Integer>> allCombs(int n) {
        //returns an arraylist of arraylists of integers
        //showing all combinations of Integers 0 to n-1
        //works realistically up to n=7
        if (n == 0)
            return new ArrayList<>();
        return allCombs_recurse(n, n);
    }

    public static ArrayList<ArrayList<Integer>> nCombs(int count, int n) {
        //returns an arraylist of arraylists of integers
        //showing all combinations of Integers 0 to n-1 --- of length "count"
        //i.e. base "n" counting up to (n^count - 1).  In order.
        if (count == 0)
            return new ArrayList<>();
        return allCombs_recurse(count, n);
    }

    public static ArrayList<ArrayList<Integer>> allCombs_recurse(int level, int n) {
        if (level == 1) {
            ArrayList<ArrayList<Integer>> list = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                ArrayList<Integer> single = new ArrayList<>();
                single.add(new Integer(i));
                list.add(single);
            }
            return list;
        }

        ArrayList<ArrayList<Integer>> prev = allCombs_recurse(level - 1, n);
        ArrayList<ArrayList<Integer>> out = new ArrayList<>();


        for (int initial = 0; initial < n; initial++) {
            //clone prev
            ArrayList<ArrayList<Integer>> prevClone = cloneALALI(prev);

            //insert
            for (ArrayList<Integer> prevItem : prevClone) {
                prevItem.add(0, new Integer(initial));
            }

            //append to out
            out.addAll(prevClone);
        }
        return out;
    }

    //returns all subsets of (0..(overallSize-1)) of size subsetSize
    public static ArrayList<ArrayList<Integer>> subsetOfSize(int subsetSize, int overallSize) {
        if (subsetSize == 1) {
            ArrayList<ArrayList<Integer>> out = new ArrayList<>();
            for (int i = 0; i < overallSize; i++) {
                ArrayList<Integer> single = new ArrayList<>();
                single.add(i);
                out.add(single);
            }
            return out;
        }

        ArrayList<ArrayList<Integer>> previousList = subsetOfSize(subsetSize - 1, overallSize);
        ArrayList<ArrayList<Integer>> out = new ArrayList<>();
        for (ArrayList<Integer> previous : previousList) {
            int biggest = previous.get(previous.size() - 1);
            for (int i = biggest + 1; i < overallSize; i++) {
                ArrayList<Integer> l = new ArrayList<>(previous);
                l.add(i);
                out.add(l);
            }
        }
        return out;
    }

    public static long nChooseK(int n, int k) {
        return ArithmeticUtils.binomialCoefficient(n, k);
    }

    public static ArrayList<String> grepFull(ArrayList<String> inList, String pattern) {
        //pattern must match full text
        ArrayList<String> outList = new ArrayList<>();
        for (String s : inList) {
            if (s.matches(pattern))
                outList.add(s);
        }

        return outList;
    }

    public static int randomInteger(int low, int high, long seed) {
        //an int from low to high inclusive.
        Random rng = new Random();
        if (seed != -1) {
            rng.setSeed(seed);
            int waste = rng.nextInt();
        }
        int out = rng.nextInt(high - low + 1) + low;
        return out;
    }

    public static int[] randomIntegerArray(int count, int low, int high, long seed) {
        //a list of "count" ints from low to high inclusive.
        Random rng = new Random();
        if (seed != -1) {
            rng.setSeed(seed);
            int waste = rng.nextInt();
        }
        int[] out = new int[count];
        for (int x = 0; x < count; x++) {
            out[x] = rng.nextInt(high - low + 1) + low;
        }
        return out;
    }

    public static double[] randomDoubleArray(int count, double low, double high, long seed) {
        //a list of "count" ints from low inclusive to high exclusive.
        Random rng = new Random();
        if (seed != -1) {
            rng.setSeed(seed);
            double waste = rng.nextDouble();
        }
        double[] out = new double[count];
        for (int x = 0; x < count; x++) {
            out[x] = rng.nextDouble() * (high - low) + low;
        }
        return out;
    }

    public static int[] randomPermutation(int count, long seed) {
        //random permutation of the array 0..(count-1).
        Random rng = new Random();
        if (seed != -1) {
            rng.setSeed(seed);
            int waste = rng.nextInt();
        }

        int[] out = new int[count];
        for (int x = 0; x < count; x++) {
            out[x] = x;
        }
        for (int x = 0; x < count - 1; x++) {
            int takeFrom = rng.nextInt(count - x) + x;
            int tmp = out[takeFrom];
            out[takeFrom] = out[x];
            out[x] = tmp;
        }
        return out;
    }

    public static ArrayList randomiseArray(ArrayList in, long seed) {
        //alternatively, Collections.shuffle(in, new Random(seed))
        ArrayList out = new ArrayList();
        int[] r = randomPermutation(in.size(), seed);
        for (int i : r) {
            out.add(in.get(i));
        }
        return out;
    }

    public static int[][] matrixMultiply(int[][] A, int[][] B) {
        int A_rows = A.length;
        int A_cols = A[0].length;
        int B_rows = B.length;
        int B_cols = B[0].length;
        if (A_cols != B_rows)
            throw new IllegalStateException("Bad dimensions in matrixMultiply");
        int[][] C = new int[A_rows][B_cols];
        for (int r = 0; r < A_rows; r++) {
            for (int c = 0; c < B_cols; c++) {
                int d = 0;
                for (int i = 0; i < A_cols; i++) {
                    d += A[r][i] * B[i][c];
                }
                C[r][c] = d;
            }
        }
        return C;
    }

    public static int[][] matrixAdd(int[][] A, int[][] B) {
        int A_rows = A.length;
        int A_cols = A[0].length;
        int B_rows = B.length;
        int B_cols = B[0].length;
        if (A_rows != B_rows || A_cols != B_cols)
            throw new IllegalStateException("Bad dimensions in matrixAdd");
        int[][] C = new int[A_rows][A_cols];
        for (int r = 0; r < A_rows; r++) {
            for (int c = 0; c < A_cols; c++) {
                C[r][c] = A[r][c] + B[r][c];
            }
        }
        return C;
    }

    public static int[][] matrixPower(int[][] A, int n) {
        int A_rows = A.length;
        int A_cols = A[0].length;

        if (A_rows != A_cols)
            throw new IllegalStateException("matrixPower matrix must be square");

        if (n < 0)
            throw new IllegalStateException("matrixPower power must be non-negative.");

        if (n == 0) {
            //identity
            int[][] I = new int[A_rows][A_cols];
            for (int i = 0; i < A_rows; i++) {
                I[i][i] = 1;
            }
            return I;
        }

        if (n == 1)
            return A;
        if (n % 2 == 1)
            return matrixMultiply(A, matrixPower(A, n - 1));
        int[][] half = matrixPower(A, n / 2);
        return matrixMultiply(half, half);
    }

    public static double[][] matrixMultiplyDouble(double[][] A, double[][] B) {
        int A_rows = A.length;
        int A_cols = A[0].length;
        int B_rows = B.length;
        int B_cols = B[0].length;
        if (A_cols != B_rows)
            throw new IllegalStateException("Bad dimensions in matrixMultiply");
        double[][] C = new double[A_rows][B_cols];
        for (int r = 0; r < A_rows; r++) {
            for (int c = 0; c < B_cols; c++) {
                double d = 0;
                for (int i = 0; i < A_cols; i++) {
                    d += A[r][i] * B[i][c];
                }
                C[r][c] = d;
            }
        }
        return C;
    }

    public static double[][] matrixAddDouble(double[][] A, double[][] B) {
        int A_rows = A.length;
        int A_cols = A[0].length;
        int B_rows = B.length;
        int B_cols = B[0].length;
        if (A_rows != B_rows || A_cols != B_cols)
            throw new IllegalStateException("Bad dimensions in matrixAdd");
        double[][] C = new double[A_rows][A_cols];
        for (int r = 0; r < A_rows; r++) {
            for (int c = 0; c < A_cols; c++) {
                C[r][c] = A[r][c] + B[r][c];
            }
        }
        return C;
    }

    public static double[][] matrixPowerDouble(double[][] A, int n) {
        if (n == 1)
            return A;
        if (n % 2 == 1)
            return matrixMultiplyDouble(A, matrixPowerDouble(A, n - 1));
        double[][] half = matrixPowerDouble(A, n / 2);
        return matrixMultiplyDouble(half, half);
    }

    //returned values slightly off.  doesn't "==" actual double.
    public static double[][] matrixInverseDouble(double[][] A) {
        RealMatrix m = new Array2DRowRealMatrix(A);
        RealMatrix inv = new LUDecomposition(m).getSolver().getInverse();
        double[][] out = inv.getData();
        return out;
    }

    //1 = 90 deg clockwise, -1 = 90 deg anticlockwise
    public static int[][] matrixRotate(int[][] A, int clockwiseSteps) {
        int A_rows = A.length;
        int A_cols = A[0].length;

        if (clockwiseSteps == 0) return A;
        clockwiseSteps %= 4;
        if (clockwiseSteps < 0) clockwiseSteps += 4;

        int[][] next = new int[A_cols][A_rows];
        for (int aRow = 0; aRow < A_rows; aRow++) {
            for (int aCol = 0; aCol < A_cols; aCol++) {
                next[aCol][A_rows - aRow - 1] = A[aRow][aCol];
            }
        }
        return matrixRotate(next, clockwiseSteps - 1);
    }

    public static boolean areAlmostEqual(double d1, double d2) {
        return areAlmostEqual(d1, d2, 1e-6);
    }

    public static boolean areAlmostEqual(double d1, double d2, double epsilon) {
        double d3 = Math.abs(d1 - d2);
        return d3 < epsilon;
    }

    //returns {gcd, a, b} where gcd = a . l1 + b . l2
    //l1, l2 >= 0
    //Cormen p.937
    public static long[] euclidGCD(long l1, long l2) {
        if (l2 == 0L)
            return new long[]{l1, 1L, 0L};
        long[] tmp = euclidGCD(l2, l1 % l2);
        long[] tmp2 = new long[]{tmp[0], tmp[2], tmp[1] - (l1 / l2) * tmp[2]};
        return tmp2;
    }

    public static ArrayList<ArrayList<Integer>> partitions(int length, int totalCount, boolean allowZero) {
        //generates all lists of numbers of length "length" with sum "totalCount".
        int lowest = allowZero ? 0 : 1;

        if (length == 1) {
            ArrayList<Integer> l = new ArrayList<>();
            l.add(totalCount);
            ArrayList<ArrayList<Integer>> ll = new ArrayList<>();
            if (totalCount >= lowest)
                ll.add(l);
            return ll;
        }

        ArrayList<ArrayList<Integer>> out = new ArrayList<>();
        for (int i = lowest; i <= totalCount; i++) {
            ArrayList<ArrayList<Integer>> head = partitions(length - 1, totalCount - i, allowZero);
            for (ArrayList<Integer> l : head) {
                l.add(i);
                out.add(l);
            }
        }
        return out;

    }

    public static <T extends Comparable<T>> ArrayList<Integer> sortedIndices(final ArrayList<T> list) {
        //sorts 0..size-1 s.t. list[out[0]] <= list[out[1]] ....
        ArrayList<Integer> indices = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            indices.add(i);
        }

        Collections.sort(indices, new Comparator<Integer>() {

            @Override
            public int compare(Integer o1, Integer o2) {
                int c1 = (list.get(o1)).compareTo(list.get(o2));
                if (c1 != 0)
                    return c1;
                else
                    return o1.compareTo(o2);
            }
        });
        return indices;
    }

    //work in progress...
    public static long powerMod(long a, long b, long p) {
        //a^b mod p.  p prime.
        long b2 = b % (p - 1); //Fermat's little theorem
        if (b2 < 0) b2 += (p - 1);
        long a2 = a % p;
        if (a2 < 0) a2 += p;
        if (b2 == 0) return 1L; //return 0^0 as 1
        if (b2 == 1) return a2;
        if (a2 == 0) return 0L;
        if (b2 % 2 == 1) {
            long oneless = powerMod(a2, b2 - 1, p);
            return (a2 * oneless) % p;
        } else {
            long half = powerMod(a2, b2 / 2, p);
            return (half * half) % p;
        }
    }

    public static long[] factsMod(int upTo, long mod) {
        long[] out = new long[upTo + 1];
        out[0] = 1L;
        long l = 1L;
        for (int i = 1; i <= upTo; i++) {
            l *= (long) i;
            l %= mod;
            out[i] = l;
        }
        return out;
    }

    public static long[] inverseFactsMod(int upTo, long mod) {
        long[] facts = factsMod(upTo, mod);
        long[] out = new long[upTo + 1];
        for (int i = 0; i <= upTo; i++) {
            out[i] = powerMod(facts[i], -1L, mod);
        }
        return out;
    }

    //give it the precomputed facts / invfacts mod p.
    public static long nChooseKModP(int n, int k, long p, long[] facts, long[] invFacts) {
        long nfact = facts[n];
        long inv1 = invFacts[k];
        long inv2 = invFacts[n - k];
        long out = nfact;
        out *= inv1;
        out %= p;
        out *= inv2;
        out %= p;
        return out;
    }

    public static long power(long a, long b) {
        //a^b
        if (b == 0) return 1L; //return 0^0 as 1
        if (b == 1) return a;
        if (b % 2 == 1) {
            long oneless = power(a, b - 1);
            return (a * oneless);
        } else {
            long half = power(a, b / 2);
            return (half * half);
        }
    }
}
