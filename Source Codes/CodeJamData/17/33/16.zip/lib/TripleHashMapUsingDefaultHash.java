package lib;

public class TripleHashMapUsingDefaultHash {
    public static <T1, T2, T3> MapFactory<Triple<T1, T2, T3>> create() {
        HashMapMaterial<T1> m1 = DefaultHashMapMaterial.create();
        HashMapMaterial<T2> m2 = DefaultHashMapMaterial.create();
        HashMapMaterial<T3> m3 = DefaultHashMapMaterial.create();
        return CustomHashMapFactory.create(TripleHashMapMaterial.of(m1, m2, m3));
    }
}
