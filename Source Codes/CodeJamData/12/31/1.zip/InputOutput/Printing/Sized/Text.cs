﻿using System.IO;
using Generic.Maths.Vectors;

namespace Generic.InputOutput.Printing.Sized
{
    class Text : SizedDocument
    {
        readonly string text;

        public Text(string text)
        {
            this.text = text;
        }

        public override void RenderLine(TextWriter builder, int line)
        {
            builder.Write(text);
        }

        public override IntVector2 Size
        {
            get { return new IntVector2(text.Length,1); }
        }
    }
}
