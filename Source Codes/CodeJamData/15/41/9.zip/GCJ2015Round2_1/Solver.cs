﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;

namespace GCJ2015Round2_1
{
	public class Solver : SolverBase
	{
		public class Arrow
		{
			public char dir;
			public Arrow leadsTo;
			public int r, c;

			public Arrow(char p, int r, int c)
			{
				this.dir = p;
				this.r = r;
				this.c = c;
				this.leadsTo = null;
			}

		}
		public const string INPUT_NAME = "small1";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = false;

		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		public int R, C;
		public override string SolveTestCase(int testCase)
		{
			var data = GetIntList();
			R = data[0];
			C = data[1];

			var allArrows = new List<Arrow>();
			var board = new Arrow[R][];
			for (int i = 0; i < R; i++)
			{
				board[i] = new Arrow[C];
				var line = GetLine();
				for (int j = 0; j < C; j++)
				{
					if (line[j] != '.')
					{
						board[i][j] = new Arrow(line[j], i, j);
						allArrows.Add(board[i][j]);
					}
				}
			}

			CalculateLeadsTo(allArrows, board);

			foreach (var arrow in allArrows)
			{
				if (arrow.leadsTo == null && !CanPointToSomeArrow(arrow, board))
				{
					return "IMPOSSIBLE";
				}
			}

			return allArrows.Count(arrow => arrow.leadsTo == null).ToString();
		}

		private bool CanPointToSomeArrow(Arrow arrow, Arrow[][] board)
		{
			foreach (char dir in new[] { '<', '>', 'v', '^' })
			{
				if (getArrowInDirection(board, arrow.r, arrow.c, dir) != null)
					return true;
			}

			return false;
		}

		private void CalculateLeadsTo(List<Arrow> allArrows, Arrow[][] board)
		{
			foreach (var arrow in allArrows)
			{
				arrow.leadsTo = getArrowInDirection(board, arrow.r, arrow.c, arrow.dir);
			}
		}

		private Arrow getArrowInDirection(Arrow[][] board, int r, int c, char dir)
		{
			switch (dir)
			{
				case '>':
					for (int i = c + 1; i < C; i++)
					{
						if (board[r][i] != null)
							return board[r][i];
					}
					return null;
					break;
				case '<':
					for (int i = c - 1; i >= 0; i--)
					{
						if (board[r][i] != null)
							return board[r][i];
					}
					return null;
					break;
				case 'v':
					for (int i = r + 1; i < R; i++)
					{
						if (board[i][c] != null)
							return board[i][c];
					}
					return null;
					break;
				case '^':
					for (int i = r - 1; i >= 0; i--)
					{
						if (board[i][c] != null)
							return board[i][c];
					}
					return null;
					break;
				default:
					throw new Exception("WAT");
			}
		}

	}
}
