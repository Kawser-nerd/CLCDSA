package pl.javahussars.Standing_Ovation;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.FileSystems;
import java.util.ArrayList;
import java.util.List;

public class DataLoader {

	private static boolean isLocal = "true".equals(System
			.getProperty("KRISSO_LOCAL_COMP"));
	private final String fileOut;
	private final BufferedReader br;

	DataLoader(String fileIn) throws FileNotFoundException {
		String pkgPath = getClass().getPackage().getName().replace('.', '/');
		String filePath = "src/" + pkgPath + "/" + fileIn;
		fileOut = "src/" + pkgPath + "/" + fileIn.replace(".in", ".out");
		FileSystems.getDefault().getPath(filePath).toFile();

		if (isLocal) {
			br = new BufferedReader(new FileReader(FileSystems.getDefault()
					.getPath(filePath).toFile()));
		} else {
			br = new BufferedReader(new InputStreamReader(System.in));
		}
	}

	FileWriter getOutputFileWriter() throws IOException {
		return new FileWriter(FileSystems.getDefault().getPath(fileOut)
				.toFile(), false);
	}

	int T; // number of test cases

	List<String> loadDataAndRun() throws IOException {
		T = Integer.parseInt(br.readLine());
		List<String> solutions = new ArrayList<>(T);

		for (int testCaseIdx = 1; testCaseIdx <= T; testCaseIdx++) {
			String data = br.readLine().split(" ")[1];
			int[] people = new int[data.length()];
			for (int i = 0; i < people.length; i++) {
				people[i] = Integer.parseInt("" + data.charAt(i));
			}

			TestCase testCase = new TestCase(people);
			solutions.add(testCase.resolve());
		}

		return solutions;
	}
}
