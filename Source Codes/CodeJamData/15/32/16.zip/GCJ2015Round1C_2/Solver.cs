﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;

namespace GCJ2015Round1C_2
{
	public class Solver : SolverBase
	{
		class KeyAppearance
		{
			public char key;
			public int appearances;
			public KeyAppearance(char key, int appearance)
			{
				this.key = key;
				this.appearances = appearance;
			}
		}
		private Random random = new Random();
		public const string INPUT_NAME = "smalltest";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = false;
		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		public override string SolveTestCase(int testCase)
		{
			var info = GetIntList();
			var K = info[0];
			var L = info[1];
			var S = info[2];

			var keys = GetLine();
			var word = GetLine();

			Dictionary<char, int> appearances = GetAppearances(keys);
			var totalAppearances = appearances.Values.Sum();

			var permutator = new Permutator<char>(keys.Distinct().ToList(), '*');
			int maxBananas = 0;
			double weightedPay = 0;
			foreach (var perm in permutator.GetArrayPermutations(S))
			{
				var bananasPaid = CountInstances(perm, word);
				if (bananasPaid > maxBananas)
					maxBananas = bananasPaid;

				double probOfChoice = ChoiceProbability(perm, appearances, totalAppearances);
				weightedPay += probOfChoice * bananasPaid;
			}

			double averagePay = weightedPay;

			return (maxBananas - averagePay).ToString();
		}

		private double ChoiceProbability(char[] perm, Dictionary<char, int> appearances, int totalAppearances)
		{
			double result = 1;
			for (int i = 0; i < perm.Length; i++)
			{
				result *= appearances[perm[i]] / ((double)totalAppearances);
			}

			return result;
		}

		private Dictionary<char, int> GetAppearances(string keys)
		{
			Dictionary<char, int> result = new Dictionary<char, int>();
			List<char> keys2 = keys.OrderBy(c => c).ToList();
			int counter = 0;
			char currKey = '\0';
			for (int i = 0; i < keys2.Count; i++)
			{
				char key = keys2[i];
				if (key == currKey)
					counter++;
				else
				{
					if (counter != 0)
					{
						result.Add(currKey, counter);
					}

					currKey = key;
					counter = 1;
				}
			}
			if (counter != 0)
			{
				result.Add(currKey, counter);
			}
			return result;
		}

		private char[] TypeWord(string keys, int S)
		{
			char[] result = new char[S];
			for (int i = 0; i < S; i++)
			{
				result[i] = keys[random.Next(keys.Length)];
			}
			return result;
		}

		private int CountInstances(char[] chars, string word)
		{
			var src = new string(chars);
			return src.Select((c, i) => src.Substring(i)).Count(sub => sub.StartsWith(word));
		}
	}
}
