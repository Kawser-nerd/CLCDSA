﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace A
{
    public struct pair
    {
        public Int64 X;
        public Int64 Y;
    }
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader("A.txt");
            StreamWriter sw = new StreamWriter("A_res.txt");
            string line = sr.ReadLine();
            Int64 count = Int64.Parse(line);
            for (Int64 i = 0; i < count; ++i)
            {
                line = sr.ReadLine();
                string[] data = line.Split(new char[] { ' ' });
                Int64 n = Int64.Parse(data[0]);
                Int64 A = Int64.Parse(data[1]);
                Int64 B = Int64.Parse(data[2]);
                Int64 C = Int64.Parse(data[3]);
                Int64 D = Int64.Parse(data[4]);
                Int64 x0 = Int64.Parse(data[5]);
                Int64 y0 = Int64.Parse(data[6]);
                Int64 M = Int64.Parse(data[7]);
                pair[] trees = new pair[n];
                pair t = new pair();
                Int64 X = x0;
                Int64 Y = y0;
                t.X = X;
                t.Y = Y;
                trees[0] = t;
                for (Int64 j = 1; j < n; ++j)
                {
                    t = new pair();
                    X = (A * X + B) % M;
                    Y = (C * Y + D) % M;
                    t.X = X;
                    t.Y = Y;
                    trees[j] = t;
                }
                Int64 res = 0;
                for (Int64 j = 0; j < n - 2; j++)
                {
                    for (Int64 k = j + 1; k < n - 1; k++)
                    {
                        for (Int64 l = k + 1; l < n; l++)
                        {
                            Int64 xc = (trees[j].X + trees[k].X + trees[l].X);
                            Int64 yc = (trees[j].Y + trees[k].Y + trees[l].Y);
                            if ((xc % 3 == 0) && (yc % 3 == 0))
                            {
                                ++res;
                            }
                        }
                    }
                }
                sw.WriteLine("Case #" + (i + 1) + ": " + res);
            }
            sw.Close();
        }
    }
}
