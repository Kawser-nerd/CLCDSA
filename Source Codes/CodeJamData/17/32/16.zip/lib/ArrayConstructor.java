package lib;

import java.lang.reflect.Array;
import java.util.function.Supplier;

public class ArrayConstructor {

    public static <T> T[] create(int n, Class<T> clazz, Supplier<T> s) {
        //noinspection unchecked
        return LimitedStream.generate(n, s).toArray(size -> (T[]) Array.newInstance(clazz, size));
    }
}
