package lib;

import java.util.List;
import java.util.function.Function;

public class ConvertedList {
    public static <T1, T2> List<T2> of(final List<T1> original, final Function<T1, T2> converter) {
        return ListUsingGetter.create(original.size(), i -> converter.apply(original.get(i)));
    }
}
