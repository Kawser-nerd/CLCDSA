namespace Template.Interfaces
{
  public interface ICaseFormatter
  {
    string FormatOutput(string value);
  }
}