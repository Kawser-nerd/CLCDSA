﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public class Solver
{
    const string Folder = @"D:\GCJ\GCJ2011\";
    string FileName;
    string GetFile { get { return Folder + FileName; } }
    List<string> Lines;
    public Solver(List<string> lines) 
    {
        Lines = lines;
        FileName = DateTime.Now.ToShortTimeString().Replace(":", "") + DateTime.Now.Second + ".txt";
    }
    void MakeAnswer(int caseNumber, string answer)
    {
        using (StreamWriter sw = File.AppendText(GetFile))
        {
            sw.WriteLine(string.Format("Case #{0}: {1}", caseNumber, answer));
        }
    }
    string Read()
    {
        string value = Lines[0];
        Lines.RemoveAt(0);
        return value;
    }
    public void Execute()
    {
        int cases = Convert.ToInt32(Read());
        for (int caseIndex = 0; caseIndex < cases; caseIndex++)
        {
            Solve(caseIndex + 1);
        }
    }

    void Solve(int caseNumber)
    {
        string answer = "";

        string[] parts = Read().Split(' ');

        int count = 0;
        int length = parts.Length;
        int oPos = 1;
        int bPos = 1;
        int lastOCount = 0;
        int lastBCount = 0;
        for (int index = 1; index < length; index += 2)
        {
            bool oTurn = parts[index] == "O";
            int buttonPos = Convert.ToInt32(parts[index + 1]);

            if (oTurn)
            {
                count += Math.Max(0, Math.Abs(buttonPos - oPos) - (count - lastOCount));
                count++;

                oPos = buttonPos;
                lastOCount = count;
            }
            else
            {
                count += Math.Max(0, Math.Abs(buttonPos - bPos) - (count - lastBCount));
                count++;

                bPos = buttonPos;
                lastBCount = count;
            }
        }

        answer = count.ToString();

        MakeAnswer(caseNumber, answer);
    }
}

