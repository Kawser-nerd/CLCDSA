rm B-large.out.*
./run.sh 0 1 2 &
./run.sh 3 4 5 &
./run.sh 6 7 8 &
./run.sh 9 
