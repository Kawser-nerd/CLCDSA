﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Milkshakes
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] lines = File.ReadAllLines("input.txt");
            string output = CaseSolver.Solve(lines);
            File.WriteAllText("output.txt", output);
        }
    }
}
