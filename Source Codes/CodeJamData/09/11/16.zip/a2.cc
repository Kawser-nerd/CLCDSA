// Powered by FTH

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <iterator>
#include <functional>
#include <utility>
#include <numeric>
#include <complex>
#include <cstdio>
#include <cmath>
#include <cctype>
#include <cassert>
using namespace std;

#define REP(i,n) for(int i = 0; i < (int)(n); i++)
#define FOR(i,c) for(__typeof((c).begin()) i = (c).begin(); i != (c).end(); ++i)
#define ALLOF(c) ((c).begin()), ((c).end())

inline int enhappy(int n, int b) {
    int m = 0;
    while(n > 0) {
        int k = n % b;
        m += k * k;
        n /= b;
    }
    return m;
}

int fillHappyTable(vector<short>& v, int k, int b) {
    int n = v.size();
    assert(k < n);
    if (v[k] < 0) {
        v[k] = 0;
        v[k] = fillHappyTable(v, enhappy(k, b), b);
    }
    return v[k];
}

int main() {

    int n = 100000000;
    vector<short> vs[11];

    for(int b = 2; b <= 10; b++) {
        fprintf(stderr, "b = %d\n", b);
        vector<short>& v = vs[b];
        v.assign(n, -1);
        v[0] = 0;
        v[1] = 1;
        for(int k = 2; k < n; k++)
            fillHappyTable(v, k, b);
    }

    fprintf(stderr, "table\n");
    vector<short> table(n);
    REP(i, n) {
        for(int b = 2; b <= 10; b++) {
            if (vs[b][i])
                table[i] |= 1 << b;
        }
    }

    REP(bits_high, 1<<9) {
        int bits = bits_high << 2;
        for(int b = 2; b <= 10; b++)
            fprintf(stderr, "%d", (bits >> b) & 1);
        fprintf(stderr, ": ");
        for(int i = 2; i < n; i++) {
            if ((table[i] & bits) == bits) {
                fprintf(stderr, "%d\n", i);
                goto FOUND;
            }
        }
        fprintf(stderr, "none\n");
    FOUND:;
    }

    return 0;

    /*
    for(int a = 2; a <= 10; a++) {
        for(int b = a+1; b <= 10; b++) {
            for(int c = b+1; c <= 10; c++) {
                vector<int> v;
                v.push_back(a);
                v.push_back(b);
                v.push_back(c);
                cout << a << "," << b << "," << c << ": " << solve(v) << endl;
            }
        }
    }
    return 0;
    */

    /*
    int nCases;
    {
        string s;
        getline(cin, s);
        istringstream is(s);
        is >> nCases;
    }

    REP(iCase, nCases) {
        string s;
        getline(cin, s);
        istringstream is(s);
        vector<int> v;
        for(int i; is >> i; )
            v.push_back(i);
        printf("Case #%d: %d\n", iCase+1, solve(v));
    }
    */

    return 0;
}
