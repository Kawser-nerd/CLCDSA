﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using JamHelpers;

namespace R2_1
{
	class Program : ProgramBase
	{
		static void Main(string[] args)
		{
			new Program().Run();
		}

		public override void RunCase()
		{
			var pars = ReadLine().Split().ToInt();
			int x = pars[0];
			int s = pars[1];
			int r = pars[2];
			double t = pars[3];
			int n = pars[4];
			double usedTime = 0;

			int last = 0;
			var ways = new List<int[]>();
			for (int i = 0; i < n; i++)
			{
				var line = ReadLine().Split().ToInt();
				if (last < line[0])
					ways.Add(new int[] { last, line[0], 0 });

				ways.Add(line);
				last = line[1];
			}
			ways.Add(new int[] { last, x, 0 });
			ways = ways.OrderBy(w => w[2]).ToList();

			foreach (var way in ways)
			{
				double len = 0.0 + way[1] - way[0];
				double runT = len / (r + way[2]);
				if (runT > t)
					runT = t;
				t -= runT;

				len -= runT * (r + way[2]);
				double walkT = len / (s + way[2]);

				usedTime += walkT;
				usedTime += runT;
			}
			WriteLine(CaseStr + " " + usedTime.ToStringInv());
		}
	}
}
