﻿namespace CodeJam.Problems
{
    using System;
    using CodeJam2011;

    public class ProblemA : ProblemBase
    {
        protected override string SolveOneCase(InputHelper input)
        {
            int A = input.GetInt();
            int B = input.GetInt();

            string[] p = input.GetStringArray();

            double exp = Math.Min(2 + B, A+B+1);

            double prob = 1;

            for (int i = 0; i < A; i++)
            {
                prob *= Double.Parse(p[i]);
                int t = B - A + 1 + (A - i -1)*2;
                double ee = prob*(t) + (1 - prob)*(t + B + 1);

//                Console.WriteLine(ee);

                exp = Math.Min(exp, ee);
            }

            return exp.ToString();
        }
    }
}