package template;

//standard libraries potentially used:
//Apache commons http://http://commons.apache.org/
//Google Guava http://code.google.com/p/guava-libraries/
import com.google.common.collect.HashMultiset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.Callable;

public class TestCase implements Callable {

    int caseRef;
    Object result;

    String letters;
    int[] list;
    int[][] grid;

    public void prepare(Scanner scanner) {
        letters = scanner.next();

//        list = new int[N];
//        for (int i = 0; i < N; i++) {
//            list[i] = scanner.nextInt();
//        }
//        grid = new int[N][N];
//        for (int r = 0; r < N; r++) {
//            for (int c = 0; c < N; c++) {
//                grid[r][c] = scanner.nextInt();
//            }
//        }
    }

    private Object solve() {
        HashMultiset<Character> s = HashMultiset.create();

        for (char c : letters.toCharArray()) {
            s.add(c);
        }

        ArrayList<Integer> out = new ArrayList<Integer>();

        Map<Character, Integer> map = new LinkedHashMap<>();
        map.put('Z', 0);
        map.put('W', 2);
        map.put('X', 6);
        map.put('U', 4);
        map.put('G', 8);
        map.put('H', 3);
        map.put('F', 5);
        map.put('S', 7);
        map.put('O', 1);
        map.put('I', 9);
        
        String[] ds = new String[] {"ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE"};
        
        for (Character c : map.keySet()) {
            int cnt = s.count(c);
            //System.out.println(c + " " + cnt);
            for (int i = 0; i < cnt; i++) {
                out.add(map.get(c));
                String q = ds[map.get(c)];
                for (char w : q.toCharArray()) {
                    boolean ok = s.remove(w);
                    assert ok : "not ok";
                }
            }
        }

        Collections.sort(out);
        return Utils.join(out, "");
    }

    /////////////////////////////////////////////////////////////////////
    public static void main(String[] args) {
        Utils.go(1);
    }

    @Override
    public Object call() throws Exception {
        return run();
    }

    public Object run() {
        System.out.println("Starting case " + this.getRef());
        Object solution = solve();
        assert solution != null : "Null result for testcase " + this.getRef();
        setResult(solution);
        System.out.println("Finished case " + this.getRef() + ", result: " + solution);
        return solution;
    }

    public int getRef() {
        return caseRef;
    }

    public void setRef(int ref) {
        this.caseRef = ref;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }

}
