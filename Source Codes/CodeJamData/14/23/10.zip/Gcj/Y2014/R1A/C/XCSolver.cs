﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Cmn.Util;
using Gcj.Util;

namespace Gcj.Y2014.R1A.C
{
    internal class XCSolver : GcjSolver
    {
        const int c = 5;

        private IEnumerable<int[]> Enrgrand()
        {
            for (var rnd = new int[c]; ; )
            {
                yield return rnd;

                for(var i = 0;;)
                {
                    rnd[i]++;
                    if(rnd[i] < c)
                        break;
                    rnd[i] = 0;
                    i++;
                    if(i == c)
                        yield break;
                }
            }
        }

        protected override IEnumerable<object> EnobjSolveCase()
        {
            var mp = new Dictionary<string, List<string>>();
            foreach(var rgrand in Enrgrand())
            {
                var rg = (c+1).Eni(1).ToArray();
                for(var i=0;i<rg.Length;i++)
                {
                    var rand = rgrand[i];
                    U.Swap(ref rg[rand], ref rg[i]);
                }
                mp.EnsureGet(rg.StJoin("", n => n.ToString())).Add(rgrand.StJoin("", n => n.ToString()));
            }
            var call = c.Eni().Aggregate(1, (m, n) => m * c);
            Debug.Assert(call == mp.Values.Sum(wrp => wrp.Count));
            File.WriteAllLines(FpatOut + ".txt", mp
                .OrderByDescending(kvp => kvp.Value.Count)
                .Select(kvp => kvp.Key 
                    + " " + kvp.Value.Count
                    + " / " + (call / (decimal)mp.Count) 
                    + " inv: " + cinv(kvp.Key.ToCharArray())
                    + "\n  "+kvp.Value.StJoin("\n  ")));

            yield break;
        }

        private int cinv(char[] rgch)
        {
            var res = 0;
            foreach(var i in c.Eni())
            {
                var ch = (i+1).ToString()[0];
                if(rgch[i]==ch)
                    continue;
                res++;
                var i2 = Array.IndexOf(rgch, ch);
                rgch[i2] = rgch[i];
                rgch[i] = ch;
            }
            return res;
        }
    }
}
