﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;

namespace km.gcj.r2 {
    class Program2CS {

        /// <summary> プログラムのスタートポイント </summary>
        /// <param name="args"> 第一引数に入力ファイルを指定 </param>
        static void Main(string[] args) {
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            Logic(args);

            sw.Stop();
            Console.WriteLine(sw.Elapsed);
            Console.ReadLine();
        }

        /// <summary> メインロジック </summary>
        /// <param name="args"></param>
        static void Logic(string[] args) {
            Problem p = Problem.createProblem(args);
            if (p == null) {
                return;
            }

            // 試行回数を取得し、ループする。
            long repeat = p.getNextLineAsInt64Array()[0];
            for (int i = 0; i < repeat; i++) {
                // MainLoop
                long n = p.getNextInt64s().ToArray()[0];

                long[] answer = solve(p.getNextLineAsStringArray().Select(x => Int64.Parse(x)-1).ToArray());


                // （／・ω・）／答えを返すよ！
                if (answer == null) {
                    p.WriteAnswerFullLine("Impossible");
                }
                else {
                    StringBuilder sb = new StringBuilder();
                    foreach (long item in answer) {
                        sb.Append(item);
                        sb.Append(" ");
                    }
                    
                    p.WriteAnswerFullLine(sb.ToString().TrimEnd());
                }
            }
        }

        static long[] solve(long[] lst) {
            int len = lst.Length;
            long[] result = new long[len+1];

            for (int i = 0; i < len+1; i++) {
                result[i] = (len + i) * (len+1)+10000000;
            }

            for (int i = 0; i < len; i++) {
                for (int j = i+1; j < lst[i]; j++)
                {
//                    result[j] -= (lst[i] - j) * (lst[i] - i);
                    result[j] -= (lst[i] - j);
                    if (lst[i] < lst[j]) {
                        return null;
                    }
                }
            }

            return result;
        }




        /// <summary> G.C.D.算出 </summary>
        /// <returns></returns>
        static int Gcd(int a, int b) {
            if (a < 0) a = -a;
            if (b < 0) b = -b;
            if (a < b) return innerGcd(b, a);
            else return innerGcd(a, b);
        }

        /// <summary> G.C.D.算出内部ロジック </summary>
        static int innerGcd(int a, int b) {
            if (a < b) return innerGcd(b, a);
            if (b == 0) return a;
            return innerGcd(b, a % b);
        }

        // （」・ω・）」ソースここまで。
        // （´・ω・｀）
        //  (ﾟдﾟ )
    }
}
