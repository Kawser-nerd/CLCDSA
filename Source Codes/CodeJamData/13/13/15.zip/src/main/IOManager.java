package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class IOManager {
	private BufferedReader input;
	private BufferedWriter output;
	public IOManager(){
		try {
			input= new BufferedReader(new FileReader("input.txt"));
		} catch (FileNotFoundException e) {
			System.out.println("Exception while initializing input.txt");
			e.printStackTrace();
		}
        try {
			output = new BufferedWriter(new FileWriter("output.txt"));
		} catch (IOException e) {
			System.out.println("Exception while initializing output.txt");
			e.printStackTrace();
		}
	}
	
	public String readLine(){
		String result = "";
		try {
			result = input.readLine();
		} catch (IOException e) {
			System.out.println("Exception while reading line.");
			e.printStackTrace();
		}
		return result;
	}
	
	public String[] readLines(int n){
		String[] result = new String[n];
		for (int i = 0; i<n; ++i)
			result[i] = readLine();
		return result;
	}
	
	public int readInt(){
		return Integer.valueOf(readLine());
	}
	
	public int[] readInts(){
		String[] line = readLine().split(" ");
		int[] result = new int[line.length];
		for (int i = 0; i < line.length; ++i){
			result[i] = Integer.valueOf(line[i]);
		}
		return result;
	}
	public long readLong(){
		return Long.valueOf(readLine());
	}
	
	public long[] readLongs(){
		String[] line = readLine().split(" ");
		long[] result = new long[line.length];
		for (int i = 0; i < line.length; ++i){
			result[i] = Long.valueOf(line[i]);
		}
		return result;
	}
	
	public void write(String txt){
		try {
			output.write(txt);
			output.newLine();
		} catch (IOException e) {
			System.out.println("Exception while writing: "+txt);
			e.printStackTrace();
		}
		
	}
	
	public void close(){
		try {
			output.close();
		} catch (IOException e) {
			System.out.println("Exception while closing output.txt");
			e.printStackTrace();
		}
	}
}
