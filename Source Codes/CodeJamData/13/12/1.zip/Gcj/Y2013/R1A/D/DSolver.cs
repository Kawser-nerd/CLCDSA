﻿using System.Collections.Generic;
using Gcj.Util;

namespace Gcj.Y2013.R1A.D
{
    internal class DSolver : GcjSolver
    {
        protected override IEnumerable<object> EnobjSolveCase()
        {
            yield break;
        }

    }
}
