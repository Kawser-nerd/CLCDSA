﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    public class Processor
    {
        int cursor = 0;
        string[] stringData;

        private string getNextValue()
        {
            return stringData[cursor++];
        }

        public string Execute(string[] data)
        {
            stringData = data;
            StringBuilder output = new StringBuilder();

            // Read number of input
            int inputs = int.Parse(getNextValue());
            List<Case> cases = new List<Case>();

            for (int i = 0; i < inputs; i++)
            {
                Case newCase = new Case();
                newCase.Cash = int.Parse(getNextValue()); // Get the cash
                int count = int.Parse(getNextValue()); // Item count
                newCase.Items = getNextValue().Split(' ').Select(item => new Item() { Value = int.Parse(item), Id = Guid.NewGuid() }).Take(count).ToList(); // Get the item values
                cases.Add(newCase);
            }

            cases.ForEach(c =>
            {
                int indexItem1 = 1;
                c.Items.ForEach(item =>
                {
                    Item result = c.Items.FirstOrDefault(subItem => subItem.Value + item.Value == c.Cash && item.Id != subItem.Id);
                    if (result != null)
                    {
                        c.item1 = indexItem1;
                        c.item2 = c.Items.IndexOf(result) + 1;

                        if (c.item1 > c.item2)
                        {
                            c.item1 = c.item2;
                            c.item2 = indexItem1;
                        }
                    }
                    indexItem1++;
                });
                output.AppendLine(string.Format("Case #{0}: {1} {2}", cases.IndexOf(c) + 1, c.item1, c.item2));
            });

            return output.ToString();
        }
    }
}
