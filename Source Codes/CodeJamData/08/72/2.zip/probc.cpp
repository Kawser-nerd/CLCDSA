// Prewritten header. See lib.el

#include <algorithm>
#include <cmath>
#include <fstream>
#include <iostream>
#include <map>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef pair<int, ii> iii;
typedef pair<ii, ii> iiii;
typedef vector<ii> vii;
typedef vector<vii> vvii;
typedef unsigned long long ull;
#define sz(a) int((a).size())
#define pb push_back
#define mp make_pair
#define all(c) (c).begin(),(c).end()
#define tr(c,i) for(typeof((c).begin()) i = (c).begin(); i != (c).end(); ++i)
#define present(c,x) ((c).find(x) != (c).end())
#define cpresent(c,x) (find(all(c),x) != (c).end())

class Solver {
public:
  Solver(ifstream& i);
  string solve();
private:
  int N;
  vector<int> vals;
};

void solve(string type){
  string infile="c:/codejam/semis/ProblemC/C-" + type + ".in";
  string outfile="c:/codejam/semis/ProblemC/C-" + type + ".out";
  cout << infile << " to " << outfile << endl;
  ifstream input(infile.c_str());
  ofstream output(outfile.c_str());
  int N;
  input >> N;
  cout << N << " cases" << endl;
  for (int i = 1; i <= N; ++i){
    cout << "Case #" << i << endl;
    Solver ps(input);
    string soln=ps.solve();
    output << "Case #" << i << ": " << soln << endl;
    cout << soln << endl;
  }
  input.close();
  output.close();
}

int main(int argc, char* argv[])
{string type = "test";
  if (argc > 1){
    int loc = 0;
    char param = argv[1][loc];
    while (param == '-'){
      ++loc;
      param = argv[1][loc];
    }
    switch (param){
    case '2':
    case 'l':
    case 'L':
      type = "large"; break;
    case '1':
    case 's':
    case 'S':
      type = "small"; break;
    default:
      type = "test"; break;}
  }
  solve(type);
}

Solver::Solver(ifstream& i){
  // Read in data to local variables.
  // Remember to define local variables in class description at top
  i >> N;
  vals.assign(N,0);
  for (int j = 0; j < N; ++j)
    i >> vals[j];
}

int next(vector<int> ds){
  if (ds.size() <= 2) return -1;
  int evenval = ds[0];
  int oddval = ds[1];
  bool evensame = true;
  bool oddsame = true;
  for (int i = 2; (evensame && oddsame) && i < ds.size(); ++i){
    if (i % 2 == 0)
      evensame = (ds[i] == evenval);
    else
      oddsame = (ds[i] == oddval);
  }
  if (evensame && oddsame) return -1;
  if (evensame){
    if (ds.size() % 2 == 0) return evenval;
    vector<int> dhalf;
    for (int i = 1; i < ds.size(); i += 2)
      dhalf.pb(ds[i]);
    return next(dhalf);
  } else {
    if (ds.size() % 2 == 1) return oddval;
    vector<int> dhalf;
    for (int i = 0; i < ds.size(); i += 2)
      dhalf.pb(ds[i]);
    return next(dhalf);
  }
}

string Solver::solve() {
  // Solve problem, using local variables, and return string.
  // If you need to parse a float with exactly 6 decimal
  // places, do:
  //  char floatBuffer[20];
  //  sprintf(floatBuffer, ".6f", f);
  vector<int> diffs(N-1,0);
  for (int k = 0; k < N-1; ++k){
    diffs[k] = vals[k+1]-vals[k];
    if (diffs[k] < 0) diffs[k] += 10007;
  }
  int nextdiff = next(diffs);
  if (nextdiff == -1)
    return "UNKNOWN";
  else{
    stringstream s;
    vals[N-1] += nextdiff;
    vals[N-1] %= 10007;
    s << vals[N-1];
    return s.str();
  }
}

