/**
 * 
 */
package gepa.gcj.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;

/**
 * @author gepa
 *
 */
public class LineParser {

    private final BufferedReader reader;

    private Deque<String> readBuffer;
    private Deque<String> unreadBuffer;
    private int nextLineNumber;
    private boolean doneReading;

    public LineParser(BufferedReader reader) {
        this.reader = reader;
        readBuffer = new ArrayDeque<String>();
        unreadBuffer = new ArrayDeque<String>();
        nextLineNumber = 0;
        doneReading = false;
    }

    /**
     * Read next line (either from the unreadBuffer, if some lines have been unread, or from the configured
     * reader). If no more lines are available, <code>null</code> is returned.
     * 
     * @return next line as a <code>String</code>, or <code>null</code> if no more lines available.
     * @throws ParseException if an I/O error occurs.
     */
    public String getNextLine() throws ParseException {
        String res = null;
        if (!unreadBuffer.isEmpty()) {
            res = unreadBuffer.removeLast();
        } else if (!doneReading) {
            try {
                res = reader.readLine();
                if (res == null) {
                    doneReading = true;
                }
            } catch (IOException e) {
                throw new ParseException("Could not read line " + nextLineNumber, e);
            }
        }
        if (res != null) {
            readBuffer.addLast(res);
            nextLineNumber++;
        }
        return res;
    }

    /**
     * Read next line (from unread buffer or from configured reader), but throw an exception if no more
     * lines available.
     * 
     * @return next line as a <code>String</code>
     * @throws ParseException if no more lines available, or an I/O error occurs.
     */
    public String getNextNotNull() throws ParseException {
        String res = getNextLine();
        if (res == null) {
            throw new ParseException("More lines expected after line " + nextLineNumber);
        }
        return res;
    }

    /**
     * Unread a line to the unread buffer, so that it is read again in a later call to {@link #getNextLine()}
     * or {@link #getNextNotNull()}.
     *
     * @throws ParseException if no more lines can be unread.
     */
    public void unreadLine() throws ParseException {
        if (readBuffer.isEmpty()) {
            throw new ParseException("No line to unread!");
        }
        String data = readBuffer.removeLast();
        unreadBuffer.addLast(data);
        nextLineNumber--;
    }

    /**
     * Read the next <code>count</code> lines as a <code>String</code> array.
     *
     * @param count number of lines to read.
     * @return the next <code>count</code> lines as a <code>String</code> array.
     * @throws ParseException if not enough lines available.
     */
    public String[] getLineArray(int count) throws ParseException {
        String[] result = new String[count];
        for (int i = 0; i < count; i++) {
            result[i] = getNextNotNull();
        }
        return result;
    }

    /**
     * Get the tokens of the next line (separated by whitespace) as a <code>String</code> array.
     *
     * @return the tokens of the next line.
     * @throws ParseException if no more lines available to read.
     */
    public String[] getStringArray() throws ParseException {
        return getNextNotNull().split(Constants.WHITESPACE_PATTERN);
    }

    /**
     * Get <code>N</code> strings (separated by whitespace) from the next line(s).
     *
     * @param N number of strings to read.
     * @return an array containing the next <code>N</code> strings.
     * @throws ParseException if not enough elements can be read.
     */
    public String[] getStringArray(int N) throws ParseException {
        String[] result = new String[N];
        int pos = 0;
        while (pos < N) {
            String[] parts = getNextNotNull().split(Constants.WHITESPACE_PATTERN);
            if (pos + parts.length > N) {
                throw new ParseException("Too many array elements at line " + nextLineNumber);
            }
            for (int i = 0; i < parts.length; i++) {
                result[pos] = parts[i];
                pos++;
            }
        }
        return result;
    }

    /**
     * Read an integer <code>N</code> from the next line, and read <code>N</code> strings (separated by
     * whitespace) after that (from more than one line if necessary).
     *
     * @return the <code>N</code> strings read.
     * @throws ParseException if no count can be found, or not enough strings can be read.
     */
    public String[] getStringArrayWithCount() throws ParseException {
        String[] data = getStringArray();
        if (data.length < 1) {
            throw new ParseException("No element count found at line " + nextLineNumber);
        }
        int N = 0;
        try {
            N = Integer.parseInt(data[0]);
        } catch (NumberFormatException e) {
            throw new ParseException("Could not parse count \"" + data[0] + "\" to an integer!", e);
        }
        String[] result = new String[N];
        int start = 1;
        int pos = 0;
        while (true) {
            if (pos + data.length - start > N) {
                throw new ParseException("Too many array elements found at line " + nextLineNumber);
            }
            while (start < data.length) {
                result[pos] = data[start];
                pos++;
                start++;
            }
            if (pos >= N) {
                break;
            }
            start = 0;
            data = getStringArray();
        }
        return result;
    }

    public int getSingleInt() throws ParseException {
        String val = getNextNotNull();
        try {
            return Integer.parseInt(val);
        } catch (NumberFormatException e) {
            throw new ParseException("Could not parse \"" + val + "\" to an int!", e);
        }
    }
    /**
     * Transform a String array to a long array.
     * 
     * @param data the array containing the numbers to parse, as Strings.
     * @return an array containing the parsed numbers.
     * @throws ParseException if not all numbers could be parsed to long.
     */
    public static long[] toLongArray(String[] data) throws ParseException {
        long[] result = new long[data.length];
        for (int i = 0; i < data.length; i++) {
            try {
                result[i] = Long.parseLong(data[i]);
            } catch (NumberFormatException e) {
                throw new ParseException("Could not parse \"" + data[i] + "\" to a long!", e);
            }
        }
        return result;
    }

    /**
     * Get the numbers of the next line (separated by whitespace) as a <code>long</code> array.
     *
     * @return the numbers of the next line.
     * @throws ParseException if no more lines available to read, or next line does not contain only numbers.
     */
    public long[] getLongArray() throws ParseException {
        return LineParser.toLongArray(getStringArray());
    }

    /**
     * Get <code>N</code> numbers (separated by whitespace) from the next line(s).
     *
     * @param N number of numbers to read.
     * @return an array containing the next <code>N</code> numbers.
     * @throws ParseException if not enough elements can be read, or not all elements can be parsed to long.
     */
    public long[] getLongArray(int N) throws ParseException {
        return LineParser.toLongArray(getStringArray(N));
    }

    /**
     * Read an integer <code>N</code> from the next line, and read <code>N</code> numbers (separated by
     * whitespace) after that (from more than one line if necessary).
     *
     * @return the <code>N</code> numbers read.
     * @throws ParseException if no count can be found, or not enough numbers can be read.
     */
    public long[] getLongArrayWithCount() throws ParseException {
        return LineParser.toLongArray(getStringArrayWithCount());
    }

    /**
     * Transform a String array to a double array.
     * 
     * @param data the array containing the numbers to parse, as Strings.
     * @return an array containing the parsed numbers.
     * @throws ParseException if not all numbers could be parsed to double.
     */
    public static double[] toDoubleArray(String[] data) throws ParseException {
        double[] result = new double[data.length];
        for (int i = 0; i < data.length; i++) {
            try {
                result[i] = Double.parseDouble(data[i]);
            } catch (NumberFormatException e) {
                throw new ParseException("Could not parse \"" + data[i] + "\" to a double!", e);
            }
        }
        return result;
    }

    /**
     * Get the numbers of the next line (separated by whitespace) as a <code>double</code> array.
     *
     * @return the numbers of the next line.
     * @throws ParseException if no more lines available to read, or next line does not contain only numbers.
     */
    public double[] getDoubleArray() throws ParseException {
        return LineParser.toDoubleArray(getStringArray());
    }

    /**
     * Get <code>N</code> numbers (separated by whitespace) from the next line(s).
     *
     * @param N number of numbers to read.
     * @return an array containing the next <code>N</code> numbers.
     * @throws ParseException if not enough elements can be read, or not all elements can be parsed to double.
     */
    public double[] getDoubleArray(int N) throws ParseException {
        return LineParser.toDoubleArray(getStringArray(N));
    }

    /**
     * Read an integer <code>N</code> from the next line, and read <code>N</code> numbers (separated by
     * whitespace) after that (from more than one line if necessary).
     *
     * @return the <code>N</code> numbers read.
     * @throws ParseException if no count can be found, or not enough numbers can be read.
     */
    public double[] getDoubleArrayWithCount() throws ParseException {
        return LineParser.toDoubleArray(getStringArrayWithCount());
    }

    public int getNextLineNumber() {
        return nextLineNumber;
    }

}
