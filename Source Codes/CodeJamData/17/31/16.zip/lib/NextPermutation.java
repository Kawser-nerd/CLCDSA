package lib;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.OptionalInt;
import java.util.stream.IntStream;

public class NextPermutation {

    public static <T> boolean step(List<T> target, Comparator<T> comparator) {
        if (target.size() <= 1)
            return false;
        OptionalInt lastIncreasing = DecreasingIntStream.of(target.size() - 2, 0)
                .filter(i -> comparator.compare(target.get(i), target.get(i + 1)) < 0)
                .findFirst();
        if (!lastIncreasing.isPresent())
            return false;
        int p = lastIncreasing.getAsInt();
        Collections.reverse(target.subList(p + 1, target.size()));
        IntStream.range(p + 1, target.size())
                .filter(i -> comparator.compare(target.get(i), target.get(p)) > 0)
                .findFirst()
                .ifPresent(i -> Collections.swap(target, p, i));
        return true;
    }

}
