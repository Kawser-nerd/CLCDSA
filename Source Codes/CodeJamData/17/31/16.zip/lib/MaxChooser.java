package lib;

import java.util.Comparator;

public class MaxChooser {

    public static <T> Chooser<T> create(final Comparator<T> comparator) {
        return new Chooser<T>() {
            T best = null;

            @Override
            public void update(T v) {
                if (best == null || comparator.compare(best, v) < 0)
                    best = v;
            }

            @Override
            public T get() {
                Assertion.check(best != null);
                return best;
            }
        };
    }
}
