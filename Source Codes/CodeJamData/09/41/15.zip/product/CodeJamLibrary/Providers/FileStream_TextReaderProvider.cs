using System.IO;
using CodeJamLibrary.Interfaces;

namespace CodeJamLibrary.Providers
{
  public class FileStream_TextReaderProvider : ITextReaderProvider
  {
    private readonly IFilePathProvider filePathProvider;
    private StreamReader streamReader;

    public FileStream_TextReaderProvider(IFilePathProvider filePathProvider)
    {
      this.filePathProvider = filePathProvider;
    }


    public TextReader GetReader()
    {
      return streamReader;
    }


    public void Open()
    {
      streamReader = new StreamReader(filePathProvider.GetFilePath());
    }

    public void Close()
    {
      streamReader.Close();
    }
  }
}