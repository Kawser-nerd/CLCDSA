﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using Google_Code_Jam.Problems.Diamonds;
using Google_Code_Jam.Problems.Factories;
using Google_Code_Jam.Problems.Hills;

namespace Google_Code_Jam
{
    class MainForm : Form
    {
        protected override void OnShown(EventArgs e)
        {
            var algorithm = new Factory();
            
            var openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                new Thread(() =>
                {
                    var inputFileName = openFileDialog.FileName;
                    var inputFile = File.OpenRead(inputFileName);
                    var outFileName = Path.Combine(Path.GetDirectoryName(inputFileName),
                        Path.GetFileNameWithoutExtension(inputFileName) + ".out");
                    var outputFile = File.Create(outFileName);
                    var outputWriter = new StreamWriter(outputFile);
                    var result = algorithm.Run(inputFile);
                    outputWriter.Write(result);
                    outputWriter.Close();
                }).Start();
            }
            else
            {
                new Thread(algorithm.SolveLargeProblems).Start();
            }
        }

        private RichTextBox console;

        public MainForm()
        {
            InitializeComponent();
            var listener = new MyListener(console);
            Trace.Listeners.Add(listener);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Close();
                return true;
            }
            return false;
        }

        class MyListener : TraceListener
        {
            readonly RichTextBox box;

            public MyListener(RichTextBox box)
            {
                this.box = box;
            }

            public override void Write(string message)
            {
                if (box.IsDisposed)
                    return;

                if (box.InvokeRequired)
                    box.BeginInvoke(new Action(() => box.AppendText(message)));
                else
                    box.AppendText(message);
            }

            public override void WriteLine(string message)
            {
                Write(message + Environment.NewLine);
            }
        }

        private void InitializeComponent()
        {
            this.console = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // console
            // 
            this.console.Dock = System.Windows.Forms.DockStyle.Fill;
            this.console.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.console.Location = new System.Drawing.Point(0, 0);
            this.console.Name = "console";
            this.console.Size = new System.Drawing.Size(706, 544);
            this.console.TabIndex = 0;
            this.console.Text = "";
            this.console.WordWrap = false;
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(706, 544);
            this.Controls.Add(this.console);
            this.Name = "MainForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }
    }
}
