package problems;

import java.math.BigInteger;

import main.IOManager;
import main.Problem;

public class Bullseye extends Problem {

	public Bullseye(IOManager io) {
		super(io);
	}

	long r, t;
	
	@Override
	protected String solveCase() {
		long[] line = io.readLongs();
		long r = line[0];
		long t = line[1];
		long ring = r;
		long count = 0;
		long lastcost = -1;
		
		long startcost = (ring+1)*(ring+1)-(ring*ring);
		long low = 1;
		long high = t;
		
		while (true){
			
			long pivot = low+(high-low)/2;
			//System.out.println(low+"-"+high+"  "+pivot+"--"+getCost(pivot, startcost));
			if (getCost(pivot, startcost) <= t && getCost(pivot+1, startcost) > t)
				return String.valueOf(pivot);
			if (getCost(pivot, startcost) < t)
				low = pivot;
			else
				high = pivot;
		}
		
//		while (true){
//			long cost;
//			if (lastcost == -1)
//				cost = (ring+1)*(ring+1)-(ring*ring);
//			else
//				cost = lastcost+4;
//			if (lastcost != -1 && lastcost+4 != cost)
//				System.out.println("Fehler in der Matrix");
//			
//			lastcost = cost;
//			if (cost > t)
//				break;
//			t-= cost;
//			count++;
//			ring += 2;
//		}
		
	}
	
	long getCost(long n, long startcost){
		BigInteger result = new BigInteger(String.valueOf(n)).multiply(new BigInteger(String.valueOf(n-1))).multiply(new BigInteger(String.valueOf(2)));
		result = result.add(new BigInteger(String.valueOf(n)).multiply(new BigInteger(String.valueOf(startcost))));
		if (result.bitLength() > 63)
			return Long.MAX_VALUE;
		return result.longValue();
		//return  (new BigInteger(n))*startcost+n*(n-1)*2;
	}

}
