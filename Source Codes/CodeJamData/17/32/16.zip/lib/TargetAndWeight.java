package lib;

import java.util.Arrays;

public final class TargetAndWeight<V> {
    final V target;
    final double weight;

    public TargetAndWeight(V target, double weight) {
        this.target = target;
        this.weight = weight;
    }

    @Override
    public String toString() {
        return Arrays.asList(target, weight).toString();
    }
}
