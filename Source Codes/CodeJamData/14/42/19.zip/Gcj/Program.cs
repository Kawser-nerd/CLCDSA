﻿using Gcj.Util;
using Gcj.Y2014.R2.A;
using Gcj.Y2014.R2.B;
using Gcj.Y2014.R2.C;

namespace Gcj
{
    class Program
    {
        static void Main(string[] args)
        {
            GcjSolver.Solve<BSolver>();
            //ConcurrentGcjSolver.Solve<OutOfGasConcurrentSolver2>(true);
        }
    }
}
