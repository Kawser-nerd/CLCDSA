﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace gcj
{
    public class ProblemReader : IDisposable
    {

        public ProblemReader(string infile)
        {
            Reader = new StreamReader(File.OpenRead(infile));
        }

        public ProblemReader Read(Action<string> action)
        {
            action(Reader.ReadLine());
            return this;
        }

        public ProblemReader Read(Action<string[]> action)
        {
            return Read(s => action(s.Split(' ')));
        }

        #region Read<T1, ..., TX>(out T1 p1, ..., out TX pX)
        public ProblemReader Read<T1>(out T1 p1)
        {
            if (typeof(T1) == typeof(string))
            {
                p1 = (T1)(object)Reader.ReadLine();
                return this;
            }
            return Read(out p1, out _x, out _x, out _x, out _x, out _x, out _x, out _x, out _x);
        }

        public ProblemReader Read<T1, T2>(out T1 p1, out T2 p2)
        {
            return Read(out p1, out p2, out _x, out _x, out _x, out _x, out _x, out _x, out _x);
        }

        public ProblemReader Read<T1, T2, T3>(out T1 p1, out T2 p2, out T3 p3)
        {
            return Read(out p1, out p2, out p3, out _x, out _x, out _x, out _x, out _x, out _x);
        }

        public ProblemReader Read<T1, T2, T3, T4>(out T1 p1, out T2 p2, out T3 p3, out T4 p4)
        {
            return Read(out p1, out p2, out p3, out p4, out _x, out _x, out _x, out _x, out _x);
        }

        public ProblemReader Read<T1, T2, T3, T4, T5>(out T1 p1, out T2 p2, out T3 p3, out T4 p4, out T5 p5)
        {
            return Read(out p1, out p2, out p3, out p4, out p5, out _x, out _x, out _x, out _x);
        }

        public ProblemReader Read<T1, T2, T3, T4, T5, T6>(out T1 p1, out T2 p2, out T3 p3, out T4 p4, out T5 p5, out T6 p6)
        {
            return Read(out p1, out p2, out p3, out p4, out p5, out p6, out _x, out _x, out _x);
        }

        public ProblemReader Read<T1, T2, T3, T4, T5, T6, T7>(out T1 p1, out T2 p2, out T3 p3, out T4 p4, out T5 p5, out T6 p6, out T7 p7)
        {
            return Read(out p1, out p2, out p3, out p4, out p5, out p6, out p7, out _x, out _x);
        }

        public ProblemReader Read<T1, T2, T3, T4, T5, T6, T7, T8>(out T1 p1, out T2 p2, out T3 p3, out T4 p4, out T5 p5, out T6 p6, out T7 p7, out T8 p8)
        {
            return Read(out p1, out p2, out p3, out p4, out p5, out p6, out p7, out p8, out _x);
        }

        public ProblemReader Read<T1, T2, T3, T4, T5, T6, T7, T8, T9>(out T1 p1, out T2 p2, out T3 p3, out T4 p4, out T5 p5, out T6 p6, out T7 p7, out T8 p8, out T9 p9)
        {
            var items = (Reader.ReadLine() ?? "").Split(' ');
            Parse(items, 0, out p1);
            Parse(items, 1, out p2);
            Parse(items, 2, out p3);
            Parse(items, 3, out p4);
            Parse(items, 4, out p5);
            Parse(items, 5, out p6);
            Parse(items, 6, out p7);
            Parse(items, 7, out p8);
            Parse(items, 8, out p9);
            return this;
        }
        #endregion Read<T1, ..., TX>(out T1 p1, ..., out TX pX)

        #region Read<T1, ..., TX>(int n, out T1[] p1, ..., out TX[] pX)
        public ProblemReader Read<T1>(int n, out T1[] p1)
        {
            return Read(n, out p1, out _y, out _y, out _y, out _y, out _y, out _y, out _y, out _y);
        }

        public ProblemReader Read<T1, T2>(int n, out T1[] p1, out T2[] p2)
        {
            return Read(n, out p1, out p2, out _y, out _y, out _y, out _y, out _y, out _y, out _y);
        }

        public ProblemReader Read<T1, T2, T3>(int n, out T1[] p1, out T2[] p2, out T3[] p3)
        {
            return Read(n, out p1, out p2, out p3, out _y, out _y, out _y, out _y, out _y, out _y);
        }

        public ProblemReader Read<T1, T2, T3, T4>(int n, out T1[] p1, out T2[] p2, out T3[] p3, out T4[] p4)
        {
            return Read(n, out p1, out p2, out p3, out p4, out _y, out _y, out _y, out _y, out _y);
        }

        public ProblemReader Read<T1, T2, T3, T4, T5>(int n, out T1[] p1, out T2[] p2, out T3[] p3, out T4[] p4, out T5[] p5)
        {
            return Read(n, out p1, out p2, out p3, out p4, out p5, out _y, out _y, out _y, out _y);
        }

        public ProblemReader Read<T1, T2, T3, T4, T5, T6>(int n, out T1[] p1, out T2[] p2, out T3[] p3, out T4[] p4, out T5[] p5, out T6[] p6)
        {
            return Read(n, out p1, out p2, out p3, out p4, out p5, out p6, out _y, out _y, out _y);
        }

        public ProblemReader Read<T1, T2, T3, T4, T5, T6, T7>(int n, out T1[] p1, out T2[] p2, out T3[] p3, out T4[] p4, out T5[] p5, out T6[] p6, out T7[] p7)
        {
            return Read(n, out p1, out p2, out p3, out p4, out p5, out p6, out p7, out _y, out _y);
        }

        public ProblemReader Read<T1, T2, T3, T4, T5, T6, T7, T8>(int n, out T1[] p1, out T2[] p2, out T3[] p3, out T4[] p4, out T5[] p5, out T6[] p6, out T7[] p7, out T8[] p8)
        {
            return Read(n, out p1, out p2, out p3, out p4, out p5, out p6, out p7, out p8, out _y);
        }

        public ProblemReader Read<T1, T2, T3, T4, T5, T6, T7, T8, T9>(int n, out T1[] p1, out T2[] p2, out T3[] p3, out T4[] p4, out T5[] p5, out T6[] p6, out T7[] p7, out T8[] p8, out T9[] p9)
        {
            p1 = new T1[n];
            p2 = new T2[n];
            p3 = new T3[n];
            p4 = new T4[n];
            p5 = new T5[n];
            p6 = new T6[n];
            p7 = new T7[n];
            p8 = new T8[n];
            p9 = new T9[n];
            for (int i = 0; i < n; i++)
            {
                Read(out p1[i], out p2[i], out p3[i], out p4[i], out p5[i], out p6[i], out p7[i], out p8[i], out p9[i]);
            }
            return this;
        }
        #endregion Read<T1, ..., TX>(int n, out T1[] p1, ..., out TX[] pX)

        public ProblemReader Read<T>(int n, out T[][] param)
        {
            param = new T[n][];
            for (int i = 0; i < n; i++)
            {
                Read(out param[i]);
            }
            return this;
        }

        public ProblemReader Read<T>(out T[] param)
        {
            param = (Reader.ReadLine() ?? "").Split(' ').Select(t => (T)Convert.ChangeType(t, typeof(T))).ToArray();
            return this;
        }

        public ProblemReader Read<T>(int n, out T[] param, Action<T> parser) where T : class, new()
        {
            param = new T[n];
            for (int i = 0; i < n; i++)
            {
                parser(param[i] = new T());
            }
            return this;
        }

        #region privates
        private void Parse<T>(string input, out T output)
        {
            output = (T)Convert.ChangeType(input, typeof(T));
        }

        private void Parse<T>(string[] inputs, int index, out T output)
        {
            if (index < inputs.Length)
                Parse(inputs[index], out output);
            else
                output = default(T);
        }

        private StreamReader Reader { get; set; }

        public void Dispose()
        {
            Reader.Dispose();
        }

        private object _x;
        private object[] _y;
        #endregion privates
    }

    public abstract class Problem
    {
        public abstract IEnumerable<Action> StaticInitialize();
        public abstract void Parse(ProblemReader reader);
        public abstract object Solve();

        public int Number { get; set; }
    }

    public class ProblemSet<TP> where TP : Problem, new()
    {
        public static void Solve(string[] args)
        {
            Console.WriteLine();
            var stopwatch = new Stopwatch();
            stopwatch.Start();
            try
            {
                var infile = args.FirstOrDefault(a => !a.StartsWith("-")) ?? "sample.in";
                var outfile = infile.Replace(".in", "") + ".out";
                var synchronous = args.Contains("-debug");

                WriteOutput(outfile, synchronous,
                    Parse(infile, synchronous,
                        Initialize().ContinueWith(x =>
                            Console.WriteLine("Initialized in {0} milliseconds.", stopwatch.ElapsedMilliseconds),
                            TaskContinuationOptions.ExecuteSynchronously)));

                Console.WriteLine("Solved in {0} milliseconds.", stopwatch.ElapsedMilliseconds);
            }
            catch (Exception e)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Error.Write(e.ToString());
                Console.ResetColor();
                Console.WriteLine();
                Console.WriteLine("Failed in {0} milliseconds.", stopwatch.ElapsedMilliseconds);
            }
        }

        private static Task Initialize()
        {
            return Task.WhenAll(new TP().StaticInitialize().Select(a => Task.Factory.StartNew(a)));
        }

        private static Task<object>[] Parse(string infile, bool synchronous, Task init)
        {
            using (var reader = new ProblemReader(infile))
            {
                int T;
                reader.Read(out T);
                var results = new Task<object>[T];
                for (var t = 0; t < T; t++)
                {
                    var problem = new TP { Number = t + 1 };
                    problem.Parse(reader);
                    results[t] = synchronous ?
                        new Task<object>(() =>
                        {
                            init.Wait();
                            return problem.Solve();
                        }) :
                        init.ContinueWith(x => problem.Solve());
                }
                return results;
            }
        }

        private static void WriteOutput(string outfile, bool synchronous, Task<object>[] problems)
        {
            using (var writer = new StreamWriter(File.Open(outfile, FileMode.Create, FileAccess.Write)))
            {
                Console.ForegroundColor = ConsoleColor.Green;
                for (var i = 0; i < problems.Length; i++)
                {
                    if (synchronous) problems[i].Start();
                    var line = String.Format("Case #{0}: {1}", i + 1, problems[i].Result);
                    Console.WriteLine(line);
                    writer.WriteLine(line);
                }
                Console.ResetColor();
            }
        }
    }

    public static class Extensions
    {
        public static TV Get<TK, TV>(this Dictionary<TK, TV> dict, TK key)
        {
            return dict.ContainsKey(key) ? dict[key] : default(TV);
        }

        public static bool Has<TK, TV>(this Dictionary<TK, TV> dict, TK key)
        {
            return dict.ContainsKey(key);
        }
    }
}
