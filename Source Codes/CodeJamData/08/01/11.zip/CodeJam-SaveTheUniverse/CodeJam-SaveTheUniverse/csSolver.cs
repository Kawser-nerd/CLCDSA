﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam_SaveTheUniverse
{
    class csSolver
    {
        public static int SolveCase(csTestCase Case)
        {
            if (Case.Keywords.Count == 0) return 0;


            List<string> Engines2 = new List<string>();
            foreach (string str in Case.EngineNames) Engines2.Add(str);

            foreach (string strKeyword in Case.Keywords)
            {
                if (Engines2.Count <= 1) break;
                if (Engines2.Contains(strKeyword)) Engines2.Remove(strKeyword);
            }

            return Solver(Case.EngineNames, Case.Keywords, Engines2[0], Case.Keywords.Count);


            /*
            int minScore = Case.Keywords.Count;
            foreach (string strEngine in Case.EngineNames)
            {
                if (!strEngine.Equals(Case.Keywords[0]))
                {
                    int Score = Solver(Case.EngineNames, Case.Keywords, strEngine, minScore);
                    if (minScore > Score) minScore = Score;
                }
            }
            return minScore;
             * */
        }

        private static int Solver(List<string> EngineNames, List<string> Keywords, string CurEngine, int maxScore)
        {
            if (Keywords.Count == 0) return 0;

            List<string> Keywords2 = new List<string>();
            foreach (string str in Keywords) Keywords2.Add(str);
            Keywords2.RemoveAt(0);

            if (!Keywords[0].Equals(CurEngine)) return Solver(EngineNames, Keywords2, CurEngine, maxScore);

            List<string> Engines2 = new List<string>();
            foreach (string str in EngineNames) Engines2.Add(str);

            foreach (string strKeyword in Keywords)
            {
                if (Engines2.Count <= 1) break;
                if (Engines2.Contains(strKeyword)) Engines2.Remove(strKeyword);
            }

            if (maxScore == 1) return 1;
            return Solver(EngineNames, Keywords2, Engines2[0], maxScore - 1) + 1;

            /*
            int minScore = maxScore-1;
            if (maxScore == 1) 
                return 1;
            foreach (string strEngine in EngineNames)
            {
                if (minScore == 0) break;
                if (!strEngine.Equals(Keywords[0]))
                {
                    int Score = Solver(EngineNames, Keywords2, strEngine, minScore);
                    if (minScore > Score) minScore = Score;
                }
            }

            return minScore + 1;
             * */
        }
    }
}
