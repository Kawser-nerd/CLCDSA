using System;

namespace Generic.Common
{
    internal class UnreachableException : Exception
    {
    }
}