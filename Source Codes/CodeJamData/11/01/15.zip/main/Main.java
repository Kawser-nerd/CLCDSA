package main;

import generic.FileProcessor;


public class Main {

	public static void main(String[] args){
		if(args.length != 2){
			System.out.println("Use: java main.Main [problem name] [filename]");
			System.exit(1);
		}
		String problemName = args[0];
		String fileName = args[1];
		FileProcessor.process(problemName, fileName);
	}
}