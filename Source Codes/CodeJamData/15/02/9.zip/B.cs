﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Numerics;

namespace GCJ
{
    public class B : X
    {
        private int N;
        private int[] D;
        private int min=0;
        private int least=3;
        private int[] count;

        public override void Init()
        {
            N = ReadIntLine();
            D = ReadIntArrayLine();
            count=new int[1001];
            for (int i = 0; i < N; i++)
            {
                int k = D[i];
                count[k]++;
                if (k > min) min = k;
            }
        }
        public override void Solve()
        {
            if (min <= least)
            ; // ok, min passt
            else if ((min==least+1) && (count[min]==1) && count[least-1]==0)  // bei einem 4er reicht 3
                min=least;
            else
            {
                int c = min;
                int max = min;
                for (int test = least; test <= max; test++)
                {
                    c = test;
                    for (int j = test+1; j <= max; j++)
                    {
                        int v = count[j];
                        if (v > 0)
                        {
                            c += ((j - 1)/test)*v;
                            if (c >= min)
                                break;
                        }
                    }
                    if (c < min)
                        min = c;
                    if (min <= test)
                        break;
                }
            }

            Result.Append(min);
        }
    }
}