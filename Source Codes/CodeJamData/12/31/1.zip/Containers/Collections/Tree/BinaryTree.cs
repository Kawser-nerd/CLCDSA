﻿namespace Generic.Containers.Collections.Tree
{
    internal class BinaryTree
    {
    }
}