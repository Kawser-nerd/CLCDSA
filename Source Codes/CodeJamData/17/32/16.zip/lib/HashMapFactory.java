package lib;

import java.util.HashMap;

public class HashMapFactory {
    public static <K> MapFactory<K> create() {
        return HashMap::new;
    }
}
