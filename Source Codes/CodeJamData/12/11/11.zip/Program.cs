﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ProblemA
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var input = new StreamReader(File.Open(args[0], FileMode.Open, FileAccess.Read)))
            using (var output = new StreamWriter(File.Open(args[1], FileMode.Create, FileAccess.Write)))
            {
                Program p = new Program();
                int T = int.Parse(input.ReadLine());
                for (int i = 0; i < T; i++)
                {
                    var ii = input.ReadLine().Split(' ').Select(ss => int.Parse(ss)).ToList();
                    var jj = input.ReadLine().Split(' ').Select(ss => double.Parse(ss)).ToList();

                    output.WriteLine(String.Format("Case #{0}: {1}", i + 1, p.Solve(ii[0], ii[1], jj)));
                }
            }
        }

        Program()
        {

        }

        double Solve(int A, int B, List<double> P)
        {
            double best = B + 2;

            for (int i = 0; i < A; i++)
            {
                double pp = 1;
                for (int j = 0; j < A-i; j++)
                    pp *= P[j];

                double z = i + (B - (A - i) + 1) + (1 - pp) * (B + 1);
                best = Math.Min(z, best);
            }

            return best;
        }
    }
}
