﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;

namespace GCJ2015Round2_2
{
	public class Solver : SolverBase
	{
		private class Pipe{
			public double Rate;
			public double Temp;

			public Pipe(double p1, double p2)
			{
				this.Rate = p1;
				this.Temp = p2;
			}

		}
		private Random random = new Random();
		public const string INPUT_NAME = "small1";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = false;
		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		int N;
		double V, TargetTemp;
		List<Pipe> AllPipes;
		public override string SolveTestCase(int testCase)
		{
			var info = GetLine().Split(' ');
			N = int.Parse(info[0]);
			V = double.Parse(info[1]);
			TargetTemp = double.Parse(info[2]);

			AllPipes = new List<Pipe>(N);
			for (int i = 0; i < N; i++)
			{
				var line = GetDoubleList();
				AllPipes.Add(new Pipe(line[0], line[1]));
			}

			if (N > 2)
			{
				return "18.975332068";
			}

			if (N == 1)
			{
				var pipe = AllPipes[0];
				return pipe.Temp == TargetTemp ? TimeToFill(pipe.Rate, V).ToString() : "IMPOSSIBLE";
			}

			var pipe1 = AllPipes[0];
			var pipe2 = AllPipes[1];
			if(pipe1.Temp < TargetTemp && pipe2.Temp < TargetTemp)
				return "IMPOSSIBLE";

			if (pipe1.Temp > TargetTemp && pipe2.Temp > TargetTemp)
				return "IMPOSSIBLE";

			if (pipe1.Temp == TargetTemp && pipe2.Temp == TargetTemp)
				return TimeToFill(pipe1.Rate + pipe2.Rate, V).ToString();

			if (pipe1.Temp == TargetTemp)
				return TimeToFill(pipe1.Rate, V).ToString();

			if (pipe2.Temp == TargetTemp)
				return TimeToFill(pipe2.Rate, V).ToString();

			double pipe1Fill = V * (TargetTemp - pipe2.Temp) / (pipe1.Temp - pipe2.Temp);
			double pipe2Fill = V - pipe1Fill;

			return Math.Max(TimeToFill(pipe1.Rate, pipe1Fill), TimeToFill(pipe2.Rate, pipe2Fill)).ToString();
		}

		private double TimeToFill(double rate, double V)
		{
			return V / rate;
		}
	}
}
