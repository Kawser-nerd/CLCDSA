package lib;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.function.Function;

public class ArrayBaseHashMapFactory {

    public static <T> MapFactory<T> of(Function<T, Object[]> extractor) {
        return CustomHashMapFactory.create(new HashMapMaterial<>(o -> {
            Object[] array = extractor.apply(o);
            return deepHash(array);
        }, (o1, o2) -> {
            Object[] v1 = extractor.apply(o2);
            Object[] v2 = extractor.apply(o1);
            return Arrays.deepEquals(v1, v2);
        }));
    }

    private static int deepHash(Object nullable) {
        if (nullable == null)
            return 0;
        if (!nullable.getClass().isArray())
            return nullable.hashCode();
        int length = Array.getLength(nullable);
        int hash = 0;
        for (int i = 0; i < length; i++)
            hash = TwoIntHash.hash(hash, deepHash(Array.get(nullable, i)));
        return hash;
    }

}
