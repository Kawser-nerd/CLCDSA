package lib;

import java.io.InputStream;
import java.util.Scanner;
import java.util.function.Function;
import java.util.function.Supplier;

public interface NormalTokenizerFactory {
    public static final Function<InputStream, Supplier<String>> INSTANCE = is -> new Scanner(is)::next;
}
