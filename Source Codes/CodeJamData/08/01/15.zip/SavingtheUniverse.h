#ifndef	__GCJ__SAVINGTHEUNIVERSE_H__
#define	__GCJ__SAVINGTHEUNIVERSE_H__

#include <vector>
#include <list>
#include <map>

#include "Task.h"

class SavingtheUniverse : private Task
{
	public:
	SavingtheUniverse(std::istream&, std::string&, boost::condition&, char &);
	SavingtheUniverse(SavingtheUniverse&);
	~SavingtheUniverse();
	void operator()();

	private:
	unsigned long		num_sengines;
	unsigned long		num_queries;
	std::string			sengine_name[100];
	unsigned long		query[1000];
};

#endif /*__GCJ__SAVINGTHEUNIVERSE_H__*/
