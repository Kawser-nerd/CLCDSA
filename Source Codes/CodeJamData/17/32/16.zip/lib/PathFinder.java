package lib;

import java.util.List;

public interface PathFinder {
    List<Integer> findOrNull(AdjacentListGetter adj, int start, int end);
}
