package lib;

import java.util.function.BinaryOperator;

public class BinomialCoefficientTable {

    public static <T> Solver<IntPair, T> create(T one, BinaryOperator<T> adder) {
        return MemoizationSolver.of(NormalIntPairHashMapFactory.INSTANCE, (terms, sub) -> {
            int n = terms.v1;
            int r = terms.v2;
            Assertion.check(n >= r && r >= 0);
            if (r == n || r == 0)
                return one;
            T sub1 = sub.solve(new IntPair(n - 1, r));
            T sub2 = sub.solve(new IntPair(n - 1, r - 1));
            return adder.apply(sub1, sub2);
        });
    }

}
