#include "cjlib.h"

int test_count, X;

int main(void) {
	array(unsigned int) p = array_new(NULL);
	char *s;
	size_t i, j;
	
	read_line();
	test_count = atoi(line);
	
	for (X=1; X<=test_count; X++) {
		s = read_line();
		p.size = 0;
		for (;*s;s++)
			array_append(p, *s - '0');
		if (!perm_next(p.item, p.size)) {
			array_append(p, 0);
			memmove(p.item+1, p.item, (p.size-1)*sizeof(*p.item));
			p.item[0] = 0;
		}
		for (j=0; j<p.size; j++) {
			if (p.item[j] != 0)
				break;
		}
		if (j > 0) {
			if (j >= p.size) {
				printf("Case #%d: 0\n", X);
				continue;
			}
			p.item[0] = p.item[j];
			p.item[j] = 0;
		}
		printf("Case #%d: ", X);
		for (i=0; i<p.size; i++)
			putchar('0'+p.item[i]);
		putchar('\n');
	}
	
	return 0;
}
