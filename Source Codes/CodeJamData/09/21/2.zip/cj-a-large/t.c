#include "cjlib.h"

int test_count, X;

int main(void) {
	read_line();
	test_count = atoi(line);
	
	for (X=1; X<=test_count; X++) {
		
	}
	
	return 0;
}
