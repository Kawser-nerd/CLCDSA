﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace codejam
{
    class fCalc
    {
        public const float prec = 0.0000001f;
        public static bool isZero(double n) { return Math.Abs(n) <= prec; }

        public static bool aIGUALb(double a, double b) { return isZero(a-b); }
        public static bool aMAYORb(double a, double b) { return isZero(a - b) ? false : a > b; }
        public static bool aMAYOR_IGUALb(double a, double b) { return isZero(a - b) ? true : a > b; }
        public static bool aMENORb(double a, double b) { return isZero(a - b) ? false : a < b; }
        public static bool aMENOR_IGUALb(double a, double b) { return isZero(a - b) ? true : a < b; }
    }
}
