﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Utils.Infrastructure {
    public interface IProblemWriter {
        void BeginCase(int caseNumber);
        void WriteResult(string result);
        void EndCase();

        void Close();
    }
}
