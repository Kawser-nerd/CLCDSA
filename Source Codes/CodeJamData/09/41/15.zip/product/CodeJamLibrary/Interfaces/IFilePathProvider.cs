namespace CodeJamLibrary.Interfaces
{
  public interface IFilePathProvider
  {
    string GetFilePath();
  }
}