package lib;

public class PolarAngleRange {
    public final PolarAngle start, end;

    public PolarAngleRange(PolarAngle start, PolarAngle end) {
        this.start = start;
        this.end = end;
    }
}
