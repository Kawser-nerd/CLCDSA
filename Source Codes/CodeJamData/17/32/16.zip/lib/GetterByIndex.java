package lib;

public interface GetterByIndex<C, I> {
    I get(C c, int index);
}
