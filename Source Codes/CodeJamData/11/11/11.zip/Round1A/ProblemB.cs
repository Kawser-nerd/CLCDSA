﻿using System.IO;
using Paraiba.IO;

namespace Round1A
{
	public class ProblemB
	{
		public static void Solve(TextReader input, TextWriter output) {
			var sc = new Scanner(input);
			var nTestCases = sc.NextInt32();
			for (int iTestCases = 0; iTestCases < nTestCases; iTestCases++) {
				var result = 0;
				output.WriteLine("Case #" + (iTestCases + 1) + ": " + result);
			}
		}
	}
}
