﻿using System.IO;
using Template.Interfaces;

namespace Template
{
  public class Input : IInput
  {
    private readonly TextReader textReader;

    public Input(TextReader textReader)
    {
      this.textReader = textReader;
    }

    public void Close()
    {
      textReader.Close();
    }

    public string ReadLine()
    {
      return textReader.ReadLine();
    }

    public string[] SplitLine()
    {
      return ReadLine().Split(' ');
    }

    public int[] ParseInt()
    {
      string[] tokens = SplitLine();
      int length = tokens.Length;

      var values = new int[length];

      for (int i = 0; i < length; i++)
      {
        values[i] = int.Parse(tokens[i]);
      }

      return values;
    }
  }
}