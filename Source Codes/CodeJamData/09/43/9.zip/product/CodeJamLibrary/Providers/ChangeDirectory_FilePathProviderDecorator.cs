using System;
using System.IO;
using CodeJamLibrary.Interfaces;

namespace CodeJamLibrary.Providers
{
  public class ChangeDirectory_FilePathProviderDecorator : IFilePathProvider
  {
    private readonly IFilePathProvider filePathProvider;
    private readonly string newDirectory;

    public ChangeDirectory_FilePathProviderDecorator(IFilePathProvider filePathProvider, string newDirectory)
    {
      this.filePathProvider = filePathProvider;
      this.newDirectory = newDirectory;
    }

    public string GetFilePath()
    {
      string path = filePathProvider.GetFilePath();
      var fileName =  Path.GetFileName(path);

      return Path.Combine(newDirectory, fileName);
    }
  }
}