using System.Configuration;
using CodeJamLibrary;
using CodeJamLibrary.Interfaces;
using CodeJamLibrary.Providers;

namespace CodeJam
{
  public class ProblemWrapper : IProblemWrapper
  {
    private FileStream_TextReaderProvider textReaderProvider;
    private FileStream_TextWriterProvider textWriterProvider;

    private ProblemExecution problemExecution;

    public void Setup()
    {
      string inputPath = ConfigurationManager.AppSettings["InputDirectory"];
      string outputPath = ConfigurationManager.AppSettings["OutputDirectory"];

      var inputFileProvider = new AutoLoadFromDirectory_FilePathProvider(inputPath);
      var outputFileProvider =
        new ChangeExtensiontodotOut_FilePathProviderDecorator(
          new ChangeDirectory_FilePathProviderDecorator(inputFileProvider, outputPath));


      textReaderProvider = new FileStream_TextReaderProvider(inputFileProvider);
      textWriterProvider = new FileStream_TextWriterProvider(outputFileProvider);

      textReaderProvider.Open();
      textWriterProvider.Open();

      var problemInput = new ProblemInput(textReaderProvider);
      var problemOutput = new ProblemOutput(textWriterProvider);
      var problemFactory = new ProblemFactory();
      var problemTypeProvider = new FromInputFilePath_ProblemTypeProvider(inputFileProvider);

      problemExecution = new ProblemExecution(problemInput, problemOutput, problemFactory, problemTypeProvider);
    }

    public void Execute()
    {
      problemExecution.Execute();
    }

    public void TearDown()
    {
      textReaderProvider.Close();
      textWriterProvider.Close();
    }
  }
}