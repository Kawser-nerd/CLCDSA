﻿using System;
using System.Globalization;
using System.Text;

namespace Chaow.Numeric {
    public struct BigInteger : IFormattable, IEquatable<BigInteger>, IComparable<BigInteger>, IComparable {
        //constants
        const decimal decHexPortion = 1.070328873M;
        const uint minusBit = 2147483648;
        const uint lengthMask = 2147483647;

        //local variables
        readonly uint[] _data;

        //static fields
        public static readonly BigInteger Zero = new BigInteger();
        public static readonly BigInteger One = 1;
        public static readonly BigInteger Two = 2;
        public static readonly BigInteger MinusOne = -1;

        //constructors
        public BigInteger(int sign, params uint[] data) : this((sign < 0) ? minusBit : 0, true, getRawLength(data), data) { }
        BigInteger(uint sign, bool copy, uint[] data) : this(sign, copy, getRawLength(data), data) { }
        BigInteger(uint sign, bool copy, uint length, uint[] data) {
            if (length == 0) {
                _data = null;
                return;
            }
            if (copy) {
                _data = new uint[length + 1];
                Array.Copy(data, _data, length);
                _data[length] = length | sign;
            } else {
                _data = data;
                _data[_data.Length - 1] = length | sign;
            }
        }

        //static methods
        static uint getRawLength(uint[] data) {
            if (data == null)
                return 0;
            int index = data.Length - 1;
            while ((index >= 0) && (data[index] == 0))
                index--;
            return (uint)(index + 1);
        }
        static int getLength(uint[] data, out uint minus) {
            if (data == null) {
                minus = 0;
                return 0;
            }
            uint length = data[data.Length - 1];
            minus = length & minusBit;
            return (int)(length & lengthMask);
        }
        static BigInteger add(uint xs, uint[] x, int xl, uint[] y, int yl) {
            uint[] data;
            if (xl < yl)
                data = add(y, yl, x, xl);
            else
                data = add(x, xl, y, yl);
            return new BigInteger(xs, false, data);
        }
        static uint[] add(uint[] x, int xl, uint[] y, int yl) {
            uint[] z = new uint[xl + 2];
            ulong c = 0L;
            int i = 0;
            while (i < yl) {
                c += (ulong)x[i] + y[i];
                z[i] = (uint)c;
                c >>= 32;
                i++;
            }
            while (c != 0L) {
                c += x[i];
                z[i] = (uint)c;
                c >>= 32;
                i++;
            }
            if (i < xl)
                Array.Copy(x, i, z, i, xl - i);
            return z;
        }
        static int compareData(uint[] x, int xl, uint[] y, int yl) {
            if (xl > yl)
                return 1;
            if (xl < yl)
                return -1;
            for (int i = xl - 1; i >= 0; i--) {
                if (x[i] < y[i])
                    return -1;
                else if (x[i] > y[i])
                    return 1;
            }
            return 0;
        }
        static BigInteger sub(uint xs, uint[] x, int xl, uint ys, uint[] y, int yl) {
            int cp = compareData(x, xl, y, yl);
            uint[] data;
            if (cp == 0)
                data = null;
            if (cp < 0) {
                data = sub(y, yl, x, xl);
                return new BigInteger(ys, false, data);
            } else {
                data = sub(x, xl, y, yl);
                return new BigInteger(xs, false, data);
            }
        }
        static uint[] sub(uint[] x, int xl, uint[] y, int yl) {
            uint[] z = new uint[xl + 1];
            bool neg = false;
            int i = 0;
            uint c, d;
            while (i < yl) {
                d = x[i];
                c = y[i];
                if (neg) {
                    neg = d == 0;
                    d--;
                }
                if (c > d)
                    neg = true;
                z[i] = d - c;
                i++;
            }
            while (neg) {
                z[i] = x[i] - 1;
                if (x[i] != 0)
                    neg = false;
                i++;
            }
            if (i < xl)
                Array.Copy(x, i, z, i, xl - i);
            return z;
        }
        static int getStartIndex(uint[] data) {
            int index = 0;
            while (data[index] == 0)
                index++;
            return index;
        }
        static BigInteger mult(uint xs, BigInteger x, int xl, BigInteger y, int yl) {
            if (xl == 0 || yl == 0)
                return Zero;
            if (yl == 1)
                return new BigInteger(xs, false, mult(x._data, xl, y._data[0]));
            if (xl == 1)
                return new BigInteger(xs, false, mult(y._data, yl, x._data[0]));
            return new BigInteger(xs, false, mult(x._data, xl, y._data, yl));
        }
        static uint[] mult(uint[] x, int xl, uint[] y, int yl) {
            uint[] z = new uint[xl + yl + 1];
            int index;
            ulong c = 0L;
            int xi = getStartIndex(x);
            int yi = getStartIndex(y);
            for (int i = xi; i < xl; i++) {
                index = i + yi;
                for (int j = yi; j < yl; j++) {
                    c += ((ulong)x[i] * y[j]) + z[index];
                    z[index++] = (uint)c;
                    c >>= 32;
                }
                while (c != 0L) {
                    c += z[index];
                    z[index++] = (uint)c;
                    c >>= 32;
                }
            }
            return z;
        }
        static uint[] mult(uint[] x, int xl, ulong y) {
            uint[] z = new uint[xl + 2];
            ulong c = 0L;
            int xs = getStartIndex(x);
            for (int i = xs; i < xl; i++) {
                c += x[i] * y;
                z[i] = (uint)c;
                c >>= 32;
            }
            if (c != 0L)
                z[xl] = (uint)c;
            return z;
        }
        static uint[] bitwise_or(uint[] x, int xl, uint[] y, int yl) {
            uint[] z = new uint[xl + 1];
            Array.Copy(x, z, xl);
            for (int i = 0; i < yl; i++)
                z[i] |= y[i];
            return z;
        }
        static uint[] bitwise_xor(uint[] x, int xl, uint[] y, int yl) {
            uint[] z = new uint[xl + 1];
            Array.Copy(x, z, xl);
            for (int i = 0; i < yl; i++)
                z[i] ^= y[i];
            return z;
        }
        static uint[] shiftLeft(uint[] x, int xl, int shift) {
            if (shift < 0)
                return shiftRight(x, xl, -shift);
            int d, r;
            d = Math.DivRem(shift, 32, out r);
            uint[] z = new uint[xl + d + 2];
            if (r == 0)
                Array.Copy(x, 0, z, d, xl);
            else {
                int s = 32 - r;
                uint c = 0, c2;
                for (int index = 0; index < xl; index++) {
                    c2 = x[index];
                    z[index + d] = (c2 << r) | c;
                    c = c2 >> s;
                }
                z[xl + d] = c;
            }
            return z;
        }
        static uint[] shiftRight(uint[] x, int xl, int shift) {
            if (shift < 0)
                return shiftLeft(x, xl, -shift);
            int d, r;
            d = Math.DivRem(shift, 32, out r);
            int zl = xl - d;
            if (zl <= 0)
                return null;
            uint[] z = new uint[zl + 1];
            if (r == 0)
                Array.Copy(x, d, z, 0, zl);
            else {
                int s = 32 - r;
                uint c = 0, c2;
                for (int j = xl - 1; j >= d; j--) {
                    c2 = x[j];
                    z[j - d] = (c2 >> r) | c;
                    c = c2 << s;
                }
            }
            return z;
        }
        static int getNormalizeShift(uint value) {
            int c = 0;
            if ((value & 4294901760) == 0) {
                value = value << 16;
                c += 16;
            }
            if ((value & 4278190080) == 0) {
                value = value << 8;
                c += 8;
            }
            if ((value & 4026531840) == 0) {
                value = value << 4;
                c += 4;
            }
            if ((value & 3221225472) == 0) {
                value = value << 2;
                c += 2;
            }
            if ((value & 2147483648) == 0) {
                value = value << 1;
                c++;
            }
            return c;
        }
        static uint[] divRem(uint[] xd, int xl, uint[] yd, int yl, out uint[] rd) {
            int shift = getNormalizeShift(yd[yl - 1]);
            uint[] u, v;
            if (shift == 0) {
                u = new uint[xl + 1];
                Array.Copy(xd, u, xl);
                v = yd;
            } else {
                u = shiftLeft(xd, xl, shift);
                v = shiftLeft(yd, yl, shift);
            }
            uint[] z = new uint[xl - yl + 2];

            ulong c, d, r;
            long a, b;
            int index;
            int vs = getStartIndex(v);
            for (int j = xl - yl; j >= 0; j--) {
                c = (4294967296UL * u[j + yl]) + u[(j + yl) - 1];
                d = c / v[yl - 1];
                c -= d * v[yl - 1];
                while ((d >= 4294967296UL) || (d * v[yl - 2] > c * 4294967296UL + u[j + yl - 2])) {
                    d -= (ulong)1L;
                    c += v[yl - 1];
                }
                a = b = 0L;
                for (index = vs; index < yl; index++) {
                    c = v[index] * d;
                    b = (long)u[index + j] - (uint)c - a;
                    u[index + j] = (uint)b;
                    c >>= 32;
                    b >>= 32;
                    a = (long)c - b;
                }
                b = u[j + yl] - a;
                u[j + yl] = (uint)b;
                z[j] = (uint)d;
                if (b < 0L) {
                    z[j]--;
                    r = 0L;
                    for (index = vs; index < yl; index++) {
                        r += v[index] + u[j + index];
                        u[j + index] = (uint)r;
                        r >>= 32;
                    }
                    r += u[j + yl];
                    u[j + yl] = (uint)r;
                }
            }
            rd = shiftRight(u, (int)getRawLength(u), shift);
            return z;
        }
        static uint[] divRem(uint[] xd, int xl, uint y, out uint[] rd) {
            ulong r = 0L, d;
            uint[] zd = new uint[xl + 1];
            rd = new uint[2];

            for (int i = xl - 1; i >= 0; i--) {
                r *= 4294967296UL;
                r += xd[i];
                d = r / y;
                r -= d * y;
                zd[i] = (uint)d;
            }
            rd[0] = (uint)r;
            return zd;
        }
        static string toDecString(BigInteger x, NumberFormatInfo info) {
            uint xs;
            uint[] xd = x._data;
            int xl = getLength(xd, out xs);
            if (xl == 0)
                return 0.ToString(info);

            int zl = (int)decimal.Ceiling(xl * decHexPortion) + 1;
            long[] z = new long[zl];
            int l = 0, index;
            long c = 0L, r;
            for (int i = xl - 1; i >= 0; i--) {
                for (int j = 0; j < l; j++) {
                    c += (long)z[j] << 32;
                    c = Math.DivRem(c, 1000000000L, out r);
                    z[j] = r;
                }
                while (c > 0L) {
                    c = Math.DivRem(c, 1000000000L, out r);
                    z[l++] = r;
                }
                index = 0;
                c = xd[i];
                while (c > 0L) {
                    c += z[index];
                    c = Math.DivRem(c, 1000000000L, out r);
                    z[index++] = r;
                }
                if (index > l)
                    l = index;
            }

            StringBuilder sb = new StringBuilder(zl * 9);
            if (xs == minusBit)
                sb.Append(info.NegativeSign);
            l--;
            sb.Append(z[l--].ToString(info));
            char zero = 0.ToString(info)[0];
            while (l >= 0)
                sb.Append(z[l--].ToString(info).PadLeft(9, zero));
            return sb.ToString();
        }
        static string toHexString(BigInteger x, string format, NumberFormatInfo info) {
            uint xs;
            uint[] xd = x._data;
            int xl = getLength(xd, out xs);
            if (xl == 0)
                return 0.ToString(format, info);

            StringBuilder sb = new StringBuilder((xl + 1) * 8);
            if (xs == minusBit)
                sb.Append(info.NegativeSign);
            sb.Append(xd[--xl].ToString(format, info));
            char zero = 0.ToString(format, info)[0];
            while (xl > 0)
                sb.Append(xd[--xl].ToString(format, info).PadLeft(8, zero));
            return sb.ToString();
        }
        static bool isSupportedStyle(NumberStyles style) {
            return (style & (NumberStyles.AllowCurrencySymbol
                           | NumberStyles.AllowDecimalPoint
                           | NumberStyles.AllowExponent
                           | NumberStyles.AllowParentheses
                           | NumberStyles.AllowThousands
                           | NumberStyles.AllowTrailingSign)) == NumberStyles.None;
        }
        static bool fromDecString(string src, NumberStyles style, IFormatProvider provider, out BigInteger result) {
            uint[] z = new uint[(int)decimal.Ceiling((src.Length / 9.0M) / decHexPortion) + 2];
            int d, l = 1, index;
            uint sign = 0;
            ulong c = 0L;
            using (System.IO.StringReader reader = new System.IO.StringReader(src)) {
                char[] buffer = new char[9];
                ulong[] multiplier = { 1L, 10L, 100L, 1000L, 10000L, 100000L, 1000000L, 10000000L, 100000000L, 1000000000L };

                int count = reader.ReadBlock(buffer, 0, 9);
                if (!int.TryParse(new string(buffer, 0, count), style, provider, out d)) {
                    result = Zero;
                    return false;
                }
                if (d < 0) {
                    sign = minusBit;
                    d = -d;
                }
                z[0] = (uint)d;

                while (count == 9) {
                    count = reader.ReadBlock(buffer, 0, 9);
                    for (int i = 0; i < l; i++) {
                        c += z[i] * multiplier[count];
                        z[i] = (uint)c;
                        c >>= 32;
                    }
                    while (c > 0) {
                        z[l++] = (uint)c;
                        c >>= 32;
                    }
                    index = 0;
                    if (!ulong.TryParse(new string(buffer, 0, count), style, provider, out c)) {
                        result = Zero;
                        return false;
                    }
                    while (c > 0L) {
                        c += z[index];
                        z[index++] = (uint)c;
                        c >>= 32;
                    }
                    if (index > l)
                        l = index;
                }
            }
            result = new BigInteger(sign, false, z);
            return true;
        }
        static bool fromHexString(string src, NumberStyles style, IFormatProvider provider, out BigInteger result) {
            int r;
            int l = Math.DivRem(src.Length, 8, out r);
            if (r == 0) {
                l--;
                r = 8;
            }

            uint[] z = new uint[l + 2];
            uint d;
            using (System.IO.StringReader reader = new System.IO.StringReader(src)) {
                char[] buffer = new char[8];
                do {
                    int count = reader.ReadBlock(buffer, 0, r);
                    if (!uint.TryParse(new string(buffer, 0, count), style, provider, out d)) {
                        result = Zero;
                        return false;
                    }
                    z[l--] = d;
                    r = 8;
                } while (l >= 0);
            }
            result = new BigInteger(0, false, z);
            return true;
        }

        //operators
        public static bool operator ==(BigInteger x, BigInteger y) {
            return x.Equals(y);
        }
        public static bool operator !=(BigInteger x, BigInteger y) {
            return !x.Equals(y);
        }
        public static bool operator <(BigInteger x, BigInteger y) {
            return Compare(x, y) < 0;
        }
        public static bool operator <=(BigInteger x, BigInteger y) {
            return Compare(x, y) <= 0;
        }
        public static bool operator >(BigInteger x, BigInteger y) {
            return Compare(x, y) > 0;
        }
        public static bool operator >=(BigInteger x, BigInteger y) {
            return Compare(x, y) >= 0;
        }
        public static BigInteger operator +(BigInteger value) {
            return value;
        }
        public static BigInteger operator -(BigInteger value) {
            uint xs;
            int xl = getLength(value._data, out xs);
            return new BigInteger(xs ^ minusBit, true, (uint)xl, value._data);
        }
        public static BigInteger operator ++(BigInteger value) {
            return value + One;
        }
        public static BigInteger operator --(BigInteger value) {
            return value - One;
        }
        public static BigInteger operator %(BigInteger x, BigInteger y) {
            BigInteger mod;
            DivRem(x, y, out mod);
            return mod;
        }
        public static BigInteger operator +(BigInteger x, BigInteger y) {
            uint xs, ys;
            int xl = getLength(x._data, out xs);
            int yl = getLength(y._data, out ys);
            if (xl == 0)
                return y;
            if (yl == 0)
                return x;
            if (xs != ys)
                return sub(xs, x._data, xl, ys, y._data, yl);
            return add(xs, x._data, xl, y._data, yl);
        }
        public static BigInteger operator -(BigInteger x, BigInteger y) {
            uint xs, ys;
            int xl = getLength(x._data, out xs);
            int yl = getLength(y._data, out ys);
            if (xl == 0)
                return new BigInteger(ys ^ minusBit, true, (uint)yl, y._data);
            if (yl == 0)
                return x;
            if (xs != ys)
                return add(xs, x._data, xl, y._data, yl);
            return sub(xs, x._data, xl, ys ^ minusBit, y._data, yl);
        }
        public static BigInteger operator *(BigInteger x, BigInteger y) {
            uint xs, ys;
            int xl = getLength(x._data, out xs);
            int yl = getLength(y._data, out ys);
            return mult(xs ^ ys, x, xl, y, yl);
        }
        public static BigInteger operator /(BigInteger dividend, BigInteger divisor) {
            BigInteger integer;
            return DivRem(dividend, divisor, out integer);
        }
        public static BigInteger operator &(BigInteger x, BigInteger y) {
            uint xs, ys;
            int xl = getLength(x._data, out xs);
            int yl = getLength(y._data, out ys);

            int min = Math.Min(xl, yl);
            uint[] z = new uint[min + 1];
            for (int i = 0; i < min; i++)
                z[i] = x._data[i] & y._data[i];
            return new BigInteger(xs & ys, false, z);
        }
        public static BigInteger operator |(BigInteger x, BigInteger y) {
            uint xs, ys;
            int xl = getLength(x._data, out xs);
            int yl = getLength(y._data, out ys);

            if (xl >= yl)
                return new BigInteger(xs | ys, false, bitwise_or(x._data, xl, y._data, yl));
            return new BigInteger(xs | ys, false, bitwise_or(y._data, yl, x._data, xl));
        }
        public static BigInteger operator ^(BigInteger x, BigInteger y) {
            uint xs, ys;
            int xl = getLength(x._data, out xs);
            int yl = getLength(y._data, out ys);

            if (xl >= yl)
                return new BigInteger(xs ^ ys, false, bitwise_xor(x._data, xl, y._data, yl));
            return new BigInteger(xs ^ ys, false, bitwise_xor(y._data, yl, x._data, xl));
        }
        public static BigInteger operator <<(BigInteger x, int shift) {
            if (shift == 0)
                return x;
            uint xs;
            int xl = getLength(x._data, out xs);
            return new BigInteger(xs, false, shiftLeft(x._data, xl, shift));
        }
        public static BigInteger operator >>(BigInteger x, int shift) {
            if (shift == 0)
                return x;
            uint xs;
            int xl = getLength(x._data, out xs);
            return new BigInteger(xs, false, shiftRight(x._data, xl, shift));
        }

        //cast from
        public static implicit operator BigInteger(int value) {
            if (value < 0)
                return new BigInteger(minusBit, false, new uint[] { (uint)-value, 0 });
            return new BigInteger(0, false, new uint[] { (uint)value, 0 });
        }
        public static implicit operator BigInteger(long value) {
            if (value < 0L) {
                value = -value;
                return new BigInteger(minusBit, false, new uint[] { (uint)value, (uint)(value >> 32), 0 });
            }
            return new BigInteger(0, false, new uint[] { (uint)value, (uint)(value >> 32), 0 });
        }
        public static implicit operator BigInteger(uint value) {
            return new BigInteger(0, false, new uint[] { value, 0 });
        }
        public static implicit operator BigInteger(ulong value) {
            return new BigInteger(0, false, new uint[] { (uint)value, (uint)(value >> 32), 0 });
        }
        public static implicit operator BigInteger(decimal value) {
            int[] bits = decimal.GetBits(decimal.Truncate(value));
            return new BigInteger(((bits[3] & -2147483648) == 0) ? 0 : minusBit, false, new uint[] { (uint)bits[0], (uint)bits[1], (uint)bits[2], 0 });
        }

        //cast to
        public static explicit operator byte(BigInteger value) {
            uint xs;
            int xl = getLength(value._data, out xs);
            if (xl == 0)
                return 0;
            if (xl > 1)
                throw new OverflowException();
            if (value._data[0] > 255)
                throw new OverflowException();
            if (xs == minusBit)
                throw new OverflowException();
            return (byte)value._data[0];
        }
        public static explicit operator sbyte(BigInteger value) {
            uint xs;
            int xl = getLength(value._data, out xs);
            if (xl == 0)
                return 0;
            if (xl > 1)
                throw new OverflowException();
            if (value._data[0] > 128)
                throw new OverflowException();
            if ((value._data[0] == 128) && (xs == 0))
                throw new OverflowException();
            return (sbyte)((int)value._data[0] * ((xs == 0) ? 1 : -1));
        }
        public static explicit operator short(BigInteger value) {
            uint xs;
            int xl = getLength(value._data, out xs);
            if (xl == 0)
                return 0;
            if (xl > 1)
                throw new OverflowException();
            if (value._data[0] > 32768)
                throw new OverflowException();
            if ((value._data[0] == 32768) && (xs == 0))
                throw new OverflowException();
            return (short)((int)value._data[0] * ((xs == 0) ? 1 : -1));
        }
        public static explicit operator ushort(BigInteger value) {
            uint xs;
            int xl = getLength(value._data, out xs);
            if (xl == 0)
                return 0;
            if (xl > 1)
                throw new OverflowException();
            if (value._data[0] > 65535)
                throw new OverflowException();
            if (xs == minusBit)
                throw new OverflowException();
            return (ushort)value._data[0];
        }
        public static explicit operator int(BigInteger value) {
            uint xs;
            int xl = getLength(value._data, out xs);
            if (xl == 0)
                return 0;
            if (xl > 1)
                throw new OverflowException();
            if (value._data[0] > 2147483648)
                throw new OverflowException();
            if ((value._data[0] == 2147483648) && (xs == 0))
                throw new OverflowException();
            return (int)value._data[0] * ((xs == 0) ? 1 : -1);
        }
        public static explicit operator uint(BigInteger value) {
            uint xs;
            int xl = getLength(value._data, out xs);
            if (xl == 0)
                return 0;
            if (xl > 1)
                throw new OverflowException();
            if (xs == minusBit)
                throw new OverflowException();
            return value._data[0];
        }
        public static explicit operator long(BigInteger value) {
            uint xs;
            int xl = getLength(value._data, out xs);
            if (xl == 0)
                return 0;
            if (xl > 2)
                throw new OverflowException();
            if (xl == 1)
                return (long)value._data[0] * ((xs == 0) ? 1L : -1L);

            ulong num = ((ulong)value._data[1] << 32) | value._data[0];
            if (num > 9223372036854775808L)
                throw new OverflowException();
            if ((num == 9223372036854775808L) && (xs == 0))
                throw new OverflowException();
            return (long)num * ((xs == 0) ? 1L : -1L);
        }
        public static explicit operator ulong(BigInteger value) {
            uint xs;
            int xl = getLength(value._data, out xs);
            if (xl == 0)
                return 0;
            if (xl > 2)
                throw new OverflowException();
            if (xs == minusBit)
                throw new OverflowException();
            if (xl == 1)
                return (ulong)value._data[0];

            return ((ulong)value._data[1] << 32) | value._data[0];
        }
        public static explicit operator float(BigInteger value) {
            float num;
            NumberFormatInfo numberFormat = CultureInfo.InvariantCulture.NumberFormat;
            if (!float.TryParse(value.ToString(), NumberStyles.Number, (IFormatProvider)numberFormat, out num))
                throw new OverflowException();
            return num;
        }
        public static explicit operator double(BigInteger value) {
            double num;
            NumberFormatInfo numberFormat = CultureInfo.InvariantCulture.NumberFormat;
            if (!double.TryParse(value.ToString(), NumberStyles.Number, (IFormatProvider)numberFormat, out num))
                throw new OverflowException();
            return num;
        }
        public static explicit operator decimal(BigInteger value) {
            uint xs;
            int xl = getLength(value._data, out xs);
            if (xl == 0)
                return 0M;
            if (xl > 3)
                throw new OverflowException();
            int lo = 0;
            int mid = 0;
            int hi = 0;
            if (xl > 2)
                hi = (int)value._data[2];
            if (xl > 1)
                mid = (int)value._data[1];
            if (xl > 0)
                lo = (int)value._data[0];
            return new decimal(lo, mid, hi, xs == minusBit, 0);
        }

        //public methods
        public bool IsNegative() {
            uint xs;
            int xl = getLength(_data, out xs);
            if (xl == 0)
                return false;
            return xs == minusBit;
        }
        public bool IsZero() {
            uint xs;
            int xl = getLength(_data, out xs);
            return xl == 0;
        }
        public bool IsPositive() {
            uint xs;
            int xl = getLength(_data, out xs);
            if (xl == 0)
                return false;
            return xs != minusBit;
        }
        public bool IsEven() {
            uint xs;
            int xl = getLength(_data, out xs);
            if (xl == 0)
                return true;
            return (_data[0] & 1) == 0;
        }
        public bool IsOdd() {
            uint xs;
            int xl = getLength(_data, out xs);
            if (xl == 0)
                return false;
            return (_data[0] & 1) == 1;
        }
        public int GetLength() {
            uint xs;
            return getLength(_data, out xs);
        }
        public byte[] ToByteArray(out bool isNegative) {
            uint xs;
            int xl = getLength(_data, out xs);
            byte[] dst = new byte[xl * 4];
            Buffer.BlockCopy(this._data, 0, dst, 0, xl * 4);
            isNegative = xs == minusBit;
            return dst;
        }
        public override int GetHashCode() {
            if (_data == null)
                return 0;
            return (int)_data[0];
        }
        public bool Equals(BigInteger other) {
            uint xs, ys;
            int xl = getLength(_data, out xs);
            int yl = getLength(other._data, out ys);
            if (xs != ys)
                return false;
            if (xl != yl)
                return false;
            for (uint i = 0; i < xl; i++) {
                if (_data[i] != other._data[i])
                    return false;
            }
            return true;
        }
        public override bool Equals(object obj) {
            return (obj is BigInteger) && Equals((BigInteger)obj);
        }
        public int CompareTo(BigInteger other) {
            return Compare(this, other);
        }
        public int CompareTo(object obj) {
            if (obj == null)
                return 1;
            if (!(obj is BigInteger))
                throw new ArgumentException("obj's type must be BigInteger", "obj");
            return Compare(this, (BigInteger)obj);
        }
        public override string ToString() {
            return toDecString(this, NumberFormatInfo.CurrentInfo);
        }
        public string ToString(string format) {
            return ToString(format, null);
        }
        public string ToString(IFormatProvider formatProvider) {
            return toDecString(this, NumberFormatInfo.GetInstance(formatProvider));
        }
        public string ToString(string format, IFormatProvider formatProvider) {
            if (!string.IsNullOrEmpty(format)) {
                switch (format) {
                case "X":
                case "x":
                    return toHexString(this, format, NumberFormatInfo.GetInstance(formatProvider));
                case "G":
                case "g":
                    break;
                default:
                    throw new NotSupportedException("Format is not supported");
                }
            }
            return toDecString(this, NumberFormatInfo.GetInstance(formatProvider));
        }

        //public static methods
        public static int Compare(BigInteger x, BigInteger y) {
            uint xs, ys;
            int xl = getLength(x._data, out xs);
            int yl = getLength(y._data, out ys);
            if (xs != ys)
                return (xs == minusBit) ? -1 : 1;
            int cp = compareData(x._data, xl, y._data, yl);
            if (cp == 0)
                return 0;
            if (cp > 0)
                return (xs == minusBit) ? -1 : 1;
            else
                return (xs == minusBit) ? 1 : -1;
        }
        public static BigInteger DivRem(BigInteger x, BigInteger y, out BigInteger result) {
            uint xs, ys;
            int xl = getLength(x._data, out xs);
            int yl = getLength(y._data, out ys);

            if (yl == 0)
                throw new DivideByZeroException();

            int c = compareData(x._data, xl, y._data, yl);
            if (c == 0) {
                result = Zero;
                return ((xs ^ ys) == 0) ? One : MinusOne;
            }
            if (c < 0) {
                result = x;
                return Zero;
            }
            uint[] zd;
            uint[] rd;
            if (yl == 1)
                zd = divRem(x._data, xl, y._data[0], out rd);
            else
                zd = divRem(x._data, xl, y._data, yl, out rd);
            result = new BigInteger(xs, false, rd);
            return new BigInteger(xs ^ ys, false, zd);
        }
        public static BigInteger Parse(string s) {
            return Parse(s, NumberStyles.Integer, null);
        }
        public static BigInteger Parse(string s, IFormatProvider provider) {
            return Parse(s, NumberStyles.Integer, provider);
        }
        public static BigInteger Parse(string s, NumberStyles style) {
            return Parse(s, style, null);
        }
        public static BigInteger Parse(string s, NumberStyles style, IFormatProvider provider) {
            BigInteger result;
            if (!isSupportedStyle(style))
                throw new NotSupportedException("Only supported styles are Integer and HexNumber");
            if (!TryParse(s, style, provider, out result))
                throw new FormatException();
            return result;
        }
        public static bool TryParse(string s, out BigInteger b) {
            return TryParse(s, NumberStyles.Integer, null, out b);
        }
        public static bool TryParse(string s, NumberStyles style, IFormatProvider provider, out BigInteger value) {
            if (!isSupportedStyle(style)) {
                value = Zero;
                return false;
            }
            if (provider == null)
                provider = CultureInfo.CurrentCulture;
            if ((style & NumberStyles.AllowHexSpecifier) != NumberStyles.None)
                return fromHexString(s.Trim(), style, provider, out value);
            else
                return fromDecString(s.Trim(), style, provider, out value);
        }
    }
}
