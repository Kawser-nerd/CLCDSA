#include <stdio.h>
int n,m,cases,a,b,c,ra,rb,i,t;
int a2[60*25];
int b2[60*25];
int main() {
	scanf("%d",&cases);
	for(c=0;c<cases;c++) {
		scanf("%d%d%d",&t,&n,&m);
//		printf("%d %d %d\n",t,n,m);
		memset(a2,0,sizeof(a2));
		memset(b2,0,sizeof(b2));
		for(i=0;i<n;i++) {
			scanf("%d%d",&a,&b);
			a2[a]--; b2[b+t]++;
		}
		for(i=0;i<m;i++) {
			scanf("%d%d",&b,&a);
			a2[a+t]++; b2[b]--;
		}
		a = b = ra = rb = 0;
		for(i=0;i<60*24;i++) {
			ra += a2[i];
			rb += b2[i];
			if(ra < 0) a -= ra, ra = 0;
			if(rb < 0) b -= rb, rb = 0;
		}
		printf("Case #%d: %d %d\n",c+1,a,b);
	}
	return 0;
}
