package lib;

public class PairHashMapMaterial {

    public static <T1, T2> HashMapMaterial<Pair<T1, T2>> of(HashMapMaterial<T1> m1, HashMapMaterial<T2> m2) {
        return new HashMapMaterial<>(pair -> {
            int hash1 = m1.hashFunction.applyAsInt(pair.v1);
            int hash2 = m2.hashFunction.applyAsInt(pair.v2);
            return TwoIntHash.hash(hash1, hash2);
        }, (p1, p2) -> {
            boolean test1 = m1.equalTester.test(p1.v1, p2.v1);
            boolean test2 = m2.equalTester.test(p1.v2, p2.v2);
            return test1 && test2;
        });
    }
}
