﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Utils.Infrastructure {
    public interface IProblemReader {
        int ReadInt();
        string ReadLine();
        T[] ReadArray<T>(int count, Func<T> readItemFunc);
        IEnumerable<T> GetEnumerable<T>(int count, Func<T> readItemFunc);
        void Close();
    }
}
