using System;
using Template.Interfaces;

namespace Template
{
  public class CaseFormatter : ICaseFormatter
  {
    private int count = 1;

    public string FormatOutput(string value)
    {
      return String.Format("Case #{0}: {1}", count++, value);
    }
  }
}