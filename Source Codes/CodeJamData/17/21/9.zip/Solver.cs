﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Text.RegularExpressions;

namespace Q1
{
	public class Solver : SolverBase
	{
		public const string INPUT_NAME = "big";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = false;
		public const bool PRINT_EVERY_RESULT = true;

		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		public override object SolveTestCase(int testCase)
		{
			var vals = GetIntList();
			var D = vals[0];
			var N = vals[1];
			var horsePos = new int[N];
			var horseSpeed = new int[N];
			for (int i = 0; i < N; i++)
			{
				vals = GetIntList();
				horsePos[i] = vals[0];
				horseSpeed[i] = vals[1];
			}

			var times = new List<double>();
			for (int i = 0; i < N; i++)
				times.Add((D - horsePos[i])/((double)horseSpeed[i]));

			return D/times.Max();
		}
	}
}
