﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Marius.CodeJam
{
    public class FairWarning: IParalelSolver
    {
        private BigInteger[] _data;
        private BigInteger _answer;

        public void ReadInput()
        {
            _data = Console.ReadLine().Split().Skip(1).Select(s => BigInteger.Parse(s)).OrderBy(s => s).ToArray();
        }

        public void WriteAnswer(int caseNumber)
        {
            Console.WriteLine("Case #{0}: {1}", caseNumber, _answer);
        }

        public void SolveAsync()
        {
            BigInteger[] diffs = new BigInteger[_data.Length - 1];
            for (int i = 0; i < diffs.Length; i++)
            {
                diffs[i] = _data[i + 1] - _data[i];
            }

            var gcd = Gcd(diffs);
            _answer = BigInteger.Remainder(BigInteger.Negate(_data[0]), gcd);
            while (_answer.Sign < 0)
                _answer = _answer + gcd;
        }

        private BigInteger Gcd(BigInteger[] nums)
        {
            BigInteger temp = nums[0];
            for (int i = 1; i < nums.Length; i++)
            {
                temp = BigInteger.GreatestCommonDivisor(temp, nums[i]);
            }
            return temp;
        }
    }
}
