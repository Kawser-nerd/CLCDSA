// Powered by FTH

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <iterator>
#include <functional>
#include <utility>
#include <numeric>
#include <complex>
#include <cstdio>
#include <cmath>
#include <cctype>
#include <cassert>
using namespace std;

#define REP(i,n) for(int i = 0; i < (int)(n); i++)
#define FOR(i,c) for(__typeof((c).begin()) i = (c).begin(); i != (c).end(); ++i)
#define ALLOF(c) ((c).begin()), ((c).end())

int table[1<<11];

void read_table() {
    FILE* fp = fopen("a.table", "r");
    assert(fp);
    REP(bits_high, 1<<9) {
        int bits = bits_high << 2;
        fscanf(fp, "%*s %d\n", &table[bits]);
    }
    fclose(fp);
}

int main() {

    read_table();

    int nCases;
    {
        string s;
        getline(cin, s);
        istringstream is(s);
        is >> nCases;
    }

    REP(iCase, nCases) {
        string s;
        getline(cin, s);
        istringstream is(s);
        vector<int> v;
        int bits = 0;
        for(int i; is >> i; )
            bits |= 1 << i;
        printf("Case #%d: %d\n", iCase+1, table[bits]);
    }

    return 0;
}
