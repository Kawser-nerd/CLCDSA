﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Globalization;
using System.ComponentModel;

namespace Utils.Infrastructure {
    public class DefaultReader : IProblemReader {
        TextReader textReader;
        string[] currentLineParts;
        int currentPartIndex;

        public DefaultReader(string fileName) {
            textReader = new StreamReader(fileName);
        }
        public void Close() {
            textReader.Close();
        }
        protected virtual string GetNext() {
            while (true) {
                currentPartIndex++;
                if (currentLineParts == null || currentPartIndex >= currentLineParts.Length) {
                    currentLineParts = textReader.ReadLine().Trim().Split(' ');
                    currentPartIndex = -1;
                }
                else {
                    string result = currentLineParts[currentPartIndex];
                    if (!String.IsNullOrEmpty(result))
                        return result;
                }
            }
        }
        public int ReadInt() {
            return Int32.Parse(GetNext(), CultureInfo.InvariantCulture);
        }

        public string ReadLine() {
            return textReader.ReadLine();
        }

        public T[] ReadArray<T>(int count, Func<T> readItemFunc) {
            T[] result = new T[count];
            for (int i = 0; i < result.Length; i++) {
                result[i] = readItemFunc();
            }
            return result;
        }

        public IEnumerable<T> GetEnumerable<T>(int count, Func<T> readItemFunc) {
            for (int i = 0; i < count; i++)
                yield return readItemFunc();
        }
    }
}
