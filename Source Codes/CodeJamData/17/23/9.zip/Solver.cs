﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Runtime.ExceptionServices;
using System.Text;

namespace Q3
{
	public class Solver : SolverBase
	{
		public const string INPUT_NAME = "big";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = false;
		public const bool PRINT_EVERY_RESULT = true;

		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		public override object SolveTestCase(int testCase)
		{
			var valss = GetIntList();
			var N = valss[0];
			var Q = valss[1];
			var horseDist = new BigInteger[N];
			var horseSpeed = new BigInteger[N];
			var cityDist = new BigInteger[N, N];
			for (int i = 0; i < N; i++)
			{
				var vals = GetBigIntList();
				horseDist[i] = vals[0];
				horseSpeed[i] = vals[1];
			}
			for (int i = 0; i < N; i++)
			{
				var vals = GetBigIntList();
				for (int j = 0; j < N; j++)
					cityDist[i, j] = vals[j];
			}
			var answers = new double[Q];
			for (int i = 0; i < Q; i++)
			{
				var vals = GetIntList();
				answers[i] = Solve(N, horseDist, horseSpeed, cityDist, vals[0]-1, vals[1]-1);
			}

			return string.Join(" ", answers);
		}

		private double Solve(int N, BigInteger[] horseDist, BigInteger[] horseSpeed, BigInteger[,] cityDist, int from, int to)
		{
			cityDist = CalculateActualDist(cityDist);
			var timeDists = CalculateTimeDists(horseDist, horseSpeed, cityDist);
			var q = new Dictionary<int, double>();
			for (int i = 0; i < N; i++)
				q[i] = double.MaxValue;
			q[from] = 0;
			while (q.Count > 0)
			{
				var curr = q.ArgMin(d => d.Value);
				if (curr.Key == to)
					return curr.Value;
				if (curr.Value == double.MaxValue)
					throw new Exception("No path?!");

				q.Remove(curr.Key);
				for (int i = 0; i < N; i++)
				{
					if (i == curr.Key || !q.ContainsKey(i))
						continue;
					if (timeDists[curr.Key, i] == -1)
						continue;
					var distToI = timeDists[curr.Key, i] + curr.Value;
					q[i] = Math.Min(distToI, q[i]);
				}
			}
			throw new Exception("WAT");
		}

		private BigInteger[,] CalculateActualDist(BigInteger[,] cityDist)
		{
			var N = cityDist.GetLength(0);
			var distance = new BigInteger[N, N];

			for (int i = 0; i < N; ++i)
				for (int j = 0; j < N; ++j)
					distance[i, j] = i == j ? 0 : cityDist[i, j];

			for (int k = 0; k < N; ++k)
				for (int i = 0; i < N; ++i)
					for (int j = 0; j < N; ++j)
						if (distance[i, k] != -1 && distance[k, j] != -1)
							if(distance[i, j] == -1 || distance[i, k] + distance[k, j] < distance[i, j])
								distance[i, j] = distance[i, k] + distance[k, j];

			return distance;
		}

		private double[,] CalculateTimeDists(BigInteger[] horseDist, BigInteger[] horseSpeed, BigInteger[,] cityDist)
		{
			var N = horseDist.Length;
			var result = new double[N, N];
			for (int i = 0; i < N; i++)
			{
				for (int j = 0; j < N; j++)
				{
					if (i == j)
						result[i, j] = 0;
					else if (cityDist[i, j] == -1 || cityDist[i, j] > horseDist[i])
						result[i, j] = -1;
					else
						result[i, j] = cityDist[i, j].DivideAndReturnDouble(horseSpeed[i]);
				}
			}
			return result;
		}
	}

	class DistObj
	{
		public int city;
		public double time;

		public DistObj(int city, double time)
		{
			this.city = city;
			this.time = time;
		}
	}
}
