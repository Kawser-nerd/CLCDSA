﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Numerics;
using Cmn.Util;
using Gcj.Util;

namespace Gcj.Y2013.R1A.B
{
    public class ManageYourEnergySolver : IConcurrentSolver
    {
       
        public int CCaseGet(Pparser pparser)
        {
            return pparser.Fetch<int>();
        }

        public ConcurrentGcjSolver.DgSolveCase DgSolveCase(Pparser pparser)
        {
            /*
             The first line of the input gives the number of test cases, T. T test cases follow. 
             * Each test case is described by two lines. The first contains three integers:
             * E, the maximum (and initial) amount of energy, R, the amount you regain after each activity,
             * and N, the number of activities planned for the day. The second line contains N integers vi,
             * describing the values of the activities you have planned for today.
             */


            int E, R,N;
            pparser.Fetch(out E, out R, out N);
            var rgv = pparser.Fetch<int[]>();
            
            return () => Solve(E,R, rgv);
        }

        private IEnumerable<object> Solve(int eMax, int R, int[] rgv)
        {
            yield return VMaxGet(0, eMax, eMax, R, rgv, new Dictionary<Tuple<int, int>, long>());

        }

        long VMaxGet(int iact, int e, int eMax, int R, int[] rgv, Dictionary<Tuple<int, int>, long> mpvmaxByeAndiact)
        {
            var key = new Tuple<int, int>(e, iact);
            if (mpvmaxByeAndiact.ContainsKey(key))
                return mpvmaxByeAndiact[key];

            long vmax = 0;
            if(iact == rgv.Length-1)
            {
                vmax = rgv[iact]*e;
            }
            else
            {
                for (int i = 0; i <= e; i++)
                {
                    //tfh i energiát felhasználunk;
                    var eNext = Math.Min(eMax, e - i + R);
                    vmax = Math.Max(vmax, rgv[iact]*i + VMaxGet(iact + 1, eNext, eMax, R, rgv, mpvmaxByeAndiact));
                }    
            }

            mpvmaxByeAndiact[key] = vmax;
            return vmax;
        }

    }
}
