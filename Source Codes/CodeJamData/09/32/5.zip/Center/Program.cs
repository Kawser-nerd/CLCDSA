﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Center
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine().Trim());

            for (int i = 0; i < n; i++)
            {
                int m = int.Parse(Console.ReadLine().Trim());

                Vector position = Vector.Zero;
                Vector velocity = Vector.Zero;

                for (int j = 0; j < m; j++)
                {
                    string[] components = Console.ReadLine().Trim().Split(' ');
                    position.Add(new Vector(double.Parse(components[0]), double.Parse(components[1]), double.Parse(components[2])));
                    velocity.Add(new Vector(double.Parse(components[3]), double.Parse(components[4]), double.Parse(components[5])));
                }
                position.Divide(m);
                velocity.Divide(m);

                if (velocity.X != 0 || velocity.Y != 0 || velocity.Z != 0)
                {
                    Vector originalVelocity = velocity;

                    velocity.Normalize();
                    double component = Vector.Dot(position, velocity);

                    if (component > 0)
                    {
                        Console.WriteLine("Case #" + (i + 1).ToString() + ": " + position.Norm().ToString("0.00000000") + " 0.00000000");
                    }
                    else
                    {
                        Vector final = new Vector(position.X - component * velocity.X,
                        position.Y - component * velocity.Y,
                        position.Z - component * velocity.Z);

                        Console.WriteLine("Case #" + (i + 1).ToString() + ": " + final.Norm().ToString("0.00000000") + " " + (-component / originalVelocity.Norm()).ToString("0.00000000"));
                    }
                }
                else
                {
                    Console.WriteLine("Case #" + (i + 1).ToString() + ": " + position.Norm().ToString("0.00000000") + " 0.00000000");
                }
            }
        }
    }

    struct Vector
    {
        public double X;
        public double Y;
        public double Z;

        public static Vector Zero = new Vector(0d, 0d, 0d);

        public Vector(double x, double y, double z)
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
        }

        public static double Dot(Vector A, Vector B)
        {
            return A.X * B.X + A.Y * B.Y + A.Z * B.Z;
        }

        public void Add(Vector vector)
        {
            X += vector.X;
            Y += vector.Y;
            Z += vector.Z;
        }

        public void Divide(double scalar)
        {
            if (scalar != 0)
            {
                X /= scalar;
                Y /= scalar;
                Z /= scalar;
            }
        }

        public double Norm()
        {
            return Math.Sqrt(X * X + Y * Y + Z * Z);
        }

        public void Normalize()
        {
            double norm = Norm();
            if (norm > 0)
            {
                X /= norm;
                Y /= norm;
                Z /= norm;
            }
        }
    }
}
