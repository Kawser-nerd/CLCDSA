﻿using Template.Interfaces;

namespace CodeJam.Factories
{
  public class NullProblem : IProblem
  {
    public void Solve(IInput input, IOutput output)
    {
      var message = "Input file needs to start with A, B, C or D.";

      output.WriteLine(message);
    }
  }
}