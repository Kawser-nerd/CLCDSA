package lib;

public class ColumnMatrix {
    public static <T> Matrix<T> of(Vector<T> v) {
        return new Matrix<>(v.n, 1, (i, j) -> v.element.at(i));
    }
}
