/**
 * 
 */
package gepa.gcj.roundSemiEmea;

import gepa.gcj.main.InputData;
import gepa.gcj.main.LineParser;
import gepa.gcj.main.ParseException;

/**
 * @author gepa
 *
 */
public class InputDataB implements InputData {

    private String[] c = new String[500];
    public int nextC;
    public int[] col;
    public int[] from;
    public int[] to;
    
    private int getCol(String x) {
        for (int i = 0; i < nextC; i++) {
            if (c[i].equals(x)) {
                return i;
            }
        }
        c[nextC] = x;
        nextC++;
        return nextC - 1;
    }
    @Override
    public void parse(LineParser parser) throws ParseException {
        c = new String[500];
        nextC = 0;
        int N = parser.getSingleInt();
        col = new int[N];
        from = new int[N];
        to = new int[N];
        for (int i = 0; i < N; i++) {
            String[] parts = parser.getStringArray(3);
            col[i] = getCol(parts[0]);
            from[i] = Integer.parseInt(parts[1]);
            to[i] = Integer.parseInt(parts[2]);
        }
        while (nextC < 3) {
            nextC++;
        }
    }

}
