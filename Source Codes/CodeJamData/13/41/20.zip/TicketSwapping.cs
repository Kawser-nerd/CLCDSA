﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class TicketSwapping : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            FileWrapper.Process<TicketSwapping>(args);
        }
        #endregion

        private int N, M;
        private ulong[][] oeps;
        const ulong MOD = 1000002013ul;

        public override object Solve()
        {
            N = In<int[]>()[0];
            M = Last<int[]>()[1];
            oeps = In<ulong[]>(M);

            ulong exp = 0;
            foreach (var oep in oeps)
            {
                exp += oep[2] * Expect(N, oep[1] - oep[0]) % MOD;
                exp %= MOD;
            }

            ulong[] starts = new ulong[N], exits = new ulong[N];
            foreach (var oep in oeps)
            {
                starts[oep[0] - 1] += oep[2];
                exits[oep[1] - 1] += oep[2];
            }

            ulong actual = 0;
            for (int i = 0; i < N; i++)
            {
                for (int j = i; exits[i] > 0 && j >= 0; j--)
                {
                    var ex = Math.Min(exits[i], starts[j]);
                    exits[i] -= ex;
                    starts[j] -= ex;
                    actual += ex * Expect(N, (ulong)(i - j));
                    actual %= MOD;
                }
            }

            return (exp + MOD - actual) % MOD;
        }

        static ulong Expect(int n, ulong k)
        {
            return k == 0 ? 0 : (k*(2*(ulong)n - k + 1)/2) % MOD;
        }
    }
}
