package codejam.r1c;

import codejam.ProblemSolver;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class B implements ProblemSolver {

    @Override
    public String solve(BufferedReader in, int testNum) throws IOException {
        String[] parts = in.readLine().split(" ");
        int k = Integer.parseInt(parts[0]);
        int l = Integer.parseInt(parts[1]);
        int s = Integer.parseInt(parts[2]);
        Map<Character, Integer> keyboard = new HashMap<>();
        String kb = in.readLine();
        for(char c : kb.toCharArray()) {
            Integer count = keyboard.get(c);
            if(count == null) {
                keyboard.put(c, 1);
            } else {
                keyboard.put(c, count + 1);
            }
        }
        String target = in.readLine();
        double retv = 0.0;
        boolean possible = (l <= s);
        long num = 1;
        for(char c : target.toCharArray()) {
            Integer keyCount = keyboard.get(c);
            if(keyCount == null) {
                possible = false;
                break;
            } else {
                num *= keyCount;
            }
        }
        int repeat = target.length();
        if(possible) {
            for(int i = 1; i < target.length(); i++) {
                if(target.startsWith(target.substring(i))) {
                    repeat = i;
                    break;
                }
            }
            retv = 1 + (s - l) / repeat;
            double den = Math.pow(k, l);
            num *= s - l + 1;
            retv -= num / den;
        }
        return retv + "";
    }
}
