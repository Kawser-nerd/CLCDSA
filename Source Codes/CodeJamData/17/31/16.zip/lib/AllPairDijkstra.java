package lib;

public class AllPairDijkstra {

    public static void calc(Vertexes<Integer> vertexes, AdjacencySupplier<Integer> edges, SetFactory<Integer> setFactory, DistanceDiscoverHandler<Integer> handler) {
        vertexes.get().forEach(src -> Dijkstra.traverse(src, edges, (dest, distance) -> {
            handler.onDiscover(src, dest, distance);
            return true;
        }, setFactory));
    }
    
}
