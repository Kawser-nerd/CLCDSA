﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class HikingDeer : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            ProblemSet<HikingDeer>.Solve(args);
        }
        #endregion

        public override void Parse(ProblemReader file)
        {
            int[][] hikers;
            file.Read(out N).Read(N, out hikers);
            Hikers = new List<Hiker>();
            for (var i = 0; i < N; i++)
            {
                var d = hikers[i][0];
                var h = hikers[i][1];
                var m = hikers[i][2];
                for (var j = 0; j < h; j++) 
                    Hikers.Add(new Hiker {Start = d, Rate = m + j});
            }
        }

        // ReSharper disable InconsistentNaming
        private int N;
        private List<Hiker> Hikers; 
        // ReSharper restore InconsistentNaming

        public override object Solve()
        {
            if (Hikers.Count == 1) return 0;

            var ha = Hikers[0];
            var hb = Hikers[1];
            var eps = 1e-12;

            var a1 = ha.TimeAt(360 - ha.Start);
            var a2 = ha.TimeAt(720 - ha.Start);
            var b1 = hb.TimeAt(360 - hb.Start);
            var b2 = hb.TimeAt(720 - hb.Start);

            // 0 if a2 > b1 AND b2 > a1
            // else 1
            return a2 - b1 > eps && b2 - a1 > eps ? 0 : 1;

            // POS = 0
            // foreach hiker, find the next time/pos they collide with each other hiker
            // find the soonest collision for which (iPOS1 < POS or iPOS2 < POS) AND (CPOS > POS)
            // tally number of hikers at that point 

            //return 0;
        }

        public class Hiker
        {
            // DEGREE
            public long Start { get; set; }
            // MIN / 360DEGREE
            public long Rate { get; set; }

            public double TimeAt(double pos)
            {
                return Rate*pos/360;
            }

        }

        public override IEnumerable<Action> StaticInitialize()
        {
            yield return () =>
            {

            };
        }
    }
}
