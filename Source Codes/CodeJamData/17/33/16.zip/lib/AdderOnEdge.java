package lib;

public interface AdderOnEdge {
    void add(int from, int to, int value);
}
