package lib;

public class Matrix<T> {
    public final int n, m;
    public final MatrixElementFunction<T> element;

    public Matrix(int n, int m, MatrixElementFunction<T> element) {
        this.n = n;
        this.m = m;
        this.element = element;
    }
}
