package lib;

public class Vector<T> {
    public final int n;
    public final VectorElementFunction<T> element;

    public Vector(int n, VectorElementFunction<T> element) {
        this.n = n;
        this.element = element;
    }
}
