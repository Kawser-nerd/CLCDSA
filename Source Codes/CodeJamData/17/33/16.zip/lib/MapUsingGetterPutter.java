package lib;

import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.IntSupplier;

@SuppressWarnings("unchecked")
public class MapUsingGetterPutter {

    @Deprecated
    public static <K, V> Map<K, V> of(final Function<K, V> getter, final BiFunction<K, V, V> putter) {
        return of(() -> {
            throw new RuntimeException();
        }, () -> {
            throw new RuntimeException();
        }, getter, putter, k -> {
            throw new UnsupportedOperationException();
        });
    }

    public static <K, V> Map<K, V> of(final Iterable<Map.Entry<K, V>> iterable, final IntSupplier sizeGetter, final Function<K, V> getter, final BiFunction<K, V, V> putter, final Function<K, V> remover) {
        return new AbstractMap<K, V>() {
            @Override
            public Set<Entry<K, V>> entrySet() {
                return new AbstractSet<Entry<K, V>>() {
                    @Override
                    public Iterator<Entry<K, V>> iterator() {
                        return iterable.iterator();
                    }

                    @Override
                    public boolean remove(Object o) {
                        throw new UnsupportedOperationException();
                    }

                    @Override
                    public int size() {
                        return sizeGetter.getAsInt();
                    }
                };
            }

            @Override
            public V remove(Object key) {
                return remover.apply((K) key);
            }

            @Override
            public V get(Object o) {
                return getter.apply((K) o);
            }

            @Override
            public boolean containsKey(Object key) {
                return getter.apply((K) key) != null;
            }

            @Override
            public V put(K key, V value) {
                return putter.apply(key, value);
            }
        };
    }


}
