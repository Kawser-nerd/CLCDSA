﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    class Case
    {
        public int Cash { get; set; }
        public List<Item> Items { get; set; }
        public int item1 { get; set; }
        public int item2 { get; set; }
    }

    class Item
    {
        public Guid Id { get; set; }
        public int Value { get; set; }
    }
}
