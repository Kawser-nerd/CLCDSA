/**
 * 
 */
package gepa.gcj.main;

/**
 * @author gepa
 *
 */
public interface InputData {

    public void parse(LineParser parser) throws ParseException;

}
