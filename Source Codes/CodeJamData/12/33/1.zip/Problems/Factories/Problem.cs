﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Generic.Common;

namespace Google_Code_Jam.Problems.Factories
{
    class Problem : DefaultObject
    {
        IList<Order> boxOrders;
        IList<Order> toyOrders;

        public Problem(IList<Order> boxOrders, IList<Order> toyOrders)
        {
            this.boxOrders = boxOrders;
            this.toyOrders = toyOrders;
        }

        public IList<Order> BoxOrders
        {
            get { return boxOrders; }
        }

        public IList<Order> ToyOrders
        {
            get { return toyOrders; }
        }
    }

    class Order : DefaultObject
    {
        long count;
        long type;

        public Order(long count, long type)
        {
            this.count = count;
            this.type = type;
        }

        public long Count
        {
            get { return count; }
        }

        public long Type
        {
            get { return type; }
        }
    }
}
