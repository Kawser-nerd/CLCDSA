import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Date: May 23, 2010
 * Time: 1:16:34 PM
 *
 * @author Timur Abishev (ttim@)
 */
public class A extends Solution {
    static boolean isOk(int[][] c) {
        int n = c.length;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++) {
                if (c[i][j] == -1) continue;

                if ((c[j][i] != -1) && (c[j][i] != c[i][j])) return false;
                if ((c[n-j-1][n-i-1] != -1) && (c[n-j-1][n-i-1] != c[i][j])) return false;
            }
        
        return true;
    }
    
    @Override
    void runOneTest(Scanner input, PrintWriter output) {
        int n = input.nextInt();

        int[][] a = new int[n][n];
        int[][] tmp = new int[2 * n - 1][];
        for (int i = 0; i < 2 * n - 1; i++) {
            int m = Math.min(i, 2 * n - i - 2) + 1;
            tmp[i] = new int[m];

            for (int j = 0; j < m; j++) {
                tmp[i][j] = input.nextInt();
            }
        }

        // read a
        int[] x = new int[n], y = new int[n];
        for (int i = 0; i < n; i++) {
            x[i] = i;
            y[i] = i;
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) a[i][j] = tmp[x[j]][y[j]];

            if (i != n - 1) {
                // find next x[j ] y[j]
                //up from 0 to n-i-1
                for (int j = 0; j < n; j++) { // n-i-1
                    x[j]++;
                }

                for (int j = n-i-1; j < n; j++) {
                    y[j]--;
                }
            }
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) System.out.print(a[i][j]+" ");
            System.out.println();
        }

        for (int ans = n; ans <= 3*n+100; ans++) {
            boolean ok = false;
            for (int i = 0; i <= ans-n; i++) {
                if (ok) break;
                for (int j = 0; j <= ans-n; j++) {
                    if (ok) break;

                    int[][] c = new int[ans][ans];
                    for (int ii = 0; ii < ans; ii++)
                        for (int jj = 0; jj < ans; jj++) c[ii][jj] = -1;
                    
                    for (int ii = i; ii < i+n; ii++)
                        for (int jj = j; jj < j+n; jj++)
                            c[ii][jj] = a[ii-i][jj-j];

                    // check
                    if (isOk(c)) {
                        ok = true;
                        break;
                    }
                }
            }
            if (ok) {
                output.println(ans*ans-n*n);
                break;
            }
        }
    }

    public static void main(String[] args) {
        (new A()).run();
    }
}
