#include "cjlib.h"
#include <ccan/stringmap/stringmap.h>

int test_count, X;

char *ffnw(const char *s, const char *e) {
	while (*s == ' ' || *s == '\n')
		s++;
	return (char*)s;
}

typedef struct Tree {
	double weight;
	size_t feature;
	struct Tree *lr[2];
} Tree;

typedef stringmap(size_t) Map;

size_t feature_counter = 1;

Tree *parse(Map *map, char *s, char *e, char **end) {
	Tree *t = block_pool_alloc(map->t.bp, sizeof(Tree));
	char *f;
	size_t *fc;
	
	s = ffnw(s, e);
	assert(*s == '(');
	s++;
	t->weight = strtod(s, &s);
	s = ffnw(s, e);
	if (*s == ')') {
		s++;
		*end = s;
		t->feature = 0;
		return t;
	}
	
	for (f=s; *f>='a' && *f<='z'; f++);
	*f = 0;
	fc = stringmap_lookup(*map, s);
	if (!fc) {
		fc = stringmap_enter(*map, s);
		*fc = feature_counter++;
	}
	t->feature = *fc;
	*f = ' ';
	s = ffnw(f+1, e);
	
	t->lr[0] = parse(map, s, e, &s);
	t->lr[1] = parse(map, s, e, &s);
	s = ffnw(s, e);
	
	assert(*s == ')');
	s = ffnw(s+1, e);
	*end = s;
	return t;
}

int by_size_t(const void *av, const void *bv) {
	size_t a = *(const size_t*)av;
	size_t b = *(const size_t*)bv;
	if (a < b)
		return -1;
	if (a > b)
		return 1;
	return 0;
}

double eval(const Tree *t, size_t a[], size_t c) {
	double ret = t->weight;
	if (t->feature) {
		if (bsearch(&t->feature, a, c, sizeof(*a), by_size_t))
			ret *= eval(t->lr[0], a, c);
		else
			ret *= eval(t->lr[1], a, c);
	}
	return ret;
}

int main(void) {
	array_char tree_str = array_new(NULL);
	array(size_t) attribs = array_new(NULL);
	size_t ac, i;
	//array_char animal = array_new(NULL);
	
	read_line();
	test_count = atoi(line);
	
	for (X=1; X<=test_count; X++) {
		int L, A;
		Tree *tree;
		Map map = stringmap_new(NULL);
		double v;
		char *dummy;
		feature_counter = 1;
		
		(void) stringmap_enter(map, "12345DUMMY12345");
		
		tree_str.size = 0;
		L = atoi(read_line());
		while (L-->0) {
			array_append_string(tree_str, read_line());
			array_append(tree_str, '\n');
		}
		array_append(tree_str, 0);
		
		tree = parse(&map, tree_str.item, tree_str.item+--tree_str.size, &dummy);
		//assert(dummy-tree_str.item == tree_str.size);
		
		A = atoi(read_line());
		printf("Case #%d:\n", X);
		
		while (A--) {
			read_line();
			attribs.size = 0;
			read_word(); //skip the name
			ac = atoi(read_word());
			array_resize(attribs, ac);
			for (i=0; i<ac; i++) {
				const char *s = read_word();
				size_t *a = stringmap_lookup(map, s);
				attribs.item[i] = a ? *a : 0;
			}
			qsort(attribs.item, attribs.size, sizeof(*attribs.item), by_size_t);
			v = eval(tree, attribs.item, attribs.size);
			printf("%f\n", v);
		}
		
		stringmap_free(map);
	}
	
	return 0;
}
