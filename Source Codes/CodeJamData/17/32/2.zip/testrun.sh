# usage: testrun.sh

cd $1
g++ $1.cpp -o $1 -O2 -std=c++14 &&
python run.py ./$1 $1.in $1.out
