package lib;

public class IntArray2DFromInput {
    public static int[][] next(Input in, int size1, int size2) {
        return ArrayConstructor.create(size1, int[].class, () -> IntArrayFromInput.next(in, size2));
    }
}
