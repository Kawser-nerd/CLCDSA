/* www.codertom.com  -  copyright Tom Harrison 2015 */
namespace CoderTom.CodeJam
{
    public class ItemInPosition<T>
    {
        public int Position { get; set; }
        public T Item { get; set; }
    }
}