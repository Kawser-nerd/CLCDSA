﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace GCJ2015Round2_3
{
	public static class BigIntUtils
	{
		public static BigInteger SqrtFloor(this BigInteger x)
		{
			if (x < 0)
			{
				throw new ArgumentException("Negative argument.");
			}
			if (x == 0 || x == 1)
			{
				return x;
			}

			BigInteger two = 2;
			BigInteger y;
			for (y = x / two;
					y > x / y;
					y = ((x / y) + y) / two) ;
			return y;
		}

		public static IEnumerable<BigInteger> PrimeFactors(this BigInteger n)
		{
			if (n <= 1)
				new List<BigInteger>() { n };
			List<BigInteger> result = new List<BigInteger>();

			BigInteger workCopy = n;
			while (workCopy % 2 == 0)
			{
				result.Add(2);
				workCopy /= 2;
			}

			BigInteger p = 3;
			BigInteger sq = workCopy.SqrtFloor();
			while (workCopy != 1)
			{
				if (workCopy % p == 0)
				{
					result.Add(p);
					workCopy /= p;
					sq = workCopy.SqrtFloor();
				}
				else
				{
					p += 2;
					if (p > sq)
						break;
				}
			}
			if (workCopy != 1)
			{
				result.Add(workCopy);
			}

			return result;
		}

		public static IEnumerable<BigInteger> GetDivisors(this BigInteger n)
		{
			if (n == 1)
				return new List<BigInteger>() { 1 };

			List<BigInteger> result = new List<BigInteger>() { 1, n };
			BigInteger sq = n.SqrtFloor();
			for (int i = 2; i <= sq; i++)
			{
				if (n % i == 0)
				{
					result.Add(i);
					if (i * i != n)
					{
						result.Add(n / i);
					}
				}
			}
			return result;
		}
	}
}
