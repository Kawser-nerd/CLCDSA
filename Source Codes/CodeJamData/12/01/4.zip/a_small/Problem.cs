﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace km.gcj
{
    class Problem
    {
        protected List<string> inputLines;

        protected readonly string pathInputFile;
        protected readonly string pathOutputFile;

        protected int answerCount = 0;

        /// <summary>
        /// 読み込み行数を取得
        /// </summary>
        public int inputLinesCount { 
            get{
                if(inputLines == null) return 0;
                return inputLines.Count;
            }
        }
        public IEnumerator<string> getInputLinesEnumerator()
        {
            foreach (string str in inputLines)
            {
                yield return str;
            }
        }

        #region 読み込み行の処理
        protected IEnumerator<string> ienum;

        /// <summary>
        /// 入力ファイルより一行読み込み、
        /// 数値の配列として返す。
        /// </summary>
        /// <returns></returns>
        public System.Int64[] getNextLineAsInt64Array()
        {
            System.Int64[] ret = null;
            if (this.ienum.MoveNext())
            {
                String[] strs = this.ienum.Current.Split(' ');
                ret = (from str in strs select Int64.Parse(str)).ToArray<long>();
                //var ret2 = strs.Select(n => Int64.Parse(n)).ToArray();
            }
            return ret;
        }
        /// <summary>
        /// 入力ファイルより一行読み込み、
        /// 文字列の配列として返す。
        /// </summary>
        /// <returns></returns>
        public string[] getNextLineAsStringArray()
        {
            string[] ret = null;
            if (this.ienum.MoveNext())
            {
                ret = this.ienum.Current.Split(' ');
            }
            return ret;
        }
        /// <summary>
        /// 入力ファイルより一行読み込み、
        /// 文字列として返す。
        /// </summary>
        /// <returns></returns>
        public string getNextLine()
        {
            string ret = null;
            if (this.ienum.MoveNext())
            {
                ret = this.ienum.Current;
            }
            return ret;
        }

        /// <summary>
        /// 入力ファイルより複数行読み込み、
        /// 文字列の配列として返す。
        /// </summary>
        /// <returns></returns>
        public string[] getNextLines(int cnt)
        {
            List<string> ret = new List<string>();
            if (cnt <= 0) return null;
            while (0 < cnt-- && this.ienum.MoveNext())
            {
                ret.Add(this.ienum.Current);
            }
            return ret.ToArray();
        }
        #endregion

        #region 回答処理
        /// <summary>
        /// 行のみで回答（文字列）する。
        /// Case #xx: line
        /// </summary>
        /// <param name="prmStr"></param>
        public void WriteAnswerFullLine(string prmStr)
        {
            System.IO.FileInfo fOut = new System.IO.FileInfo(this.pathOutputFile);
            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(fOut.FullName,true))
            {
                this.answerCount++;
                sw.WriteLine("Case #{0}: {1}", this.answerCount, prmStr);
                sw.Flush();
                // Console.WriteLine("write successful");
            }
        }

        /// <summary>
        /// 行のみで回答（数値：書式指定）する。
        /// Case #xx: 0.00000
        /// </summary>
        /// <param name="prmStr"></param>
        public void WriteAnswerFullLine(System.Double prmD,string prmFormat)
        {
            System.IO.FileInfo fOut = new System.IO.FileInfo(this.pathOutputFile);
            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(fOut.FullName, true))
            {
                this.answerCount++;
                sw.WriteLine("Case #{0}: {1:" + prmFormat + "}", this.answerCount, prmD);
                sw.Flush();
                // Console.WriteLine("write successful");
            }
        }

        /// <summary>
        /// 複数行で回答する。<br />
        /// Case #xx:<br />
        /// line01<br />
        /// line02<br />
        /// </summary>
        /// <param name="prmStr"></param>
        public void WriteAnswerMultiLine(string[] prmStrs)
        {
            System.IO.FileInfo fOut = new System.IO.FileInfo(this.pathOutputFile);
            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(fOut.FullName, true))
            {
                this.answerCount++;
                sw.WriteLine("Case #{0}:", this.answerCount);
                foreach (string str in prmStrs)
                {
                    sw.WriteLine("{0}", str);
                }
                sw.Flush();
                // Console.WriteLine("write successful");
            }
        }

        /// <summary>
        /// 配列で回答する。<br />
        /// Case #xx: [line1, line2, line3]<br />
        /// </summary>
        /// <param name="prmStr"></param>
        public void WriteAnswerMultiLineArray(string[] prmStrs)
        {
            System.IO.FileInfo fOut = new System.IO.FileInfo(this.pathOutputFile);
            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(fOut.FullName, true))
            {
                this.answerCount++;
                sw.WriteLine("Case #{0}: [{1}]", this.answerCount, string.Join(", ", prmStrs));
                sw.Flush();
                // Console.WriteLine("write successful");
            }
        }

        /// <summary>
        /// 回答ヘッダのみを書き出す。<br />
        /// Case #xx:<br />
        /// </summary>
        /// <param name="prmStr"></param>
        public void WriteAnswerHeader()
        {
            System.IO.FileInfo fOut = new System.IO.FileInfo(this.pathOutputFile);
            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(fOut.FullName, true))
            {
                this.answerCount++;
                sw.WriteLine("Case #{0}:", this.answerCount);
                sw.Flush();
                // Console.WriteLine("write successful");
            }
        }

        /// <summary>
        /// 行を書き出す。
        /// line
        /// </summary>
        /// <param name="prmStr"></param>
        public void WriteAnswerSubLine(string prmStr)
        {
            System.IO.FileInfo fOut = new System.IO.FileInfo(this.pathOutputFile);
            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(fOut.FullName, true))
            {
                // this.answerCount++;
                sw.WriteLine("{0}", prmStr);
                sw.Flush();
                // Console.WriteLine("write successful");
            }
        }


        #endregion

        #region コンストラクタ、初期化処理
        private Problem()
        {
            inputLines = new List<string>();
        }
        private Problem(string pathIn, string pathOut)
            : this()
        {
            this.pathInputFile = pathIn;
            this.pathOutputFile = pathOut;
        }

        /// <summary>
        /// 初期化処理
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public static Problem createProblem(string[] args)
        {
            Problem ret;
            if (args.Length < 1)
            {
                Console.WriteLine("Error: arguments");
                return null;
            }
            ret = new Problem(args[0], args[0] + ".out");
            System.IO.FileInfo fIn = new System.IO.FileInfo(ret.pathInputFile);
            Console.WriteLine("reading..."+fIn.FullName);
            if (!fIn.Exists)
            {
                Console.WriteLine("Error: input file");
                return null;
            }
            using (System.IO.StreamReader sr = new System.IO.StreamReader(fIn.FullName))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                   ret.inputLines.Add(line);
                }
            }
            ret.ienum = ret.getInputLinesEnumerator();
            return ret;
        }
        #endregion
    }
}
