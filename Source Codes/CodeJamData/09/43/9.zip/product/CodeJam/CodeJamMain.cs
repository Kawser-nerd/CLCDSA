﻿namespace CodeJam
{
  internal class CodeJamMain
  {
    private static void Main(string[] args)
    {
      var problemWrapper = new ProblemWrapper();
      
      problemWrapper.Setup();
      problemWrapper.Execute();
      problemWrapper.TearDown();
    }
  }
}