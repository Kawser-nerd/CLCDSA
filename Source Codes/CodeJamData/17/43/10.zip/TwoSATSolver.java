import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TwoSATSolver {
    public List<Integer>[] edges, rEdges;
    public int varsCount;

    public TwoSATSolver(int n) {
        this.varsCount = n;
        edges = new List[2 * n];
        rEdges = new List[2 * n];
        for (int i = 0; i < 2 * n; i++) {
            edges[i] = new ArrayList<>();
            rEdges[i] = new ArrayList<>();
        }
    }

    int not(int v) {
        return v < varsCount ? v + varsCount : v - varsCount;
    }

    private void addEdge(int v, int u) {
        edges[v].add(u);
        rEdges[u].add(v);
    }

    void addClause(int v, int u) {
        v = v < 0 ? (~v) + varsCount : v;
        u = u < 0 ? (~u) + varsCount : u;
        System.err.println(v + " " + u);
        addEdge(not(v), u);
        addEdge(not(u), v);
    }

    boolean[] was;
    int[] order;
    int cn;
    int[] color;

    private void makeOrder(int v) {
        was[v] = true;
        for (int i = 0; i < edges[v].size(); i++) {
            int to = edges[v].get(i);
            if (!was[to]) {
                makeOrder(to);
            }
        }
        order[cn++] = v;
    }

    private void makeColor(int v, int c) {
        color[v] = c;
        for (int i = 0; i < rEdges[v].size(); i++) {
            int to = rEdges[v].get(i);
            if (color[to] < 0) {
                makeColor(to, c);
            }
        }
    }

    boolean[] solve() {
        int n = edges.length;
        cn = 0;
        order = new int[n];
        was = new boolean[n];
        for (int i = 0; i < n; i++) {
            if (was[i]) continue;
            makeOrder(i);
        }
        int colors = 0;
        color = new int[n];
        Arrays.fill(color, -1);
        for (int it = cn - 1; it >= 0; it--) {
            int v = order[it];
            if (color[v] < 0) {
                makeColor(v, colors++);
            }
        }
        for (int i = 0; i < varsCount; i++) {
            if (color[i] == color[not(i)]) {
                return null;
            }
        }
        int[] backColor = new int[colors];
        Arrays.fill(backColor, -1);
        for (int i = 0; i < n; i++) {
            int c = color[i];
            int cc = color[not(i)];
            if (backColor[c] >= 0 && backColor[c] != cc) {
                throw new AssertionError();
            }
            backColor[c] = cc;
        }
        if ((colors & 1) == 1) throw new AssertionError();
        int[] w = new int[colors];
        Arrays.fill(w, -1);
        for (int i = colors - 1; i >= 0; i--) {
            if (w[i] < 0) {
                w[i] = 1;
                w[backColor[i]] = 0;
            }
        }
        boolean[] ret = new boolean[varsCount];
        for (int i = 0; i < varsCount; i++) {
            ret[i] = w[color[i]] == 1;
        }
        return ret;
    }
}

