﻿using System;
using CodeJamLibrary.Interfaces;

namespace CodeJamLibrary
{
  public class NullProblem : IProblem
  {
    public void Solve(IProblemInput problemInput, IProblemOutput problemOutput)
    {
      var message = "Input file needs to start with A, B, C or D.";

      Console.WriteLine(message);
      problemOutput.WriteCase(message);

    }
  }
}