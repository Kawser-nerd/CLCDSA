#! /usr/bin/env python
from __future__ import print_function, division
try:
    range = xrange
except NameError:
    pass

# import collections
# import functools
import itertools as it
import numpy as np # See http://www.numpy.org
# import sympy as sp # See http://sympy.org/en/index.html
# import gmpy2 # See https://code.google.com/p/gmpy/
# import networkx as nx # See http://networkx.github.io/
import brute

import os
import sys
# MY MODULES - available at https://github.com/lackofcheese/CodeJamLib/
sys.path.append(os.path.join(
    os.environ['GOOGLE_DRIVE'], 'Coding', 'GCJ', 'CodeJamLib'))
import codejam_io

def toks_line(f_in, fun=int):
    return [fun(k) for k in f_in.readline().split()]

def process_first(f_in):
    num_cases = int(f_in.readline())
    other_data = None
    return num_cases, other_data

def process_case(f_in, f_out, case_no, other_data=None):
    R, C, N = toks_line(f_in)
    ans = solve(R, C, N)
    print("Case #{}: {}".format(case_no, ans), file=f_out)

def solve(R, C, N):
    if N <= 1:
        return 0

    max_happy = (R * C + 1) // 2
    num_to_add = N - max_happy
    if num_to_add <= 0:
        return 0

    R, C = sorted((R, C))
    if R == 1:
        if C % 2 == 0:
            return num_to_add * 2 - 1
        else:
            return num_to_add * 2

    if R * C % 2 == 0:
        num_corners = 2
        num_edges = R + C - 4
        return calc_unhappy(num_to_add, num_corners, num_edges)
    else:
        nc1 = 0
        ne1 = R + C - 2
        na1 = num_to_add
        uh1 = calc_unhappy(na1, nc1, ne1)

        nc2 = 4
        ne2 = R + C - 6
        na2 = num_to_add + 1
        uh2 = calc_unhappy(na2, nc2, ne2)
        
        return min(uh1, uh2)

def calc_unhappy(num_to_add, num_corners, num_edges):
    unhappiness = 0

    unhappy_corners = min(num_to_add, num_corners)
    num_to_add -= unhappy_corners
    unhappiness += 2 * unhappy_corners
    if num_to_add <= 0:
        return unhappiness
    
    unhappy_edges = min(num_to_add, num_edges)
    num_to_add -= unhappy_edges
    unhappiness += 3 * unhappy_edges
    if num_to_add <= 0:
        return unhappiness

    return unhappiness + num_to_add * 4

if __name__ == '__main__':
    codejam_io.process_input(process_case, process_first, __file__)
