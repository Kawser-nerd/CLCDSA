package lib;

import java.util.function.Function;

public class ArrayFromInput {

    public static <T> T[] next(Input in, int length, Class<T> clazz, Function<String, T> converter) {
        return ArrayConstructor.create(length, clazz, () -> converter.apply(in.next()));
    }

}
