﻿using Gcj.Util;
using Gcj.Y2012.R1A.C;
using Gcj.Y2013.R1A.A;
using Gcj.Y2013.R1A.B;
using Gcj.Y2013.R1A.C;

namespace Gcj
{
    class Program
    {
        static void Main(string[] args)
        {
            ConcurrentGcjSolver.Solve<GoodLuckSolver>(false);
        }
    }
}
