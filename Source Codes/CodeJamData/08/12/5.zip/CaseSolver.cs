﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Milkshakes
{
    class CaseSolver
    {
        public static string Solve(string[] lines)
        {
            Case[] cases = Reader.Read(lines);
            int index = 1;
            StringBuilder sb = new StringBuilder();
            foreach (var cas in cases)
            {
                string result;
                if (Solve(cas, out result))
                {
                    sb.AppendLine(string.Format("Case #{0}: {1}", index++, result));
                }
                else
                {
                    sb.AppendLine(string.Format("Case #{0}: IMPOSSIBLE", index++));
                }
            }
            return sb.ToString();
        }

        public static bool Solve(Case cas, out string result)
        {
            result = null;
            bool[] flowers = new bool[cas.count + 1];
            foreach (Custom custom in cas.Customs)
            {
                if (custom.hasMalted && custom.flowers.Length == 0)
                {
                    flowers[custom.malted] = true;
                    custom.ok = true;
                }
            }

            bool allright = false;
            do
            {
                allright = true;
                foreach (Custom custom in cas.Customs)
                {
                    if (custom.flowers.Length == 0)
                        continue;

                    custom.ok = false;
                    foreach (int flower in custom.flowers)
                    {
                        if (!flowers[flower])
                        {
                            custom.ok = true;
                            break;
                        }
                    }
                    if(custom.hasMalted && flowers[custom.malted])
                    {
                        custom.ok = true;
                    }
                    if (!custom.ok)
                    {
                        allright = false;
                        if (custom.hasMalted)
                        {
                            flowers[custom.malted] = true;
                            custom.ok = true;
                            continue;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            } while (!allright);

            List<string> list = new List<string>();
            for (int i = 1; i < flowers.Length; i++)
            {
                if (flowers[i])
                    list.Add("1");
                else
                    list.Add("0");
            }
            result = string.Join(" ", list.ToArray());
            return true;
        }
    }
}
