using System;
using System.Configuration;
using CodeJam.Providers;
using Problems;
using Template;

namespace CodeJam.Factories
{

  // Originally wanted to use IOC container...
  public class ObjectFactory
  {
    public static T GetInstance<T>()
    {

      if(typeof(T) == typeof(CodeJamMain))
      {
        return (T) Activator.CreateInstance(typeof (T),
                              GetInstance<ProblemFactory>(),
                              GetInstance<ProblemTypeProvider>(),
                              GetInstance<InputOutputFactory>(),
                              GetInstance<Timer>());
      }

      if (typeof(T) == typeof(InputOutputFactory))
      {
        return (T)Activator.CreateInstance(typeof(T),
                              GetInstance<FilePathProvider>());
      }

      if (typeof(T) == typeof(ProblemTypeProvider))
      {
        return (T) Activator.CreateInstance(typeof (T),
                              GetInstance<FilePathProvider>());
      }

      if (typeof(T) == typeof(Timer))
      {
        return (T)Activator.CreateInstance(typeof(T),
                              GetInstance<FilePathProvider>());
      }

      if (typeof(T) == typeof(FilePathProvider))
      {
        return (T) Activator.CreateInstance(typeof (T),
                              ConfigurationManager.AppSettings["InputDirectory"],
                              ConfigurationManager.AppSettings["OutputDirectory"],
                              ConfigurationManager.AppSettings["TimerFile"]);
      }



      if (typeof(T) == typeof(ProblemA) ||
          typeof(T) == typeof(ProblemB) ||
          typeof(T) == typeof(ProblemC) ||
          typeof(T) == typeof(ProblemD))
      {
        return (T)Activator.CreateInstance(typeof(T), GetInstance<CaseFormatter>());
      }



      return (T) Activator.CreateInstance(typeof (T));
    }

    public static T GetInstance<T, P>(P param)
    {
      return (T) Activator.CreateInstance(typeof (T), param);

    }
  }
}