﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskB
{
	public class Shaker
	{

		public int[] GetBest (int flavoursNum, int[][] clientsLoves)
		{
			int[] res = new int[flavoursNum];
			/*for (int i = 0; i < flavoursNum; ++i)
				res[i] = -1;*/

			/*
			for (int c = 0; c < clientsLoves.Length; ++c)
			{
				if (IsMaltetClient (clientsLoves[c]))
					res[clientsLoves[c][0]-1] = 1;
			}
			*/


			List<int> clientsToCheck = new List<int> ();
			List<int> clientsToCheck2 = new List<int> ();
			bool isResChanged;
			for (int c = 0; c < clientsLoves.Length; ++c)
				clientsToCheck.Add (c);

			do
			{
				isResChanged = false;
				clientsToCheck2.Clear ();
				foreach (int c in clientsToCheck)
				{
					bool clientSatisfied = false;
					for (int i = 0; i < clientsLoves[c].Length; i += 2)
					{
						if (clientsLoves[c][i + 1] == 0 && res[clientsLoves[c][i] - 1] == 0)
						{
							clientSatisfied = true;
							break;
						}
					}
					if (clientSatisfied)
					{
						clientsToCheck2.Add (c);
						continue;
					}

					for (int i = 0; i < clientsLoves[c].Length; i += 2)
					{
						if (clientsLoves[c][i + 1] == 1)
						{
							res[clientsLoves[c][i] - 1] = 1;
							clientSatisfied = true;
							isResChanged = true;
							break;
						}
					}
					if (!clientSatisfied)
						return null;
				}
				clientsToCheck = new List<int>(clientsToCheck2);
			} while (isResChanged);
			

			return res;
		}




		/// <summary>
		/// 
		/// </summary>
		/// <param name="clientLoves"></param>
		/// <returns></returns>
		private bool IsMaltetClient (int[] clientLoves)
		{
			for (int i = 1; i < clientLoves.Length; i += 2)
				if (clientLoves[i] == 0)
					return false;

			return true;
		}
	}
}
