#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <math.h>
#include <assert.h>
#include <stack>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <functional>
#include <vector>
#include <deque>
#include <utility>
#include <bitset>
#include <limits.h>
#include <time.h>
#include <functional>
#include <numeric>
#include <iostream>

using namespace std;
typedef long long ll;
typedef unsigned long long llu;
typedef double lf;
typedef unsigned int uint;
typedef long double llf;
typedef pair<int, int> pii;
typedef pair<ll, int> pli;
typedef pair<ll, ll> pll;

llf PI = acos(-1);
#define debug(format, ...) printf(format, __VA_ARGS__);

const int MOD = (int)1e9 + 7;

class modint {
  int v;
public:
  modint (): v(0) { }
  modint (ll v): v((v + MOD) % MOD) { }

  bool operator== (modint x) { return v == x.v; }
  bool operator!= (modint x) { return v != x.v; }

  modint operator+ (modint x) { return v + x.v; }
  modint operator- (modint x) { return v - x.v; }
  modint operator* (modint x) { return (ll)v * x.v; }

  modint& operator+= (const modint x) { return *this = (*this + x); }
  modint& operator-= (const modint x) { return *this = (*this - x); }
  modint& operator*= (const modint x) { return *this = (*this * x); }

  int operator* () { return v; }
};

int N, K;
long double P[55];
long double U;

bool good (long double th) {
  if(N == K) {
    // prod (pi + ui) >= th
    // sum log (pi + ui) >= log th
    // u1에 대해 편미분하면 미분계수는 1 / (pi + ui)임. 그래서?
    // 같은 돈을 투자했을 때 가장 많이 발전할 가능성이 있으려면 pi가 작아야 함.
    // 그래서 pi가 작은 순으로 투자하면 될 듯
    return true;
  }else {
    return true;
  }
}

int main() {
  cin >> N >> K >> U;
  for(int i = 0; i < N; i++) {
    cin >> P[i];
  }
  sort(P, P+N);

  long double ans = 1;
  for(int i = 0; i < N; i++) ans *= P[i];

  if (N == K) {

    long double budget = U;
    P[N] = 1;
    for(int i = 1; i <= N && budget > 1e-9; i++) {
      // P[i] 값 가진 것 i+1개 있음
      long double needs = i * (P[i] - P[i-1]);
      if(needs <= budget) {
        budget -= needs;
        for(int j = 0; j < i; j++) P[j] = P[i];
      }else {
        long double delta = budget / i;
        for(int j = 0; j < i; j++) P[j] += delta;
        budget -= delta * i;
      }
      long double cur = 1;
      for(int j = 0; j < N; j++) cur *= P[j];
      ans = max(ans, cur);
    }
  }else {
    long double low = ans, high = 1;
    for(int rep = 0; rep < 100; rep++) {
      double mid = (low + high) / 2;
      if(good(mid)) {
        low = mid;
        ans = mid;
      }else {
        high = mid;
      }
    }
  }

  printf("%.20Lf\n", ans);
  return 0;
}
