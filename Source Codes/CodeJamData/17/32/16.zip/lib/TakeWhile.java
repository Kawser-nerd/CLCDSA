package lib;

import java.util.Spliterator;
import java.util.Spliterators;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

// TODO 자바책 보고 만들긴 했는데 지금은 딱히 쓸데를 못찾겠다. 지우지말고 언젠가 잘 써보자.. 
public class TakeWhile {
    public static <T> Stream<T> of(Stream<T> stream, Predicate<? super T> predicate) {
        Spliterator<T> iterator = stream.spliterator();
        return StreamSupport.stream(new Spliterators.AbstractSpliterator<T>(iterator.estimateSize(), 0) {
            boolean finished = false;

            @Override
            public boolean tryAdvance(Consumer<? super T> consumer) {
                if (finished)
                    return false;
                boolean originalAdvanced = iterator.tryAdvance(e -> {
                    if (predicate.test(e))
                        consumer.accept(e);
                    else
                        finished = true;
                });
                if (!originalAdvanced)
                    return false;
                return !finished;
            }
        }, false);
    }
}
