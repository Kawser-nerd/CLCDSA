import sys
import re
import os
import time
from itertools import *
from pprint import pprint

from euler import *


def max_power(p, n):
    result = 0
    i = 1
    while i <= n:
        i *= p
        result += 1
    return result-1

def max_calls(n):
    result = 1
    for p in primes():
        if p > n:
            break
        result += max_power(p, n)
    return result


def min_calls(n):
    if n == 1:
        return 1
    result = 0
    for p in primes():
        if p > n:
            break
        result += 1

    return result


def d_calls(n):
    if n == 1:
        return 0
    result = 1
    for p in primes():
        if p*p > n:
            break
        result += max_power(p, n)-1
    #assert result == max_calls(n) - min_calls(n)
    return result

def solve():
    n = int(next(fin))
    #a = min_calls(n)
    #b = max_calls(n)
    #print n, a, b
    print>>fout, d_calls(n)


if len(sys.argv) != 2:
    print 'specify input file'
    exit()

startTime = time.clock()

fin = open(sys.argv[1])
fout = open(os.path.splitext(sys.argv[1])[0]+'.out', 'w')

numCases = int(next(fin))
for caseNo in range(numCases):
    print '\b'*10, 100*caseNo/numCases, '%',
    print>>fout, 'Case #%s:'%(caseNo+1),
    solve()

try:
    next(fin)
    assert False, 'not all lines are processed'
except StopIteration:
    pass

fin.close()
fout.close()

print '\b'*10+'it took %.1fs'%(time.clock()-startTime)