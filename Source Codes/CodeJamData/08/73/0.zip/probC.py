import getopt, sys
def CodeJamSolver(infilename, problemclasstype, outfilename):
	print "Parsing " + infilename + " to " + outfilename
	infileobject = open(infilename,'r')
	outfileobject = open(outfilename, 'w')
	N = int(infileobject.readline())
	for i in range(N):

		print 'Case #' + str(i+1)
		problem = problemclasstype(infileobject)
		solution = problem.solution()
		print solution
		outfileobject.write('Case #' + str(i+1) + ': ' + solution + '\n')
	infileobject.close()
	outfileobject.close()

class ProblemC:
    def __init__(self, fileobject):
        ## Read from fileobject into local variables with lines like
        ## self.T = int(fileobject.readline())
        ##  or
        ## self.contents=fileobject.readline().rstrip('\n')
        ##  or
        ## self.words=fileobject.readline().split(' ')
        ##  or
        ## self.nums = [int(x) for x in fileobject.readline().split(' ')]
        [self.M, self.Q] = [int(x) for x in fileobject.readline().split(' ')]
        print "Q=", self.Q, "M=", self.M
        self.probs = [[float(x) for x in fileobject.readline().rstrip('\n').split(' ')] for i in range(self.Q)]

    def solution(self):
        ## Use above local variables to return string
        ## for example: return str(x) + ' ' + str(y)
        ## parse floats with eg. "%1.6f" % f
        fp = self.probs[0]
        for i in range(1,self.Q):
            fp = [a * b for a in fp for b in self.probs[i]]
        fp.sort()
        fp.reverse()
        length = min(self.M,len(fp))
        return str(sum([fp[k] for k in range(length)]))

def usage():
	print "probC.py    runs on test data"
	print "probC.py -t runs on test data"
	print "probC.py -s runs on small data"
	print "probC.py -l runs on large data"
	print "probC.py -h prints this message"

def main():
	try:
		opts, args = getopt.getopt(sys.argv[1:], "hstl", ["help", "small", "test", "large"])
	except getopt.GetoptError, err:
		print str(error)
		usage()
		sys.exit(2);
	type = "test"
	for o, a in opts:
		if o in ("-h", "--help"):
			usage()
			sys.exit()
		elif o in ("-s", "--small"):
			type = "small"
		elif o in ("-l", "--large"):
			type = "large"
	infile = "c:\codejam\semis\problemC\C-" + type + ".in"
	outfile = "c:\codejam\semis\problemC\C-" + type + ".out"
	CodeJamSolver(infile, ProblemC, outfile)

if __name__ == "__main__":
	main()

