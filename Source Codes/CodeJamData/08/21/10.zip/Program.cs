﻿﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace a
{
    class Program
    {
        static void Main(string[] args)
        {

            StreamReader sr = new StreamReader(args[0]);
            StreamWriter sw = new StreamWriter(args[1]);

            int N = int.Parse(sr.ReadLine());
            for (int ii = 1; ii <= N; ii++)
            {
                string[] ln = sr.ReadLine().Split(new Char[]{' '});
                int n = int.Parse(ln[0]);
                int A = int.Parse(ln[1]);
                int B = int.Parse(ln[2]);
                int C = int.Parse(ln[3]);
                int D = int.Parse(ln[4]);
                int x = int.Parse(ln[5]);
                int y = int.Parse(ln[6]);
                int M = int.Parse(ln[7]);

                int[,] t = new int[n, 2];
                t[0, 0] = x;
                t[0, 1] = y;
                for (int i = 1; i < n; i++)
                {
                    t[i,0] = (A*t[i-1,0]+B)%M;
                    t[i,1] = (C*t[i-1,1]+D)%M;
                }

                int rv = 0;
                for (int i = 0; i < n; i++)
                    for (int j = i + 1; j < n; j++)
                        for (int k = j + 1; k < n; k++)
                            if ((t[i, 0] + t[j, 0] + t[k, 0]) % 3 == 0 && (t[i, 1] + t[j, 1] + t[k, 1]) % 3 == 0)
                                rv++;

                sw.WriteLine("Case #" + ii + ": " + rv);
            }

            sr.Close();
            sw.Close();
        }
    }
}
