using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;

public class Problem:IComparer<int[]>
{
    static public string InputName = "../../A-large.in";

    public void Solve(TextReader rdr, TextWriter wr)
    {
        int probnum =int.Parse(rdr.ReadLine());
        for (int cs = 1; cs <= probnum; cs++)
        {
            string[] prts=rdr.ReadLine().Split(' ');
            int n=int.Parse(prts[0]);
            long A=int.Parse(prts[1]);
            long B = int.Parse(prts[2]);
            long C = int.Parse(prts[3]);
            long D = int.Parse(prts[4]);
            long x0 = int.Parse(prts[5]);
            long y0 = int.Parse(prts[6]);
            long M = int.Parse(prts[7]);
            List<int[]> trees=new List<int[]>();

            List<int[]>[,] mod=new List<int[]>[3,3];            
            for(int i=0;i<3;i++)
                for (int k = 0; k < 3; k++)
                {
                    mod[i, k] = new List<int[]>();
                }
            long x=x0;
            long y=y0;
            for(int i=0;i<n;i++)
            {
                int[] pt=new int[]{(int)x,(int)y};
                trees.Add(pt);
                int mx = (int)x % 3;
                int my = (int)y % 3;
                mod[x%3,y%3].Add(pt);                
                x=(A*x+B)%M;
                y=(C*y+D)%M;
            }        
            long res=0;
            /*for(int a=0;a<trees.Count;a++)
                for (int b = a+1; b < trees.Count; b++)
                    for (int c = b + 1; c < trees.Count; c++)
                    {
                        if (((trees[a][0] + trees[b][0] + trees[c][0]) % 3 == 0) &&
                            ((trees[a][1] + trees[b][1] + trees[c][1]) % 3 == 0))
                            res++;
                    }*/
            for(int x1=0;x1<3;x1++)
                for(int x2=0;x2<3;x2++)
                    for(int y1=0;y1<3;y1++)
                        for(int y2=0;y2<3;y2++)
                        {
                            int x3=(3-(x1+x2)%3)%3;
                            int y3=(3-(y1+y2)%3)%3;
                            long that=1;
                            if(x1==x2 && y1==y2)
                            {
                                if(x1==x3&&y1==y3)
                                    that*=((long)mod[x1,y1].Count-0)*(mod[x1,y1].Count-1)*(mod[x1,y1].Count-2);
                                else
                                {
                                    that *= ((long)mod[x1, y1].Count - 0) * (mod[x1, y1].Count - 1) * (mod[x3, y3].Count - 0);
                                }
                            }
                            else
                            {
                                if(x1==x3&&y1==y3)
                                    that *= ((long)mod[x1, y1].Count - 0) * (mod[x2, y2].Count - 0) * (mod[x1, y1].Count - 1);
                                else
                                {
                                    if(x2==x3&&y2==y3)
                                        that *= ((long)mod[x1, y1].Count - 0) * (mod[x2, y2].Count - 0) * (mod[x2, y2].Count - 1);
                                    else
                                        that *= ((long)mod[x1, y1].Count - 0) * (mod[x2, y2].Count - 0) * (mod[x3, y3].Count - 0);
                                }
                            }
                            res += that;
                        }
            res /= 6;
            wr.WriteLine("Case #{0}: {1}", cs, res);
        }
    }

    

    public string Solve(string problem)
    {
        StringWriter wr = new StringWriter();
        StringReader rdr = new StringReader(problem);
        Solve(rdr, wr);
        return wr.ToString();
    }

    #region IComparer<int[]> Members

    public int Compare(int[] x, int[] y)
    {
        throw new NotImplementedException();
    }

    #endregion
}


