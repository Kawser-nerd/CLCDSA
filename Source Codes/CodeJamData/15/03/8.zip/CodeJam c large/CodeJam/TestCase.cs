/* www.codertom.com  -  copyright Tom Harrison 2015 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace CoderTom.CodeJam
{
    public static class Quat
    {
        public enum Q
        {
            one = 0,
            i = 1,
            j = 2,
            k = 3,
            _one = 4,
            _i = 5,
            _j = 6,
            _k = 7
        }

        public static Q[][]
            matrix = new Q[][]
            {
                new Q[] {Q.one,    Q.i,     Q.j,    Q.k         ,Q._one,    Q._i,       Q._j,       Q._k     },
                new Q[] {Q.i,      Q._one,  Q.k,    Q._j        ,Q._i,      Q.one,      Q._k,       Q.j    },
                new Q[] {Q.j,      Q._k,    Q._one, Q.i         ,Q._j,      Q.k,        Q.one,      Q._i     },
                new Q[] {Q.k,      Q.j,     Q._i,   Q._one      ,Q._k,      Q._j,       Q.i,        Q.one  },
                new Q[] {Q._one,   Q._i,    Q._j,   Q._k        ,Q.one,     Q.i,        Q.j,        Q.k     },
                new Q[] {Q._i,     Q.one,   Q._k,   Q.j         ,Q.i,       Q._one,     Q.k,        Q._j    },
                new Q[] {Q._j,     Q.k,     Q.one,  Q._i        ,Q.j,       Q._k,       Q._one,     Q.i     },
                new Q[] {Q._k,     Q._j,    Q.i,    Q.one       ,Q.k,       Q.j,        Q._i,       Q._one  },
                
            };

        public static Q Times(Q a, Q b)
        {
            return matrix[(int)a][(int)b];
        }
    }

    public class TestCase
    {
        public TestCase()
        {
        }

        public TestCase(StreamReader stream)
        {
            var lx = stream.ReadLongArray();
            Length = (int) lx[0];
            Times = lx[1];
            Chain = stream.ReadString();

        }

        public string Chain { get; set; }

        public long Times { get; set; }

        public int Length { get; set; }

        public string Solve()
        {
            var lookup = new Dictionary<char, Quat.Q> { { 'i', Quat.Q.i }, { 'j', Quat.Q.j }, { 'k', Quat.Q.k } };

            var valueSoFar = Quat.Q.one;
            var chars = Chain.ToCharArray();
            foreach (var c in chars)
            {
                var thisTerm = lookup[c];
                valueSoFar = Quat.Times(valueSoFar, thisTerm);
            }

            switch (valueSoFar)
            {
                case Quat.Q.one:
                    return "NO";

                case Quat.Q._one:
                    if (Times % 2 != 1)
                    // must be 1 mod 2 times
                    return "NO";

                    break;

                default:
                    if (Times % 4 != 2)
                        // must be 2 mod 4 times
                    return "NO";

                    break;
            }

            List<Quat.Q> numbersStartedWith = new List<Quat.Q>();

            var currentNumber = Quat.Q.one;
            bool hasI = false;
            int timesSoFar = 0;

            while (!numbersStartedWith.Contains(currentNumber) && timesSoFar < Times)
            {
                numbersStartedWith.Add(currentNumber);
                foreach (var c in chars)
                {
                    var thisTerm = lookup[c];
                    currentNumber = Quat.Times(currentNumber, thisTerm);
                    if (hasI && currentNumber == Quat.Q.j)
                        return "YES";

                    if (!hasI && currentNumber == Quat.Q.i)
                    {
                        hasI = true;
                        currentNumber = Quat.Q.one;
                        numbersStartedWith = new List<Quat.Q>();
                    }
                }

                timesSoFar++;
            }


            return "NO";
        }

        private static Dictionary<Tuple<char, char>, char> ijkMultiplies;
    }
}
