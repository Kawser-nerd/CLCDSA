package lib;

import java.util.Comparator;
import java.util.stream.Stream;

public class Max {
    public static <T> T max(T v1, T v2, Comparator<T> comparator) {
        return Stream.of(v1, v2).max(comparator).get();
    }
}
