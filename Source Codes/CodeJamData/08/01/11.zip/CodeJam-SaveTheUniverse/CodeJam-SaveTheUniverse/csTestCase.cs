﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam_SaveTheUniverse
{
    class csTestCase
    {
        public List<string> EngineNames = new List<string>();
        public List<string> Keywords = new List<string>();
        public int Solution = -1;
    }
}
