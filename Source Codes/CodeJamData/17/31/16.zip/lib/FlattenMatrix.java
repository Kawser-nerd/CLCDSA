package lib;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class FlattenMatrix {
    public static <T> Matrix<T> create(Matrix<T> src) {
        List<Vector<T>> list = IntStream.range(0, src.n)
                .mapToObj(i -> FlattenVector.create(RowVector.of(src, i)))
                .collect(Collectors.toList());
        return MatrixFromRowVectors.wrap(list);
    }
}
