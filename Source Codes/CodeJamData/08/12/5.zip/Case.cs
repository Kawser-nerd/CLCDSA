﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Milkshakes
{
    class Case
    {
        private List<Custom> list = new List<Custom>();

        public int count;

        public Custom[] Customs
        {
            get
            {
                return list.ToArray();
            }
        }

        public void Add(Custom c)
        {
            list.Add(c);
        }
    }

    internal class Custom
    {
        public Custom(string s)
        {
            string[] ss = s.Split(' ');
            int index = 0;
            count = int.Parse(ss[index++]);
            List<int> list = new List<int>();
            for(int i = 0; i < count; ++i)
            {
                int f = int.Parse(ss[index++]);
                int m = int.Parse(ss[index++]);
                if(m == 1)
                {
                    malted = f;
                }
                else
                {
                    list.Add(f);
                }
            }
            flowers = list.ToArray();
        }
        public int count;
        public int[] flowers;
        public int malted;
        public bool hasMalted
        {
            get
            {
                return flowers.Length != count;
            }
        }

        public bool ok = false;
    }
}
