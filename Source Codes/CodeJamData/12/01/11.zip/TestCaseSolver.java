package template;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TestCaseSolver implements Runnable {

    private ArrayList<TestCase> testCases;
    private int ref;

    public TestCaseSolver(ArrayList<TestCase> tcs, int ref) {
        testCases = tcs;
        this.ref = ref;
    }

    public TestCaseSolver(TestCase tc, int ref) {
        ArrayList<TestCase> tcs = new ArrayList<>();
        tcs.add(tc);
        testCases = tcs;
        this.ref = ref;
    }

    public int getRef() {
        return ref;
    }

    @Override
    public void run() {
        for (TestCase tc : testCases) {
            long startTime = System.nanoTime();
            solve(tc);
            long duration = System.nanoTime() - startTime;
            double secs = (double)duration / (1000000000d);
            tc.setTime(secs);
            System.out.println("Thread " + ref + " solved testcase " + tc.getRef() + " in " + String.format("%.2f", secs) + " secs.");
        }
    }

    private void solve(TestCase tc) {
        String inDict  = "ejpmysljylckdkxveddknmcrejsicpdrysirbcpcypcrtcsradkhwyfrepkymveddknkmkrkcddekrkdeoyakwaejtysrreujdrlkgcjv";
        String outDict = "ourlanguageisimpossibletounderstandtherearetwentysixfactorialpossibilitiessoitisokayifyouwanttojustgiveup";
        Map<String, String> transMap = new HashMap<>();
        for (int i = 0; i < inDict.length(); i++) {
            transMap.put(inDict.substring(i, i+1), outDict.substring(i, i+1));
        }
        transMap.put("z", "q");
        transMap.put("q", "z");
        System.out.println(transMap.keySet().size());
        
        String in = tc.getString("s");
        String out = "";
        for (int i = 0; i < in.length(); i++) {
            String c = in.substring(i, i+1);
            if (c.equals(" ")) {
                out += c;
            } else {
                    out += transMap.get(c);
            }
        }

        tc.setSolution(out);
    }
}
