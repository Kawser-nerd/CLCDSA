﻿using System;
using System.IO;
using CodeJamLibrary.Interfaces;

namespace CodeJamLibrary
{
  public class ProblemOutput : IProblemOutput
  {
    private readonly ITextWriterProvider textWriterProvider;
    private int count;

    public ProblemOutput(ITextWriterProvider textWriterProvider)
    {
      this.textWriterProvider = textWriterProvider;
      count = 1;
    }

    public void WriteCase(string value)
    {
      TextWriter textWriter = textWriterProvider.GetWriter();
      textWriter.WriteLine(String.Format("Case #{0}: {1}", count++, value));
      textWriter.Flush();

      Console.Error.WriteLine(String.Format("Case #{0}: {1}", count-1, value));
    }
  }
}
