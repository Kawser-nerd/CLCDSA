﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Marius.CodeJam
{
    public class ThemePark: IParalelSolver
    {
        private ulong R, k, N;
        private ulong[] g;

        private ulong _answer;

        public void ReadInput()
        {
            var data = Console.ReadLine().Split().Select(s => ulong.Parse(s)).ToArray();
            R = data[0];
            k = data[1];
            N = data[2];

            g = Console.ReadLine().Split().Select(s => ulong.Parse(s)).ToArray();
        }

        public void WriteAnswer(int caseNumber)
        {
            Console.WriteLine("Case #{0}: {1}", caseNumber, _answer);
        }

        public void SolveAsync()
        {
            checked
            {
                int rotIndex = 0;
                Dictionary<int, int> rots = new Dictionary<int, int>();

                int round = 0;
                ulong size;
                int max;

                while (!rots.ContainsKey(rotIndex))
                {
                    rots.Add(rotIndex, round);

                    size = 0;
                    max = g.Length;
                    while (true)
                    {
                        size += g[rotIndex];
                        if (size > k)
                            break;

                        rotIndex++;
                        rotIndex = rotIndex % g.Length;
                        max--;
                        if (max <= 0)
                            break;
                    }
                    round++;
                }

                int startRound = rots[rotIndex];
                ulong diff = (ulong)round - (ulong)startRound;
                ulong roundPrice = Price(rotIndex, diff);
                ulong startPrice = 0;
                if (rotIndex > 0)
                    startPrice = Price(0, (ulong)startRound);

                if (R < (ulong)startRound)
                {
                    _answer = Price(0, R);
                }
                else
                {
                    ulong calcR = R;
                    calcR -= (ulong)startRound;
                    ulong full = calcR / diff;
                    ulong part = calcR % diff;

                    _answer = startPrice + roundPrice * full + Price(rotIndex, part);
                }
            }
        }

        private ulong Price(int start, ulong count)
        {
            checked
            {
                ulong roundPrice = 0;
                ulong size;
                int max;

                for (ulong i = 0; i < count; i++)
                {
                    size = 0;
                    max = g.Length;
                    while (true)
                    {
                        size += g[start];
                        if (size > k)
                            break;

                        roundPrice += g[start];

                        start++;
                        start = start % g.Length;
                        max--;
                        if (max <= 0)
                            break;
                    }
                }
                return roundPrice;
            }
        }
    }
}
