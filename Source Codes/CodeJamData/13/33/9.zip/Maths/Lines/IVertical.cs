﻿namespace Generic.Maths.Lines
{
    public interface IVertical : ILine
    {
         double X { get; }
    }
}
