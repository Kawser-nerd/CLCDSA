﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam_TrainTimetable
{
    class csTrip
    {
        public int Departure, Arrival;

        public csTrip(int DepH, int DepM, int ArrH, int ArrM)
        {
            Departure = DepH * 60 + DepM;
            Arrival = ArrH * 60 + ArrM;
        }
    }
}
