import time, math, operator, re
from helper import *

t1 = starttimer()

filename = "A%s.%s"
# 0 for test, 1 for small, 2 for large
is_large = 1

mode_str = '' if is_large == 0 else '-small-attempt0' if is_large == 1 else '-large'
infile = filename % (mode_str, 'in')
outfile = filename % (mode_str, 'out')

# parse input
inf = open(infile, 'r')
outf = open(outfile, 'w')

try:
    T = readI(inf)
    
    for case in range(1, T+1):
        r1 = readI(inf)
        c1 = [readIA(inf) for _ in range(4)]
        r2 = readI(inf)
        c2 = [readIA(inf) for _ in range(4)]

        s = set(c1[r1-1]) & set(c2[r2-1])
        if len(s) == 1:
            output = s.pop()
        elif len(s) == 0:
            output = "Volunteer cheated!"
        else:
            output = "Bad magician!"        
                
        outf.write("Case #%d: %s\n" % (case, output))
        print "Case #%d: %s" % (case, output)  
       
    
finally:
    inf.close()
    outf.close()

endtimer(t1)
