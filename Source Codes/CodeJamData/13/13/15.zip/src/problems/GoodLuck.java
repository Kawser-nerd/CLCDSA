package problems;

import main.IOManager;
import main.Problem;

public class GoodLuck extends Problem {

	public GoodLuck(IOManager io) {
		super(io);
	}

	int r, n, m, k;
	
	@Override
	protected String solveCase() {
		int[] line = io.readInts();
		r = line[0];
		n = line[1];
		m = line[2];
		k = line[3];
		String result = "";
		for (int i = 0; i < r; ++i){
			result+="\n";
			long[] p = io.readLongs();
			long[][] primeFactors;
			primeFactors = new long[k][];
			for (int j = 0; j < k; ++j){
				primeFactors[j] = primeFactors(p[j]);
			}
			int[] primeCounter = new int[10];
			int maxDs[] = new int [10];
			for (int j = 0; j < k; ++j){
				int[] ds = new int[10];
				for (int l = 0; l < primeFactors[j].length; ++l){
					ds[(int)primeFactors[j][l]]++;
					primeCounter[(int)primeFactors[j][l]]++;
				}
				for (int l = 0; l < 10; ++l)
					if (ds[l] > maxDs[l])
						maxDs[l] = ds[l];
			}
			int dCounter = 0;
			int[] digitCounter = new int[10];
			for (int j = 0; j < 10; ++j){
				for (int l = 0; l < maxDs[j]; ++l){
					if (j != 2)
						result+=j;
					else if (l < maxDs[j]-1){
						result+="4";
						l++;
					}else
						result+="2";
					dCounter++;
				}
			}
//			for (int j = 0; j < digitCounter.length; ++j){
//				if (digitCounter[j] > 0){
//					result += String.valueOf(j);
//					dCounter++;
//				}
//			}
			while (dCounter < n){
				result+= "2";
				dCounter++;
			}
			
		}
		
		return result;
	}
	
    public static long[] primeFactors (long n) {
        int maxFactors = (int) Math.ceil(Math.log10(n)/Math.log10(2));

        long[] tmp = new long[maxFactors];
        int anzahlFaktoren = 0;
        for (long j = 2; j <= n; j++ ) {
            if (n % j == 0) {
                tmp[anzahlFaktoren++] = j;
                n = n/j;
                j = 1;
            }
        }
        long[] prf = new long[anzahlFaktoren];
        for (int i = 0; i < anzahlFaktoren; i++) {
            prf[i] = tmp[i];
        }
        return prf;
    }

}
