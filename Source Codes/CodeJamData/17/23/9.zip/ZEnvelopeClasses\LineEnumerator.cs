﻿using System.Collections.Generic;
using System.IO;
using System.Collections;

namespace Q3
{
	public class LineEnumerator : IEnumerator<string>
	{
		#region Fields

		private StreamReader m_InputReader;
		private string m_LastLineRead;
		private string m_InputPath;

		private int m_CurrentTestCase = -1;

		#endregion

		#region C'tor

		public LineEnumerator(string inputPath)
		{
			this.TestCaseInfo = new TestCaseInfo();

			m_InputPath = inputPath;
			m_InputReader = new StreamReader(inputPath);
			m_LastLineRead = m_InputReader.ReadLine();
			UpdateTestCaseInfo();
		}

		#endregion

		#region Properties

		public TestCaseInfo TestCaseInfo { get; private set; }

		public string Current
		{
			get
			{
				UpdateTestCaseInfo();
				return m_LastLineRead;
			}
		}

		object IEnumerator.Current
		{
			get
			{
				return this.Current;
			}
		}

		#endregion

		#region Methods

		public void UpdateTestCase(int t)
		{
			m_CurrentTestCase = t;
		}

		public void Dispose()
		{
			m_InputReader.Dispose();
		}

		public bool MoveNext()
		{
			m_LastLineRead = m_InputReader.ReadLine();
			return m_LastLineRead != null;
		}

		private void UpdateTestCaseInfo()
		{
			if (m_CurrentTestCase != -1)
			{
				this.TestCaseInfo.AddTestCaseInputInfo(m_CurrentTestCase, m_LastLineRead);
			}
		}

		public void Reset()
		{
			m_InputReader.Dispose();
			m_InputReader = new StreamReader(m_InputPath);
		}

		#endregion
	}
}
