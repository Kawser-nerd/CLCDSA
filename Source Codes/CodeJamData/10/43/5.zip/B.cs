﻿/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    class B : ParallelSolution
    {
        struct State
        {
            public int index { get; set; }
            public int toMiss { get; set; }
        }


        override public Func<String> StartSolving()
        {
            int P = ReadInt();
            var M = ReadInts(1<<P);

            int[][] costs = ReadLines(P).Select(line => Array.ConvertAll(line.Trim().Split(' '),int.Parse)).ToArray();

            return () =>
                {
                    Dictionary<State, int> best = new Dictionary<State, int>();
                    
                    for (int i = 0; i < M.Length; i++)
                        best[new State { index = i, toMiss = M[i] }] = 0;
                        
                    for (int round = 0; round < P; round++)
                    {
                        Dictionary<State, int> nextRound = new Dictionary<State, int>();

                        for (int index = 0; index < 1 << (P - round-1); index++)
                        {
                            for (int toMissL = 0; toMissL <= P; toMissL++)
                                for (int toMissR = 0; toMissR <= P; toMissR++)
                            {
                                int costL;
                                int costR;
                                if (best.TryGetValue(new State { index = index * 2, toMiss = toMissL }, out costL) &&
                                    best.TryGetValue(new State { index = index * 2 + 1, toMiss = toMissR }, out costR))
                                {
                                    improve(nextRound, new State { index = index, toMiss = Math.Min(toMissL, toMissR) }, costL + costR + costs[round][index]);
                                    improve(nextRound, new State { index = index, toMiss = Math.Min(toMissL, toMissR) - 1 }, costL + costR);
                                }
                            }
                        }

                        best = nextRound;
                    }

                    return best.Where(e => e.Key.toMiss>=0).Min(e => e.Value).ToString();
                };
        }

        private void improve(Dictionary<State, int> nextRound, State state, int p)
        {
            int old;
            if (nextRound.TryGetValue(state, out old))
            {
                if (p < old)
                    nextRound[state] = p;
            }
            else
                nextRound[state] = p;
        }
    }
}
