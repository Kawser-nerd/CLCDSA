#include <vector>
#include <list>
#include <sstream>

#include "SavingtheUniverse.h"
#include "Utils.h"


SavingtheUniverse::SavingtheUniverse(std::istream &in, std::string &out, boost::condition &c, char &f)
	: Task(out, c, f)
{
	std::istringstream	input_ne;
	std::istringstream	input_nq;
	std::string			str;
	unsigned long		ch1;
	unsigned long		ch2;

	GetString(in, str);

	input_ne.str(str);
	input_ne >> num_sengines;

	for(ch1 = 0; ch1 < num_sengines; ch1++)
		GetString(in, sengine_name[ch1]);

	GetString(in, str);
	input_nq.str(str);
	input_nq >> num_queries;

	for(ch1 = 0; ch1 < num_queries; ch1++)
	{
		GetString(in, str);
		for(ch2 = 0; ch2 < num_sengines && str.compare(sengine_name[ch2]); ch2++);
		query[ch1] = ch2;
	}
}

SavingtheUniverse::SavingtheUniverse(SavingtheUniverse &n) : Task(n)
{
	unsigned long		ch1;

	num_sengines = n.num_sengines;
	num_queries = n.num_queries;
	for(ch1 = 0; ch1 < num_sengines; ch1++)
		sengine_name[ch1] = n.sengine_name[ch1];
	memcpy(query, n.query, num_queries * sizeof(unsigned long));
}


SavingtheUniverse::~SavingtheUniverse()
{
}

void SavingtheUniverse::operator()()
{
	std::ostringstream	output;
	unsigned long		key[4];
	unsigned long		num_found;
	unsigned long		ch1;
	unsigned long		ind;
	unsigned long		bset;
	unsigned long		num_switches;

	memset(key, 0, 4 * sizeof(unsigned long));

	num_found = 0;
	num_switches = 0;
	for(ch1 = 0; ch1 < num_queries; ch1++)
	{
		if(query[ch1] == num_sengines)
			continue;
		ind = query[ch1] >> 5;
		bset = 1 << (query[ch1] & 31);
		if(key[ind] & bset)
			continue;

		num_found++;
		if(num_found == num_sengines)
		{
			num_switches++;
			num_found = 1;
			memset(key, 0, 4 * sizeof(unsigned long));
		}
		key[ind] |= bset;
	}

	output << num_switches;
	result= output.str();

	flag = 1;
	finish.notify_all();
}
