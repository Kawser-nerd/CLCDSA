﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCJ2015Round1C_3
{
	public class Edge<T>
		where T : IComparable<T>
	{
		public Node<T> Source { get; private set; }
		public Node<T> Target { get; private set; }

		public Edge(Node<T> source, Node<T> target)
		{
			this.Source = source;
			this.Target = target;
		}
	}
}
