package lib;

import java.util.List;

public class AddedList {
    public static <T> List<T> of(List<T> list, T item) {
        return ListUsingGetter.create(list.size() + 1, index -> index < list.size() ? list.get(index) : item);
    }
}
