using CodeJam.Providers;
using Template.Interfaces;

namespace CodeJam.Factories
{
  public interface IProblemFactory
  {
    IProblem CreateProblem(ProblemType problemType);
  }
}