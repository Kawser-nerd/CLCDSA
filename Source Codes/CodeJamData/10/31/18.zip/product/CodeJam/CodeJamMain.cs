using System.IO;
using CodeJam.Factories;
using CodeJam.Providers;

namespace CodeJam
{
  public class CodeJamMain : ICodeJamMain
  {
    private readonly IProblemFactory problemFactory;
    private readonly IProblemTypeProvider problemTypeProvider;
    private readonly IInputOutputFactory inputOutputFactory;
    private readonly ITimer timer;


    public CodeJamMain(IProblemFactory problemFactory, IProblemTypeProvider problemTypeProvider, IInputOutputFactory inputOutputFactory, ITimer timer)
    {
      this.problemFactory = problemFactory;
      this.problemTypeProvider = problemTypeProvider;
      this.inputOutputFactory = inputOutputFactory;
      this.timer = timer;
    }


    public void Execute()
    {
      var input = inputOutputFactory.CreateInput();
      var output = inputOutputFactory.CreateOutput();

      var problem = problemFactory.CreateProblem(problemTypeProvider.GetProblemType());
      
      timer.Start();
      problem.Solve(input, output);
      timer.Stop();

      timer.WriteToFile();

      input.Close();
      output.Close();
    }

  }
}