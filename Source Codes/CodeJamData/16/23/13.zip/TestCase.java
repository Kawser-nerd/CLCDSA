package template;

//standard libraries potentially used:
//Apache commons http://http://commons.apache.org/
//Google Guava http://code.google.com/p/guava-libraries/
//JGraphT

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Callable;
import org.jgrapht.alg.flow.EdmondsKarpMaximumFlow;
import org.jgrapht.alg.interfaces.MaximumFlowAlgorithm.MaximumFlow;
import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.SimpleDirectedGraph;
import org.jgrapht.graph.SimpleDirectedWeightedGraph;

public class TestCase implements Callable {

    int caseRef;
    Object result;

    int N;
    String[] list;
    int[][] grid;

    public void prepare(Scanner scanner) {
        N = Integer.valueOf(scanner.nextLine());

        list = new String[N];
        for (int i = 0; i < N; i++) {
            list[i] = scanner.nextLine();
        }
//        grid = new int[N][N];
//        for (int r = 0; r < N; r++) {
//            for (int c = 0; c < N; c++) {
//                grid[r][c] = scanner.nextInt();
//            }
//        }
    }

    private Object solve() {
        List<String> alphas = new ArrayList<>();
        List<String> betas = new ArrayList<>();
        
        for (String s : list) {
            String[] ss = s.split(" ");
            if (!alphas.contains("a_" + ss[0])) alphas.add("a_" + ss[0]);
            if (!betas.contains("b_" + ss[1])) betas.add("b_" + ss[1]);
        }
        
        //System.out.println(alphas + " " + betas);
        
        SimpleDirectedWeightedGraph<String, DefaultWeightedEdge> g = new SimpleDirectedWeightedGraph<>(DefaultWeightedEdge.class);
        g.addVertex("source");
        g.addVertex("sink");
        
        for (String a : alphas) {
            g.addVertex(a);
            DefaultWeightedEdge e = g.addEdge("source", a);
            g.setEdgeWeight(e, 1d);
        }
        for (String b : betas) {
            g.addVertex(b);
            DefaultWeightedEdge e = g.addEdge(b, "sink");
            g.setEdgeWeight(e, 1d);
        }    
        
        for (String s : list) {
            String[] ss = s.split(" ");
            DefaultWeightedEdge e = g.addEdge("a_" + ss[0], "b_" + ss[1]);
            g.setEdgeWeight(e, 1d);
        }        
        
        //System.out.println(g);
        
        EdmondsKarpMaximumFlow<String, DefaultWeightedEdge> ek = new EdmondsKarpMaximumFlow<>(g);
        MaximumFlow<String, DefaultWeightedEdge> mf = ek.buildMaximumFlow("source", "sink");
        double d = mf.getValue();
        int flow = (int)(d + 0.5d);
        System.out.println(d + " " + flow);
        
        int C = alphas.size();
        int R = betas.size();
        return N - (C + R) + flow;
    }

    /////////////////////////////////////////////////////////////////////
    public static void main(String[] args) {
        Utils.go(1);
    }

    @Override
    public Object call() throws Exception {
        return run();
    }

    public Object run() {
        System.out.println("Starting case " + this.getRef());
        Object solution = solve();
        assert solution != null : "Null result for testcase " + this.getRef();
        setResult(solution);
        System.out.println("Finished case " + this.getRef() + ", result: " + solution);
        return solution;
    }

    public int getRef() {
        return caseRef;
    }

    public void setRef(int ref) {
        this.caseRef = ref;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }

}
