﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace codejam
{
    public class line2d
    {
        /*
         * FORM 1: y = ax + b
         * FORM 2: mx + ny + k = 0;
         * 
         * a = - m/n
         * b = - k/n
         * 
         * IF b != 0
         * m = a/b
         * n = -1/b
         * k = 1
         * 
         * IF b == 0
         * m = a
         * n = 1
         * k = 0
         * */
        protected double m, n, k;

        private void CalcCoef(double a, double b)
        {
            if (b == 0)
            {
                k = 0;
                m = a;
                n = -1;
            }
            else
            {
                k = 1;
                m = a / b;
                n = -1 / b;
            }
        }

        public line2d() { m = 0; n = 1; k = 0; }
        public line2d(double a, double b)
        {
            CalcCoef(a, b);
        }
        public line2d(object a, object b)
        {
            CalcCoef(Convert.ToDouble(a), Convert.ToDouble(b));
        }
        public line2d(PointF p1, PointF p2)
        {
            if (p1.X == p2.X)
            {
                m = -1/p1.X;
                n = 0;
                k = 1;
            }
            else
            {
                double a, b;
                a = (p1.Y - p2.Y) / (p1.X - p2.X);
                b = p1.Y - a * p1.X;
                CalcCoef(a, b);
            }
        }

        public bool isPointOnLine(PointF p)
        {
            return (fCalc.isZero(m * p.X + n * p.Y + k));
        }

        public static bool operator ==(line2d l1, line2d l2)
        {
            return l1.m == l2.m && l1.n == l2.n && l1.k == l2.k;
        }

        public static bool operator !=(line2d l1, line2d l2)
        {
            return l1.m != l2.m || l1.n != l2.n || l1.k != l2.k;
        }

        /// <summary>
        /// Determina si la recta es del tipo x = cte
        /// </summary>
        public bool isVertical { get { return fCalc.isZero(n); } }

        //Antes de usar, asegurarse que n!=0
        protected double a { get { return -m / n; } }
        protected double b { get { return -k / n; } }

        public static bool isParallel(line2d l1, line2d l2)
        {
            if (l1.isVertical && l2.isVertical)
                return true;

            if (l1.isVertical || l2.isVertical)
                return false;

            return fCalc.isZero(l1.a - l2.a);
        }

        public bool isParallel(line2d l)
        {
            return isParallel(l, this);
        }

        public static PointF intesection(line2d l1, line2d l2)
        {
            if (line2d.isParallel(l1, l2)) return new PointF(float.NaN, float.NaN);

            line2d l=null, lv=null;
            double x=0,y,a,b;
            
            if (l1.isVertical)
            {
                lv = l1;
                l = l2;
                x = 1;
            }
            else if (l2.isVertical)
            {
                lv = l2;
                l = l1;
                x = 1;
            }
            

            if (x==1)
            {
                x = -1 / lv.m;
                y = l.a * x + l.b;

                return new PointF((float)x, (float)y); 
            }
            
            a = l1.a;
            b = l1.b;

            x = -(b - l2.b) / (a - l2.a);
            y = a * x + b;

            return new PointF((float)x, (float)y);
        }

        public PointF intesection(line2d l)
        {
            return intesection(l, this);
        }

        
    }

    public class segment2d : line2d
    {
        private PointF pt1, pt2;
        public segment2d()
            : base() { }

        public segment2d(PointF ipoint, PointF fpoint)
            : base(ipoint, fpoint)
        {
            pt1 = ipoint;
            pt2 = fpoint;
        }

        public PointF p1 { get { return pt1; } }
        public PointF p2 { get { return pt2; } }


        /// <summary>
        /// Determina si el punto p esta sobre el segmento
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public bool isPointOnSegment(PointF p)
        {
            if (!this.isPointOnLine(p))
                return false;

            double x1, x2, y1, y2;

            x1 = Math.Min(p1.X, p2.X);
            x2 = Math.Max(p1.X, p2.X);
            y1 = Math.Min(p1.Y, p2.Y);
            y2 = Math.Max(p1.Y, p2.Y);

            return
                fCalc.aMAYOR_IGUALb(p.X, x1) && fCalc.aMENOR_IGUALb(p.X, x2) &&
                fCalc.aMAYOR_IGUALb(p.Y, y1) && fCalc.aMENOR_IGUALb(p.Y, y2)
                ;
        }

        public line2d line { get { return (line2d)this; } }
        
    }
}


/*public void RunOnce()
        {
            line2d l2 = new line2d(1, 0);
            line2d l1 = new line2d(new PointF(1,1), new PointF(0,0));

            ml.tell("Las rectas " + (l1.isParallel(l2) ? "si" : "no") + " son parallelas");
            ml.tell("Las rectas se cortan en (x;y) = " + l1.intesection(l2).ToString());
            ml.tell("Las rectas " + (l1 != l2 ? "no" : "si") + " son iguales");
        }
*/