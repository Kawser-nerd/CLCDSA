﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GCJ2015Round2_2
{
	public class Neighbours<T> : IEnumerable<T>
	{
		#region Fields

		private T[][] m_Board;
		private int m_X;
		private int m_Y;
		private T m_Default;

		#endregion

		#region C'tor

		public Neighbours(T[][] board, int x, int y, T defaultValue = default(T))
		{
			this.m_Board = board;
			this.m_X = x;
			this.m_Y = y;
			this.m_Default = defaultValue;
		}

		#endregion

		#region Properties

		public T Left
		{
			get
			{
				if (!HasLeft)
				{
					return m_Default;
				}

				return m_Board[m_X - 1][m_Y];
			}
			set
			{
				if (!HasLeft)
					return;
				m_Board[m_X - 1][m_Y] = value;
			}
		}
		public bool HasLeft
		{
			get
			{
				return m_X > 0;
			}
		}

		public T Right
		{
			get
			{
				if (!HasRight)
				{
					return m_Default;
				}

				return m_Board[m_X + 1][m_Y];
			}
			set
			{
				if (!HasRight)
					return;
				m_Board[m_X + 1][m_Y] = value;
			}
		}
		public bool HasRight
		{
			get
			{
				return m_X < m_Board.Length - 1;
			}
		}

		public T Top
		{
			get
			{
				if (!HasTop)
				{
					return m_Default;
				}

				return m_Board[m_X][m_Y + 1];
			}
			set
			{
				if (!HasTop)
					return;
				m_Board[m_X][m_Y + 1] = value;
			}
		}
		public bool HasTop
		{
			get
			{
				return m_Y < m_Board[m_X].Length - 1;
			}
		}

		public T Bottom
		{
			get
			{
				if (!HasBottom)
				{
					return m_Default;
				}

				return m_Board[m_X][m_Y - 1];
			}
			set
			{
				if (!HasBottom)
					return;
				m_Board[m_X][m_Y - 1] = value;
			}
		}

		public bool HasBottom
		{
			get
			{
				return m_Y > 0;
			}
		}

		public T TopLeft
		{
			get
			{
				if (!HasTopLeft)
				{
					return m_Default;
				}

				return m_Board[m_X - 1][m_Y + 1];
			}
			set
			{
				if (!HasTopLeft)
					return;
				m_Board[m_X - 1][m_Y + 1] = value;
			}
		}

		public bool HasTopLeft
		{
			get
			{
				return HasTop && HasLeft;
			}
		}

		public T TopRight
		{
			get
			{
				if (!HasTopRight)
				{
					return m_Default;
				}

				return m_Board[m_X + 1][m_Y + 1];
			}
			set
			{
				if (!HasTopRight)
					return;
				m_Board[m_X + 1][m_Y + 1] = value;
			}
		}

		public bool HasTopRight
		{
			get
			{
				return HasTop && HasRight;
			}
		}

		public T BottomRight
		{
			get
			{
				if (!HasBottomRight)
				{
					return m_Default;
				}

				return m_Board[m_X + 1][m_Y - 1];
			}
			set
			{
				if (!HasBottomRight)
					return;
				m_Board[m_X + 1][m_Y - 1] = value;
			}
		}

		public bool HasBottomRight
		{
			get
			{
				return HasBottom && HasRight;
			}
		}

		public T BottomLeft
		{
			get
			{
				if (!HasBottomLeft)
				{
					return m_Default;
				}

				return m_Board[m_X - 1][m_Y - 1];
			}
			set
			{
				if (!HasBottomLeft)
					return;
				m_Board[m_X - 1][m_Y - 1] = value;
			}
		}

		public bool HasBottomLeft
		{
			get
			{
				return HasBottom && HasLeft;
			}
		}

		#endregion

		public IEnumerator<T> GetEnumerator()
		{
			if (HasTopLeft)
				yield return TopLeft;
			if (HasTop)
				yield return Top;
			if (HasTopRight)
				yield return TopRight;
			if (HasRight)
				yield return Right;
			if (HasBottomRight)
				yield return BottomRight;
			if (HasBottom)
				yield return Bottom;
			if (HasBottomLeft)
				yield return BottomLeft;
			if (HasLeft)
				yield return Left;
		}

		System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}
	}
}
