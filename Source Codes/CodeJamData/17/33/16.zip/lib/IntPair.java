package lib;

import java.util.Arrays;

public class IntPair {

    public final int v1, v2;

    public IntPair(int v1, int v2) {
        this.v1 = v1;
        this.v2 = v2;
    }

    @Override
    public String toString() {
        return Arrays.asList(v1, v2).toString();
    }
}
