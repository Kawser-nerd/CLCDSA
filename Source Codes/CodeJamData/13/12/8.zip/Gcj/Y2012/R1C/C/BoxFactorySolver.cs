﻿using System;
using System.Collections;
using System.Globalization;
using System.Linq;
using System.Collections.Generic;
using Cmn.Util;
using Gcj.Util;

namespace Gcj.Y2012.R1C.C
{
    public class BoxFactorySolver : IConcurrentSolver
    {
      
        public int CCaseGet(Pparser pparser)
        {
            return pparser.Fetch<int>();
        }

        public ConcurrentGcjSolver.DgSolveCase DgSolveCase(Pparser pparser)
        {
            /*
             * Each test case begins with a line contains two integers N and M. 
             * It is followed by a line containing 2 * N integers a1, A1, a2, A2, ..., aN, AN, 
             * and another line containing 2 * M integers b1, B1, b2, B2, ..., bM, BM.
             *
             *  This means that the first assembly line will make a1 boxes of type A1, then a2 boxes of type A2,
             *  etc., until it finishes with aN boxes of type AN. Similarly, the second assembly will make b1 
             *  toys of type B1, followed by b2 toys of type B2, etc., until it finishes with bM toys of type BM.
             *  
             * A toy can be matched with a box if and only if they have the same type number.*/
            int ctbox, cttoy;
            pparser.Fetch(out ctbox, out cttoy);


            var facs = new Facs(new Facl(pparser.Fetch<long[]>()), new Facl(pparser.Fetch<long[]>()));
            return () => EnobjSolveCase("{0} {1}".StFormat(ctbox, cttoy), facs);
        }

        //factory line
        protected class Facl
        {
            public readonly long[] rgcUtem;
            public readonly long[] rgt;

            public Facl(long[] rgxxx)
            {
                var rgcUtemT = new List<long>();
                var rgtT = new List<long>();
                long tPrev = -1;
                for (long i = 0; i < rgxxx.Length / 2; i++)
                {
                    var iutem = rgxxx[2*i];
                    var t = rgxxx[2*i + 1];
                    if(t == tPrev)
                    {
                        rgcUtemT[rgcUtemT.Count - 1] += iutem;
                    }
                    else
                    {
                        rgcUtemT.Add(iutem);
                        rgtT.Add(t);
                        tPrev = t;
                    }
                }

                this.rgcUtem = rgcUtemT.ToArray();
                this.rgt = rgtT.ToArray();
            }
        }

        //factory state
        protected class Facs
        {
            public readonly Facl faclBox;
            public readonly Facl faclToy;
            public readonly long iutemToy;  //ebben az ütemeben vagyunk
            public readonly long iutemBox;
            private readonly long cprocToy; //az aktuális ütemből ennyit dolgoztunk fel
            private readonly long cprocBox;

            public readonly long CPacked;

            public Facs(Facl faclBox, Facl faclToy)
            {
                this.faclBox = faclBox;
                this.faclToy = faclToy;
                this.CPacked = CPacked;
            }

            private Facs(Facl faclBox, Facl faclToy, long iutemToy, long iutemBox, long cprocToy, long cprocBox, long cPacked)
            {
                this.faclBox = faclBox;
                this.faclToy = faclToy;
                this.iutemToy = iutemToy;
                this.iutemBox = iutemBox;
                this.cprocToy = cprocToy;
                this.cprocBox = cprocBox;
                this.CPacked = cPacked;
            }
            public bool FDone()
            {
                return FDoneToy() && FDoneBox();
            }
            public bool FDoneToy()
            {
                return faclToy.rgcUtem.Length == iutemToy;
            }

            public bool FDoneBox()
            {
                return faclBox.rgcUtem.Length == iutemBox;
            }

            public long TToyCurrent()
            {
                return faclToy.rgt[iutemToy];
            }

            public long TBoxCurrent()
            {
                return faclBox.rgt[iutemBox];
            }

            public long CAllRemainingToy()
            {
                var c = CRemainingToy();
                for (var i = iutemToy + 1; i < faclToy.rgcUtem.Length; i++)
                    c += faclToy.rgcUtem[i];
                return c;
            }

            public long CAllRemainingBox()
            {
                var c = CRemainingBox();
                for (var i = iutemBox + 1; i < faclBox.rgcUtem.Length; i++)
                    c += faclBox.rgcUtem[i];
                return c;
            }

            public long CRemainingToy()
            {
                return faclToy.rgcUtem[iutemToy] - cprocToy;
            }

            public long CRemainingBox()
            {
                return faclBox.rgcUtem[iutemBox] - cprocBox;
            }

            public bool FContainsBoxFor(long iboxStart, long t)
            {
                return FContainsT(faclBox, iboxStart, t);
            }

            public bool FContainsToyFor(long itoyStart, long t)
            {
                return FContainsT(faclToy, itoyStart, t);
            }

            private static bool FContainsT(Facl facl, long iutem, long t)
            {
                for (long i = iutem; i < facl.rgcUtem.Length; i++)
                    if (facl.rgt[i] == t)
                        return true;
                return false;
            }

            public Facs AdvanceToy(long cAmount)
            {
                var iutemToyNew = iutemToy;
                var cprocToyNew = cprocToy;

                Advance(cAmount, faclToy, ref iutemToyNew, ref cprocToyNew);
                return new Facs(faclBox, faclToy, iutemToyNew, iutemBox, cprocToyNew, cprocBox, CPacked);
            }

            public Facs AdvanceBox(long cAmount)
            {
                var iutemBoxNew = iutemBox;
                var cprocBoxNew = cprocBox;

                Advance(cAmount, faclBox, ref iutemBoxNew, ref cprocBoxNew);
                return new Facs(faclBox, faclToy, iutemToy, iutemBoxNew, cprocToy, cprocBoxNew, CPacked);
            }

            private static void Advance(long cAmount, Facl facl, ref long iutem, ref long cproc)
            {
                //amíg nem fér bele ebbe az ütembe
                while (iutem< facl.rgcUtem.Length && cproc + cAmount >= facl.rgcUtem[iutem])
                {
                    cAmount -= facl.rgcUtem[iutem] - cproc;
                    cproc = 0;
                    iutem++;
                }

                cproc += cAmount;

                if (iutem == facl.rgcUtem.Length && cproc != 0)
                    throw new Exception("kimentünk");
            }

            public bool Equals(Facs other)
            {
                if (ReferenceEquals(null, other)) return false;
                if (ReferenceEquals(this, other)) return true;
                return other.iutemToy == iutemToy && other.iutemBox == iutemBox && other.cprocToy == cprocToy && other.cprocBox == cprocBox;
            }

            public override bool Equals(object obj)
            {
                if (ReferenceEquals(null, obj)) return false;
                if (ReferenceEquals(this, obj)) return true;
                if (obj.GetType() != typeof (Facs)) return false;
                return Equals((Facs) obj);
            }

            public override int GetHashCode()
            {
                unchecked
                {
                    long result = iutemToy;
                    result = (result*397) ^ iutemBox;
                    result = (result*397) ^ cprocToy;
                    result = (result*397) ^ cprocBox;
                    return (int) result;
                }
            }

            public Facs Pack(long cAmount)
            {
                Facs facs = AdvanceBox(cAmount).AdvanceToy(cAmount);
                return new Facs(facs.faclBox, facs.faclToy, facs.iutemToy, facs.iutemBox, facs.cprocToy, facs.cprocBox,
                                CPacked + cAmount);
            }


            public IEnumerable<Tuple<long, long>>  EnTAndCToyRemaining()
            {
                return EnTAndCRemaining(faclToy, iutemToy, cprocToy);
            }

            public IEnumerable<Tuple<long, long>> EnTAndCBoxRemaining()
            {
                return EnTAndCRemaining(faclBox, iutemBox, cprocBox);
            }

            private IEnumerable<Tuple<long, long>> EnTAndCRemaining(Facl facl, long iutem, long cproc)
            {
                while(iutem<facl.rgcUtem.Length)
                {
                    yield return new Tuple<long, long>(facl.rgt[iutem], facl.rgcUtem[iutem] - cproc);
                    cproc = 0;
                    iutem++;
                }
                
            }

            public int CutemToy()
            {
                return faclToy.rgcUtem.Length;
            }

            public int CutemBox()
            {
                return faclBox.rgcUtem.Length;
            }
        }


        class Heap<T>
        {

            new SortedDictionary<long, Queue<T>> mp = new SortedDictionary<long, Queue<T>>();

            public Heap()
            {
            }

            public void Insert(T t, long w)
            {
                if(!mp.ContainsKey(w))
                    mp[w] = new Queue<T>();
                mp[w].Enqueue(t);
            }

            public void Clear()
            {
                mp.Clear();
            }
            public long WMin()
            {
                return mp.First().Key;
            }
            public T TMin()
            {
                return mp.First().Value.First();
            }
            public bool Any()
            {
                return mp.Any();
            }
            public void RemoveMin()
            {
                var kvp = mp.First();
                if(kvp.Value.Count == 1)
                    mp.Remove(kvp.Key);
                else
                    kvp.Value.Dequeue();
            }
        }

        protected IEnumerable<object> EnobjSolveCase(String st, Facs facs)
        {
            Console.Write (st+": ");
            var heapCurrent = new Heap<Facs>();
            var hlmSeen = new Dictionary<Facs, long>();
            heapCurrent.Insert(facs, 0);
            hlmSeen[facs] = 0;

            long[,] mph = FillMph(facs);
            

            while (heapCurrent.Any())
            {
                var facsCurrent = heapCurrent.TMin();
                var wCurrent = hlmSeen[facsCurrent];

                heapCurrent.RemoveMin();

                if(facsCurrent.FDone())
                {
                    Console.WriteLine(facsCurrent.CPacked);
                    yield return facsCurrent.CPacked;
                    yield break;
                    
                }
                
                //innen tovább:
                foreach (var kvpfacsAnddist in EnkvpfacsAnddistNext(facsCurrent))
                {

                    var facsNext = kvpfacsAnddist.Key;
                    var dist = kvpfacsAnddist.Value;

                    long h = 0;
                    if(facsNext.iutemBox<facsNext.CutemBox()-1 && facsNext.iutemToy < facsNext.CutemToy()-1)
                        h = mph[facsNext.iutemToy+1, facsNext.iutemBox+1];
                   
                    if(!hlmSeen.ContainsKey(facsNext) || hlmSeen[facsNext] > dist + wCurrent)
                    {
                        hlmSeen[facsNext] = dist + wCurrent;
                        heapCurrent.Insert(facsNext, dist + wCurrent + h);
                    }
                }
            }
        }

        private long[,] FillMph(Facs facs)
        {
            var ctoy = facs.CutemToy();
            var cbox = facs.CutemBox();
            var mph = new long[ctoy, cbox];
            for (int i = 0; i < ctoy; i++)
            for (int j = 0; j < cbox; j++)
                    mph[i, j] = -1;
            FillMph(facs, mph, 0, 0);
            return mph;
        }

        private void FillMph(Facs facs, long[,] mph, int itoy, int ibox)
        {
            if (itoy >= facs.CutemToy())
                return;
            if (ibox >= facs.CutemBox())
                return;
            if(mph[itoy, ibox] != -1)
                return;

          
            FillMph(facs, mph, itoy + 1, ibox);
            FillMph(facs, mph, itoy, ibox + 1);

            mph[itoy, ibox] = 0;
            if(itoy< facs.CutemToy()-1 && ibox<facs.CutemBox()-1)
            {
                mph[itoy, ibox] = mph[itoy + 1, ibox] + mph[itoy, ibox+1] - mph[itoy+1, ibox+1];
                if (facs.faclBox.rgt[ibox] != facs.faclToy.rgt[itoy])
                    mph[itoy, ibox] += facs.faclBox.rgcUtem[ibox] + facs.faclToy.rgcUtem[itoy];
            }
                

            if(ibox< facs.CutemBox()-1) 
                mph[itoy, ibox] = mph[itoy, ibox+1];

            if(!facs.FContainsToyFor(itoy, facs.faclBox.rgcUtem[ibox]))
                mph[itoy, ibox] += facs.faclBox.rgcUtem[ibox];

            if (!facs.FContainsBoxFor(ibox, facs.faclToy.rgcUtem[itoy]))
                mph[itoy, ibox] += facs.faclToy.rgcUtem[itoy];
        }
        private IEnumerable<KeyValuePair<Facs, long>> Filter1(IEnumerable<KeyValuePair<Facs, long>> enkvp)
        {
            foreach (var kvp in enkvp)
            {
                var facsNext = kvp.Key;
                var dist = kvp.Value;

                    while (!facsNext.FDoneBox() && !facsNext.FDoneToy() && !facsNext.FContainsToyFor(facsNext.iutemToy, facsNext.TBoxCurrent()))
                    {
                        var cThrowAway = facsNext.CRemainingBox();
                        facsNext = facsNext.AdvanceBox(cThrowAway);
                        dist += cThrowAway;
                    }
                    while (!facsNext.FDoneBox() && !facsNext.FDoneToy() && !facsNext.FContainsBoxFor(facsNext.iutemBox, facsNext.TToyCurrent()))
                    {
                          
                        var cThrowAway = facsNext.CRemainingToy();
                        facsNext = facsNext.AdvanceToy(cThrowAway);
                        dist += cThrowAway;

                    }

                
                yield return new KeyValuePair<Facs, long>(facsNext, dist);
            }
        }
        private IEnumerable<KeyValuePair<Facs, long>> EnkvpfacsAnddistNext(Facs facs)
        {
            if (facs.FDoneBox())
            {
                var cThrowAway = facs.CAllRemainingToy();
                yield return new KeyValuePair<Facs, long>(facs.AdvanceToy(cThrowAway), cThrowAway);
                yield break;
                
            }

            if (facs.FDoneToy())
            {
                var cThrowAway = facs.CAllRemainingBox();
                yield return new KeyValuePair<Facs, long>(facs.AdvanceBox(cThrowAway), cThrowAway);
                yield break;
                
            }


            if (facs.TBoxCurrent() == facs.TToyCurrent())
                yield return new KeyValuePair<Facs, long>(facs.Pack(Math.Min(facs.CRemainingBox(), facs.CRemainingToy())), 0);

           
            {
                var cThrowAway = facs.CRemainingBox();
                yield return new KeyValuePair<Facs, long>(facs.AdvanceBox(cThrowAway), cThrowAway);
            }

          
            {
                var cThrowAway = facs.CRemainingToy();
                yield return new KeyValuePair<Facs, long>(facs.AdvanceToy(cThrowAway), cThrowAway);
            }

        }
    }
}
