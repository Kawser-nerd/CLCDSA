/********************************** INCLUDES **********************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "inout.h"


/******************************* PRIVATE MACROS *******************************/
//#define DBG_ENABLE

#ifdef DBG_ENABLE
#define DBG_PRINTF(...)      printf(__VA_ARGS__)
#else
#define DBG_PRINTF(...)      do{}while(0);
#endif

#define NUM_OF_ARGUMENT         3
#define IN_FILE_NAME_INDEX      1
#define OUT_FILE_NAME_INDEX     2

#define max(a,b)                        \
    (                                   \
        {                               \
            __typeof__ (a) _a = (a);    \
            __typeof__ (b) _b = (b);    \
            _a > _b ? _a : _b;          \
        }                               \
    )

#define min(a,b)                        \
    (                                   \
        {                               \
            __typeof__ (a) _a = (a);    \
            __typeof__ (b) _b = (b);    \
            _a < _b ? _a : _b;          \
        }                               \
    )

#define MAX_CHAR_LEN        100

/******************************** PRIVATE TYPES *******************************/


/*********************** PRIVATE FUNCTIONS DECLARATIONS ***********************/


/*********************** PRIVATE (GLBL) DATA DEFINITIONS **********************/


/*************************** PUBLIC DATA DEFINITIONS **************************/


/************************ PRIVATE FUNCTIONS DEFINITIONS ***********************/


/************************* PUBLIC FUNCTION DEFINITIONS ************************/
void addCar(char** cars, int n, bool* used, char* carSet, int connected, int* ways, int index)
{
    char (*p)[MAX_CHAR_LEN+1] = cars;
    int len = strlen(carSet);
    
    strcat(carSet, &p[index][0]);
    used[index] = true;
    connected += 1;
    
    if (connected == n)
    {
        // the end, it needs to check
        int i = 0;
        bool alphaFound[26];
        bool possible = true;
        
        memset(alphaFound, 0, sizeof(bool)*26);

        DBG_PRINTF("Check carSet=%s\n", carSet);

        while(carSet[i])
        {
            int alphaIndex = carSet[i] - 'a';
            if (alphaFound[alphaIndex])
            {
                if (carSet[i-1] != carSet[i])
                    possible = false;
            }
            else
            {
                alphaFound[alphaIndex] = true;
            }
            i += 1;
        }
        if (possible)
        {
            *ways += 1;
            DBG_PRINTF("possible ways=%d\n", *ways);
        }
    }
    else
    {
        int i;
        for (i=0; i<n; i++)
        {
            if (!used[i])
            {
                addCar(cars, n, used, carSet, connected, ways, i);
            }
        }
    }
    
    // resume carSet
    carSet[len] = 0;
    used[index] = false;
}


void processAllTestCase(FILE* inFile, FILE* outFile)
{
    int numOfTestCase;
    int i,j;
    long long result = 0;
    int n;
    char cars[100][MAX_CHAR_LEN+1];
    bool used[100];
    char carSet[100*MAX_CHAR_LEN+1];
    int setLen;

    readNumStrFromFileToInt(inFile, &numOfTestCase);
    
    //Process all test cases
    for (i=0; i<numOfTestCase; i++)
    {
        //Process a test case
        readNumStrFromFileToInt(inFile, &n);
        
        memset(used, 0, sizeof(bool)*n);
        
        for (j=0; j<n; j++)
        {
            readNumStrFromFileToCharArray(inFile, &cars[j][0], MAX_CHAR_LEN+1);
        }
        
#ifdef DBG_ENABLE
        DBG_PRINTF("case %d n=%d\n", i+1,n);
        for (j=0; j<n; j++)
        {
            DBG_PRINTF("car %d, %s\n", j+1, &cars[j][0]);
        }
#endif

        setLen = 0;
        result = 0;
        carSet[0] = 0;
                
        for (j=0; j<n; j++)
        {
            addCar(cars, n, used, carSet, 0, &result, j);
        }

        //Output Result, case num start from 1
        outputCaseIntResult(outFile, i+1, result);
    }
}

/* program in_file_name out_file_name */
int main( int argc, const char* argv[] )
{
    int i;
    FILE* inFile;
    FILE* outFile;

    DBG_PRINTF( "argc=%d\n", argc );
    if (argc != NUM_OF_ARGUMENT) {
        printf("Not enough Argument!!\ne.g. argv[0] <in_file_name> <out_file_name>\n");
        return 1;
    }
    
    for (i=0; i<argc; i++) {
        DBG_PRINTF("%s\n", argv[i]);
    }
    
    inFile = fopen(argv[IN_FILE_NAME_INDEX], "r");
    if ( inFile == NULL) {
        printf("Can't open input file %s\n", argv[IN_FILE_NAME_INDEX]);
        return 1;
    }
    
    outFile = fopen(argv[OUT_FILE_NAME_INDEX], "w");
    if ( outFile == NULL) {
        printf("Can't open output file %s\n", argv[OUT_FILE_NAME_INDEX]);
        return 1;
    }

    processAllTestCase(inFile, outFile);
   
    fclose(inFile);
    fclose(outFile);
    
    return 0;
}
