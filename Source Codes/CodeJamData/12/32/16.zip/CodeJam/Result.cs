﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    class Result
    {
        private string _result;

        public int ProblemIndex { get; set; }
        public string Output { 
            get { return string.Format("Case #{0}:" + Environment.NewLine + "{1}", ProblemIndex + 1, _result.Trim()); }
            set { _result = value; } 
        }
    }
}
