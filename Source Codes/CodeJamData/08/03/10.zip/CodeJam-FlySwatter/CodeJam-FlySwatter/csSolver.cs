﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam_FlySwatter
{
    class csSolver
    {

        private static double Area(double RectX, double RectY, double RectW, double CircleRadius)
        {
            //if encapsulated
            if (Math.Pow(RectX + RectW, 2) + Math.Pow(RectY + RectW, 2) <= Math.Pow(CircleRadius, 2))
                return RectW * RectW;

            //if outside
            if (Math.Pow(RectX,2) + Math.Pow(RectY,2) >= Math.Pow(CircleRadius,2)) 
                return 0;

            //cross lower corner
            if (Math.Pow(RectY + RectW, 2) >= Math.Pow(CircleRadius, 2) - Math.Pow(RectX, 2))
                if (Math.Pow(RectX + RectW, 2) >= Math.Pow(CircleRadius, 2) - Math.Pow(RectY, 2))
                {
                    double Y2 = Math.Sqrt(Math.Pow(CircleRadius, 2) - Math.Pow(RectX, 2));
                    double X2 = Math.Sqrt(Math.Pow(CircleRadius, 2) - Math.Pow(RectY, 2));

                    double A1 = Math.Atan(RectY / X2);
                    double A2 = Math.Atan(Y2 / RectX);

                    double AreaOfSector = 0.5 * CircleRadius * CircleRadius * (A2 - A1);
                    double AreaOfTriangles = 0.5 * (Y2 - RectY) * RectX + 0.5 * (X2 - RectX) * RectY;

                    return AreaOfSector - AreaOfTriangles;
                }

            //cross upper corner
            if (Math.Pow(RectY, 2) <= Math.Pow(CircleRadius, 2) - Math.Pow(RectX+RectW, 2))
                if (Math.Pow(RectX, 2) <= Math.Pow(CircleRadius, 2) - Math.Pow(RectY + RectW, 2))
                {
                    double Y2 = Math.Sqrt(Math.Pow(CircleRadius, 2) - Math.Pow(RectX + RectW, 2));
                    double X2 = Math.Sqrt(Math.Pow(CircleRadius, 2) - Math.Pow(RectY + RectW, 2));

                    double A1 = Math.Atan(Y2 / (RectX + RectW));
                    double A2 = Math.Atan((RectY + RectW) / X2);

                    double AreaOfSector = 0.5 * CircleRadius * CircleRadius * (A2 - A1);
                    double AreaOfTriangles = 0.5 * (RectY + RectW - Y2) * X2 + 0.5 * (RectX + RectW - X2) * Y2;

                    double ExcludedArea = (RectX + RectW - X2) * (RectY + RectW - Y2) - AreaOfSector + AreaOfTriangles;

                    return RectW * RectW -ExcludedArea;
                }

            //cross horizontal sides
            if (Math.Pow(RectX + RectW, 2) >= Math.Pow(CircleRadius, 2) - Math.Pow(RectY, 2))
                if (Math.Pow(RectX, 2) <= Math.Pow(CircleRadius, 2) - Math.Pow(RectY + RectW, 2))
                {
                    double X2L = Math.Sqrt(Math.Pow(CircleRadius, 2) - Math.Pow(RectY, 2));
                    double X2U = Math.Sqrt(Math.Pow(CircleRadius, 2) - Math.Pow(RectY + RectW, 2));

                    double A1 = Math.Atan(RectY / X2L);
                    double A2 = Math.Atan((RectY+RectW)/X2U);

                    double AreaOfSector = 0.5 * CircleRadius * CircleRadius * (A2 - A1);
                    double AreaOfTriangles = 0.5 * (X2L - X2U) * RectY + 0.5 * RectW * X2U;

                    return AreaOfSector - AreaOfTriangles + RectW * (X2U - RectX);
                }



            //cross vertical sides
            if (Math.Pow(RectY + RectW, 2) >= Math.Pow(CircleRadius, 2) - Math.Pow(RectX, 2))
                if (Math.Pow(RectY, 2) <= Math.Pow(CircleRadius, 2) - Math.Pow(RectX + RectW, 2))
                {
                    double Y2L = Math.Sqrt(Math.Pow(CircleRadius, 2) - Math.Pow(RectX, 2));
                    double Y2R = Math.Sqrt(Math.Pow(CircleRadius, 2) - Math.Pow(RectX + RectW, 2));

                    double A1 = Math.Atan(Y2R / (RectX+RectW));
                    double A2 = Math.Atan(Y2L / RectX);

                    double AreaOfSector = 0.5 * CircleRadius * CircleRadius * (A2 - A1);
                    double AreaOfTriangles = 0.5 * (Y2L - Y2R) * RectX + 0.5 * RectW * Y2R;

                    return AreaOfSector - AreaOfTriangles + RectW * (Y2R - RectY);
                }

            return 0;
        }

        public static double Solve(csTestCase Case)
        {
            if (Case.gp <= 0) return 1;
            double TotalArea = 0;
            int limit = (int)Math.Floor((Case.Rp - Case.rp) / (Case.gp + 2 * Case.rp));
            for (int i = 0; i <= limit; i++)
                for (int j = 0; j <= limit; j++)
                {
                    TotalArea += Area(Case.rp + (2 * Case.rp + Case.gp) * i, Case.rp + (2 * Case.rp + Case.gp) * j, Case.gp, Case.Rp);
                }

            return 1 - TotalArea * 4 / (Math.PI * Case.R * Case.R);
        }
    }
}
