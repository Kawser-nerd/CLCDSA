﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    interface ISolution
    {
        int GetProblem(int problemIndex, int startIndex, string[] data);
        Result ProcessProblem();
    }
}
