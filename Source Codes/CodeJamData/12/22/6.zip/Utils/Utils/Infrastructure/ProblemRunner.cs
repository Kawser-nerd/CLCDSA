﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Utils.Infrastructure {
    public class ProblemRunner {
        IProblem problem;
        IProblemReader reader;
        IProblemWriter writer;
        
        public ProblemRunner(IProblem problem, IProblemReader reader, IProblemWriter writer) {
            this.problem = problem;
            this.reader = reader;
            this.writer = writer;
        }
        public void Run() {            
            problem.Initialize(reader, writer);
            int count = problem.GetProblemsCount();            
            for (int i = 0; i < count; i++) {
                IProblemSolver solver = problem.GetNextProblemSolver();
                object result = solver.Solve();
                writer.BeginCase(i + 1);
                writer.WriteResult(result.ToString());
                writer.EndCase();                    
            }
            reader.Close();
            writer.Close();
        }
        
    }


}
