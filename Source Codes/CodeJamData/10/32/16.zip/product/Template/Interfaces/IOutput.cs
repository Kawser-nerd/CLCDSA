namespace Template.Interfaces
{
  public interface IOutput
  {
    void Close();
    void WriteLine(string value);
  }
}