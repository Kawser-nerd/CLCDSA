import sys

class TestCase:
    """A class meant to be overwritten by a test case for a specific test."""

    def __init__(self, file):
        self.parseTestCase(file)

    def parseTestCase(self, file):
        """Classes should over write this method."""
        pass

class GoogleProblem:
    """Parse and run a solver on a google test case."""

    def __init__(self, inputFilename=None,
                 outputFilename=None,
                 testcaseClass=None):
        """inputFilename should be the name of the file with the test cases. If inputFilename is not given, use sys.argv[1].

outputFilename should be the name of file into which to write the output. If outputFilename is not given, use inputFilename with a ".in" suffix translated to ".out".

testcaseClass should be the class used to parse each test case."""
        assert(testcaseClass is not None)
        self.testcaseClass = testcaseClass
        if inputFilename is None:
            try:
                inputFilename = sys.argv[1]
            except:
                raise Exception("Missing input filename on commandline.")
        self.inputFilename = inputFilename
        self.inputFile = open(inputFilename)
        if outputFilename is None:
            outputFilename = self._openOutputFilename(inputFilename)
        self.outputFile = self._openOutputFile(outputFilename)
        self.numCases = self._readNumCases()

    def solve(self, solver):
        """Solve test cases.

        solver should be a function that takes an TestCase object as input and returns a string that is the solution to the test case."""

        assert(solver is not None)
        for caseNum in range(self.numCases):
            self.debug("Working on case #%d" % (caseNum + 1))
            testcase = self.testcaseClass(self.inputFile)
            solution = str(solver(testcase))
            self.debug("Case #%d: %s" % (caseNum + 1, solution))
            self._writeOutput("Case #%d: %s" % (caseNum + 1, solution))

    def _openOutputFilename(self, inputFilename):
        outputFilename = inputFilename
        if outputFilename.endswith(".in"):
            outputFilename = outputFilename[:-3]
        outputFilename += ".out"
        return outputFilename

    def _openOutputFile(self, outputFilename):
        self.debug("Writing output to %s" % outputFilename)
        outputFile = open(outputFilename, "w")
        return outputFile
    
    def _writeOutput(self, msg):
        msg.rstrip()
        self.outputFile.write(msg + "\n")
        self.outputFile.flush()

    def _readNumCases(self):
        try:
            numCaseStr = self.inputFile.readline()
            numCases = int(numCaseStr)
        except Exception, e:
            raise Exception("Error reading number of cases from %s: %s" % (
                    self.inputFilename, e))
        return numCases

    def _readCase(self):
        return self._readlineTokens()

    def _readlineTokens(self):
        return self.inputFile.readline().split()

    def debug(self, msg):
        msg.rstrip()
        sys.stderr.write(msg + "\n")
