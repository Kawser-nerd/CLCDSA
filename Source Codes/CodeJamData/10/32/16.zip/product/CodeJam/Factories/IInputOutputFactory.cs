using Template.Interfaces;

namespace CodeJam.Factories
{
  public interface IInputOutputFactory
  {
    IInput CreateInput();
    IOutput CreateOutput();
  }
}