/********************************** INCLUDES **********************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "inout.h"


/******************************* PRIVATE MACROS *******************************/
//#define DBG_ENABLE

#ifdef DBG_ENABLE
#define DBG_PRINTF(...)      printf(__VA_ARGS__)
#else
#define DBG_PRINTF(...)      do{}while(0);
#endif

#define NUM_OF_ARGUMENT         3
#define IN_FILE_NAME_INDEX      1
#define OUT_FILE_NAME_INDEX     2

#define max(a,b) \
    ({ __typeof__ (a) _a = (a); \
    __typeof__ (b) _b = (b); \
    _a > _b ? _a : _b; })

#define min(a,b) \
    ({ __typeof__ (a) _a = (a); \
    __typeof__ (b) _b = (b); \
    _a < _b ? _a : _b; })


/******************************** PRIVATE TYPES *******************************/


/*********************** PRIVATE FUNCTIONS DECLARATIONS ***********************/


/*********************** PRIVATE (GLBL) DATA DEFINITIONS **********************/


/*************************** PUBLIC DATA DEFINITIONS **************************/


/************************ PRIVATE FUNCTIONS DEFINITIONS ***********************/
#ifdef DBG_ENABLE
static void printGraph(int** graph, int n)
{
    int (*p)[n] = graph;
    int i, j;
    
    for (i=0; i<n; i++)
    {
        for (j=0; j<n; j++)
        {
            DBG_PRINTF("%d", p[i][j]);
        }
        DBG_PRINTF("\n");
    }
    DBG_PRINTF("\n");
}
#endif

static int cmpAccending(const void * a, const void * b)
{
    int aa = *(int*)a;
    int bb = *(int*)b;
    if (aa < bb) return -1;
    if (aa > bb) return 1;
    return 0;
}

static int cmpDecending(const void * a, const void * b)
{
    int aa = *(int*)a;
    int bb = *(int*)b;
    if (aa < bb) return 1;
    if (aa > bb) return -1;
    return 0;
}

/************************* PUBLIC FUNCTION DEFINITIONS ************************/
int getNumConnected(int** graph, int n, int node)
{
    int (*p)[n] = graph;
    int i;
    int numConnected = 0;
    
    for (i=0; i<n; i++)
    {
        numConnected += p[node][i];
    }
    return numConnected;
}

//return number of node to delete
int traverse(int** graph, int n, int fromNode, int node, int* connected)
{
    int (*p)[n] = graph;
    int i;
    int numConnected = 0;
    int numNodeConnected[n];
//    int numNodeToDelete[n] = {0};
    int numNodeToDelete = 0;
    int result = 0;
    
    memset(numNodeConnected, 0, n*sizeof(int));
    
    for (i=0; i<n; i++)
    {
        if (i != fromNode && p[node][i])
        {
            numConnected += 1;
            numNodeToDelete += traverse(p, n, node, i, &numNodeConnected[i]);
        }
    }

    switch (numConnected)
    {
        case 0:
        //nothing to delete
        break;
        case 1:
        numNodeToDelete += 1;
        
        //need to delete the node
        for (i=0; i<n; i++)
        {
            if (numNodeConnected[i])
            {
                numNodeToDelete += numNodeConnected[i];
            }
        }
        break;
        case 2:
        //no need to delete
        *connected = 2;
        
        //count number of connected by this node
        for (i=0; i<n; i++)
        {
            if (numNodeConnected[i])
            {
                *connected += numNodeConnected[i];
            }
        }
        break;
        default:
        {
            int deleted = 0;
            
            //there's more than 2 node connected
            *connected = 2;
            numNodeToDelete += numConnected - 2;
        
            //sort num connected
            qsort(numNodeConnected, n, sizeof(numNodeConnected[0]), cmpDecending);
        
            for (i=0; i<numConnected; i++)
            {
                if (i<2)
                {
                    *connected += numNodeConnected[i];
                }
                else
                    numNodeToDelete += numNodeConnected[i];
            }
        }
    }
    
    return numNodeToDelete;
}

void processAllTestCase(FILE* inFile, FILE* outFile)
{
    int numOfTestCase;
    int i;
//    int result = 0;

    readNumStrFromFileToInt(inFile, &numOfTestCase);
    
    //Process all test cases
    for (i=0; i<numOfTestCase; i++)
    {
        int n;
        int minDelNodeNum;
        //Process a test case
        readNumStrFromFileToInt(inFile, &n);
        
        //set the max value
        minDelNodeNum = n-1;
        
        {
            int graph[n][n];
            int x;
            int y;
            int j;
            
            memset(graph, 0, n*n*sizeof(int));
            
            for (j=0; j<n-1; j++)
            {
                readNumStrFromFileToInt(inFile, &x);
                readNumStrFromFileToInt(inFile, &y);
                
                graph[min(x,y)-1][max(x, y)-1] = 1;
                graph[max(x,y)-1][min(x, y)-1] = 1;
            }
#ifdef DBG_ENABLE
            printGraph(graph, n);
#endif
            
            //find min node to delete
            for (j=0; j<n; j++)
            {
                int numConnected = getNumConnected(graph, n, j);
                
                if (numConnected > 1)
                {
                    int connected = 0;
                    int numNodeToDelete = traverse(graph, n, -1, j, &connected);
                
                    if (minDelNodeNum > numNodeToDelete)
                    {
                        minDelNodeNum = numNodeToDelete;
                    
                        if (minDelNodeNum == 0)
                            break;
                    }
                }
            }
        }
        
        //Output Result, case num start from 1
        outputCaseIntResult(outFile, i+1, minDelNodeNum);
    }
}

/* program in_file_name out_file_name */
int main( int argc, const char* argv[] )
{
    int i;
    FILE* inFile;
    FILE* outFile;

    DBG_PRINTF( "argc=%d\n", argc );
    if (argc != NUM_OF_ARGUMENT) {
        printf("Not enough Argument!!\ne.g. argv[0] <in_file_name> <out_file_name>\n");
        return 1;
    }
    
    for (i=0; i<argc; i++) {
        DBG_PRINTF("%s\n", argv[i]);
    }
    
    inFile = fopen(argv[IN_FILE_NAME_INDEX], "r");
    if ( inFile == NULL) {
        printf("Can't open input file %s\n", argv[IN_FILE_NAME_INDEX]);
        return 1;
    }
    
    outFile = fopen(argv[OUT_FILE_NAME_INDEX], "w");
    if ( outFile == NULL) {
        printf("Can't open output file %s\n", argv[OUT_FILE_NAME_INDEX]);
        return 1;
    }

    processAllTestCase(inFile, outFile);
   
    fclose(inFile);
    fclose(outFile);
    
    return 0;
}
