C# .NET 4.0 - compile all source files into a single executable.

As sample batch script for how to do this with csc.exe is in the file compile.bat