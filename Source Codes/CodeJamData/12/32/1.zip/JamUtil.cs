﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using Generic.Common;
using Generic.Containers.Collections.List;
using Generic.InputOutput.Printing.Sizable;

namespace Google_Code_Jam
{
    class JamUtil
    {
        static int indent;

        [Conditional("DEBUG")]
        public static void DebugConsole(bool condition, Document print)
        {
            if (condition)
                DebugConsole(print);
        }

        [Conditional("DEBUG")]
        public static void DebugConsole(Document print)
        {
            Debug.WriteLine(print.Indent(indent).Render(160));
        }

        [Conditional("DEBUG")]
        public static void Indent()
        {
            indent += 2;
        }

        [Conditional("DEBUG")]
        public static void Undent()
        {
            indent -= 2;
        }

        public static IList<double> ReadDoubles(StreamReader reader)
        {
            return ReadWords(reader).Select(s => double.Parse(s,CultureInfo.InvariantCulture)).ToIList();
        }

        public static IList<int> ReadInts(StreamReader reader)
        {
            return ReadWords(reader).Select(int.Parse).ToIList();
        }

        public static IList<long> ReadLongs(StreamReader reader)
        {
            return ReadWords(reader).Select(long.Parse).ToIList();
        }

        public static IList<string> ReadWords(StreamReader reader)
        {
            return reader.ReadLine().Split(' ');
        }
    }
}
