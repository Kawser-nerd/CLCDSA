﻿using System.IO;
using Generic.Maths.Vectors;

namespace Generic.InputOutput.Printing.Sized
{
    internal abstract class SizedDocument
    {
        public abstract void RenderLine(TextWriter builder, int line);
        public abstract IntVector2 Size { get; }

        public static readonly SizedDocument Empty = new SizedEmpty();

        public static SizedDocument operator +(SizedDocument left, SizedDocument right)
        {
            if (left is SizedEmpty)
                return right;
            if (right is SizedEmpty)
                return left;
            return new SizedLeftRight(left, right);
        }

        public static SizedDocument operator ^(SizedDocument top, SizedDocument bottom)
        {
            if (top is SizedEmpty)
                return bottom;
            if (bottom is SizedEmpty)
                return top;
            return new SizedTopBottom(top, bottom);
        }
    }
}
