namespace Template.Interfaces
{
  public interface IInput
  {
    void Close();
    string ReadLine();
    string[] SplitLine();
    int[] ParseInt();
  }
}