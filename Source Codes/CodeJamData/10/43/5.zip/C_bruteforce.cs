﻿/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    class C : ParallelSolution
    {
        struct Rect { 
            public Rect(int[] coords) : this() { X1 = coords[0]-1; Y1 = coords[1]-1; X2 = coords[2]; Y2 = coords[3]; }
            public int X1 { get; set; } public int X2 { get; set; } public int Y1 { get; set; } public int Y2 { get; set; }
            public bool Touches(Rect other)
            {
                if (other.X2 + 1 < X1)
                    return false;
                if (other.Y2 + 1 < Y1)
                    return false;
                if (X2 + 1 < other.X1)
                    return false;
                if (Y2 + 1 < Y1)
                    return false;
                return true;
            }
        }

        struct State
        {
            public int rectId { get; set; }
            public int minX { get; set; }
            public int minY { get; set; }
        }

        override public Func<String> StartSolving()
        {
            int R = ReadInt();

            Rect[] rects = Array.ConvertAll(ReadLines(R), line => new Rect(Array.ConvertAll(line.Trim().Split(' '), int.Parse)));

            return () =>
            {
                bool[,] field = new bool[100, 100];

                foreach(Rect r in rects)
                    for (int x = r.X1; x < r.X2; x++)
                        for (int y = r.Y1; y < r.Y2; y++)
                            field[x, y] = true;

                for (int step = 0; ; step++)
                {
                    bool[,] newField = new bool[100, 100];
                    bool empty = true;
                    for(int x=0;x<100;x++)
                        for (int y = 0; y < 100; y++)
                        {
                            if(field[x,y])
                                empty = false;
                            bool left = x != 0 && field[x - 1, y];
                            bool top = y != 0 && field[x, y-1];
                            newField[x,y] =
                                    !left&&!top ? false:
                                    (
                                    (left&&top) ? true :
                                    field[x,y]
                                    )
                                ;
                        }
                    field = newField;
                    if (empty)
                        return step.ToString();
                }
            };
        }
    }
}
