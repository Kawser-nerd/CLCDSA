package lib;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class FlattenVector {
    public static <T> Vector<T> create(Vector<T> src) {
        List<T> list = IntStream.range(0, src.n).mapToObj(src.element::at).collect(Collectors.toList());
        return new Vector<T>(src.n, list::get);
    }
}
