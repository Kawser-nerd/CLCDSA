﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class Brattleship : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            ProblemSet<Brattleship>.Solve(args);
        }
        #endregion

        public override void Parse(ProblemReader file)
        {
            file.Read(out R, out C, out W);
            mem = Enumerable.Repeat(-1, C+1).ToArray();
        }

        // ReSharper disable InconsistentNaming
        private int R, C, W;
        private int[] mem;
        // ReSharper restore InconsistentNaming

        public override object Solve()
        {
            var pre = (R - 1)*((C+2*W-2)/(2*W-1));
            return pre + SolveLast(C);
        }

        private int SolveLast(int c)
        {
            if (c < W) return int.MaxValue;
            if (c == W) return W;

            if (mem[c] == -1)
            {
                // guess W-1
                var miss = 1 + SolveLast(c - W);
                var hit = 1 + W;
                mem[c] = miss == int.MaxValue ? hit :  Math.Max(hit, miss);
            }

            return mem[c];
        }

        public override IEnumerable<Action> StaticInitialize()
        {
            yield return () =>
            {

            };
        }
    }
}
