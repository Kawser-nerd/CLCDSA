package lib;

public class ResidualNetwork {

    public static AdjacentListGetter of(AdjacentListGetter adj, GetterOnEdge residualGetter) {
        return (from, visitor) -> {
            adj.forEach(from, to -> {
                if (residualGetter.get(from, to) > 0)
                    visitor.accept(to);
            });
        };
    }

}
