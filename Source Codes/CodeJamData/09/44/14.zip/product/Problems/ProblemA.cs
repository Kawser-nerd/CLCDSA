﻿using System;
using System.Collections.Generic;
using CodeJamLibrary;
using CodeJamLibrary.Interfaces;

namespace Problems
{
  public class ProblemA : ProblemTemplate
  {
    protected override string Solve(IProblemInput problemInput)
    {
      int N = problemInput.ParseInt()[0];

      int[,] data = new int[N,N];

      for (int i = 0; i < N; i++)
      {
        var t = problemInput.ReadLine().ToCharArray();
        for (int j = 0; j < N; j++)
        {
          data[i, j] = int.Parse(t[j].ToString());
        }
      }

      int[] num = new int[N];

      for (int i = 0; i < N; i++)
      {
        int row = 0;
        for (int j = 0; j < N; j++)
        {
          if (data[i,j] == 1)
          {
            row = j;
          }
        }
        num[i] = row;
      }

      int c = 0;

      for (int i = 0; i < N; i++)
      {
        if(num[i] > i)
        {
          int j;
          for (j = i; j < N; j++)
          {
            if(!(num[j] > i))
              break;
          }

          for (int k = j; k > i; k--)
          {
            int swap = num[k];
            num[k] = num[k - 1];
            num[k - 1] = num[k];
            c++;
          }
        }
      }

      return c.ToString();
    }
  }
}