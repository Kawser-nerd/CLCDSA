#include <iostream>
#include <fstream>
#include "lp_lib.h"
#include <cstring>

using namespace std;

void lpsolve(const char* fn)
{
   char tmp[1000];
   strcpy(tmp, fn);
   lprec* lp = read_LP(&tmp[0], CRITICAL, "mm");
   int r = solve(lp);
   // cout << "Status: " << r << endl;
   REAL obj = get_objective(lp);
   cout << obj << endl;
}

class Sol
{
public:
   void read()
   {
      cin >> N;
      for (int i = 0; i < N; ++i) {
         cin >> x[i] >> y[i] >> r[i] >> s[i];
      }
   }

   void formulate(const char* fn) {
      ofstream os(fn, ios::out);
      os << "max: 0";
      for (int i = 0; i < N; ++i) {
         if (s[i] == 0) continue;
         if (s[i] > 0) os << "+";
         os << s[i] << " x" << i << " ";
      }
      os << ";" << endl;
      for (int i = 0; i < N; ++i) {
         for (int j = 0; j < N; ++j) {
            if (i == j) continue;
            if (checkDist(i, j, r[i])) {
               os << "x" << i << " - x" << j << " <= 0;" << endl;
            }
         }
      }

      for (int i = 0; i < N; ++i) {
         os << "bin x" << i << ";" << endl;
      }
   }

   bool checkDist(int i, int j, int d) {
      int r = (x[i] - x[j])*(x[i] - x[j]) + (y[i] - y[j]) * (y[i] - y[j]);
      return r <= d * d;
   }

   void solve(int caseNo) {
      read();
      formulate("tmp.lp");
      cout << "Case #" << caseNo << ": ";
      lpsolve("tmp.lp");
   }

   int N;
   int x[600], y[600], r[600], s[600];
};

int main()
{
   int T;
   cin >> T;
   for (int t = 1; t<= T; ++t) {
      Sol s;
      s.solve(t);
   }
   return 0;

}
