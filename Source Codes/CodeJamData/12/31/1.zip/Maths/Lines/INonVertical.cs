﻿namespace Generic.Maths.Lines
{
    public interface INonVertical : ILine
    {
        double DyDx { get; }
        double Y0 { get; }
        double Y(double x);
    }
}
