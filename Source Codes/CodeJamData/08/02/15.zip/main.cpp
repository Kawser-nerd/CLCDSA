#include <fstream>

#include <boost/thread/thread.hpp>
#include <boost/thread/condition.hpp>

#include "Utils.h"
#include "TrainTimetable.h"

int main(int argc, char **argv)
{
	unsigned int		cpus_number = 1/*GetCpusNumber()*/;
	boost::thread		**threads;
	char				*thr_finish_flag;
	boost::condition	thr_finish;
	boost::mutex::scoped_lock	thr_finish_lock(boost::mutex());
	std::ifstream		input;
	std::ofstream		output;
	std::string			*results;
	unsigned long		start_time;
	unsigned int		ch1;
	unsigned int		ch2;

	unsigned long		num;
	
	if(argc < 3)
	{
		std::cout << "Uasge: {programm}.exe input-file-name output-file-name" << std::endl;
		return 1;
	}
	try
	{
		input.open(argv[1]);
		output.open(argv[2], std::ios_base::out | std::ios_base::trunc);
	}
	catch(...)
	{
		std::cout << "Uasge: {programm}.exe input-file-name output-file-name" << std::endl;
		return 1;
	}

	input >> num;
	while(input.get() != '\n');

	std::cout << "Number of cases: " << num << std::endl;
	
	results = new std::string[num];
	thr_finish_flag = new char[cpus_number];
	memset(thr_finish_flag, 0xff, sizeof(char) * cpus_number);
	threads = new boost::thread*[cpus_number];

	start_time = GetTime();
	for(ch1 = 0; ch1 < num; ch1++)
	{
		for(ch2 = 0; ch2 < cpus_number && !thr_finish_flag[ch2]; ch2++);
		while(ch2 == cpus_number)
		{
			thr_finish.wait(thr_finish_lock);
			for(ch2 = 0; ch2 < cpus_number && !thr_finish_flag[ch2]; ch2++);
		}
		if(thr_finish_flag[ch2] == 1)
		{
			threads[ch2]->join();
			delete threads[ch2];
		}
		thr_finish_flag[ch2] = 0;
		std::cout << "Start " << (ch1 + 1) << " case." << std::endl;
		threads[ch2] = new boost::thread(TrainTimetable(input, results[ch1], thr_finish, thr_finish_flag[ch2]));
	}

	for(ch1 = 0; ch1 < cpus_number; ch1++)
	{
		while(!thr_finish_flag[ch1])
			thr_finish.wait(thr_finish_lock);
		if(thr_finish_flag[ch1] == 1)
		{
			threads[ch1]->join();
			delete threads[ch1];
		}
	}

	start_time = GetTime() - start_time;

	std::cout << "Work time: " << (start_time / 1000) << "s" << (start_time % 1000) << "ms" << std::endl;

	for(ch1 = 0; ch1 < num; ch1++)
		output << "Case #" << (ch1 + 1) << ": " << results[ch1] << std::endl;
	
	return 1;
	
}
