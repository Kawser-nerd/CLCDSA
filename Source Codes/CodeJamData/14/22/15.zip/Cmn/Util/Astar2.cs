using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Cmn.Util
{
    public class Astar2
    {
        public static Nodi<TNode, TDistance> Find<TNode, TDistance>(IEnumerable<Nodi<TNode, TDistance>> enstateStart, Func<TNode, bool> fEnd, Func<Nodi<TNode, TDistance>, IEnumerable<Nodi<TNode, TDistance>>> enNextGet, Func<Nodi<TNode, TDistance>, TDistance> distGetMinToEnd = null) where TDistance : IComparable<TDistance>
        {
            distGetMinToEnd = distGetMinToEnd ?? (state => state.DistFromStart) ;

            var hlmDone = new HashSet<TNode>();
            var mpActive = new SortedDictionary<TDistance, ISet<TNode>>();
            var mpdisttoendByNode = new Dictionary<TNode, TDistance>();
            var mpdistFromStartByNode = new Dictionary<TNode, TDistance>();

            for(var rgnodi = enstateStart;;)
            {
                foreach(var state in rgnodi)
                {
                    var distTotal = distGetMinToEnd(state);

                    TDistance distTotalOld;
                    if(mpdisttoendByNode.TryGetValue(state.Node, out distTotalOld))
                    { 
                        if(distTotalOld.CompareTo(distTotal) <= 0)
                            continue;

                        var hlmn = mpActive[distTotalOld];
                        hlmn.Remove(state.Node);
                        if (hlmn.Count == 0)
                            mpActive.Remove(distTotalOld);
                    }
                    mpdisttoendByNode[state.Node] = distTotal;
                    mpdistFromStartByNode[state.Node] = state.DistFromStart;
                    mpActive.EnsureGet(distTotal, () => state.Node is IComparable<TNode> ? (ISet<TNode>)new SortedSet<TNode>() : new HashSet<TNode>()).Add(state.Node);
                }

                if (mpActive.Count == 0)
                    return null;

                var kvpFirst = mpActive.First();
                var distToEndCurrent = kvpFirst.Key;
                var nodeCurrent = kvpFirst.Value.First();
                var distFromStartCurrent = mpdistFromStartByNode[nodeCurrent];

                mpdistFromStartByNode.Remove(nodeCurrent);
                mpdisttoendByNode.Remove(nodeCurrent);
                kvpFirst.Value.Remove(nodeCurrent);

                if(kvpFirst.Value.Count == 0)
                    mpActive.Remove(distToEndCurrent);

                Debug.Assert(!hlmDone.Contains(nodeCurrent));

                if(fEnd(nodeCurrent))
                {
                    Debug.Assert(distFromStartCurrent.CompareTo(distToEndCurrent)==0);
                    return new Nodi<TNode, TDistance>(nodeCurrent, distFromStartCurrent);
                }

                hlmDone.Add(nodeCurrent);

                rgnodi = enNextGet(new Nodi<TNode, TDistance>(nodeCurrent, distFromStartCurrent)).Where(stateTo => !hlmDone.Contains(stateTo.Node));
            }
        }
    }

    public class Nodi<TNode, TDistance> where TDistance : IComparable<TDistance>
    {
        public readonly TNode Node;
        private readonly Func<TDistance> dgDistFromStart;

        public TDistance DistFromStart
        {
            get
            {
                return dgDistFromStart();
            }
        }

        public Nodi(TNode node, Func<TDistance> dgDistFromStart)
        {
            Node = node;
            this.dgDistFromStart = dgDistFromStart.ToCached();
        }

        public Nodi(TNode node, TDistance distFromStart) : this(node, () => distFromStart)
        {
        }
    }
}