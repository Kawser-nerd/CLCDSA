package lib;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.function.Function;
import java.util.function.Supplier;

public class FastTokenizerFactory {

    private static class OpenMindByteArrayOutputStream extends ByteArrayOutputStream {
        byte[] getInternalBytes() {
            return buf;
        }
    }

    public static final Function<InputStream, Supplier<String>> INSTANCE = is -> {
        byte[] bytes;
        int bytesLength;
        try {
            OpenMindByteArrayOutputStream bos = new OpenMindByteArrayOutputStream();
            byte[] buffer = new byte[1024 * 1024];
            while (true) {
                int read = is.read(buffer);
                if (read == -1)
                    break;
                bos.write(buffer, 0, read);
            }
            bytes = bos.getInternalBytes();
            bytesLength = bos.size();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return new Supplier<String>() {
            int pos = 0;

            @Override
            public String get() {
                while (Character.isWhitespace(bytes[pos]))
                    pos++;
                int start = pos;
                while (pos < bytesLength && !Character.isWhitespace(bytes[pos]))
                    pos++;
                int end = pos;
                return new String(bytes, start, end - start);
            }
        };
    };

}
