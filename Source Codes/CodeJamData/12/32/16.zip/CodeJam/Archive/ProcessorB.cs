﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    public class ProcessorB
    {
        int cursor = 0;
        string[] stringData;

        private string getNextValue()
        {
            return stringData[cursor++];
        }

        public string Execute(string[] data)
        {
            stringData = data;
            StringBuilder output = new StringBuilder();

            // Read number of input
            int inputs = int.Parse(getNextValue());
            
            for (int i = 0; i < inputs; i++)
            {
                output.AppendLine(string.Format("Case #{0}: {1}", i + 1, string.Join(" ", getNextValue().Split(' ').Reverse())));
            }

            return output.ToString();
        }
    }
}
