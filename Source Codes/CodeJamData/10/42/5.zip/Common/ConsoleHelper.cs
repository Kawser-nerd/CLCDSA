﻿/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    abstract class SolutionBase
    {
        /// <summary>
        /// Solves the problem read from Console.In, writing results to Console.Out
        /// </summary>
        public abstract void Solve();

        public static int[] ReadInts(int count)
        {
            int[] result = ReadInts();
            if (result.Length != count)
                throw new Exception(String.Format("input length mismatch: {0} numbers instead of {1}", result.Length, count));
            return result;
        }

        public static string[] ReadLines(int count)
        {
            return Enumerable.Range(0, count).Select(i => ReadLine()).ToArray();
        }

        public static string ReadLine()
        {
            var res = Console.ReadLine();
            if (res == null)
                throw new Exception("No line to read!");
            return res;
        }

        private static int[] ReadInts()
        {
            return ReadLine().Split(new[]{' '}, StringSplitOptions.RemoveEmptyEntries).Select(item => int.Parse(item)).ToArray();
        }

        public double[] ReadDoubles(int count)
        {
            var result = ReadLine().Split(' ').Select(item => double.Parse(item)).ToArray();
            if (result.Length != count)
                throw new FormatException("count mismatch: " + result.Length + " instead of " + count); ;
            return result;
        }

        public static int ReadInt()
        {
            return ReadInts(1).Single();
        }

        public static void ReadInts(out int a, out int b)
        {
            int[] arr = ReadInts(2);
            a = arr[0];
            b = arr[1];
        }

        public static void ReadInts(out int a, out int b, out int c)
        {
            int[] arr = ReadInts(3);
            a = arr[0];
            b = arr[1];
            c = arr[2];
        }

        public static void ReadInts(out int a, out int b, out int c, out int d)
        {
            int[] arr = ReadInts(4);
            a = arr[0];
            b = arr[1];
            c = arr[2];
            d = arr[3];
        }

        public static void ReadInts(out int a, out int b, out int c, out int d, out int e)
        {
            int[] arr = ReadInts(5);
            a = arr[0];
            b = arr[1];
            c = arr[2];
            d = arr[3];
            e = arr[4];
        }

        public static void ReadInts(out int a, out int b, out int c, out int d, out int e, out int f)
        {
            int[] arr = ReadInts(6);
            a = arr[0];
            b = arr[1];
            c = arr[2];
            d = arr[3];
            e = arr[4];
            f = arr[5];
        }
    }
}
