﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    public class QualifierA
    {
        int _cursor = 0;
        string[] _stringData;

        private string GetNextValue()
        {
            return _stringData[_cursor++];
        }

        public string Execute(string[] data)
        {
            _stringData = data;
            var output = new StringBuilder();

            // Read number of input
            int inputs = int.Parse(GetNextValue());
            
            for (int i = 0; i < inputs; i++)
            {
                string original = GetNextValue();
                string result = "";
                foreach (char t in original)
                {
                    switch(t)
                    {
                        case 'a':
                            result += 'y';
                            break;
                        case 'b':
                            result += 'h';
                            break;
                        case 'c':
                            result += 'e';
                            break;
                        case 'd':
                            result += 's';
                            break;
                        case 'e':
                            result += 'o';
                            break;
                        case 'f':
                            result += 'c';
                            break;
                        case 'g':
                            result += 'v';
                            break;
                        case 'h':
                            result += 'x';
                            break;
                        case 'i':
                            result += 'd';
                            break;
                        case 'j':
                            result += 'u';
                            break;
                        case 'k':
                            result += 'i';
                            break;
                        case 'l':
                            result += 'g';
                            break;
                        case 'm':
                            result += 'l';
                            break;
                        case 'n':
                            result += 'b';
                            break;
                        case 'o':
                            result += 'k';
                            break;
                        case 'p':
                            result += 'r';
                            break;
                        case 'q':
                            result += 'z';
                            break;
                        case 'r':
                            result += 't';
                            break;
                        case 's':
                            result += 'n';
                            break;
                        case 't':
                            result += 'w';
                            break;
                        case 'u':
                            result += 'j';
                            break;
                        case 'v':
                            result += 'p';
                            break;
                        case 'w':
                            result += 'f';
                            break;
                        case 'x':
                            result += 'm';
                            break;
                        case 'y':
                            result += 'a';
                            break;
                        case 'z':
                            result += 'q';
                            break;
                        case ' ':
                            result += ' ';
                            break;
                    }
                }

                output.AppendLine(string.Format("Case #{0}: {1}", i + 1, result));
            }

            return output.ToString();
        }
    }
}
