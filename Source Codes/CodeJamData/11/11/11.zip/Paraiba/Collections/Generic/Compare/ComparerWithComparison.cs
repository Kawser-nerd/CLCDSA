﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;

namespace Paraiba.Collections.Generic.Compare
{
	public class ComparerWithComparison<T> : IComparer<T>
	{
		private readonly Comparison<T> _compareFunc;

		public ComparerWithComparison(Comparison<T> compareFunc)
		{
			Contract.Requires(compareFunc != null);

			_compareFunc = compareFunc;
		}

		#region IComparer<TValue> メンバ

		public int Compare(T x, T y)
		{
			return _compareFunc(x, y);
		}

		#endregion

		public Comparison<T> CompareDelegate
		{
			get { return _compareFunc; }
			//set { _compareFunc = value; }	// 状態変化できない方が良いかな
		}
	}
}