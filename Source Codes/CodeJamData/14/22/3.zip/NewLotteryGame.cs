﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace gcj
{
    class NewLotteryGame : Problem
    {
        #region Main
        static void Main(string[] args)
        {
            ProblemSet<NewLotteryGame>.Solve(args);
        }
        #endregion

        public override void Parse(ProblemReader file)
        {
            file.Read(out A, out B, out K);
        }

        // ReSharper disable InconsistentNaming
        private long A, B, K;
        // ReSharper restore InconsistentNaming

        public override object Solve()
        {
            long ct = 0;
            for (var i = 0L; i < A; i++)
                for (var j = 0L; j < B; j++)
                    if ((i & j) < K) ct++;
            return ct;
        }

        public override IEnumerable<Action> StaticInitialize()
        {
            yield return () =>
            {

            };
        }
    }
}
