package lib;

public interface CodeJamCaseSolver {
    void solve(String caseTitle, Input in);
}
