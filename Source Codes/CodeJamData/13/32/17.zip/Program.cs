﻿namespace CodeJam2013.B
{
    using System;
    using System.Diagnostics;

    /// <summary>
    /// The program's entry point
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// The program's entry point
        /// </summary>
        /// <param name="args">List of arguments.</param>
        private static void Main(string[] args)
        {
            var problemFileNameBase = args.Length == 0 ? @"test" : args[0];
            var inputFileNaame = problemFileNameBase + ".in";

            var cc = CaseCollection.Load(inputFileNaame);
            cc.Solve();

            var solvedTime = DateTime.Now;
            var outputFileName = problemFileNameBase + "_" + solvedTime.ToString("yyyy-MM-dd-HH-mm-ss") + ".out";
            cc.OutputResults(outputFileName);

            // Opens the output directory and the result file automatically
            Process.Start("explorer.exe", "/select," + outputFileName);
            Process.Start(outputFileName);
        }
    }
}
