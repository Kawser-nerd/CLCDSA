namespace CodeJamLibrary
{
  public enum ProblemType
  {
    Unknown, 
    ProblemA,
    ProblemB,
    ProblemC,
    ProblemD
  }
}