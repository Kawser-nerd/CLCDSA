import generic.InUtils;
import generic.Solver;

// Unsolved

public class QD implements Solver {

	@Override
	public String solveCase() {
		int n=InUtils.oneInt();
		int[] initialArray = InUtils.oneLineIntArray();
		int sum = 0;
		for(int i=0; i<n; i++)
			if(initialArray[i]-1 != i)
				sum++;		
		return Integer.toString(sum)+".000000";
	}
}
