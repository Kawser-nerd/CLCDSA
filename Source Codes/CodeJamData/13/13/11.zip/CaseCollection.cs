﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright>
//    Copyright © 2013 Daisuke Takahashi
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace CodeJam2013.C
{
    using System;
    using System.IO;
    using System.Text;

    /// <summary>
    /// Manages list of problem cases.
    /// </summary>
    internal class CaseCollection
    {
        private readonly Case[] cases;

        /// <summary>
        /// Initializes a new instance of the <see cref="CaseCollection" /> class.
        /// </summary>
        /// <param name="cases">The cases.</param>
        private CaseCollection(Case[] cases)
        {
            this.cases = cases;
        }

        /// <summary>
        /// Loads the specified input file name.
        /// </summary>
        /// <param name="inputFilePath">Path of the input file.</param>
        /// <returns>A new instance of <see cref="CaseCollection"/> class.</returns>
        /// <exception cref="System.ApplicationException">Invalid input file.</exception>
        public static CaseCollection Load(string inputFilePath)
        {
            using (var sr = new StreamReader(inputFilePath))
            {
                var casesCountString = sr.ReadLine();
                if (casesCountString == null)
                {
                    throw new ApplicationException("Invalid input file.");
                }

                var casesCount = int.Parse(casesCountString);
                var caseList = new Case[casesCount];
                for (var i = 0; i < casesCount; ++i)
                {
                    caseList[i] = Case.Load(sr);
                }

                return new CaseCollection(caseList);
            }
        }

        /// <summary>
        /// Solves this instance.
        /// </summary>
        /// <exception cref="System.InvalidOperationException">The list does not contain any cases to be solved.</exception>
        public void Solve()
        {
            if (this.cases == null || this.cases.Length == 0)
            {
                throw new InvalidOperationException("The list does not contain any cases to be solved.");
            }

            var casesSolvedCount = 0;
            var casesCount = this.cases.Length;
            foreach (var c in this.cases)
            {
                c.Solve();
                ++casesSolvedCount;
                Console.WriteLine("{0} out of {1} cases solved.", casesSolvedCount, casesCount);
            }
        }

        /// <summary>
        /// Outputs the results.
        /// </summary>
        /// <param name="outputFilePath">The output file path.</param>
        public void OutputResults(string outputFilePath)
        {
            using (var sw = new StreamWriter(outputFilePath, false, Encoding.ASCII))
            {
                var i = 1;
                foreach (var c in this.cases)
                {
                    sw.WriteLine("Case #{0}: {1}", i, c.Answer);
                    ++i;
                }
            }
        }
    }
}
