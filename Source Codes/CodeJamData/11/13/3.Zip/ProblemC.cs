﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CodeJam2011.Problems
{
    public class ProblemC : ProblemBase
    {
        protected override string SolveOneCase(InputHelper input)
        {
            int[] C = new int[81];
            int[] S = new int[81];
            int[] T = new int[81];

            List<int> hand = new List<int>();


            int N = input.GetInt();
            for (int i = 0; i < N; i++)
            {
                C[i] = input.GetInt();
                S[i] = input.GetInt();
                T[i] = input.GetInt();
                hand.Add(i);
            }

            int M = input.GetInt();
            for (int i = 0; i < M; i++)
            {
                C[i+N] = input.GetInt();
                S[i + N] = input.GetInt();
                T[i + N] = input.GetInt();
            }

            int turns = 1;
            int score = 0;
            int bestScore = 0;

            int next = N;

            while( turns > 0 && hand.Count > 0)
            {
                for (int i = hand.Count-1; i >=0; i--)
                {
                    int j = hand[i];


                    if (T[j] >= 1)
                    {
                        hand.RemoveAt(i);

                        score += S[j];
                        turns += T[j] - 1;

                        // redo for large
                        if( C[j] == 1 && next <  N+M)
                        {
                            hand.Add(next++);
                            i = hand.Count; // restart loop.
                        }

                    }
                }

                if (hand.Count == 0)
                    break;

                int noDrawCount = (from i in hand
                                  where C[i] == 0
                                  select i).Count();

                if( noDrawCount >= turns )
                {
                    

                    var q = from t in hand
                            where C[t] == 0
                            orderby S[t] descending 
                            select t;

                    int candidate = score + q.Take(turns).Sum(x => S[x]);

                    bestScore = Math.Max(candidate, bestScore);

                }

                var qq = from t in hand
                        where C[t] == 1
                        orderby S[t] descending
                        select t;

                int nn;
                if( qq.Count() > 0)
                {
                    nn = qq.First();
                }
                else
                {
                    nn = (from t in hand
                         where C[t] == 0
                         orderby S[t] descending
                         select t).First();
                }


                score += S[nn];
                turns += T[nn] - 1;

                // redo for large
                if (C[nn] == 1 && next < N + M)
                {
                    hand.Add(next++);
                }

                hand.Remove(nn);
            }



            return Math.Max(bestScore, score).ToString();
        }
    }
}