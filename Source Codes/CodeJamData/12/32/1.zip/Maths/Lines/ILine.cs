﻿namespace Generic.Maths.Lines
{
    public interface ILine
    {
        double X(double y);
    }
}
