package lib;

import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Set;

public class Dijkstra {

    static class HeapItem<V> {
        final V vertex;
        final double distance;

        HeapItem(V vertex, double distance) {
            this.vertex = vertex;
            this.distance = distance;
        }

        @Override
        public String toString() {
            return Arrays.asList(vertex, distance).toString();
        }
    }

    public static <V> void traverse(V start, AdjacencySupplier<V> adj, DiscoverHandler<V> onDiscover, SetFactory<V> setFactory) {
        PriorityQueue<HeapItem<V>> heap = new PriorityQueue<>(Comparator.comparingDouble(o -> o.distance));
        Set<V> visited = setFactory.create();
        heap.add(new HeapItem<>(start, 0));
        while (!heap.isEmpty()) {
            HeapItem<V> item = heap.poll();
            V vertex = item.vertex;
            if (visited.contains(vertex))
                continue;
            visited.add(vertex);
            if (!onDiscover.handleAndGetContinuity(vertex, item.distance))
                break;
            adj.get(vertex).forEach(tw -> {
                if (!visited.contains(tw.target))
                    heap.add(new HeapItem<V>(tw.target, item.distance + tw.weight));
            });
        }
    }

}
