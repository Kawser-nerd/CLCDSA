﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Generic.Containers.Collections.List;
using Generic.InputOutput.Printing;
using Generic.Maths.Vectors;

namespace Google_Code_Jam.Problems
{
    enum Direction {N,E,S,W}
    class PogoStick : Algorithm<IntVector2,IList<Direction>>
    {
        public override IntVector2 Parse(StreamReader reader)
        {
            var ints = JamUtil.ReadInts(reader);
            return new IntVector2(ints[0], ints[1]);
        }

        public override IList<Direction> Solve(IntVector2 problem)
        {
            var horizontalDirections = GetHorizontalDirections(problem.X > 0, Math.Abs(problem.X));
            var verticalDirections = GetVerticalDirections(problem.Y > 0, Math.Abs(problem.Y));
            return horizontalDirections.Concat(verticalDirections).ToList();
        }
         
        static IEnumerable<Direction> GetHorizontalDirections(bool moveForward, int hopCount)
        {
            return GetDirection(moveForward, hopCount, Direction.W, Direction.E);
        }

        static IEnumerable<Direction> GetVerticalDirections(bool moveForward, int hopCount)
        {
            return GetDirection(moveForward, hopCount, Direction.S, Direction.N);
        }

        static IEnumerable<Direction> GetDirection(bool moveForward, int hopCount, Direction backward, Direction forward)
        {
            var sequence = moveForward ? ListUtil.New(backward, forward) : ListUtil.New(forward, backward);
            return Enumerable.Range(0, hopCount).SelectMany(_ => sequence);
        }

        public override string Print(IList<Direction> solution)
        {
            return solution.Select(d => d.ToString().Print()).HorizontalConcat().Render();
        }
    }
}
