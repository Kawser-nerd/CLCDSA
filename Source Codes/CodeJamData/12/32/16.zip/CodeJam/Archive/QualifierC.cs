﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeJam
{
    public class QualifierC
    {
        int _cursor = 0;
        string[] _stringData;

        private string GetNextValue()
        {
            return _stringData[_cursor++];
        }

        class ValuePair
        {
            public long Value1 { get; set; }
            public long Value2 { get; set; }

            public override bool Equals(object obj)
            {
                var compareTo = (ValuePair) obj;

                return (compareTo.Value1 == Value1 && compareTo.Value2 == Value2) || (compareTo.Value2 == Value1 && compareTo.Value1 == Value2);
            }
        }

        public string Execute(string[] data)
        {
            _stringData = data;
            var output = new StringBuilder();

            var discoveredPairs = new List<ValuePair>();

            long mainLimit = 2000000;

            for (long value = 1; value <= mainLimit; value++)
            {
                string valueString = value.ToString();

                for (int j = 1; j < valueString.Length; j++)
                {
                    long newValue = long.Parse(valueString.Substring(j) + valueString.Substring(0, j));
                    if (newValue <= mainLimit && newValue >= 1 && newValue != value &&
                        newValue.ToString().Length == valueString.Length && !discoveredPairs.Contains(new ValuePair() { Value1 = value, Value2 = newValue }))
                    {
                        discoveredPairs.Add(new ValuePair() { Value1 = value, Value2 = newValue });
                    }
                }
            }

            // Read number of input
            int inputs = int.Parse(GetNextValue());

            for (int i = 0; i < inputs; i++)
            {
                List<long> values = GetNextValue().Split(' ').Select(long.Parse).ToList();
                long lowerLimit = values[0];
                long upperLimit = values[1];
                int result = discoveredPairs.Count(p => p.Value1 >= lowerLimit && p.Value1 <= upperLimit &&p.Value2 >= lowerLimit && p.Value2 <= upperLimit);
                output.AppendLine(string.Format("Case #{0}: {1}", i + 1, result));
            }

            return output.ToString();
        }
    }
}
