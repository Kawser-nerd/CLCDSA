using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Cmn.Util
{
    public class Astar<N, T> where T : IComparable<T>
    {
        private readonly HashSet<N> hlmDone = new HashSet<N>();
        private readonly SortedDictionary<T, HashSet<N>> mpActive2 = new SortedDictionary<T, HashSet<N>>();
        private readonly Dictionary<N, T> mpttotalByN = new Dictionary<N, T>();
        private readonly Dictionary<N, T> mptByN = new Dictionary<N, T>();
        private readonly Func<N,bool> fEnd;
        private readonly Func<N, T, IEnumerable<N>> dgenNextGet;
        private readonly Func<N, T, N, T> tGet;
        private readonly Func<N, T, T> tGetMinTotal;

        //public Astar(IEnumerable<Tuple<N, T>> enprntStart, IEnumerable<N> ennEnd, Func<N, T, IEnumerable<N>> dgenNextGet, Func<N, T, N, T> tGet, Func<N, T, T> tGetMinTotal = null)
        //    :this(enprntStart, n => )
        //{
            
        //}

        public Astar(IEnumerable<Tuple<N, T>> enprntStart, Func<N, bool> fEnd, Func<N, T, IEnumerable<N>> dgenNextGet, Func<N, T, N, T> tGet, Func<N, T, T> tGetMinTotal = null)
        {
            this.dgenNextGet = dgenNextGet;
            this.tGet = tGet;
            this.tGetMinTotal = tGetMinTotal ?? ((n, t) => t) ;

            foreach(var prnt in enprntStart)
            {
                AddActive(prnt.Item1, this.tGetMinTotal(prnt.Item1,prnt.Item2), prnt.Item2);
            }

            this.fEnd = fEnd;
        }

        private void AddActive(N n, T tTotal, T t)
        {
            T tTotalOld;
            if(mpttotalByN.TryGetValue(n, out tTotalOld))
            {
                if(tTotalOld.CompareTo(tTotal) <= 0)
                    return;

                var hlmn = mpActive2[tTotalOld];
                hlmn.Remove(n);
                if(hlmn.Count == 0)
                    mpActive2.Remove(tTotalOld);
            }
            mpttotalByN[n] = tTotal;
            mptByN[n] = t;
            mpActive2.EnsureGet(tTotal).Add(n);
        }

        public Tuple<N, T> Find()
        {
            for(;;)
            {
                if(mpActive2.Count == 0)
                    return null;

                var kvpFirst = mpActive2.First();
                var ttotalFrom = kvpFirst.Key;
                var nFrom = kvpFirst.Value.First();
                var tFrom = mptByN[nFrom];

                mptByN.Remove(nFrom);
                mpttotalByN.Remove(nFrom);
                kvpFirst.Value.Remove(nFrom);

                if(kvpFirst.Value.Count == 0)
                    mpActive2.Remove(ttotalFrom);

                Debug.Assert(!hlmDone.Contains(nFrom));

                if(fEnd(nFrom))
                {
                    Debug.Assert(tFrom.CompareTo(ttotalFrom)==0);
                    return new Tuple<N, T>(nFrom, tFrom);
                }

                hlmDone.Add(nFrom);

                foreach(var nTo in dgenNextGet(nFrom, tFrom))
                {
                    if(hlmDone.Contains(nTo))
                        continue;

                    var t = tGet(nFrom, tFrom, nTo);
                    AddActive(nTo, tGetMinTotal(nTo,t), t);
                }
            }
        }
    }
}