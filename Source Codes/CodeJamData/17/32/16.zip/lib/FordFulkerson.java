package lib;

import java.util.List;

public class FordFulkerson {

    public static int fillAndGetAddition(PathFinder pathFinder, AdjacentListGetter adj, AdderOnEdge flowAdder, GetterOnEdge capacity, GetterOnEdge flow, int start, int end) {
        GetterOnEdge residualGetter = ResidualGetter.of(capacity, flow);
        AdjacentListGetter residualNetwork = ResidualNetwork.of(adj, residualGetter);
        int total = 0;
        while (true) {
            List<Integer> augmentingPath = pathFinder.findOrNull(residualNetwork, start, end);
            if (augmentingPath == null || augmentingPath.size() == 1)
                break;
            int min = calcMinimumResidualOnPath(augmentingPath, residualGetter);
            adjustFlowOnPath(augmentingPath, flowAdder, min);
            total += min;
        }
        return total;
    }

    private static int calcMinimumResidualOnPath(List<Integer> path, GetterOnEdge residualGetter) {
        int min = Integer.MAX_VALUE;
        for (int i = 0; i < path.size() - 1; i++)
            min = Math.min(min, residualGetter.get(path.get(i), path.get(i + 1)));
        return min;
    }

    private static void adjustFlowOnPath(List<Integer> path, AdderOnEdge flowAdder, int flow) {
        for (int i = 0; i < path.size() - 1; i++)
            FlowAdjuster.adjust(flowAdder, path.get(i), path.get(i + 1), flow);
    }

}
