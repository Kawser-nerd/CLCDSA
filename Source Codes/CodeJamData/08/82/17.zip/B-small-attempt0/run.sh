#!/bin/bash
for f in `find . -name \*.java`; do javac $f; done
java gepa.gcj.main.Main --inputDataClass=gepa.gcj.roundSemiEmea.InputDataB --solverClass=gepa.gcj.roundSemiEmea.SolverB --inputFile=B-small-attempt0.in --outputFile=B-small-attempt0.out
