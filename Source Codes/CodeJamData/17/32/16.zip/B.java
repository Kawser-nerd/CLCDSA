import lib.CodeJamLauncher;
import lib.Input;
import lib.IntQuadruple;
import lib.MapFactoryUsing4DArray;
import lib.MemoizationSolver;
import lib.Repeat;
import lib.Solver;

import java.util.Arrays;
import java.util.stream.IntStream;

public class B {

    public static final int MAX = 999999;
    private static int[] d;

    public static void main(String[] ignored) throws Exception {
        CodeJamLauncher.run("B-large.in", (caseTitle, in) -> {
            int ac = in.nextInt();
            int aj = in.nextInt();
            d = new int[1440];
            Arrays.fill(d, -1);
            inputRanges(in, ac, 0);
            inputRanges(in, aj, 1);

//            System.out.println(Arrays.toString(d));

            Solver<IntQuadruple, Integer> solver = MemoizationSolver.of(MapFactoryUsing4DArray.of(2, 2, 1441, 1441, q -> q.v1, q -> q.v2, q -> q.v3, q -> q.v4), (terms, self) -> {
                int first = terms.v1;
                int current = terms.v2;
                int now = terms.v3;
                int cameron = terms.v4;

                if (now == 1440) {
                    if (cameron == 720) {
                        return (first == current) ? 0 : 1;
                    } else {
                        return MAX;
                    }
                } else {
                    int min = MAX;
                    if (d[now] == -1 || d[now] == 0)
                        min = Math.min(min, (current == 0 ? 0 : 1) + self.solve(new IntQuadruple(first, 0, now + 1, cameron + 1)));
                    if (d[now] == -1 || d[now] == 1)
                        min = Math.min(min, (current == 1 ? 0 : 1) + self.solve(new IntQuadruple(first, 1, now + 1, cameron)));
                    return min;
                }
            });


            int cameron = solver.solve(new IntQuadruple(0, 0, 0, 0));
            int jamie = solver.solve(new IntQuadruple(1, 1, 0, 0));
            System.out.println(caseTitle + Math.min(cameron, jamie));
        });
    }

    private static void inputRanges(Input in, int ac, int v) {
        Repeat.run(ac, () -> {
            int x = in.nextInt();
            int y = in.nextInt();
            IntStream.range(x, y).forEach(i -> d[i] = v);
        });
    }

}
