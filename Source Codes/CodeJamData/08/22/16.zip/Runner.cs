﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

class Runner
{    
    public static StreamReader TestLines
    {
        get
        {
            return System.IO.File.OpenText(Problem.InputName);
        }
    }

    public static void Run()
    {
        using (StreamWriter wr = System.IO.File.CreateText("../../out.txt"))
        {
            (new Problem()).Solve(TestLines, wr);
        }
    }

}