package lib;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class Launcher {

    public static void run(Function<InputStream, Supplier<String>> tokenizerFactory, Consumer<Input> consumer) {
        InputStream is = getInputStream();
        Input input = new Input(tokenizerFactory.apply(new BufferedInputStream(is)));
        consumer.accept(input);
    }

    private static InputStream getInputStream() {
        StackTraceElement[] trace = Thread.currentThread().getStackTrace();
        for (StackTraceElement e : trace) {
            String candidate = problemIdCandidate(e);
            InputStream res = Launcher.class.getResourceAsStream("/" + candidate + ".txt");
            if (res != null)
                return res;
        }
        return System.in;
    }

    private static String problemIdCandidate(StackTraceElement e) {
        String simpleClassName = getSimpleClassName(e);
        int underscore = simpleClassName.indexOf("_");
        return underscore != -1 ? simpleClassName.substring(0, underscore) : simpleClassName;
    }

    private static String getSimpleClassName(StackTraceElement e) {
        String className = e.getClassName();
        int dot = className.lastIndexOf(".");
        return dot == -1 ? className : className.substring(dot + 1);
    }

}
