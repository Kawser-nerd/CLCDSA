package lib;

import java.util.stream.IntStream;

public class DecreasingIntStream {

    static IntStream of(int start, int last) {
        Assertion.check(start >= last);
        return IntStream.rangeClosed(0, start - last)
                .map(i -> start - i);
    }
}
