﻿using System.Collections.Generic;
using System.Linq;

namespace CodeJam.Round1C
{
    internal class SolutionA : ISolution
    {
        private List<List<int>> classes;

        private int problemIndex;

        public int GetProblem(int problemIndex, int startIndex, string[] data)
        {
            classes = new List<List<int>>();

            this.problemIndex = problemIndex;
            int count = int.Parse(data[startIndex++]);
            for (int i = 0; i < count; i++)
            {
                List<int> inherits = data[startIndex++].Split(' ').Select(int.Parse).Skip(1).ToList();
                classes.Add(inherits);
            }
            return startIndex;
        }

        public Result ProcessProblem()
        {
            string result = "No";

            var caseClasses = classes.Select(t => new CaseClass()).ToList();
            for (int i = 0; i < classes.Count; i++)
            {
                List<int> inherits = classes[i];
                caseClasses[i].InheritsInts = inherits;

                foreach (int t in inherits)
                {
                    caseClasses[i].InheritsFrom.Add(caseClasses[t - 1]);
                }
            }

            for (int i = 0; i < caseClasses.Count; i++)
            {
                List<int> inherits = caseClasses[i].GetInheritanceChain(new List<int>());
                if (inherits.Any(c => inherits.Count(x => x == c) > 1))
                {
                    result = "Yes";
                    break;
                }
            }

                return new Result()
                           {
                               Output = result,
                               ProblemIndex = problemIndex
                           };
        }

        class CaseClass
        {
            public readonly List<CaseClass> InheritsFrom = new List<CaseClass>();
            public List<int> InheritsInts;

            public List<int> GetInheritanceChain(List<int> chain)
            {
                chain.AddRange(InheritsInts);
                InheritsFrom.ForEach(i => chain = i.GetInheritanceChain(chain));
                return chain;
            } 
        }
    }
}
