﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;

namespace GCJ2015Round1C_1
{
	public class Solver : SolverBase
	{
		public const string INPUT_NAME = "smalltest";
		public const bool SKIP_LINE_AFTER_CASE_OUTPUT = false;

		public Solver(IEnumerator<string> inputEnumerator)
			: base(inputEnumerator)
		{
		}

		public override string SolveTestCase(int testCase)
		{
			var data = GetIntList();
			var R = data[0];
			var C = data[1];
			var W = data[2];

			if (W == 1)
				return (R * C).ToString();

			int misses = (C / W) - 1;
			if (C % W != 0)
			{
				misses++;
			}
			int shotsForCorrect = (misses + W);

			int shotsForIncorrect = (C / W);

			return (shotsForCorrect + shotsForIncorrect * (R - 1)).ToString();
		}

	}
}
