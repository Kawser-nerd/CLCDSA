#!/usr/bin/env python
import sys
from mypy.codejam import *
import re

clockRegex = re.compile("(\d\d):(\d\d)")

def timeToMinutes(time):
    """Convert 24 hour time string to number of minutes (int)."""
    m = clockRegex.match(time)
    assert(m is not None)
    minutes = int(m.group(1)) * 60 + int(m.group(2))
    return minutes

class Trip:
    def __init__(self, times):
        self.departure = timeToMinutes(times[0])
        self.arrival = timeToMinutes(times[1])

    def __str__(self):
        return "%d -> %d" % (self.departure, self.arrival)

class TrainTestCase(TestCase):
    def parseTestCase(self, file):
        self.turnAroundTime = int(file.readline())
        numTrips = map(int, file.readline().split())
        assert(len(numTrips) == 2)
        self.numTripsAB = numTrips[0]
        self.numTripsBA = numTrips[1]
        self.tripsAB = []
        for n in xrange(self.numTripsAB):
            self.tripsAB.append(Trip(file.readline().split()))
        self.tripsBA = []
        for n in xrange(self.numTripsBA):
            self.tripsBA.append(Trip(file.readline().split()))

def findTrainBeforeTime(list, time):
    """Given a sorted list of times, find the last that is before time."""
    for index in xrange(len(list)-1, -1, -1):
        if list[index] <= time:
            return index
    return None

def findNumTrainsNeeded(arrivals, departures, turnAroundTime):
    arrivals.sort()
    departures.sort()
    numTrainsNeeded = 0
    for departure in departures:
        departure -= turnAroundTime
        index = findTrainBeforeTime(arrivals, departure)
        if index is None:
            numTrainsNeeded += 1
        else:
            arrivals.pop(index)
    return numTrainsNeeded

def solver(testcase):
    assert(testcase is not None)
    # Find all arrivals to and departures from A and B
    arrivalsA = map(lambda t:t.arrival, testcase.tripsBA)
    departuresA = map(lambda t:t.departure, testcase.tripsAB)
    arrivalsB = map(lambda t:t.arrival, testcase.tripsAB)
    departuresB = map(lambda t:t.departure, testcase.tripsBA)
    trainsNeededA = findNumTrainsNeeded(arrivalsA, departuresA,
                                        testcase.turnAroundTime)
    trainsNeededB = findNumTrainsNeeded(arrivalsB, departuresB,
                                        testcase.turnAroundTime)
    return "%d %d" % (trainsNeededA, trainsNeededB)
    
def main():
    problem = GoogleProblem(testcaseClass=TrainTestCase)
    problem.solve(solver)

if __name__ == "__main__":
    sys.exit(main())
