using System;
using System.IO;
using CodeJam.Providers;
using Template;
using Template.Interfaces;

namespace CodeJam.Factories
{
  public class InputOutputFactory : IInputOutputFactory
  {
    private readonly IFilePathProvider filePathProvider;

    public InputOutputFactory(IFilePathProvider filePathProvider)
    {
      this.filePathProvider = filePathProvider;
    }

    public IInput CreateInput()
    {
      var streamReader = new StreamReader( filePathProvider.InputFilePath());
      return ObjectFactory.GetInstance<Input, TextReader>(streamReader);
    }

    public IOutput CreateOutput()
    {
      var streamWriter = new StreamWriter(filePathProvider.OutputFilePath());
      return ObjectFactory.GetInstance<Output, TextWriter>(streamWriter);
    }
  }
}