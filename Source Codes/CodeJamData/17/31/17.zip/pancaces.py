import jam
import math

def side(radius, height):
    return 2 * math.pi * radius * height

def area(radius, height):
    return math.pi * (radius ** 2)

def solve(K, pancakes):
    res = 0

    for i, bottom in enumerate(pancakes):
        rest = pancakes[:i] + pancakes[i+1:]

        rest = [side(*x) for x in rest if x[0] <= bottom[0]]
        rest.sort(reverse=True)

        result = side(*bottom) + area(*bottom) + sum(rest[:(K-1)])
        res = max(result, res)

    return res


def parse():
    N, K = [int(x) for x in input().strip().split()]
    
    pancakes = [
        [int(x) for x in input().strip().split()]
        for _ in range(N)
    ]

    return solve(K, pancakes)

# print(solve(2, [(100, 10), (100, 10), (100, 10), ]))

jam.run(parse)