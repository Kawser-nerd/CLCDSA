package generic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class InUtils {
	
	private static Scanner inScanner;
	
	protected static void setScanner(Scanner scanner){
		inScanner = scanner;
	}

	public static int oneInt(){
		return Integer.parseInt(inScanner.nextLine());
	}

	public static double oneDouble(){
		return Double.parseDouble(inScanner.nextLine());
	}

	public static String oneLine(){
		return inScanner.nextLine();
	}

	public static int[] oneLineIntArray(){
		String[] integerStrings = inScanner.nextLine().split(" ");
		int[] integers = new int[integerStrings.length];
		for(int i=0; i<integerStrings.length; i++)
			integers[i] = Integer.parseInt(integerStrings[i]);
		return integers;
	}

	public static List<Integer> oneLineIntList(){
		String[] integerStrings = inScanner.nextLine().split(" ");
		List<Integer> integers = new ArrayList<Integer>();
		for(String integerString : integerStrings)
			integers.add(Integer.parseInt(integerString));
		return integers;
	}

	public static double[] oneLineDoubleArray(){
		String[] doubleStrings = inScanner.nextLine().split(" ");
		double[] doubles = new double[doubleStrings.length];
		for(int i=0; i<doubleStrings.length; i++)
			doubles[i] = Double.parseDouble(doubleStrings[i]);
		return doubles;
	}

	public static List<Double> oneLineDoubleList(){
		String[] doubleStrings = inScanner.nextLine().split(" ");
		List<Double> doubles = new ArrayList<Double>();
		for(String doubleString : doubleStrings)
			doubles.add(Double.parseDouble(doubleString));
		return doubles;
	}

	public static String[] oneLineStringArray(){
		String[] strings = inScanner.nextLine().split(" ");
		return strings;
	}

	public static List<String> oneLineStringList(){
		return Arrays.asList(oneLineStringArray());
	}

	public static int[] multiLineIntArray(int numberOfLines){
		int[] integers = new int[numberOfLines];
		for(int i=0; i<numberOfLines; i++){
			String integerString = inScanner.nextLine();
			integers[i] = Integer.parseInt(integerString);
		}
		return integers;
	}

	public static List<Integer> multiLineIntList(int numberOfLines){
		List<Integer> integers = new ArrayList<Integer>();
		for(int i=0; i<numberOfLines; i++){
			String integerString = inScanner.nextLine();
			integers.add(Integer.parseInt(integerString));
		}
		return integers;
	}

	public static double[] multiLineDoubleArray(int numberOfLines){
		double[] doubles = new double[numberOfLines];
		for(int i=0; i<numberOfLines; i++){
			String integerString = inScanner.nextLine();
			doubles[i] = Double.parseDouble(integerString);
		}
		return doubles;
	}

	public static List<Double> multiLineDoubleList(int numberOfLines){
		List<Double> doubles = new ArrayList<Double>();
		for(int i=0; i<numberOfLines; i++){
			String doubleString = inScanner.nextLine();
			doubles.add(Double.parseDouble(doubleString));
		}
		return doubles;
	}

	public static String[] multiLineStringArray(int numberOfLines){
		String[] strings = new String[numberOfLines];
		for(int i=0; i<numberOfLines; i++){
			strings[i] = inScanner.nextLine();
		}
		return strings;
	}

	public static List<String> multiLineStringList(int numberOfLines){
		return Arrays.asList(multiLineStringArray(numberOfLines));
	}
}
