import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Date: May 23, 2010
 * Time: 1:16:34 PM
 *
 * @author Timur Abishev (ttim@)
 */
public class C extends Solution {
    boolean ok(boolean[][] f) {
        for (int i = 0; i < f.length; i++)
            for (int j = 0; j < f[i].length; j++)
                if (f[i][j]) return false;
        return true;
    }

    boolean[][] nextField(boolean[][] f) {
        boolean[][] nf = new boolean[101][101];
        for (int i = 0; i < 101; i++)
            for (int j = 0; j < 101; j++) {
                nf[i][j] = f[i][j];
                // create?
                if ((i != 0) && (f[i - 1][j]) && (j != 0) && (f[i][j - 1])) {
                    nf[i][j] = true;
                }
                // remove&
                if (((i == 0) || ((i != 0) && !(f[i - 1][j]))) &&
                        ((j == 0) || ((j != 0) && !(f[i][j - 1])))) {
                    nf[i][j] = false;
                }
            }
        return nf;
    }

    @Override
    void runOneTest(Scanner input, PrintWriter output) {
        boolean[][] f = new boolean[101][101];

        int r = input.nextInt();

        for (int i = 0; i < r; i++) {
            int x1 = input.nextInt();
            int y1 = input.nextInt();
            int x2 = input.nextInt();
            int y2 = input.nextInt();

            for (int xx = x1; xx <= x2; xx++)
                for (int yy = y1; yy <= y2; yy++) {
                    f[xx][yy] = true;
                }
        }
        int ans = 0;
        while (!ok(f)) {
            f = nextField(f);
            ans++;
        }
        output.println(ans);
    }

    public static void main(String[] args) {
        (new C()).run();
    }
}