﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace km.gcj.gcj2013.qual
{
    class Program_A
    {
        /// <summary> プログラムのスタートポイント </summary>
        /// <param name="args"> 第一引数に入力ファイルを指定 </param>
        static void Main(string[] args)
        {
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            Logic(args);

            sw.Stop();
            Console.WriteLine(sw.Elapsed);
            Console.ReadLine();
        }

        private static void Logic(string[] args)
        {
            //throw new NotImplementedException();
            Problem p = Problem.createProblem(args);
            if (p == null) {
                return;
            }

            // 試行回数を取得し、ループする。
            long repeat = p.getNextLineAsInt64Array()[0];
            for (int i = 0; i < repeat; i++)
            {

                // MainLoop
//                long n = p.getNextInt64s().ToArray()[0];
                var board = p.getNextLinesChars(4).ToList();
                p.getNextLine();



                p.WriteAnswerFullLine(CheckResult(board));
            }
         }
        private static String CheckResult(List<List<char>> board){
            List<List<int>> cntRow = new List<List<int>>();
            List<List<int>> cntCol = new List<List<int>>();
            List<List<int>> cntDia = new List<List<int>>();
            int cntSpace = 0;
            cntRow.Add(new List<int> { 0, 0, 0 });
            cntRow.Add(new List<int> { 0, 0, 0 });
            cntRow.Add(new List<int> { 0, 0, 0 });
            cntRow.Add(new List<int> { 0, 0, 0 });
            cntCol.Add(new List<int> { 0, 0, 0 });
            cntCol.Add(new List<int> { 0, 0, 0 });
            cntCol.Add(new List<int> { 0, 0, 0 });
            cntCol.Add(new List<int> { 0, 0, 0 });
            cntDia.Add(new List<int> { 0, 0, 0 });
            cntDia.Add(new List<int> { 0, 0, 0 });
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (board[i][j] == 'T')
                    {
                        cntRow[i][0]++;
                        cntCol[j][0]++;
                        if (i - j == 0) cntDia[0][0]++;
                        if (i + j == 3) cntDia[1][0]++;
                    }
                    if (board[i][j] == 'X')
                    {
                        cntRow[i][1]++;
                        cntCol[j][1]++;
                        if (i - j == 0) cntDia[0][1]++;
                        if (i + j == 3) cntDia[1][1]++;
                    }
                    if (board[i][j] == 'O')
                    {
                        cntRow[i][2]++;
                        cntCol[j][2]++;
                        if (i - j == 0) cntDia[0][2]++;
                        if (i + j == 3) cntDia[1][2]++;
                    }
                    if (board[i][j] == '.') cntSpace++;
                }
            }
            foreach (var item in cntRow)
            {
                if (item[0] > 1) continue;
                if (item[0] + item[1] == 4) return "X won";
                if (item[0] + item[2] == 4) return "O won";
            }
            foreach (var item in cntCol)
            {
                if (item[0] > 1) continue;
                if (item[0] + item[1] == 4) return "X won";
                if (item[0] + item[2] == 4) return "O won";
            }
            foreach (var item in cntDia)
            {
                if (item[0] > 1) continue;
                if (item[0] + item[1] == 4) return "X won";
                if (item[0] + item[2] == 4) return "O won";
            }
            if (cntSpace > 0)
            {
                return "Game has not completed";
            }
            else
            {
                return "Draw";
            }
        }
    }
}
