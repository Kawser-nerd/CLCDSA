﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;

namespace km.gcj.qual
{
    class ProgramAS
    {

        static void Main(string[] args)
        {
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            Logic(args);

            sw.Stop();
            Console.WriteLine(sw.Elapsed);
            Console.ReadLine();
        }

        static void Logic(string[] args)
        {
            Problem p = Problem.createProblem(args);
            if (p == null || p.inputLinesCount == 0)
            {
                return;
            }

            long repeat = p.getNextLineAsInt64Array()[0];
            for (int i = 0; i < repeat; i++)
			{
                p.WriteAnswerFullLine(Replace(p.getNextLine()));
			}
        }

        static string Replace(string prmStr)
        {
            prmStr = prmStr.Replace("y", "A");
            prmStr = prmStr.Replace("n", "B");
            prmStr = prmStr.Replace("f", "C");
            prmStr = prmStr.Replace("i", "D");
            prmStr = prmStr.Replace("c", "E");
            prmStr = prmStr.Replace("w", "F");
            prmStr = prmStr.Replace("l", "G");
            prmStr = prmStr.Replace("b", "H");
            prmStr = prmStr.Replace("k", "I");
            prmStr = prmStr.Replace("u", "J");
            prmStr = prmStr.Replace("o", "K");
            prmStr = prmStr.Replace("m", "L");
            prmStr = prmStr.Replace("x", "M");
            prmStr = prmStr.Replace("s", "N");
            prmStr = prmStr.Replace("e", "O");
            prmStr = prmStr.Replace("v", "P");
            prmStr = prmStr.Replace("z", "Q");
            prmStr = prmStr.Replace("p", "R");
            prmStr = prmStr.Replace("d", "S");
            prmStr = prmStr.Replace("r", "T");
            prmStr = prmStr.Replace("j", "U");
            prmStr = prmStr.Replace("g", "V");
            prmStr = prmStr.Replace("t", "W");
            prmStr = prmStr.Replace("h", "X");
            prmStr = prmStr.Replace("a", "Y");
            prmStr = prmStr.Replace("q", "Z");
            return prmStr.ToLower();
        }
    }
}
