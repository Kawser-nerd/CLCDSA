import time, math, operator, re
from helper import *

t1 = starttimer()

filename = "C%s.%s"
# 0 for test, 1 for small, 2 for large
is_large = 2

mode_str = '' if is_large == 0 else '-small-attempt1' if is_large == 1 else '-large'
infile = filename % (mode_str, 'in')
outfile = filename % (mode_str, 'out')

# parse input
inf = open(infile, 'r')
outf = open(outfile, 'w')

def place(board, a, b, r, c):
    for i in range(a, a+r):
        for j in range(b, b+c):
            board[i][j] = '.'    

def get_board(board):
    return '\n'.join(map(lambda x: ''.join(x), board))

def fill(board, r, c, n, a, b, first):
    # fill in a zigzag pattern, so each row is at most c wide
    # and last row has at least 2, followed by empty rows
    # if returning True, fill in board starting from corner (a, b)
    # if first == True, then the first 2 rows have to be the same width
    if n == 0: return True
    if n > r*c: return False
    if n == 1 or c == 1: return False
    if r == 0 or c == 0: return False
    
    if not first:
        if n <= c:
            place(board, a, b, 1, n)
            return True
        if n == r*c and not first:
            place(board, a, b, r, c)
            return True

    min_width = (n + r-1) / r
    for width in range(c, min_width-1, -1):
        # can't have width=1 segments
        if width == 1: break
        if first:
            if n < 2*width: continue
            if fill(board, r-2, width, n-2*width, a+2, b, False):
                place(board, a, b, 2, width)
                return True
        else:
            if fill(board, r-1, width, n-width, a+1, b, False):
                place(board, a, b, 1, width)
                return True
    return False

def solve(R, C, n):
    board = [['*' for _ in range(C)] for _ in range(R)]
    valid = True

    if n == 1: pass
    elif R == 1: place(board, 0, 0, 1, n)            
    elif C == 1: place(board, 0, 0, n, 1)
    elif n <= 3: valid = False
    else:
        valid = fill(board, R, C, n, 0, 0, True)
        
    if valid:
        board[0][0] = 'c'
        output = get_board(board)
    else:
        output = "Impossible"
    return output

try:
    T = readI(inf)
    
    for case in range(1, T+1):
        R, C, M = readIA(inf)
        n = R*C - M
        
        output = solve(R, C, n)        
        outf.write("Case #%d:\n%s\n" % (case, output))
        #print "Case #%d:\n%s" % (case, output)  
       
    
finally:
    inf.close()
    outf.close()

endtimer(t1)
