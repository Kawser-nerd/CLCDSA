﻿namespace Generic.Containers.Pointers
{
    public interface IPointer<T>
    {
        T Value { get; set;}
    }
}
