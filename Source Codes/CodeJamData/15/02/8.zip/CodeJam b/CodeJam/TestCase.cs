/* www.codertom.com  -  copyright Tom Harrison 2015 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace CoderTom.CodeJam
{
    public class TestCase
    {
        public TestCase()
        {
        }

        public TestCase(StreamReader stream)
        {
            PlateCount = stream.ReadInt();
            Plates = stream.ReadIntArray();
        }

        public int[] Plates { get; set; }

        public int PlateCount { get; set; }

        public string Solve()
        {
            var aggregatePlates = Plates
                .GroupBy(x => x)
                .Select(g => new PancakeGroup {pancakes = g.Key, diners = g.Count()})
                .OrderByDescending(g => g.pancakes)
                .ToList();

            var minTimeTillSolved = aggregatePlates[0].pancakes;

            var bestMinTime = minTimeTillSolved;
            var targetPancakes = aggregatePlates[0].pancakes;
            while (targetPancakes > 1) 
            {
                targetPancakes--;
                var extraMoves = 0;

                foreach (var aggregatePlate in aggregatePlates)
                {
                    if (aggregatePlate.pancakes > targetPancakes)
                    {
                        var numberOfMovesForOnePlate = (int)Math.Ceiling(aggregatePlate.pancakes / (double)targetPancakes) - 1;
                        extraMoves += numberOfMovesForOnePlate*aggregatePlate.diners;
                    }
                    else
                    {
                        break;
                    }
                }

                minTimeTillSolved = targetPancakes + extraMoves;
                if (minTimeTillSolved < bestMinTime)
                    bestMinTime = minTimeTillSolved;

            } 

            return bestMinTime.ToString();
        }

    }

    public class PancakeGroup
    {
        public int pancakes { get; set; }
        public int diners { get; set; }
    }
}
