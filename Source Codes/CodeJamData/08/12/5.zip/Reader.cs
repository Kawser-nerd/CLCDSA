﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Milkshakes
{
    class Reader
    {
        public static Case[] Read(string[] lines)
        {
            int index = 0;
            int count = int.Parse(lines[index++]);
            Case[] cases = new Case[count];
            for(int i = 0; i < count; ++i)
            {
                Case cas = new Case();
                cas.count = int.Parse(lines[index++]);
                int cusCount = int.Parse(lines[index++]);
                for(int j = 0; j < cusCount; ++j)
                {
                    cas.Add(new Custom(lines[index++]));
                }
                cases[i] = cas;
            }
            return cases;
        }
    }
}
