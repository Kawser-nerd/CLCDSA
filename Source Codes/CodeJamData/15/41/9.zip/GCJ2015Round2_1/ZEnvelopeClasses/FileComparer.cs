﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace GCJ2015Round2_1
{
	public class FileComparer : IDisposable
	{
		#region Fields

		private string m_ResultFilePath;
		private StreamReader m_ResultReader;
		private string m_ComparisonFilePath;
		private StreamReader m_ComparisonReader;
		private TestCaseInfo m_Info;

		private bool m_IsResultMultline;

		#endregion

		#region C'tor

		public FileComparer(string resultFilePath, string comparisonFilePath, TestCaseInfo info)
		{
			this.m_ResultFilePath = resultFilePath;
			this.m_ComparisonFilePath = comparisonFilePath;
			this.m_Info = info;
			this.m_IsResultMultline = Solver.SKIP_LINE_AFTER_CASE_OUTPUT;

			this.m_ResultReader = new StreamReader(m_ResultFilePath);
			this.m_ComparisonReader = new StreamReader(m_ComparisonFilePath);
		}

		#endregion

		#region Methods

		public void PrintComparisonResults()
		{
			Dictionary<int, string> originalTestCaseResults = GetTestCaseResults(m_ResultReader);
			Dictionary<int, string> comparisonTestCaseResults = GetTestCaseResults(m_ComparisonReader);

			bool differencesFound = PrintResultDifferencesIfAny(originalTestCaseResults, comparisonTestCaseResults);

			Program.PrintOut("Comparison complete between {0} and {1}: {2}!",
							  Path.GetFileName(m_ResultFilePath),
							  Path.GetFileName(m_ComparisonFilePath),
							  differencesFound ? "NOT equal" : "files are equal");
		}

		private bool PrintResultDifferencesIfAny(Dictionary<int, string> originalTestCaseResults,
												 Dictionary<int, string> comparisonTestCaseResults)
		{
			if (originalTestCaseResults.Count != comparisonTestCaseResults.Count)
			{
				Program.PrintOut("Wrong number of test cases! Result has {0}, compared has {1}", originalTestCaseResults.Count, comparisonTestCaseResults.Count);
				return true;
			}

			if (!originalTestCaseResults.Keys.SequenceEqual(comparisonTestCaseResults.Keys))
			{
				Program.PrintOut("Wrong test case! Result and comparison have different test cases?!");
				return true;
			}
			int testCaseMax = originalTestCaseResults.Keys.Max();
			int testCaseMin = originalTestCaseResults.Keys.Min();

			if (testCaseMax - testCaseMin + 1 != originalTestCaseResults.Keys.Count)
			{
				Program.PrintOut("Wrong test case! Non-sequential test cases! Min: {0}, Max: {1}, Total: {2}", testCaseMin, testCaseMax, originalTestCaseResults.Keys.Count);
				return true;
			}

			bool differencesFound = false;
			for (int i = testCaseMax; i >= testCaseMin; i--)
			{
				if (!originalTestCaseResults[i].Equals(comparisonTestCaseResults[i]))
				{
					differencesFound = true;
					PrintCaseDifference(originalTestCaseResults[i], comparisonTestCaseResults[i], i);
				}
			}

			return differencesFound;
		}

		private Dictionary<int, string> GetTestCaseResults(StreamReader reader)
		{
			Dictionary<int, string> result = new Dictionary<int, string>();
			int currentTestCase = -1;
			string accumulatedResult = null;

			for (string line = reader.ReadLine(); line != null; line = reader.ReadLine())
			{
				if (line.StartsWith("Case #"))
				{
					if (accumulatedResult != null)
					{
						if(m_IsResultMultline)
							accumulatedResult = accumulatedResult.Substring(0, accumulatedResult.Length - Environment.NewLine.Length);
						result.Add(currentTestCase, accumulatedResult);
					}

					currentTestCase = int.Parse(line.Split('#')[1].Split(':')[0]);
					accumulatedResult = string.Empty;
				}

				if (m_IsResultMultline)
				{
					accumulatedResult += line + Environment.NewLine;
				}
				else
				{
					accumulatedResult = string.Join(":", line.Split(':').Skip(1)).Substring(1);
				}
			}

			if (accumulatedResult != null)
			{
                accumulatedResult = accumulatedResult.TrimEnd('\r', '\n');
				result.Add(currentTestCase, accumulatedResult);
			}

			return result;
		}

		private void PrintCaseDifference(string originalResult, string comparisonResult, int currentCase)
		{
			Program.PrintOut("Test case #{0} yielded different results for files!", currentCase);
			Program.PrintOut("Tese case input:\n{0}", m_Info[currentCase]);
			Program.PrintOut("Original result:\n{0}", originalResult);
			Program.PrintOut("Compared result:\n{0}", comparisonResult);
		}

		public void Dispose()
		{
			this.m_ResultReader.Dispose();
			this.m_ComparisonReader.Dispose();
		}

		#endregion
	}
}
