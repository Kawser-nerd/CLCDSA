import time, math, operator, re
from helper import *

t1 = starttimer()

filename = "B%s.%s"
# 0 for test, 1 for small, 2 for large
is_large = 1

mode_str = '' if is_large == 0 else '-small-attempt1' if is_large == 1 else '-large'
infile = filename % (mode_str, 'in')
outfile = filename % (mode_str, 'out')

# parse input
inf = open(infile, 'r')
outf = open(outfile, 'w')

try:
    T = readI(inf)
    
    for case in range(1, T+1):
        N = readI(inf)
        stars = [readIA(inf) for _ in range(N)]
        output = "Too Bad"
            
        # greedy - go for any level with 2 stars you can do
        # or level with biggest gap between 2 star and current pos
        cur_stars = 0
        levels = 0
        moved = True
        done = [0 for _ in range(N)]
        while moved:
            moved = False
            # choice, level, cost
            best = None
            for i in range(N):
                if done[i] < 2 and stars[i][1] <= cur_stars:
                    if case == 4:
                        print i, 2
                    # do it
                    cur_stars += 2 - done[i]
                    levels += 1
                    moved = True
                    done[i] = 2
                    
                elif done[i] == 0 and stars[i][0] <= cur_stars:
                    cost = stars[i][1] - stars[i][0]
                    if best == None or cost > best[2]:
                        best = (i, 1, stars[i][1] - stars[i][0])

            if moved: continue
            if best == None:
                break

            # perform best
            cur_stars += 1 - done[best[0]]
            levels += 1
            moved = True
            done[best[0]] = 1
            if case == 4:
                print best[0], 1

        if all(done[i] == 2 for i in range(N)):
            output = levels
            
        outf.write("Case #%d: %s\n" % (case, output))
        print "Case #%d: %s" % (case, output)
    
finally:
    inf.close()
    outf.close()

endtimer(t1)
