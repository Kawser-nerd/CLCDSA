package lib;

import java.util.stream.IntStream;

public class Range {
    public static IntStream of(int start, int end) {
        return IntStream.range(start, end);
    }
}
