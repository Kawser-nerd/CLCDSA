package jp.funnything.prototype;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import jp.funnything.competition.util.CompetitionIO;
import jp.funnything.competition.util.Packer;

import org.apache.commons.io.FileUtils;

import com.google.common.collect.Maps;

public class Runner {
    public static void main( final String[] args ) throws Exception {
        new Runner().run();
    }

    void pack() {
        try {
            final File dist = new File( "dist" );

            if ( dist.exists() ) {
                FileUtils.deleteQuietly( dist );
            }

            final File workspace = new File( dist , "workspace" );

            FileUtils.copyDirectory( new File( "src/main/java" ) , workspace );
            FileUtils.copyDirectory( new File( "../../../../CompetitionUtil/Lib/src/main/java" ) , workspace );

            Packer.pack( workspace , new File( dist , "sources.zip" ) );
        } catch ( final IOException e ) {
            throw new RuntimeException( e );
        }
    }

    Map< Character , Character > prepare() {
        final String from =
                "ejp mysljylc kd kxveddknmc re jsicpdrysi/rbcpc ypc rtcsra dkh wyfrepkym veddknkmkrkcd/de kr kd eoya kw aej tysr re ujdr lkgc jv";
        final String to =
                "our language is impossible to understand/there are twenty six factorial possibilities/so it is okay if you want to just give up";

        final Map< Character , Character > map = Maps.newTreeMap();

        map.put( 'q' , 'z' );
        map.put( 'z' , 'q' );

        for ( int index = 0 ; index < from.length() ; index++ ) {
            final char f = from.charAt( index );
            final char t = to.charAt( index );

            if ( f == t ) {
                continue;
            }

            if ( map.containsKey( f ) ) {
                if ( map.get( f ) != t ) {
                    throw new RuntimeException( "assert" );
                }
            } else {
                map.put( f , t );
            }
        }

        return map;
    }

    void run() throws Exception {
        final Map< Character , Character > map = prepare();

        final CompetitionIO io = new CompetitionIO();

        final int n = io.readInt();

        for ( int index = 0 ; index < n ; index++ ) {
            final String s = io.read();
            io.write( index + 1 , solve( map , s ) );
        }

        io.close();

        pack();
    }

    String solve( final Map< Character , Character > map , final String s ) {
        final StringBuilder buf = new StringBuilder();

        for ( final Character c : s.toCharArray() ) {
            if ( map.containsKey( c ) ) {
                buf.append( map.get( c ) );
            } else {
                buf.append( c );
            }
        }

        return buf.toString();
    }
}
