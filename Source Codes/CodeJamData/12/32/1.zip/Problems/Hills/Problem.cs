﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Generic.Common;

namespace Google_Code_Jam.Problems.Hills
{
    class Problem : DefaultObject
    {
        IList<BlockerMoment> blockerMoments;
        IList<double> accelerations;
        double distance;

        public Problem(IList<BlockerMoment> blockerMoments, IList<double> accelerations, double distance)
        {
            this.blockerMoments = blockerMoments;
            this.accelerations = accelerations;
            this.distance = distance;
        }

        public double Distance
        {
            get { return distance; }
        }

        public IList<BlockerMoment> BlockerMoments
        {
            get { return blockerMoments; }
        }

        public IList<double> Accelerations
        {
            get { return accelerations; }
        }
    }

    class BlockerMoment : DefaultObject
    {
        double position;
        double time;

        public BlockerMoment(double position, double time)
        {
            this.position = position;
            this.time = time;
        }

        public double Position
        {
            get { return position; }
        }

        public double Time
        {
            get { return time; }
        }
    }
}
