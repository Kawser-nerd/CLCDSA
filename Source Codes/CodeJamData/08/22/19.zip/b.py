""" Milkshakes

:Abstract: Solution to Google Code Jam 2008 round 1A
:Authors:  iki
:Contact:  jan.killian at (g)mail.com

Problem sample:

>>> test(
...   testlabel='sample via parse()',
...   testinput='''2
... 10 20 5
... 10 20 3
... ''')
Case #1: 9
Case #2: 7

>>> test([[10**11, 10**11+10**6, 10**11+10**6]],
...   testlabel='large',
...   testresult=[10**6+1]
... )

>>> test([[10**11, 10**11+10**6, 10**10]],
...   testlabel='large',
...   testresult=0
... )
"""
__docformat__ = 'restructuredtext en'

from codejam import *
from collections import deque

def solve(a, b, p):
    if log.debug: log.debug('<a, b> = <%d, %d>, p = %d' % (a,b,p))
    if p >= b:
        return b - a + 1

    smap = {}
    i = a
    while i <= b:
        smap[i] = set((i,))
        i += 1

    for f in primes():
        if f < p:
            continue
        if f >= b:
            break
        if log.debug: log.debug(f)
        i = a / f * f
        if i < a: i += f
        s = set()
        while i <= b:
            s.update(smap[i])
            for o in smap[i]:
                smap[o] = s
            i += f

    return len(set(map(frozenset, smap.values())))

def parse(fi):
    nl = fi.next
    a,b,p = map(int, nl().strip().split())
    assert 1 <= a <= b
    assert p <= b
    return a, b, p

def primes():
    """ Sieve of Eratosthenes, yield each prime in sequence
    """
    yield 2
    D = {}
    q = 3
    while True:
        p = D.pop(q, 0)
        if p:
            x = q + p
            while x in D: x += p
            D[x] = p
        else:
            yield q
            D[q*q] = 2*q
        q += 2

main(solve, parse)
