﻿using System.IO;
using Generic.Maths.Vectors;

namespace Generic.InputOutput.Printing.Sized
{
    internal class WhiteSpace : SizedDocument
    {
        private readonly IntVector2 size;

        public WhiteSpace(int width, int height) : this(new IntVector2(width,height))
        {
        }

        public WhiteSpace(IntVector2 size)
        {
            this.size = size;
        }

        public override IntVector2 Size
        {
            get { return size; }
        }

        public override void RenderLine(TextWriter builder, int line)
        {
            builder.Write(new string(' ',size.X));
        }
    }
}