package lib;

public class PairHashMapFactory {
    public static <T1, T2> MapFactory<Pair<T1, T2>> of(HashMapMaterial<T1> m1, HashMapMaterial<T2> m2) {
        return CustomHashMapFactory.create(PairHashMapMaterial.of(m1, m2));
    }
}
