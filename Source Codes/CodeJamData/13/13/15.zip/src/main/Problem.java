package main;


public abstract class Problem {
	protected IOManager io;
	private final int cases;
	private String[] result;
	
	public Problem(IOManager io){
		this.io = io;
		cases = Integer.valueOf(io.readLine());
		result = new String[cases];
	}
	
	public void solve(){
		for(int i = 0; i< cases; ++i){
			result[i] = solveCase();
			io.write("Case #"+(i+1)+": "+result[i]);
			System.out.println("Case #"+(i+1)+": "+result[i]);
		}
		io.close();
	}
	
	protected abstract String solveCase();
}
