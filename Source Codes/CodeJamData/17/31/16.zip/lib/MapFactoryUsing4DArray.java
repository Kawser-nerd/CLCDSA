package lib;

import java.util.function.ToIntFunction;

public class MapFactoryUsing4DArray {

    public static <K> MapFactory<K> of(
            final int size1, final int size2, final int size3, final int size4,
            final ToIntFunction<K> index1Getter, final ToIntFunction<K> index2Getter, final ToIntFunction<K> index3Getter, final ToIntFunction<K> index4Getter) {
        return MapFactoryUsing3DArray.of(size1, size2, size3 * size4, index1Getter, index2Getter, value -> {
            int i3 = index3Getter.applyAsInt(value);
            int i4 = index4Getter.applyAsInt(value);
            return i3 * size4 + i4;
        });
    }

}
