using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Cmn.Util;
using System.Linq;

namespace Gcj.Util
{
    public interface IConcurrentSolver
    {
        int CCaseGet(Pparser pparser);
        ConcurrentGcjSolver.DgSolveCase DgSolveCase(Pparser pparser);
    }
    
    public sealed class ConcurrentGcjSolver
    {
        public delegate IEnumerable<object> DgSolveCase();
        
        public static void Solve<T>(bool fParallel) where T : IConcurrentSolver, new()
        {
            Lg.dgIlgFromTy = tyT => new LgConsole(tyT);

            var ty = typeof(T);

            Console.Title = string.Format("Running {0}",ty.Name);

            Console.WriteLine("Running: {0}", ty.Name);
            foreach(var fpat in Directory.EnumerateFiles(ty.Namespace.Substring(5).Replace('.','/'), "*.in").Reverse())
            {
                var solver = new ConcurrentGcjSolver();
                var fmtfpat = fpat.Substring(0, fpat.Length - 3);
                solver.FpatIn = string.Format("{0}.in", fmtfpat);
                solver.FpatOut = string.Format("{0}.out", fmtfpat);
                solver.FpatRefout = string.Format("{0}.refout", fmtfpat);

                solver.InitAndSolve(new T(), fParallel);

            }
            Console.WriteLine("Finished");
            Console.ReadLine();
        }

        public string FpatIn;
        public string FpatOut;
        public string FpatRefout;

        public void InitAndSolve(IConcurrentSolver solver, bool fParallel)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FpatOut));
            var pparser = new Pparser(FpatIn);
            var cCase = solver.CCaseGet(pparser);

            var rgresult = new object[cCase][];

            var rgdgSolve = new Action[cCase];
            for (var iCase = 0; iCase < cCase; iCase++)
            {
                var iCaseT = iCase;
                var dgSolveCase = solver.DgSolveCase(pparser);
                rgdgSolve[iCaseT] = () => rgresult[iCaseT] = dgSolveCase().ToArray();
            }

            if(fParallel)
                Parallel.Invoke(rgdgSolve);
            else
                foreach (var dgSolve in rgdgSolve)
                    dgSolve();

            using (var solwrt = new Solwrt(FpatOut, FpatRefout))
            {
                for (var iCase = 0; iCase < cCase; iCase++)
                     solwrt.WriteLine(new object[] { string.Format("Case #{0}:", (iCase+1)) }.Concat(rgresult[iCase]));
            }
        }
    }
}