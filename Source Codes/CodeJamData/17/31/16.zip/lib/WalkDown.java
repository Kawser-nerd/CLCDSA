package lib;

public interface WalkDown {
    void on(int from, int to);
}
