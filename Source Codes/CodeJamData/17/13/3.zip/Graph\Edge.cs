﻿using System;

namespace Q3
{
	public class Edge<T>
		where T : IComparable<T>
	{
		public Node<T> Source { get; private set; }
		public Node<T> Target { get; private set; }

		public Edge(Node<T> source, Node<T> target)
		{
			this.Source = source;
			this.Target = target;
		}
	}
}
