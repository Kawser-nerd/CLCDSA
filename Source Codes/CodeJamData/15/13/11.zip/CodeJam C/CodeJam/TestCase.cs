/* www.codertom.com  -  copyright Tom Harrison 2015 */

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography.X509Certificates;

namespace CoderTom.CodeJam
{
    public class TestCase
    {
        public TestCase()
        {
        }

        public TestCase(StreamReader stream)
        {
            Count = stream.ReadInt();
            Trees = new List<long[]>();
            for (int i = 0; i < Count; i++)
            {
                Trees.Add(stream.ReadLongArray());
            }
        }

        public List<long[]> Trees { get; set; }

        public int Count { get; set; }

        public string Solve()
        {
            if (Count == 1)
            {
                return "0";
            }
            var output = new long[Count];
            for (int i = 0; i < Count; i++)
            {
                output[i] = long.MaxValue;
            }
            
            for (int i = 0; i < Count - 1; i++)
            {
                for (int j = i + 1; j < Count; j++)
                {
                    var start = Trees[i];
                    var end = Trees[j];
                    var direction = new long[] {end[0] - start[0], end[1] - start[1]};

                    var greater = 0;
                    var lesser = 0;

                    for (int k = 0; k < Count; k++)
                    {
                        if (k == i || k == j)
                            continue;
                        var candidate = Trees[k];
                        var other = new long[] { candidate[0] - start[0], candidate[1] - start[1] };

                        var scalar = direction[0] * other[1] - direction[1] * other[0];
                        if (scalar > 0)
                        {
                            greater++;
                        }
                        if (scalar < 0)
                        {
                            lesser++;
                        }
                    }

                    if (greater < output[i])
                    {
                        output[i] = greater;
                    }

                    if (lesser < output[i])
                    {
                        output[i] = lesser;
                    }

                    if (greater < output[j])
                    {
                        output[j] = greater;
                    }

                    if (lesser < output[j])
                    {
                        output[j] = lesser;
                    }
                }
            }


            return String.Join(Environment.NewLine, output);
        }
    }
}