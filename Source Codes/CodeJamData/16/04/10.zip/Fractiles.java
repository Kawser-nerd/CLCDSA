import java.io.PrintStream;
import java.math.BigInteger;
import java.util.Scanner;
import java.util.function.Supplier;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import java.util.stream.Stream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;


public class Fractiles {
    static void run() {
        int k = rdInt();
        int c = rdInt();
        int s = rdInt();
        long[] vs = solve(k, c);
        assert vs.length > 0;
        if (vs.length > s) {
            wrVal("IMPOSSIBLE");
        } else {
            for (long v : vs) {
                assert v >= 1;
                assert BigInteger.valueOf(k).pow(c).compareTo(BigInteger.valueOf(v)) >= 0;
                wrVal(v);
            }
        }
    }

    private static long[] solve(int k, int c) {
        List<Long> list = new ArrayList<>();
        int p = 0;
        while (p < k) {
            long v = 0;
            for (int i = 1; i <= c && p < k; ++i, ++p) {
                long oldv = v;
                v = v * k + p;
                assert (v - p) / k == oldv;
            }
            list.add(v + 1);
        }
        return list.stream().mapToLong(v -> v).toArray();
    }

    public static void main(String[] args) {
        int n = rdInt();
        for (int i = 0; i < n; ++i) {
            output.print("Case #" + (i + 1) + ":");
            outputSep = " ";
            run();
            output.print("\n");
        }
        output.flush();
    }

    static Scanner input = new Scanner(System.in);
    static int rdInt() { return rdT(() -> input.nextInt()); }
    static long rdLong() { return rdT(() -> input.nextLong()); }
    static double rdDbl() { return rdT(() -> input.nextDouble()); }
    static BigInteger rdBigInt() { return rdT(() -> input.nextBigInteger()); }
    static String rdStr() { return rdT(() -> input.next()); }
    static String rdLine() { return input.nextLine(); }
    static String[] rdStrs(int n) { return Stream.generate(() -> rdStr()).limit(n).toArray(x -> new String[x]); }
    static int[] rdInts(int n) { return IntStream.generate(() -> rdInt()).limit(n).toArray(); }
    static long[] rdLongs(int n) { return LongStream.generate(() -> rdLong()).limit(n).toArray(); }
    static double[] rdDbls(int n) { return DoubleStream.generate(() -> rdDbl()).limit(n).toArray(); }
    private static <T> T rdT(Supplier<T> supplier) { T t = supplier.get(); input.skip(" |\n|\r\n"); return t; }

    static PrintStream output = new PrintStream(System.out, true);
    static String outputSep = " ";
    static void wrVal(String v) { wrT(v); }
    static void wrVal(int v) { wrT(v); }
    static void wrVal(long v) { wrT(v); }
    static void wrVal(BigInteger v) { wrT(v); }
    static void wrVal(double v) { wrVal(v, 10); }
    static void wrVal(double v, int fracdigs) { wrT(String.format("%." + fracdigs + "f", v)); }
    static void wrVals(int[] vs) { for (int v : vs) wrVal(v); }
    static void wrVals(long[] vs) { for (long v : vs) wrVal(v); }
    static void wrVals(double[] vs) { for (double v : vs) wrVal(v); }
    static void wrVals(double[] vs, int fracdigs) { for (double v : vs) wrVal(v, fracdigs); }
    static void wrVals(String[] vs) { for (String v : vs) wrVal(v); }
    static void wrLn() { output.print("\n"); outputSep = ""; }
    private static void wrT(Object v) { output.print(outputSep); output.print(v); outputSep = " "; }
}
