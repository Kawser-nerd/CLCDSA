package lib;

public class NormalIntPairHashMapMaterial {
    public static final HashMapMaterial<IntPair> INSTANCE = new HashMapMaterial<>(p -> TwoIntHash.hash(p.v1, p.v2), (p1, p2) -> p1.v1 == p2.v1 && p1.v2 == p2.v2);
}
